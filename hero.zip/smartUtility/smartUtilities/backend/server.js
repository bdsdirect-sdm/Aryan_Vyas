// Import required modules
const express = require('express');
const path = require('path');
const morgan = require('morgan');
const mysql = require('mysql');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const session = require('express-session');
const myConnection = require('express-myconnection');
const cors = require('cors');
const formidable = require('formidable');
const https = require('https');
const fs = require('fs');

// Initialize Express app
const app = express();
app.use(cors());

// Import routes
const adminRoutes = require('./src/routes/manageAdmins');
const managemastermodules = require('./src/routes/managemastermodules');
const shared = require('./src/routes/shared');
const customer = require('./src/routes/customer');
const incident = require('./src/routes/incident');
const payment = require('./src/routes/payment');
const utilityServiceRequest = require('./src/routes/utilityServiceRequest');
const superAdmin = require('./src/routes/superadmin');
const notification = require('./src/routes/notification');
const db = require('./config/dbConfig.js');

// Express settings
app.set('port', process.env.PORT || 6002);
app.set('views', path.join(__dirname, 'views'));
app.set('view engine', 'ejs');

// Middleware for parsing requests
app.use(bodyParser.json({ limit: '50mb' }));
app.use(bodyParser.json()); // Support JSON-encoded bodies
app.use(bodyParser.urlencoded({ extended: true })); // Support URL-encoded bodies

// Session setup
app.use(session({
  secret: 'smartUtilities',
  resave: true,
  saveUninitialized: true
}));

// Import validation tools
const { validate, ValidationError, Joi } = require('express-validation');

// Logging middleware
app.use(morgan('dev'));

// Database connection middleware
app.use(myConnection(mysql, {
  host: db.host,
  user: db.user,
  password: db.password,
  database: db.database
}, 'single'));

app.use(express.urlencoded({ extended: false }));

// Test database connection
const testConnection = mysql.createConnection({
  host: db.host,
  user: db.user,
  password: db.password,
  database: db.database
});

testConnection.connect((err) => {
  if (err) {
    console.error('❌ Database connection failed:', err.message);
  } else {
    console.log('✅ Successfully connected to the database!');
  }
  testConnection.end(); // Close the connection after testing
});

// Register routes
app.use('/admin', adminRoutes);
app.use('/shared', shared);
app.use('/api', managemastermodules);
app.use('/customer', customer);
app.use('/incident', incident);
app.use('/payment', payment);
app.use('/utilityServiceRequest', utilityServiceRequest);
app.use('/superAdmin', superAdmin);
app.use('/notification', notification);

// CORS Headers Middleware
app.use((req, res, next) => {
  res.header('Access-Control-Allow-Origin', req.header.origin);
  res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, PATCH, OPTIONS');
  res.header('Access-Control-Allow-Headers',
    'Origin, X-Requested-With, Content-Type, Accept, OPTIONS, access-control-allow-origin, access-control-allow-headers, access-control-allow-methods'
  );
  res.header('Access-Control-Allow-Credentials', true);
  next();
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.log('Error detected:', err);
  if (err instanceof ValidationError) {
    return res.status(err.statusCode).json(err);
  }
  return res.status(500).json(err);
});

// Serve static files
app.use(express.static(path.join(__dirname, 'dist')));
app.use(express.static(path.join(__dirname, 'public')));

// Catch-all route to serve frontend
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../backend/dist/index.html'));
});

// Uncomment the below lines if using HTTPS
// const options = {
//   key: fs.readFileSync('/home/jenkins/workspace/54_smartUtilities/SSL/server.key', 'utf8'),
//   cert: fs.readFileSync('/home/jenkins/workspace/54_smartUtilities/SSL/server.crt', 'utf8')
// };
// const appServer = https.createServer(options, app);
// appServer.listen(app.get('port'));

// Start the server
app.listen(app.get('port'), () => {
  console.log(`🚀 Server running on port ${app.get('port')}`);
});
