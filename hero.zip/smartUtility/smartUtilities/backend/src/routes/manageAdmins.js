const router = require('express').Router();
const adminsController = require('../controllers/manageAdminsController');
const { validate, ValidationError, Joi } = require('express-validation')
const express = require('express')
const app = express();
var jwt = require('../services/jwt');

router.get('/list', jwt.verifyToken ,  adminsController.list);
/**
 * Author : Sanjeev Kumar
 * Description : Used to addd admins
 * Parameter : first_name , last_name ,  email , password , provider_id
 */
const addAdminValidation = {
    body: Joi.object({
        first_name: Joi.string()
            .label('First Name')
            .required(),
        last_name: Joi.string()
            .required()
            .label('Last Name'),
        email: Joi.string()
            .label('Email')
            .email()
            .required(),
        password: Joi.string()
            .required().
            label('Password'),
    }).unknown(true),
}
router.post('/add', jwt.verifyToken, validate(addAdminValidation, {}, {}), adminsController.save);
/**
 * Auth : Sanjeev Kumar
 * Description : Used to edit admins
 * Para : first_name , last_name ,  email , password , provider_id
 */
router.get('/edit/:id' , adminsController.edit);
/**
 * Auth : Sanjeev Kumar
 * Description : Used to addd admins
 * Para : first_name , last_name ,  email , password , provider_id
 */
const UpdateAdminValidation = {
    body: Joi.object({
        first_name: Joi.string()
            .label('First Name')
            .required(),
        last_name: Joi.string()
            .required()
            .label('Last Name'),
        email: Joi.string()
            .label('Email')
            .email()
            .required(),
        provider_id: Joi.string()
            .label('provider id')
            .required()
    }).unknown(true),
}
router.post('/update/:id', jwt.verifyToken ,adminsController.update);
router.delete('/delete/:id', jwt.verifyToken, adminsController.delete);
router.delete('/soft_delete/:id', jwt.verifyToken , adminsController.soft_delete);
router.post('/activeInactive/:id', jwt.verifyToken ,adminsController.activeInactive);
router.post('/multi_activeInactive',jwt.verifyToken , adminsController.multi_activeInactive);
router.get('/getModules',jwt.verifyToken , adminsController.getModules);
router.get('/getModulesSubAdmin',jwt.verifyToken , adminsController.getModulesSubAdmin);
router.get('/getSubAdminPermession/:id',jwt.verifyToken , adminsController.getSubAdminPermession);
router.get('/getrequestServiceProviders',jwt.verifyToken , adminsController.getrequestServiceProviders);

module.exports = router;

