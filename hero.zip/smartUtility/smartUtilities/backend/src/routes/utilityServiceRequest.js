const router = require('express').Router();
const utilityServiceRequestController = require('../controllers/utilityServiceRequestController');
const { validate, ValidationError, Joi } = require('express-validation')
var jwt = require('../services/jwt');

const utilityServiceRequestValidation = {
    body: Joi.object({
        service_type_id: Joi.string()
            .label('service id')
            .required(),
            
    }).unknown(true),
}
router.post('/add', jwt.verifyToken, utilityServiceRequestController.save)
router.post('/markJobDone', jwt.verifyToken, utilityServiceRequestController.markJobDone)
router.post('/list', jwt.verifyToken, utilityServiceRequestController.list);
router.get('/listServiceStatus', jwt.verifyToken, utilityServiceRequestController.listServiceStatus);
router.get('/edit/:id', utilityServiceRequestController.edit);
router.get('/getServiceRequestHistory/:id', utilityServiceRequestController.getServiceRequestHistory);
router.post('/update/:id', jwt.verifyToken, utilityServiceRequestController.update);
router.post('/activeInactiveDelete',jwt.verifyToken,  utilityServiceRequestController.multi_activeInactive);
router.get('/getUtilityServiceTypes',  jwt.verifyToken,utilityServiceRequestController.getUtilityServiceTypes);
router.post('/getserviceProviders',jwt.verifyToken, utilityServiceRequestController.getserviceProviders);
router.post('/getAllServiceGroup', jwt.verifyToken, utilityServiceRequestController.getAllServiceGroup);
router.post('/updateRequestStatus', jwt.verifyToken, utilityServiceRequestController.updateRequestStatus);

module.exports = router;
