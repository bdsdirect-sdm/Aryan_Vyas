const router = require('express').Router();
const sharedController = require('../controllers/sharedController');
const { validate, ValidationError, Joi } = require('express-validation')
const multer = require('multer');
const stripePaymentController = require('../controllers/stripePaymentController')

var fileMiddleware = require("../policies/multer");
/******multer file upload  storage ***/
var storage = multer.diskStorage({
    destination: function(req, file, cb) {
        cb(null, './public/uploads/profilePic');
     },
    filename: function (req, file, cb) {
        cb(null , Date.now()+file.originalname);
    }
});
var upload = multer({ storage: storage })
/**file upload multer end */

const loginValidation = {
    body: Joi.object({
        email: Joi.string()
            .label('Email')
            .email()
            .required(),
        password: Joi.string()
            .required().
            label('Password'),
    }).unknown(true),
}
router.post('/login',validate(loginValidation, {}, {}), sharedController.login);
router.post('/superAdminLogin',validate(loginValidation, {}, {}), sharedController.superadminlogin);
router.post('/utilityAdminslogin', validate(loginValidation, {}, {}), sharedController.utilityAdminslogin);
router.post('/customerlogin', validate(loginValidation, {}, {}), sharedController.customerlogin);
router.post('/upload',upload.single('file'), sharedController.upload);

router.post('/uploadFile',[fileMiddleware.cpUpload], sharedController.uploadFile);
router.post('/customer_signup', sharedController.customer_signup);

router.post('/notificationStatus', sharedController.notificationStatus);
//stripe payment routes
router.post('/paywithStripe', stripePaymentController.payWithStripe)
router.post('/createStripeCustomer', stripePaymentController.createStripeCustomer)
module.exports = router;
