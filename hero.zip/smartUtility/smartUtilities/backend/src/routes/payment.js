const router = require('express').Router();
const paymentController = require('../controllers/paymentController');
const multer = require('multer');
var jwt = require('../services/jwt');





router.post('/payNow',jwt.verifyToken, paymentController.payNow);
router.post('/list', jwt.verifyToken, paymentController.list);

module.exports = router;
