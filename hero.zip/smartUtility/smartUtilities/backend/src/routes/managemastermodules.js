const router = require('express').Router();
const serviceTypesController = require('../controllers/serviceTypesController');
const serviceProvidersController = require('../controllers/serviceProvidersController');
const incidentController = require('../controllers/incidentController');
const sharedController = require('../controllers/sharedController');
const utilityServiceRequestController = require('../controllers/utilityServiceRequestController');

var jwt = require('../services/jwt');


router.post('/utility/login', sharedController.login);
router.get('/utility/getserviceType', jwt.verifyToken ,serviceTypesController.getserviceType);
router.post('/utility/addserviceType',jwt.verifyToken, serviceTypesController.addserviceType);
router.get('/utility/getserviceTypeDetails',jwt.verifyToken ,  jwt.verifyToken , serviceTypesController.getserviceTypeDetails);
router.post('/utility/updateserviceType',jwt.verifyToken , serviceTypesController.updateserviceType);
router.post('/utility/findserviceType/',jwt.verifyToken , serviceTypesController.findserviceType);
router.post('/utility/deleteServiceType',jwt.verifyToken , serviceTypesController.deleteServiceType);
router.post('/utility/multiUpdate',jwt.verifyToken , serviceTypesController.multiUpdate);


router.get('/utility/getserviceProviders',jwt.verifyToken, serviceProvidersController.getserviceProvider);
router.post('/utility/addserviceProvider',jwt.verifyToken,   serviceProvidersController.addserviceProvider);
router.get('/utility/getserviceProviderDetails',jwt.verifyToken , serviceProvidersController.getserviceProviderDetails);
router.post('/utility/updateserviceProvider',jwt.verifyToken ,serviceProvidersController.updateserviceProvider);
router.post('/utility/findserviceProviders/',jwt.verifyToken , serviceProvidersController.findserviceProvider);
router.post('/utility/deleteServiceProvider',jwt.verifyToken , serviceProvidersController.deleteServiceProvider);
router.post('/utility/multiUpdateserviceProviders', serviceProvidersController.multiUpdateserviceProviders);
router.get('/utility/incidentList',jwt.verifyToken , incidentController.incidentList);
router.post('/utility/deleteIncident',jwt.verifyToken , incidentController.deleteIncident);
router.post('/utility/searchIncident',jwt.verifyToken , incidentController.searchIncident);
router.post('/utility/incidentStatus',jwt.verifyToken , incidentController.incidentStatus);
router.post('/utility/incidentMarkResolved',jwt.verifyToken , incidentController.incidentMarkResolved);

router.post('/utilityServiceProvider/calendarInDates',jwt.verifyToken, utilityServiceRequestController.calendarInDates);
router.get('/utility/ratingList',jwt.verifyToken , incidentController.ratingList);
router.post('/utility/searchRating',jwt.verifyToken , incidentController.searchRating);
router.get('/utility/getProviderDetails',serviceProvidersController.getProviderDetails);

module.exports = router;
