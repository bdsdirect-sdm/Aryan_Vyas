const router = require('express').Router();
const superAdminController = require('../controllers/superAdminController');
const utilityController = require('../controllers/utilityController')
const subscriptionsController = require('../controllers/subscriptionsController')
var jwt = require('../services/jwt');
var fileMiddleware = require("../policies/multer");

router.post('/utilityProviderSave', [fileMiddleware.cpUploadArray], superAdminController.utilityProviderSave)
router.get('/utilityProvidersList', superAdminController.utilityList);
router.post('/utilityProvider/multi_activeInactiveUtitlity', superAdminController.multi_activeInactiveUtitlity);
router.get('/utilityProviderEdit/:id', superAdminController.utilityProviderEdit);
router.post('/utilityProviderUpdate', [fileMiddleware.cpUploadArray], superAdminController.utilityProviderUpdate);
/*utilitre routes */
router.post('/utility/save', utilityController.save);
router.get('/utility/list', utilityController.list);
router.post('/utility/multi_activeInactive', utilityController.multi_activeInactive);
router.get('/utility/edit/:id', utilityController.edit);
router.post('/utility/update/', utilityController.update);
/***settings routes */
// router.post('/utility/save',utilityController.save)
// router.get('/utility/list', utilityController.list);
// router.post('/utility/multi_activeInactive', utilityController.multi_activeInactive);


router.get('/utility/providerCategories', jwt.verifyToken, utilityController.providerCategories);
router.get('/getCategories', jwt.verifyToken, utilityController.getCategories);
router.get('/getSubCategories/:id', utilityController.getSubCategories);
router.post('/getOptions', jwt.verifyToken, utilityController.getOptions);
router.get('/getAllCategories', utilityController.getAllCategories);


router.get('/settings/edit', utilityController.settingsedit);
router.post('/settings/update', [fileMiddleware.cpUpload], utilityController.settingsupdate);
/*subscriptions routes */
/*utilitre routes */
router.post('/subscriptions/save', subscriptionsController.save)
router.get('/subscriptions/list', subscriptionsController.list);
router.post('/subscriptions/multi_activeInactive', subscriptionsController.multi_activeInactive);
router.get('/subscriptions/edit/:id', subscriptionsController.edit);
router.post('/subscriptions/update/', subscriptionsController.update);
module.exports = router;
