const router = require('express').Router();
const notificationController = require('../controllers/notificationController')
var jwt = require('../services/jwt');

router.get('/list', jwt.verifyToken ,notificationController.list);
router.get('/Utilitylist', jwt.verifyToken ,notificationController.Utilitylist);
module.exports = router;
