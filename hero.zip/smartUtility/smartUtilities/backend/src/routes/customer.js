const router = require('express').Router();
const customerController = require('../controllers/customerController');
const { validate, ValidationError, Joi } = require('express-validation')
const multer = require('multer');
var jwt = require('../services/jwt');
/******multer file upload  storage ***/
var storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, './uploads/profilePic');
    },
    filename: function (req, file, cb) {
        cb(null, Date.now() + file.originalname);
    }
});

var upload = multer({
    storage: storage,
    fileFilter: (req, file, cb) => {
        if (file.mimetype == "image/png" || file.mimetype == "image/jpg" || file.mimetype == "image/jpeg") {
            cb(null, true);
        } else {
            cb(null, false);

            return cb(new Error('Only .png, .jpg and .jpeg format allowed!'));
        }
    }
})
/**file upload multer end */
const add = {
    body: Joi.object({
        email: Joi.string()
            .label('Email')
            .email()
            .required(),
        password: Joi.string()
            .required().
            label('Password'),
    }).unknown(true),
}
//router.post('/add',upload.single('profile_pic'), validate(add, {}, {}), customerController.save);

router.post('/add', jwt.verifyToken, customerController.save);
router.get('/list', jwt.verifyToken, customerController.list);
router.get('/edit/:id', jwt.verifyToken, customerController.edit);
router.post('/update/:id', jwt.verifyToken, customerController.update);
router.post('/activeInactiveDelete', jwt.verifyToken, customerController.multi_activeInactive);
//api to get all customer requests
router.post('/getCustomerRequests', jwt.verifyToken, customerController.getCustomerRequests);
router.post('/requestService', jwt.verifyToken, customerController.requestService);
router.get('/getrequestService', jwt.verifyToken, customerController.getrequestService);
router.post('/getutilityProviders', customerController.getutilityProviders);
router.post('/getutilityProvidersDropDown', customerController.getutilityProvidersDropDown);
router.get('/getUtilityServiceSubTypes/:id', customerController.getUtilityServiceSubTypes);
router.get('/getRequestDetails/:id', customerController.getServiceRequestDetails);
router.post('/cancelServiceRequest', jwt.verifyToken, customerController.cancelServiceRequest);

module.exports = router;
