const router = require('express').Router();
const incidentController = require('../controllers/incidentController');
const { validate, ValidationError, Joi } = require('express-validation')
const multer = require('multer');
var jwt = require('../services/jwt');

router.post('/saveIncident',jwt.verifyToken , incidentController.saveIncident);
router.get('/incidentDetail/:id',jwt.verifyToken , incidentController.incidentDetail);
router.post('/saveFeedback',jwt.verifyToken , incidentController.saveFeedback);
module.exports = router;
