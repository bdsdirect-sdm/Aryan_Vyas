const controller = {};
const managetServiceRequest = require('../services/stripePaymentService')
 
controller.payWithStripe = (req, res) => {
    console.log('req---->',req.body)
    managetServiceRequest.pay(req,res)
    res.status(200).send('data')
};

controller.createStripeCustomer = (req, res) => {
    console.log('req---->',req.body)
    managetServiceRequest.createStripeCustomer(req,res)
    //res.status(200).send('cus')
};
module.exports = controller;
