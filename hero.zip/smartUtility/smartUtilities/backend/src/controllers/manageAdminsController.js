const controller = {};
const manageAdminService = require('../services/manageAdminService')
var md5 = require('md5');
controller.list = (req, res) => {
       
    const login_user_id = req.headers.decoded.user_id;
     let utility_id=1;
     let utility_provider_id = req.headers.decoded.user_id;
     console.log("utility_provider_id===>",utility_provider_id)
    req.getConnection((err, conn) => {
        if (err) {
            res.status(400).send({ "error": err})
            return false
        }
        //conn.query("SELECT * FROM utilityAdmins where is_deleted='false' OR first_name LIKE ? AND last_name LIKE ? AND email like ?",['%'+req.query.first_name+'%','%'+req.query.last_name+'%','%'+req.query.email+'%'], (err, admins) 
        conn.query(`SELECT * FROM utilitySubAdmins where (first_name LIKE ? or last_name LIKE ? or  email LIKE ? ) and is_deleted = ? and utility_provider_id=?  ORDER BY id DESC`, ['%'+req.query.keyword+'%','%'+req.query.keyword+'%','%'+req.query.keyword+'%','false',utility_provider_id], (err, admins)=>{
            if (err) {
                res.status(400).send({ "error": err})
                return false
            }
            res.status(200).send(admins)
        });
    });
};
controller.save = async (req, res) => {
    
    var provider_id_with_admin_id
    try {
         provider_id_with_admin_id = await manageAdminService.get_provider_of_admin(req)
    } catch (error) { 
       res.status(400).send(error)
       return false
    }
    
    const data = req.body;
    var module_id = req.body.module_id
    const login_user_id = req.headers.decoded.user_id
    console.log('login user id', login_user_id);
    delete(data.module_id)
    data['utility_provider_id'] = provider_id_with_admin_id
    data['password'] = md5(req.body.password)
    req.getConnection((err, connection) => {
        if (err) {
            res.status(400).send({ "error": err})
            return false
        }
         connection.query('select * from utilitySubAdmins where utility_provider_id=? and email = ?',[data.utility_provider_id,data.email], (err, Newadmin) => {
            if (err) {
                res.status(400).send({ "error": err})
                return false
            }
            //checking is email already exists....
           if(Newadmin.length == 0){
                req.getConnection((err, connection) => {
                     data['created_at'] = new Date;
                     connection.query('INSERT INTO utilitySubAdmins set ?', data, (err, Newadmin) => {
                        if (err) {
                            res.status(400).send({ "error": err})
                            return false
                        }
                        
                       
                        module_id = module_id.map(Number);
                        
                        if(module_id.length > 0){
                            /**saving the permessins for admin.. */
                            connection.query('SELECT id FROM modules where parent_module_id IN (?) ', [module_id], (err, childModules) => {
                                if (err) {
                                    res.status(400).send({ "error": err})
                                    return false
                                }
                               //let module_id_childModules =[...module_id,...childModules]
                                console.log("module_id_childModules---->",childModules);
                                    childModules.map((obj)=>{
                                        module_id.push(obj.id)
                                    })
                                    console.log("--->module_id-->",module_id)
                            module_id.map(m_id => {
                                let permession_data = { 
                                                        module_id: m_id,
                                                        utility_id : 1,
                                                        utility_sub_admin_id : Newadmin.insertId,
                                                        created_at : new Date()
                                                       }
                                connection.query('INSERT INTO utilityRolesPermission set ?', permession_data, (err,data) => { 
                                    if (err) {
                                        res.status(400).send({ "error": err})
                                        return false
                                    }else{
                                       // console.log('===?',data)
                                    }
                                });
                            });
                               
                            })

                        }
                        res.status(200).send({ "success": true , data : "New user added."  })
                        return
                    })
                })
           }else{
            res.status(400).send({ "error": "email already exists."})
           }
        })
    })
};

controller.edit = (req, res) => {
    let {id} = req.params;
    console.log("id--------->",id)
    req.getConnection((err, conn) => {
        if (err) {
            res.status(400).send({ "error": err})
            return false
        }
        id=Buffer.from(id, 'base64').toString();
        conn.query("SELECT * from utilitySubAdmins WHERE id = ?", [id], (err, utilityAdmins) => {
            if (err) {
                res.status(400).send({ "error": err})
                return false
            }
            conn.query("SELECT * from utilityRolesPermission WHERE utility_sub_admin_id = ?", [id], (err, rows) => {
                if (err) {
                    res.status(400).send({ "error": err})
                    return false
                }  
                let combine_data = {
                    user : utilityAdmins,
                    permissions : rows
                }
                res.status(200).send({ "success": true , data :  combine_data })
            }); 
           // res.status(200).send({ "success": true , data : rows  })
        });
    });
};

controller.update = (req, res) => {
    let {id} = req.params;
    const body = req.body;

    const module_id = req.body.module_id
    console.log('data in body---->',req.body.module_id)
    delete(body.module_id)
    id=Buffer.from(id, 'base64').toString();
    req.getConnection((err, conn) => {
        if (err) {
            res.status(400).send({ "error": err})
            return false
        }
        conn.query('UPDATE utilitySubAdmins set ? where id = ?', [body, id], (err, rows) => {
            //update permessions       
            if (err) {
                res.status(400).send({ "error": err})
                return false
            }
            manageAdminService.updateRolPer(req , res ,id, module_id);
           
            res.status(200).send({ "success": true , data : rows  })
        });
    });
};

controller.delete = (req, res) => {
    let {id} = req.params;
    req.getConnection((err, connection) => {
        if (err) {
            res.status(400).send({ "error": err})
            return false
        }
        id=Buffer.from(id, 'base64').toString();
        connection.query('DELETE FROM utilityAdmins WHERE id = ?', [id], (err, rows) => {
            if (err) {
                res.status(400).send({ "error": err})
                return false
            }
            connection.query('DELETE FROM utilityRolesPermission WHERE utilityAdmins_id = ?', [id], (err, rows) => {
                res.status(200).send({ "success": true , data : "Record deleted."  })
            });
        });
       
    });
};
controller.soft_delete = (req, res) => {
    let {id} = req.params;
    const body = req.body;
    req.getConnection((err, conn) => {
        if (err) {
            res.status(400).send({ "error": err})
            return false
        }
        id=Buffer.from(id, 'base64').toString();
        conn.query('UPDATE utilitySubAdmins set is_deleted = ? where id = ?', ['true', id], (err, rows) => {
            conn.query('UPDATE utilityRolesPermission set is_deleted = ? where utilityAdmins_id = ?', ['true',id], (err, rows) => {
                if (err) {
                    res.status(400).send({ "error": err})
                    return false
                }
                res.status(200).send({ "success": true , data : rows  })
            });
         
        });
    });
};
controller.activeInactive = (req, res) => {
    let {id} = req.params;
    const body = req.body;
    req.getConnection((err, conn) => {
        if (err) {
            res.status(400).send({ "error": err})
            return false
        }
        conn.query('UPDATE utilitySubAdmins set is_active = ? where id = ?', [body.is_active, id], (err, rows) => {
            if (err) {
                res.status(400).send({ "error": err})
                return false
            }
            res.status(200).send({ "success": true , data : "Record updated"  })
        });
    });
};



controller.getModules = (req, res) => {
    req.getConnection((err, conn) => {
        console.log("-------getModules------->",req.query)
        conn.query('SELECT * FROM modules where  parent_module_id = 0 AND is_active=?',['true'], (err, modules) => {
            console.log("--------getModules-----",err);
            if (err) {
                res.status(400).send({ "error": err})
                return false
            }
            res.status(200).send(modules)
        });
    });
};
controller.getModulesSubAdmin = (req, res) => {
    req.getConnection((err, conn) => {
        console.log("-------------->",req.query.email)
        conn.query('SELECT * FROM modules where parent_module_id = 0 AND id not in(1,2)',[], (err, admins) => {
            if (err) {
                res.status(400).send({ "error": err})
                return false
            }
            res.status(200).send(admins)
        });
    });
};
controller.multi_activeInactive = (req, res) => {
    console.log("multiUpdate sanjeev-----",req.body);
    
    let encodedIds=[];

    for(let i=0;i<req.body.dataId.length;i++){
        encodedIds.push(Buffer.from(req.body.dataId[i], 'base64').toString())
    }
    req.body.dataId=encodedIds;
    if(req.body.action=='delete'){
        req.getConnection((err, connection) => {
            connection.query('update utilitySubAdmins set is_deleted=? where id IN(?)', 
                ['true',req.body.dataId], (err, result) => {
                    if (err) {
                        res.status(400).send({ "error": err})
                        return false
                    }
                res.status(200).send(result)
            });
        });
    }else if(req.body.action=='activate'){
        console.log('deactive---------->',req.body.dataId);
        req.getConnection((err, connection) => {
            if (err) {
                res.status(400).send({ "error": err})
                return false
            }
            connection.query('update utilitySubAdmins set is_active=? where id IN(?)', 
                ['true',req.body.dataId], (err, result) => {
                    if (err) {
                        res.status(400).send({ "error": err})
                        return false
                    }
                res.status(200).send(result)
            });
        });
    }else if(req.body.action=='deactivate'){
        console.log('deactive---------->',req.body.dataId);
        req.getConnection((err, connection) => {
            if (err) {
                res.status(400).send({ "error": err})
                return false
            }
            connection.query('update utilitySubAdmins set is_active=? where id IN(?)', 
                ['false',req.body.dataId], (err, result) => {
                    if (err) {
                        res.status(400).send({ "error": err})
                        return false
                    }
                res.status(200).send(result)
            });
        });
    }else{
        
    }
};

controller.getSubAdminPermession = (req, res) => {
    let {id} = req.params;
    req.getConnection((err, conn) => {
        if (err) {
            res.status(400).send({ "error": err})
            return false
        }
        id=Buffer.from(id, 'base64').toString();
        console.log("---->",id)
        conn.query("SELECT utilityRolesPermission.*, modules.* FROM utilityRolesPermission INNER JOIN modules on utilityRolesPermission.module_id = modules.id where utilityRolesPermission.utility_sub_admin_id = ?",[id], (err, admins) => {
            if (err) {
                res.status(400).send({ "error": err})
                return false
            }
            res.status(200).send(admins)
        });
    });
};


controller.getrequestServiceProviders = (req, res) => {
    req.getConnection((err, conn) => {
        if(err){
            res.status(400).send({ err : err })
            return
        }
        var quer;
        var para;
        const login_user_id = req.headers.decoded.user_id
        console.log('provider id--->',login_user_id)
       quer = `SELECT *,utilityServiceRequest.id as id, utilityServiceTypes.title as utilityServiceTypes_title  FROM utilityServiceRequest INNER JOIN utilities on utilities.id = utilityServiceRequest.utility_id 
       INNER JOIN utilityProviders on utilityProviders.id = utilityServiceRequest.utility_provider_id 
       INNER JOIN utilityServiceTypes on utilityServiceTypes.id = utilityServiceRequest.service_type_id 
       where utilityServiceRequest.utility_provider_id = ? `
                para = [login_user_id]
        conn.query(quer, para, (err, customer)=> {
            if(err){
                res.status(400).send({ err : err })
                return
            }else{
                res.status(200).send({ "success": true , data : customer  })
            }
           
        });
    });
};

module.exports = controller;
