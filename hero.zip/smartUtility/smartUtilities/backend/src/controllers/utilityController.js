const controller = {};
const manageAdminService = require("../services/manageAdminService");
const emailService = require("../services/emailService");
/*
 * @api url : /utility/list?keyword=
 * @description: list utilites with search keyword
 *  @type : GET
 * @author: Sanjeev
 */
controller.list = async (req, res) => {
  console.log(req.query.keyword);
  req.getConnection((err, conn) => {
    conn.query(
      "SELECT * FROM utilities where title LIKE ? and is_deleted=? ORDER BY id DESC;",
      ["%" + req.query.keyword + "%", "false"],
      (err, customer) => {
        if (err) {
          res.status(400).send({ err: err });
          return false;
        }
        res.status(200).send({ success: true, data: customer });
      }
    );
  });
};

controller.providerCategories = async (req, res) => {
  var utility_provider_id;
  if (req.query.utility_provider_id == 0) {
    utility_provider_id = req.query.utility_provider_id;

    req.getConnection((err, conn) => {
      conn.query(
        'SELECT * FROM utilities where is_active="true" and is_deleted=? ORDER BY id ASC;',
        ["false"],
        (err, utilities) => {
          if (err) {
            res.status(400).send({ err: err });
            return false;
          }
          res.status(200).send({ success: true, data: utilities });
        }
      );
    });
  } else {
    utility_provider_id = Buffer.from(
      req.query.utility_provider_id,
      "base64"
    ).toString();

    req.getConnection((err, conn) => {
      conn.query(
        "SELECT utilities.* FROM utilities LEFT JOIN utilityModulesProviders on utilities.id=utilityModulesProviders.utility_id where utilities.is_active='true' and utilities.is_deleted=? and utilityModulesProviders.utility_provider_id=? group by utilityModulesProviders.utility_id ORDER BY id DESC;",
        ["false", utility_provider_id],
        (err, customer) => {
          if (err) {
            res.status(400).send({ err: err });
            return false;
          }
          req.getConnection((err, conn) => {
            conn.query(
              "SELECT * FROM utilities where is_active='true' and is_deleted=? ORDER BY id ASC;",
              ["false"],
              (err, utilities) => {
                if (err) {
                  res.status(400).send({ err: err });
                  return false;
                }
                res.status(200).send({
                  success: true,
                  data: customer,
                  utilities: utilities,
                });
              }
            );
          });
        }
      );
    });
  }
};
/*
 * @author: Sanjeev
 * @api url : /utility/save
 * @description: This function is used to save the utilites
 * @type : POST
 * @Prameters : title , description
 */
controller.save = async (req, res) => {
  const data = req.body;
  data["is_deleted"] = "false";
  data["is_active"] = "true";
  data["created_date"] = new Date();
  var subCategories = data["subCategories"];
  delete data["subCategories"];
  req.getConnection((err, connection) => {
    connection.query(
      "select * from utilities where title = ?",
      [data.title],
      (err, utilities) => {
        if (utilities.length > 0) {
          res
            .status(300)
            .json({ status: "error", msg: "Category already exists." });
          return false;
        }
        connection.query(
          "INSERT INTO utilities set ?",
          data,
          (err, utility) => {
            if (err) {
              res.status(400).send({ error: err });
              return false;
            }
            if (subCategories.length > 0) {
              console.log(
                "-----subCategories----",
                utility.insertId,
                subCategories
              );

              var sql = "INSERT INTO subUtilities (utility_id,title) VALUES ?";
              var records = [];
              for (let i = 0; i < subCategories.length; i++) {
                records.push([utility.insertId, subCategories[i]]);
              }

              console.log("-=-=new rsqlecords-=", records);
              let query = connection.query(sql, [records], (err, result) => {
                console.log("---=-=err-=-", err);
                if (err) {
                  res.json(err);
                  res.status(500).json({ status: "error", error: err });
                }
                res.status(200).send({ success: true, data: utility });
              });
            } else {
              res.status(200).send({ success: true, data: utility });
            }
          }
        );
      }
    );
  });
};
/*
 * @author: Sanjeev
 * @api url :/utility/edit/:id
 * @description: This function is used to get single utility information
 * @type : GET
 * @Prameters : */
controller.edit = (req, res) => {
  var id = req.params.id;
  id = Buffer.from(id, "base64").toString();
  req.getConnection((err, conn) => {
    if (err) {
      res.status(400).send({ err: err });
      return false;
    }
    conn.query("SELECT * FROM utilities WHERE id = ?", [id], (err, rows) => {
      console.log("=-=-=--=", err, rows);
      if (err) {
        res.status(400).send({ err: err });
        return false;
      }

      conn.query(
        "SELECT id,title FROM subUtilities WHERE utility_id = ? and is_deleted='False'",
        [id],
        (err, subCategories) => {
          console.log("=-=-=--=", err, subCategories);
          if (err) {
            res.status(400).send({ err: err });
            return false;
          }

          res.status(200).send({
            success: true,
            data: rows[0],
            subCategories: subCategories,
          });
        }
      );

      // res.status(200).send({ success: true, data: rows[0],subCategories: [] })
    });
  });
};

/*
 * @author: Sanjeev
 * @api url : /utility/update
 * @description: This function is used to update the utility with id
 * @Prameters : title or description
 *  @type : POST
 */
controller.update = (req, res) => {
  var id = req.body.id;
  delete req.body.id;
  data = req.body;

  var subCategories = data["subCategories"];
  var dbsubCategories = data["dbsubCategories"];
  delete data["subCategories"];
  delete data["dbsubCategories"];

  const utility = req.body;
  // id = Buffer.from(id, 'base64').toString();
  req.getConnection((err, conn) => {
    conn.query(
      "UPDATE utilities set ? where id = ?",
      [utility, id],
      (err, rows) => {
        if (err) {
          res.status(400).send({ error: err });
          return false;
        }

        if (subCategories && subCategories.length > 0) {
          let deleteCats = [];
          if (dbsubCategories && dbsubCategories.length > 0) {
            deleteCats = arr_diff(subCategories, dbsubCategories);
          }

          updateSubcategoriesConditionaly(
            0,
            subCategories,
            conn,
            id,
            (finalRes) => {
              if (finalRes && finalRes.success) {
                if (deleteCats && deleteCats.length > 0) {
                  deleteSubcategoriesConditionaly(
                    0,
                    deleteCats,
                    conn,
                    id,
                    (finalRes2) => {
                      if (finalRes2 && finalRes2.success) {
                        res.status(200).send({ success: true, data: [] });
                      } else {
                        res
                          .status(400)
                          .send({ success: false, error: finalRes2.error });
                      }
                    }
                  );
                } else {
                  res.status(200).send({ success: true, data: [] });
                }
              } else {
                res.status(400).send({ success: false, error: finalRes.error });
              }
            }
          );
        }
      }
    );
  });
};

function arr_diff(a1, a2) {
  var a = [],
    diff = [];

  for (var i = 0; i < a1.length; i++) {
    a[a1[i]] = true;
  }

  for (var i = 0; i < a2.length; i++) {
    if (a[a2[i]]) {
      delete a[a2[i]];
    } else {
      a[a2[i]] = true;
    }
  }

  for (var k in a) {
    diff.push(k);
  }

  return diff;
}

function deleteSubcategoriesConditionaly(i, data, conn, id, callback) {
  if (i < data.length) {
    conn.query(
      "delete from subUtilities where utility_id = ? and title=?",
      [id, data[i]],
      (err, rows) => {
        i = i + 1;
        deleteSubcategoriesConditionaly(i, data, conn, id, callback);
      }
    );
  } else {
    let finalData = {
      success: true,
      data: data,
    };
    callback(finalData);
  }
}

function updateSubcategoriesConditionaly(i, data, conn, id, callback) {
  if (i < data.length) {
    conn.query(
      "select * from subUtilities where utility_id = ? and title=?",
      [id, data[i]],
      (err, rows) => {
        console.log("=-=-updateSubcategoriesConditionaly=--=", err, rows);

        if (rows.length == 0) {
          var sql = "INSERT INTO subUtilities (utility_id,title) VALUES ?";
          var records = [];
          records.push([id, data[i]]);
          console.log("-=-=new rsqlecords-=", records);
          let query = conn.query(sql, [records], (err, result) => {
            console.log("---=-=essssrr-=-", err);
            if (err) {
              let finalData = {
                success: false,
                error: err,
              };
              callback(finalData);
            }
            i = i + 1;
            updateSubcategoriesConditionaly(i, data, conn, id, callback);
          });
        } else {
          i = i + 1;
          updateSubcategoriesConditionaly(i, data, conn, id, callback);
        }
      }
    );
  } else {
    let finalData = {
      success: true,
      data: data,
    };
    callback(finalData);
  }
}

/*
 * @author: Sanjeev
 * @api url : /customer/multi_activeInactive
 * @description: This function is used to delete ,active and deavtivate utility
 * @Prameters : dataId in array e.g [1,2] and action = delete or activate or deactivate
 * @type : POST
 */
controller.multi_activeInactive = (req, res) => {
  console.log("multiUpdate sanjeev-----", req.body);
  let encodedIds = [];
  for (let i = 0; i < req.body.dataId.length; i++) {
    encodedIds.push(Buffer.from(req.body.dataId[i], "base64").toString());
  }
  req.body.dataId = encodedIds;
  console.log("raman -encodedIds--", encodedIds);
  req.getConnection((err, connection) => {
    connection.query(
      "select utilities.id from utilities left join utilityModulesProviders on utilities.id=utilityModulesProviders.utility_id LEFT JOIN utilityProviders on utilityProviders.id=utilityModulesProviders.utility_provider_id where utilityProviders.is_active='true' and utilityProviders.is_deleted='false' and utilities.id IN(?) group by utilityModulesProviders.utility_id",
      [req.body.dataId],
      (err, rows) => {
        if (
          rows.length > 0 &&
          req.body.action != "activate" &&
          req.body.dataId.length == 1 &&
          rows[0].id == req.body.dataId[0]
        ) {
          res.status(300).json({
            status: "error",
            msg:
              "You can not " +
              req.body.action +
              " this category. This Service catagory is associated with utility provider",
          });
          return false;
        }
        if (req.body.action == "delete") {
          connection.query(
            "update utilities set is_deleted=? where id IN(?)",
            ["true", req.body.dataId],
            (err, result) => {
              if (err) {
                res.json(err);
                res.status(500).json({ status: "error", error: err });
              }
              res.status(200).send(result);
            }
          );
        } else if (req.body.action == "activate") {
          console.log("deactive---------->", req.body.dataId);
          req.getConnection((err, connection) => {
            if (err) {
              res.status(400).send({ err: err });
              return;
            }
            connection.query(
              "update utilities set is_active=? where id IN(?)",
              ["true", req.body.dataId],
              (err, result) => {
                if (err) {
                  res.json(err);
                  res.status(500).json({ status: "error", error: err });
                }
                res.status(200).send(result);
              }
            );
          });
        } else if (req.body.action == "deactivate") {
          console.log("deactive---------->", req.body.dataId);
          req.getConnection((err, connection) => {
            connection.query(
              "update utilities set is_active=? where id IN(?)",
              ["false", req.body.dataId],
              (err, result) => {
                if (err) {
                  res.json(err);
                  res.status(500).json({ status: "error", error: err });
                }
                res.status(200).send(result);
              }
            );
          });
        } else {
        }
      }
    );
  });
};

/*
 * @author: Sanjeev
 * @api url :/settings/edit
 * @description: This function is used to get single utility information
 * @type : GET
 * @Prameters : */
controller.settingsedit = (req, res) => {
  req.getConnection((err, conn) => {
    if (err) {
      res.status(400).send({ err: err });
      return false;
    }
    conn.query("SELECT * FROM settings WHERE id = ?", [1], (err, rows) => {
      if (err) {
        res.status(400).send({ err: err });
        return false;
      }
      res.status(200).send({ success: true, data: rows[0] });
    });
  });
};

/*
 * @author: Raman
 * @api url :/getCategories
 * @description: This function is used to get single utility information
 * @type : GET
 * @Prameters : */
controller.getCategories = async (req, res) => {
  try {
    var provider_id_with_admin_id = await manageAdminService.get_provider_of_admin(
      req
    );
  } catch (error) {
    console.log(error);
    res.status(400).send(error);
    return false;
  }
  let utility_provider_id = provider_id_with_admin_id;
  req.getConnection((err, conn) => {
    if (err) {
      res.status(400).send({ err: err });
      return false;
    }
    conn.query(
      "SELECT utilities.title,utilities.id FROM utilities LEFT JOIN utilityModulesProviders on utilities.id=utilityModulesProviders.utility_id  where utilities.is_active=? and  utilities.is_deleted='false' and utilityModulesProviders.utility_provider_id=? group by utilityModulesProviders.utility_id",
      ["true", utility_provider_id],
      (err, rows) => {
        console.log("errrr", err);
        if (err) {
          res.status(400).send({ err: err });
          return false;
        }
        res.status(200).send({ success: true, data: rows });
      }
    );
  });
};

/*
 * @author: Raman
 * @api url :/getCategories
 * @description: This function is used to get single utility information
 * @type : GET
 * @Prameters : */
controller.getOptions = async (req, res) => {
  try {
    var provider_id_with_admin_id = await manageAdminService.get_provider_of_admin(
      req
    );
  } catch (error) {
    console.log(error);
    res.status(400).send(error);
    return false;
  }
  let utility_provider_id = provider_id_with_admin_id;
  console.log("=utility_provider_id==", utility_provider_id);
  req.getConnection((err, conn) => {
    if (err) {
      res.status(400).send({ err: err });
      return false;
    }
    console.log("=err==", err);
    conn.query(
      "SELECT utilityServiceSubTypes.* FROM utilityServiceSubTypes LEFT JOIN utilityServiceTypes on utilityServiceSubTypes.service_type_id=utilityServiceTypes.id  where utilityServiceTypes.is_active=? and utilityServiceTypes.utility_id=? and utilityServiceTypes.subutility_id=? and  utilityServiceTypes.is_deleted='false' and utilityServiceTypes.utility_provider_id=? order by utilityServiceSubTypes.sub_category_title",
      [
        "true",
        req.body.utility_id,
        req.body.subUtility_id,
        utility_provider_id,
      ],
      (err, rows) => {
        console.log("errrr", err, JSON.stringify(rows));
        if (err) {
          res.status(400).send({ err: err });
          return false;
        }
        res.status(200).send({ success: true, data: rows });
      }
    );
  });
};

/*
 * @author: Raman
 * @api url :/getCategories
 * @description: This function is used to get single utility information
 * @type : GET
 * @Prameters : */
controller.getSubCategories = async (req, res) => {
  let { id } = req.params;
  console.log("===id===", id);
  req.getConnection((err, conn) => {
    if (err) {
      res.status(400).send({ err: err });
      return false;
    }
    conn.query(
      "SELECT id,title FROM subUtilities where utility_id=? and is_active='True' and is_deleted='False' order by title DESC",
      [id],
      (err, rows) => {
        console.log(
          "--ssss",
          err,
          "SELECT * FROM subUtilities where utility_id=" +
            id +
            " and is_active=? and is_deleted='False' order by title DESC",
          rows
        );
        if (err) {
          res.status(400).send({ err: err });
          return false;
        }
        res.status(200).send({ success: true, data: rows });
      }
    );
  });
};

/*
 * @author: Raman
 * @api url :/getCategories
 * @description: This function is used to get single utility information
 * @type : GET
 * @Prameters : */
controller.getAllCategories = async (req, res) => {
  req.getConnection((err, conn) => {
    if (err) {
      res.status(400).send({ err: err });
      return false;
    }
    conn.query(
      "SELECT * FROM utilities where is_active=? and is_deleted='false' order by title DESC",
      ["true"],
      (err, rows) => {
        if (err) {
          res.status(400).send({ err: err });
          return false;
        }
        res.status(200).send({ success: true, data: rows });
      }
    );
  });
};

/*
 * @author: Sanjeev
 * @api url : /settings/update
 * @description: This function is used to update the utility with id
 * @Prameters : title or description
 *  @type : POST
 */
controller.settingsupdate = (req, res) => {
  req.getConnection((err, conn) => {
    req.body = JSON.parse(req.body.data);
    if (req.file) {
      req.body["logo"] = req.file.filename;
    }
    conn.query(
      "UPDATE settings set ? where id = ?",
      [req.body, 1],
      (err, rows) => {
        if (err) {
          res.status(400).send({ error: err });
          return false;
        }
        res.status(200).send({ success: true, data: rows });
      }
    );
  });
};
/*
 * @author: Sanjeev
 * @api url : /customer/multi_activeInactive
 * @description: This function is used to delete ,active and deavtivate utility
 * @Prameters : dataId in array e.g [1,2] and action = delete or activate or deactivate
 * @type : POST
 */
module.exports = controller;
