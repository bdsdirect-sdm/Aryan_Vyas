const controller = {};
var md5 = require("md5");
const formidable = require("formidable");
const managetServiceRequest = require("../services/manageAdminService");
const emailService = require("../services/emailService");
const manageAdminService = require("../services/manageAdminService");
const stripe = require("../services/stripe");

var moment = require("moment");
/*
 * @api url : /superAdmin/utilitylist
 * @description:
 *  @type : GET
 * @author: Sanjeev
 */
// 

controller.utilityList = async (req, res) => {
  req.getConnection((err, conn) => {
    if (err) {
      return res.status(500).send({ err: "Database connection error" });
    }
    const searchKeyword = req.query.keyword.replace(/[\s()-]/g, '');

    conn.query(
      `SELECT * FROM utilityProviders 
      WHERE (
        first_name LIKE ? 
        OR last_name LIKE ? 
        OR email LIKE ?  
        OR REPLACE(REPLACE(REPLACE(REPLACE(phone, ' ', ''), '-', ''), '(', ''), ')', '') LIKE ?  
        OR concat(first_name, ' ', last_name) LIKE ?
      ) 
      AND is_deleted = ?  
      ORDER BY id DESC;`,
      [
        `%${req.query.keyword}%`,
        `%${req.query.keyword}%`,
        `%${req.query.keyword}%`,
        `%${searchKeyword}%`,
        `%${req.query.keyword}%`,
        "false",
      ],
      (err, customer) => {
        if (err) {
          return res.status(400).send({ err: err });
        }
        res.status(200).send({ success: true, data: customer });
      }
    );
  });
};


/*
 * @author: Sanjeev
 * @api url : /superAdmin/utilityProviderSave
 * @description: This function is used to save the utility providers
 * @type : POST
 * @Prameters :  */
// controller.utilityProviderSave = async (req, res) => {
//   const data = JSON.parse(req.body.data);
//   var module_id = data.module_id;
//   var category_id = data.category_id;
//   delete data.module_id;
//   delete data.category_id;
//   data["password"] = md5(data.password);
//   if (req.files && req.files.length) {
//     req.files.forEach((element) => {
//       if (element.originalname === "logo") {
//         data["logo"] = element.filename;
//       }
//       if (element.originalname === "idfront") {
//         data["idProofFront"] = element.filename;
//       }
//       if (element.originalname === "idback") {
//         data["idProofBack"] = element.filename;
//       }
//     });
//   }
//   data["created_date"] = new Date();

//   req.getConnection((err, connection) => {
//     if (err) {
//       res.status(400).send({ error: err });
//       return false;
//     }
//     connection.query(
//       "select * from utilityProviders where email = ?",
//       [data.email],
//       (err, Newadmin) => {
//         if (err) {
//           res.status(400).send({ error: err });
//           return false;
//         }
//         //checking is email already exists....
//         if (Newadmin.length == 0) {
//           req.getConnection(async (err, connection) => {
//             try {
//               var dataCustomer = await stripe.createConnectedAccount(req);
//             } catch (error) {
//               console.log("===my error==", error.raw.message);
//               res.status(300).send({ status: "error", msg: error.raw.message });
//               return false;
//             }

//             connection.query(
//               "INSERT INTO utilityProviders set ?",
//               data,
//               async (err, Newadmin) => {
//                 if (err) {
//                   res.status(400).send({ error: err });
//                   return false;
//                 }
//                 module_id = module_id.map(Number);

//                 if (module_id.length > 0) {
//                   /**saving the permessins for admin.. */
//                   connection.query(
//                     "SELECT id FROM modules where id IN (?) ",
//                     [module_id],
//                     async (err, childModules) => {
//                       if (err) {
//                         res.status(400).send({ error: err });
//                         return false;
//                       }
//                       //let module_id_childModules =[...module_id,...childModules]
//                       // console.log("module_id_childModules---->", childModules);
//                       // childModules.map((obj) => {
//                       //     module_id.push(obj.id)
//                       // })
//                       module_id.map((m_id) => {
//                         category_id.map((c_id) => {
//                           let permession_data = {
//                             module_id: m_id,
//                             utility_id: c_id,
//                             utility_provider_id: Newadmin.insertId,
//                           };

//                           connection.query(
//                             "INSERT INTO utilityModulesProviders set ?",
//                             permession_data,
//                             (err, data) => {
//                               console.log("--erroroororor", err);
//                               if (err) {
//                                 res.status(400).send({ error: err });
//                                 return false;
//                               } else {
//                                 console.log("===>>", data);
//                               }
//                             }
//                           );
//                         });
//                       });
//                     }
//                   );
//                 }
//                 var customerData = {
//                   email: data.email,
//                 };

//                 //  const dataCustomer = await stripe.createConnectedAccount(req, customerData)
//                 //  console.log("customer -data-->>",dataCustomer)
//                 var updateProvider = { stripe_account_id: dataCustomer.id };
//                 connection.query(
//                   "update utilityProviders set ? where email = ?",
//                   [updateProvider, data.email],
//                   (err, result) => {
//                     if (err) {
//                       res.status(400).send({ error: err });
//                       return false;
//                     }
//                     //res.status(400).send({ "error": err })
//                     res
//                       .status(200)
//                       .send({ success: true, data: "New user added." });
//                     //return
//                   }
//                 );
//               }
//             );
//           });
//         } else {
//           res
//             .status(300)
//             .json({ status: "error", msg: "Email already exists." });
//           return false;
//         }
//       }
//     );
//   });

// };

controller.utilityProviderSave = async (req, res) => {
  try {
    const data = JSON.parse(req.body.data);
    let module_id = data.module_id || [];
    let category_id = data.category_id || [];

    delete data.module_id;
    delete data.category_id;

    if (!data.password) {
      return res.status(400).json({ status: "error", msg: "Password is required." });
    }

    data["password"] = md5(data.password);
    data["created_date"] = new Date();
    data["logo"] = null;
    data["idProofFront"] = "default_id_front.png"; 
    data["idProofBack"] = "default_id_back.png";
    data["stripe_account_id"] = "";

    if (!data.company_name || data.company_name === null) {
      data.company_name = "";
    }

    console.log("Data before insert:", data);

    if (req.files && req.files.length) {
      req.files.forEach((file) => {
        if (file.fieldname === "logo") data["logo"] = file.filename;
        if (file.fieldname === "idfront") data["idProofFront"] = file.filename;
        if (file.fieldname === "idback") data["idProofBack"] = file.filename;
      });
    }

    req.getConnection((err, connection) => {
      if (err) {
        console.error("Database connection error:", err);
        return res.status(500).send({ status: "error", msg: "Database connection failed." });
      }

      connection.query("SELECT id FROM utilityProviders WHERE email = ?", [data.email], (err, existingUser) => {
        if (err) {
          console.error("Database query error:", err);
          return res.status(500).send({ status: "error", msg: "Database query failed." });
        }

        if (existingUser.length > 0) {
          return res.status(400).json({ status: "error", msg: "Email already exists." });
        }
        connection.query("INSERT INTO utilityProviders SET ?", data, (err, result) => {
          if (err) {
            console.error("Database insertion error:", err.sqlMessage);
            return res.status(500).send({ status: "error", msg: "Failed to create user.", error: err.sqlMessage });
          }

          const newProviderId = result.insertId;

          if (module_id.length > 0) {
            connection.query("SELECT id FROM modules WHERE id IN (?)", [module_id], (err, childModules) => {
              if (err) {
                console.error("Error fetching modules:", err);
                return res.status(500).send({ status: "error", msg: "Failed to assign modules." });
              }

              module_id.forEach((m_id) => {
                category_id.forEach((c_id) => {
                  let permissionData = {
                    module_id: m_id,
                    utility_id: c_id,
                    utility_provider_id: newProviderId,
                  };

                  connection.query("INSERT INTO utilityModulesProviders SET ?", permissionData, (err) => {
                    if (err) console.error("Error inserting permission:", err);
                  });
                });
              });
            });
          }

          return res.status(200).json({ success: true, msg: "New user added successfully." });
        });
      });
    });
  } catch (error) {
    console.error("Signup Error:", error);
    return res.status(500).send({ status: "error", msg: "Internal server error." });
  }
};


controller.multi_activeInactiveUtitlity = (req, res) => {
  console.log("multiUpdate sanjeev-----", req.body);

  let encodedIds = [];
  for (let i = 0; i < req.body.dataId.length; i++) {
    encodedIds.push(Buffer.from(req.body.dataId[i], "base64").toString());
  }
  req.body.dataId = encodedIds;
  if (req.body.action == "delete") {
    req.getConnection((err, connection) => {
      connection.query(
        "update utilityProviders set is_deleted=? where id IN(?)",
        ["true", req.body.dataId],
        (err, result) => {
          if (err) {
            res.status(400).send({ error: err });
            return false;
          }
          res.status(200).send(result);
        }
      );
    });
  } else if (req.body.action == "activate") {
    console.log("deactive---------->", req.body.dataId);
    req.getConnection((err, connection) => {
      if (err) {
        res.status(400).send({ error: err });
        return false;
      }
      connection.query(
        "update utilityProviders set is_active=? where id IN(?)",
        ["true", req.body.dataId],
        (err, result) => {
          if (err) {
            res.status(400).send({ error: err });
            return false;
          }
          res.status(200).send(result);
        }
      );
    });
  } else if (req.body.action == "deactivate") {
    console.log("deactive---------->", req.body.dataId);
    req.getConnection((err, connection) => {
      if (err) {
        res.status(400).send({ error: err });
        return false;
      }
      connection.query(
        "update utilityProviders set is_active=? where id IN(?)",
        ["false", req.body.dataId],
        (err, result) => {
          if (err) {
            res.status(400).send({ error: err });
            return false;
          }
          res.status(200).send(result);
        }
      );
    });
  } else {
  }
};
controller.utilityProviderEdit = (req, res) => {
  let { id } = req.params;
  console.log("id--------->", id);
  req.getConnection((err, conn) => {
    if (err) {
      res.status(400).send({ error: err });
      return false;
    }
    id = Buffer.from(id, "base64").toString();
    conn.query(
      "SELECT * from utilityProviders WHERE id = ?",
      [id],
      (err, utilityAdmins) => {
        if (err) {
          res.status(400).send({ error: err });
          return false;
        }
        conn.query(
          "SELECT * from utilityModulesProviders WHERE utility_provider_id = ?",
          [id],
          (err, rows) => {
            if (err) {
              res.status(400).send({ error: err });
              return false;
            }
            let combine_data = {
              user: utilityAdmins,
              utilityModules: rows,
            };
            res.status(200).send({ success: true, data: combine_data });
          }
        );
        // res.status(200).send({ "success": true , data : rows  })
      }
    );
  });
};
controller.utilityProviderUpdate = (req, res) => {
  req.body = JSON.parse(req.body.data);
  let id = req.body.id;
  delete req.body.id;
  delete req.body.created_date;
  req.body.modified_date = moment().format("YYYY-MM-DD HH:mm:ss");
  const body = req.body;
  if (req.files && req.files.length) {
    req.files.forEach((element) => {
      if (element.originalname === "logo") {
        body["logo"] = element.filename;
      }
      if (element.originalname === "idfront") {
        body["idProofFront"] = element.filename;
      }
      if (element.originalname === "idback") {
        body["idProofBack"] = element.filename;
      }
    });
  }
  const module_id = req.body.module_id;
  const category_id = req.body.category_ids;
  console.log("data in body---->", req.body.module_id);
  delete body.module_id;
  delete body.category_ids;
  // id=Buffer.from(id, 'base64').toString();
  req.getConnection((err, conn) => {
    if (err) {
      res.status(400).send({ error: err });
      return false;
    }
    conn.query(
      "UPDATE utilityProviders set ? where id = ?",
      [body, id],
      (err, rows) => {
        console.log("errrooror", err);
        if (err) {
          res.status(400).send({ error: err });
          return false;
        }
        manageAdminService.UpdateutilityProvidermodules(
          req,
          res,
          id,
          module_id,
          category_id
        );
        res.status(200).send({ success: true, data: rows });
        return false;
      }
    );
  });
};

module.exports = controller;
