const controller = {};
const formidable = require('formidable');
const managetServiceRequest = require('../services/manageAdminService')
const stripe = require('../services/stripe')
const emailService = require('../services/emailService')

controller.getserviceProvider = async (req, res) => {
    //res.status(200).send(result)
   
    try {
        var provider_id_with_admin_id = await managetServiceRequest.get_provider_of_admin(req)
    } catch (error) { 
        console.log(error)
    res.status(400).send(error)
    return false
    }

    let utility_id=1;
    let utility_provider_id = provider_id_with_admin_id;
    req.getConnection((err, conn) => {
        conn.query(`SELECT *, 
        (SELECT count(*) FROM utilityServiceRequest  INNER JOIN utilityProgressServices on utilityProgressServices.service_request_id =  utilityServiceRequest.id where service_provider_id = utilityServiceProviders.id AND utilityProgressServices.service_request_status=2) as countOfRequests FROM utilityServiceProviders where  utility_provider_id=? and is_deleted='false' order by id DESC`,[utility_provider_id],(err, result) => {
            if (err) {
                //res.json(err);
                res.status(500).json({status: 'error',error:err});
            }
            console.log("-=-=-result=--=",JSON.stringify(result));
            res.status(200).send(result)
        });
    });
};

controller.getserviceProviderDetails = (req, res) => {
    console.log("-=-=rgetserviceTypeDetails-==-",req.query.id);
    req.query.id=Buffer.from(req.query.id, 'base64').toString();
    req.getConnection((err, connection) => {
        connection.query('SELECT usp.*,ups.service_id FROM utilityServiceProviders as usp LEFT JOIN utilityProviderServices as ups ON ups.service_provider_id=usp.id  where usp.id=?  and usp.is_deleted=?', 
            [req.query.id,'false'], (err, result) => {
                 console.log("---getserviceProviderDetails--",err,JSON.stringify(result));
          if (err) {
                res.json(err);
                res.status(500).json({status: 'error',error:err});
            }


            connection.query('SELECT day_index as day,availableFrom as timeFrom,availableTo as timeTo FROM utilityServiceProviderAvailability where service_provider_id=?', 
            [req.query.id,'false'], (err, avail) => {
                 console.log("---utilityServiceProviderAvailability--",err,JSON.stringify(result));
                    if (err) {
                            res.json(err);
                            res.status(500).json({status: 'error',error:err});
                        }   
                    
                    res.status(200).send({result:result,avail:avail})
                });
          
            
        });
    });
};


controller.getProviderDetails = (req, res) => {
    
    let id=Buffer.from(req.query.id, 'base64').toString();
    console.log("-=-=rgetserviceTypeDetails-==-",req.query.id);
    req.getConnection((err, connection) => {
        connection.query('SELECT *,"" as myservices,"" as recentServices FROM utilityProviders  where id=?  and is_deleted=?  and is_active=?', 
            [id,'false','true'], (err, result) => {
                 //console.log("---getProviderDetails--",err,JSON.stringify(result));
          if (err) {
                res.json(err);
                res.status(500).json({status: 'error',error:err});
            }
            if(result.length>0){
                getservicesTypes(result, connection,id,finalRes2 => {
                    if(finalRes2 && finalRes2.success) {        
                        
                        console.log("====daata",JSON.stringify(finalRes2.data));
                        res.status(200).send({ "success": true, data: finalRes2.data })
                    } else {
                        res.status(400).send({ "success": false, error: finalRes2.error })
                    }
                    
                });
            }else{
                res.status(200).send({ "success": true, data: result })
            }
           
        });
    });
};


function getservicesTypes(data, conn,id,callback) {
       
        conn.query('select utilities.title as mainCategory,subUtilities.title as subcategory        from subUtilities  LEFT JOIN utilities on utilities.id=subUtilities.utility_id LEFT JOIN utilityServiceTypes on subUtilities.id=utilityServiceTypes.subUtility_id  where utilities.id=utilityServiceTypes.utility_id and utilities.is_active="true" and utilities.is_deleted="false" and subUtilities.is_active="true" and subUtilities.is_deleted="false" and utilityServiceTypes.is_active="true" and utilityServiceTypes.is_deleted="false" and  utilityServiceTypes.utility_provider_id= ? order by utilities.title ASC', [id], (err, services) => {

            if (err) {
                console.log(err);
                    let finalData = {
                        success : false,
                        data: data
                    }
                    callback(finalData);
                }
                data[0]['myservices']=services;
                conn.query('select customers.first_name,customers.last_name,utilities.title as mainCategory,subUtilities.title as subcategory,utilityServiceProviderRating.rating,utilityServiceProviderRating.comments,utilityServiceRequest.created_at  from utilityServiceRequest  LEFT JOIN utilities on utilities.id=utilityServiceRequest.utility_id LEFT JOIN subUtilities on subUtilities.id=utilityServiceRequest.subUtility_id LEFT JOIN utilityServiceProviderRating on utilityServiceProviderRating.service_request_id=utilityServiceRequest.id  LEFT JOIN customers on customers.id=utilityServiceRequest.customer_id where utilities.id=utilityServiceRequest.utility_id and utilities.is_active="true" and utilities.is_deleted="false" and subUtilities.is_active="true" and subUtilities.is_deleted="false" and utilityServiceRequest.current_status=5 and  utilityServiceRequest.utility_provider_id= ?  order by utilityServiceRequest.id DESC LIMIT 6', [id], (err, recentServices) => {
                    console.log(err)
                    if (err) {
                        console.log(err);
                            let finalData = {
                                success : false,
                                data: data
                            }
                            callback(finalData);
                        }
                     
                     data[0]['recentServices']=recentServices;
                     
                    let finalData = {
                        success : true,
                        data: data
                    }
                    callback(finalData);
                });
            });
        }           

	

controller.addserviceProvider = async (req, res) => {

     try {
        var provider_id_with_admin_id = await managetServiceRequest.get_provider_of_admin(req)
    } catch (error) { 
        console.log(error)
    
    }            
   
     var data=req.body.formdata;
    let utility_id=1;
    let utility_provider_id=provider_id_with_admin_id;
    req.getConnection((err, conn) => {
        conn.query("SELECT * FROM utilityServiceProviders where utility_provider_id=? and email=? and is_deleted='false'",[utility_provider_id,data.email], (err, countData) => {
            if (err) {
                res.json(err);
                res.status(500).json({status: 'error',error:err});
            }

            console.log("-=-=-countData-=-==",JSON.stringify(countData));
             if(countData.length>0){
                    res.status(300).json({status: 'error',msg:'Email already exists'});
                    return false
                }

        stripe.createProviderAndBankAccount(req, response => { 
             
        console.log("-=-cust_id=-=-=-=Raman-=-=",response);
            
          req.getConnection((err, connection) => {
                const query = connection.query('insert into utilityServiceProviders(first_name,last_name,phone,email,password,address,photo,identityproof,account_no,ifsc_code,stripe_cust_id,stripe_bank_id,utility_provider_id,yearsExperience) values(?,?,?,?,?,?,?,?,?,?,?,?,?,?)', [data.first_name,data.last_name,data.phone,data.email,data.password,data.address,data.photo,data.identityproof,data.account_no,data.ifsc_code,response.cust_id,response.bank_id,utility_provider_id,data.yearsExperience], (err, result) => {
                    console.log("-=-=-",err, result);
                    
                    let providerId=result.insertId;

                     if (err) {
                        res.json(err);
                        res.status(500).json({status: 'error',error:err});
                    }

                    var serviceTypes=req.body.serviceTypes;
                    if(providerId && serviceTypes.length>0){

                        var sql = "INSERT INTO utilityProviderServices (service_id, service_provider_id) VALUES ?";
                        var records = [];
                        for(let i=0;i<serviceTypes.length;i++){
                            records.push([serviceTypes[i], providerId]);
                        }
                       
                        console.log("-=-=new records-=",records);
                         req.getConnection((err, connection) => {
                                const query = connection.query(sql, [records], (err, result) => {                  
                                     if (err) {
                                        res.json(err);
                                        res.status(500).json({status: 'error',error:err});
                                    }
                                })
                   
                            });

                    }
                    

                    var availability=req.body.availability;
                    if(providerId && availability.length>0){

                        var sql = "INSERT INTO utilityServiceProviderAvailability (day_index, service_provider_id,availableFrom,availableTo) VALUES ?";
                        var records = [];
                        for(let i=0;i<availability.length;i++){
                            let timeFrom=availability[i].timeFrom;
                            let timeTo=availability[i].timeFro;
                            if(timeFrom==":"){
                                  timeFrom=null;  
                            }
                            if(timeTo==":"){
                                timeTo=null;
                            }
                            if(availability[i].timeFrom && availability[i].timeTo){
                                records.push([availability[i].day, providerId,timeFrom,timeTo]);
                            }
                        }
                       
                        console.log("-=-=new records-=",records);
                         req.getConnection((err, connection) => {
                                const query = connection.query(sql, [records], (err, result) => {  
                                console.log("---=-=err-=-",err);                
                                     if (err) {
                                        res.json(err);
                                        res.status(500).json({status: 'error',error:err});
                                    }
                                    emailService.sendEmail(req, res, 1, data.email, data.password, data.first_name + ' ' + data.first_name.last_name, null, finalRes => {
                                        res.status(200).send(result)
                                    });
                                   
                    
                                })
                   
                            });

                    }else{
                        emailService.sendEmail(req, res, 1, data.email, data.password, data.first_name + ' ' + data.first_name.last_name, null, finalRes => {
                            res.status(200).send(result)
                        });
                    }                    
                   
                })
   
            });
        });
     });
       
   });    
     
 
 
}

 
controller.updateserviceProvider = (req, res) => {
    let utility_id=1;
    let utility_provider_id=1;
    var data=req.body.formdata;
    console.log("=--d=ada-d=ad-=a-dad-ad-a=-da=d-=",JSON.stringify(data));
  
          req.getConnection((err, connection) => {

            connection.query("SELECT * FROM utilityServiceProviders where  utility_provider_id=? and email=? and is_deleted='false' and id!=?",[utility_provider_id,data.email,data.id], (err, countData) => {
                    

                    console.log("-=-=-countData-=-==",err,JSON.stringify(countData));
                     if(countData.length>0){
                            res.status(300).json({status: 'error',msg:'Email already exists'});
                            return false
                        }



                const query = connection.query('update utilityServiceProviders set first_name=?,last_name=?,phone=?,email=?,address=?,photo=?,identityproof=?,account_no=?,ifsc_code=?,yearsExperience=? where id=?', [data.first_name,data.last_name,data.phone,data.email,data.address,data.photo,data.identityproof,data.account_no,data.ifsc_code,data.yearsExperience,data.id], (err, result) => {
                    let providerId=data.id;

                    var sql = "delete from utilityProviderServices where service_provider_id = ?";
                         req.getConnection((err, connection) => {
                                const query = connection.query(sql, [providerId], (err, result) => {                  
                                     if (err) {
                                        res.json(err);
                                        res.status(500).json({status: 'error',error:err});
                                    }
                                })
                   
                            });


                    var sql = "delete from utilityServiceProviderAvailability where service_provider_id = ?";
                     req.getConnection((err, connection) => {
                            const query = connection.query(sql, [providerId], (err, result) => {                  
                                 if (err) {
                                    res.json(err);
                                    res.status(500).json({status: 'error',error:err});
                                }
                            })
               
                        });

                   

                    var serviceTypes=req.body.serviceTypes;
                    if(providerId && serviceTypes.length>0){

                        var sql = "INSERT INTO utilityProviderServices (service_id, service_provider_id) VALUES ?";
                        var records = [];
                        for(let i=0;i<serviceTypes.length;i++){
                            records.push([serviceTypes[i], providerId]);
                        }
                       
                        console.log("-=-=new records-=",records);
                         req.getConnection((err, connection) => {
                                const query = connection.query(sql, [records], (err, result) => {                  
                                     if (err) {
                                        res.json(err);
                                        res.status(500).json({status: 'error',error:err});
                                    }
                                })
                   
                            });

                    }

                    var availability=req.body.availability;
                     console.log("-=--availability-=--",availability,availability.length);
                    if(providerId && availability.length>0){

                        var sql = "INSERT INTO utilityServiceProviderAvailability (day_index, service_provider_id, availableFrom, availableTo) VALUES ?";
                        var records = [];
                        for(let i=0;i<availability.length;i++){
                           let timeFrom=availability[i].timeFrom;
                            let timeTo=availability[i].timeTo;
                            if(timeFrom==":"){
                                  timeFrom=null;  
                            }
                            if(timeTo==":"){
                                timeTo=null;
                            }
                            
                                records.push([availability[i].day, providerId,timeFrom,timeTo]);
                            
                        }

                        console.log("-=-=new records-=",records);
                         req.getConnection((err, connection) => {
                                const query = connection.query(sql, [records], (err, result) => {  
                                console.log("---=-=err-=-",err);                
                                     if (err) {
                                        res.json(err);
                                        res.status(500).json({status: 'error',error:err});
                                    }
                                    res.status(200).send(result)
                    
                                })
                   
                            });

                    }else{
                        res.status(200).send(result)
                    }                    
                   
                })
            })
    });
}


controller.findserviceProvider = (req, res) => {
   console.log("findserviceType-----",req.body);
   let utility_id=1;
 let utility_provider_id=1;

    req.getConnection((err, conn) => {

        conn.query(`SELECT *, 
        (SELECT count(*) FROM utilityServiceRequest  INNER JOIN utilityProgressServices on utilityProgressServices.service_request_id =  utilityServiceRequest.id where service_provider_id = utilityServiceProviders.id AND utilityProgressServices.service_request_status=2) as countOfRequests FROM utilityServiceProviders where (first_name LIKE ? or last_name LIKE ? or phone LIKE ? or concat(first_name," ",last_name) LIKE ?) and utility_provider_id=? and is_deleted=?  order by id DESC`, ['%'+req.body.keyword+'%','%'+req.body.keyword+'%','%'+req.body.keyword+'%','%'+req.body.keyword+'%',utility_provider_id,'false'], (err, result) => {
             if (err) {
                res.json(err);
                res.status(500).json({status: 'error',error:err});
            }
            res.status(200).send(result)
        });
    });
};

controller.deleteServiceProvider = (req, res) => {
    console.log("deleteServiceType-----",req.body);
    req.body.id=Buffer.from(req.body.id, 'base64').toString()
    req.getConnection((err, connection) => {
        connection.query('update utilityServiceProviders set is_deleted=? where id =?', ['true',req.body.id], (err, result) => {
             if (err) {
                res.json(err);
                res.status(500).json({status: 'error',error:err});
            }
            res.status(200).send(result)
        });
    });
};


controller.multiUpdateserviceProviders = (req, res) => {
    console.log("multiUpdate-----",req.body);
    let encodedIds=[];
    for(let i=0;i<req.body.dataId.length;i++){
        encodedIds.push(Buffer.from(req.body.dataId[i], 'base64').toString())
    }
    req.body.dataId=encodedIds;

    if(req.body.action=='delete'){
        req.getConnection((err, connection) => {
            connection.query('update utilityServiceProviders set is_deleted=? where id IN(?)', 
                ['true',req.body.dataId], (err, result) => {
                 if (err) {
                    res.json(err);
                    res.status(500).json({status: 'error',error:err});
                }
                res.status(200).send(result)
            });
        });
    }else if(req.body.action=='activate'){
        req.getConnection((err, connection) => {
            connection.query('update utilityServiceProviders set is_active=? where id IN(?)', 
                ['true',req.body.dataId], (err, result) => {
                 if (err) {
                    res.json(err);
                    res.status(500).json({status: 'error',error:err});
                }
                res.status(200).send(result)
            });
        });
    }else if(req.body.action=='deactivate'){
        req.getConnection((err, connection) => {
            connection.query('update utilityServiceProviders set is_active=? where id IN(?)', 
                ['false',req.body.dataId], (err, result) => {
                 if (err) {
                    res.json(err);
                    res.status(500).json({status: 'error',error:err});
                }
                res.status(200).send(result)
            });
        });
    }else{
        
    }
};

module.exports = controller;
