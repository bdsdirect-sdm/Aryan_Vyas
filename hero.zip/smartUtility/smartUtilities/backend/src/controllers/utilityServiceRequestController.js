/*
 * @file: customerController.js
 * @description: It Contain functions for customer CRUD operations
 * @author: Sanjeev
 */
const controller = {};
var md5 = require("md5");
const formidable = require("formidable");
var moment = require("moment");
const managetServiceRequest = require("../services/manageAdminService");
const notification = require("../services/notifications");
const emailService = require("../services/emailService");

/*
 * @api url : /utilityServiceRequest/list
 * @description: It Contain functions list the utilityServiceRequest and searh with keyword
 *  @type : GET
 * @author: Sanjeev
 */

controller.getAllServiceGroup = async (req, res) => {
  try {
    var provider_id_with_admin_id = await managetServiceRequest.get_provider_of_admin(
      req
    );
  } catch (error) {
    console.log(error);
    res.status(400).send(error);
    return false;
  }
  req.getConnection((err, conn) => {
    var quer;
    const login_user_id = provider_id_with_admin_id;
    quer = `SELECT DISTINCT *,utilityProgressServices.service_request_status, utilityServiceRequest.id as id, customers.first_name as first_name,customers.last_name as last_name, utilityServiceTypes.title as utilityServiceTypes_title,utilityStatus.status as taskStatus,utilityStatus.id as taskStatusId,utilityServiceSubTypes.sub_category_title  
            FROM utilityServiceRequest INNER JOIN utilities on utilities.id = utilityServiceRequest.utility_id 
            LEFT JOIN utilityProviders on utilityProviders.id = utilityServiceRequest.utility_provider_id 
            LEFT JOIN utilityServiceTypes on utilityServiceTypes.id = utilityServiceRequest.service_type_id
            INNER JOIN utilityServiceSubTypes on utilityServiceSubTypes.service_type_id = utilityServiceTypes.id 
            LEFT JOIN customers on customers.id = utilityServiceRequest.customer_id
            LEFT JOIN utilityProgressServices on utilityProgressServices.service_request_id = utilityServiceRequest.id
            LEFT JOIN utilityStatus on utilityStatus.id = utilityServiceRequest.current_status
            where utilityServiceRequest.utility_provider_id = ? 
            AND utilityServiceRequest.current_status= utilityProgressServices.service_request_status
            AND customers.is_deleted = 'false' 
            AND customers.is_active = 'true'
            AND  utilityServiceRequest.current_status=? and utilityServiceRequest.is_deleted='false' group by utilityServiceRequest.id order by utilityServiceRequest.id DESC LIMIT ?`;
    var para = [login_user_id, req.body.status, req.body.limit];
    conn.query(quer, para, (err, customer) => {
      console.log("=-=-=-", err);
      if (err) {
        res.status(400).send({ err: err });
        return false;
      } else {
        console.log(
          "=-=-=-customer-=-=-",
          req.body,
          quer,
          JSON.stringify(customer)
        );
        res.status(200).send({ success: true, data: customer });
      }
    });
  });
};

controller.list = async (req, res) => {
  try {
    var provider_id_with_admin_id = await managetServiceRequest.get_provider_of_admin(
      req
    );
  } catch (error) {
    console.log(error);
    res.status(400).send(error);
    return false;
  }
  req.getConnection((err, conn) => {
    var quer;
    var para;

    //const login_user_id = req.headers.decoded.user_id
    const login_user_id = provider_id_with_admin_id;

    console.log(
      "asasdasd========------------------------------------------->=>",
      login_user_id
    );

    if (!req.body.search) {
      req.body.search = "";
    }
    if (req.body.customer_id && !req.body.service_provider_id) {
      console.log("one--------------------");
      quer = `SELECT DISTINCT *,utilityServiceProviders.first_name as utilityServiceProviders_first_name,utilityServiceProviders.last_name as utilityServiceProviders_last_name,utilityProgressServices.service_request_status, utilityServiceRequest.id as id, customers.first_name as first_name,customers.last_name as last_name, utilities.title as utilityServiceTypes_title,subUtilities.title as subUtilityServiceTypes_title,utilityStatus.status as taskStatus,utilityStatus.id as taskStatusId,utilityServiceSubTypes.sub_category_title,utilityServiceSubTypes.hourly_rate as jobType,utilityServiceSubTypes.flat_rate as optionCost  FROM utilityServiceRequest INNER JOIN utilities on utilities.id = utilityServiceRequest.utility_id 
            INNER JOIN subUtilities on subUtilities.id = utilityServiceRequest.subUtility_id
            LEFT JOIN utilityProviders on utilityProviders.id = utilityServiceRequest.utility_provider_id 
            LEFT JOIN utilityServiceTypes on utilityServiceTypes.id = utilityServiceRequest.service_type_id
            INNER JOIN utilityServiceSubTypes on utilityServiceSubTypes.service_type_id = utilityServiceTypes.id 
            LEFT JOIN customers on customers.id = utilityServiceRequest.customer_id
            LEFT JOIN utilityProgressServices on utilityProgressServices.service_request_id = utilityServiceRequest.id
            LEFT JOIN utilityServiceProviders on utilityServiceProviders.id = utilityProgressServices.service_provider_id
            LEFT JOIN utilityStatus on utilityStatus.id = utilityServiceRequest.current_status
            where utilityServiceRequest.utility_provider_id = ? 
            AND utilityServiceRequest.current_status= utilityProgressServices.service_request_status
            AND subUtilities.utility_id=utilities.id 
            AND utilityServiceRequest.customer_id = ? 
            AND utilityServiceProviders.is_deleted = 'false' 
            AND utilityServiceProviders.is_active = 'true'
            AND customers.is_deleted = 'false' 
            AND customers.is_active = 'true'
            AND utilityServiceSubTypes.id=utilityServiceRequest.utility_service_sub_type_id
            AND (request_number LIKE ? OR  customers.mobile LIKE ? OR utilityServiceProviders.first_name like ? OR customers.first_name like ? )  and utilityServiceRequest.is_deleted='false' group by utilityServiceRequest.id order by utilityServiceRequest.id DESC`;
      para = [
        login_user_id,
        req.body.customer_id,
        "%" + req.body.search + "%",
        "%" + req.body.search + "%",
        "%" + req.body.search + "%",
        "%" + req.body.search + "%",
      ];
    } else if (!req.body.customer_id && req.body.service_provider_id) {
      console.log("two--------------------");
      quer = `SELECT DISTINCT *,utilityServiceProviders.first_name as utilityServiceProviders_first_name,utilityServiceProviders.last_name as utilityServiceProviders_last_name,utilityProgressServices.service_request_status, utilityServiceRequest.id as id, customers.first_name as first_name,customers.last_name as last_name, utilities.title as utilityServiceTypes_title,subUtilities.title as subUtilityServiceTypes_title,utilityStatus.status as taskStatus,utilityStatus.id as taskStatusId,utilityServiceSubTypes.sub_category_title,utilityServiceSubTypes.hourly_rate as jobType,utilityServiceSubTypes.flat_rate as optionCost   FROM utilityServiceRequest INNER JOIN utilities on utilities.id = utilityServiceRequest.utility_id 
            INNER JOIN subUtilities on subUtilities.id = utilityServiceRequest.subUtility_id
            LEFT JOIN utilityProviders on utilityProviders.id = utilityServiceRequest.utility_provider_id 
            LEFT JOIN utilityServiceTypes on utilityServiceTypes.id = utilityServiceRequest.service_type_id 
             INNER JOIN utilityServiceSubTypes on utilityServiceSubTypes.service_type_id = utilityServiceTypes.id
            LEFT JOIN customers on customers.id = utilityServiceRequest.customer_id
            LEFT JOIN utilityProgressServices on utilityProgressServices.service_request_id = utilityServiceRequest.id
            LEFT JOIN utilityServiceProviders on utilityServiceProviders.id = utilityProgressServices.service_provider_id
             LEFT JOIN utilityStatus on utilityStatus.id = utilityServiceRequest.current_status
            where utilityServiceRequest.utility_provider_id = ? AND utilityProgressServices.service_provider_id = ? 
            AND utilityServiceRequest.current_status= utilityProgressServices.service_request_status
            AND customers.is_deleted = 'false' 
            AND customers.is_active = 'true'
            AND subUtilities.utility_id=utilities.id
            AND utilityServiceSubTypes.id=utilityServiceRequest.utility_service_sub_type_id 
            AND (request_number LIKE ? OR  customers.mobile LIKE ? OR utilityServiceProviders.first_name like ? OR customers.first_name like ?)  and utilityServiceRequest.is_deleted='false'  group by utilityServiceRequest.id order by utilityServiceRequest.id DESC`;
      para = [
        login_user_id,
        req.body.service_provider_id,
        req.body.search + "%",
        "%" + req.body.search + "%",
        "%" + req.body.search + "%",
        "%" + req.body.search + "%",
      ];
    } else if (req.body.customer_id && req.body.service_provider_id) {
      console.log("three--------------------");
      quer = `SELECT DISTINCT *,utilityServiceProviders.first_name as utilityServiceProviders_first_name ,utilityServiceProviders.last_name as utilityServiceProviders_last_name,utilityProgressServices.service_request_status, utilityServiceRequest.id as id, customers.first_name as first_name,customers.last_name as last_name, utilities.title as utilityServiceTypes_title,subUtilities.title as subUtilityServiceTypes_title,utilityStatus.status as taskStatus,utilityStatus.id as taskStatusId,utilityServiceSubTypes.sub_category_title,utilityServiceSubTypes.hourly_rate as jobType,utilityServiceSubTypes.flat_rate as optionCost   FROM utilityServiceRequest INNER JOIN utilities on utilities.id = utilityServiceRequest.utility_id 
            INNER JOIN subUtilities on subUtilities.id = utilityServiceRequest.subUtility_id
            LEFT JOIN utilityProviders on utilityProviders.id = utilityServiceRequest.utility_provider_id 
            LEFT JOIN utilityServiceTypes on utilityServiceTypes.id = utilityServiceRequest.service_type_id 
             INNER JOIN utilityServiceSubTypes on utilityServiceSubTypes.service_type_id = utilityServiceTypes.id
            LEFT JOIN customers on customers.id = utilityServiceRequest.customer_id
            LEFT JOIN utilityProgressServices on utilityProgressServices.service_request_id = utilityServiceRequest.id
            LEFT JOIN utilityServiceProviders on utilityServiceProviders.id = utilityProgressServices.service_provider_id
             LEFT JOIN utilityStatus on utilityStatus.id = utilityServiceRequest.current_status
            where utilityServiceRequest.utility_provider_id = ? AND utilityProgressServices.service_provider_id = ? AND  utilityServiceRequest.customer_id = ? 
            AND utilityServiceRequest.current_status= utilityProgressServices.service_request_status
            AND customers.is_deleted = 'false' 
            AND customers.is_active = 'true' 
            AND utilityServiceSubTypes.id=utilityServiceRequest.utility_service_sub_type_id
            AND subUtilities.utility_id=utilities.id
            AND (request_number LIKE ? OR  customers.mobile LIKE ? OR utilityServiceProviders.first_name like ? OR customers.first_name like ?)  and utilityServiceRequest.is_deleted='false'   group by utilityServiceRequest.id order by utilityServiceRequest.id DESC`;
      para = [
        login_user_id,
        req.body.service_provider_id,
        req.body.customer_id,
        req.body.search + "%",
        "%" + req.body.search + "%",
        "%" + req.body.search + "%",
        "%" + req.body.search + "%",
      ];
    } else {
      console.log("data in else--------------------->", login_user_id);
      quer = `SELECT DISTINCT *,utilityServiceProviders.first_name as utilityServiceProviders_first_name ,utilityServiceProviders.last_name as utilityServiceProviders_last_name,utilityProgressServices.service_request_status, utilityServiceRequest.id as id, customers.first_name as first_name,customers.last_name as last_name, customers.email as cust_email,utilities.title as utilityServiceTypes_title,subUtilities.title as subUtilityServiceTypes_title,utilityStatus.status as taskStatus,utilityStatus.id as taskStatusId,utilityServiceSubTypes.sub_category_title,utilityServiceSubTypes.hourly_rate as jobType,utilityServiceSubTypes.flat_rate as optionCost   FROM utilityServiceRequest INNER JOIN utilities on utilities.id = utilityServiceRequest.utility_id 
            INNER JOIN subUtilities on subUtilities.id = utilityServiceRequest.subUtility_id
            LEFT JOIN utilityProviders on utilityProviders.id = utilityServiceRequest.utility_provider_id 
            
            LEFT JOIN utilityServiceTypes on utilityServiceTypes.id = utilityServiceRequest.service_type_id 
            INNER JOIN utilityServiceSubTypes on utilityServiceSubTypes.service_type_id = utilityServiceTypes.id
            LEFT JOIN customers on customers.id = utilityServiceRequest.customer_id
            LEFT OUTER JOIN utilityProgressServices on utilityProgressServices.service_request_id = utilityServiceRequest.id
            LEFT OUTER JOIN utilityServiceProviders on utilityServiceProviders.id = utilityProgressServices.service_provider_id
           LEFT JOIN utilityStatus on utilityStatus.id = utilityServiceRequest.current_status
            where utilityServiceRequest.utility_provider_id = ? 
            AND utilityServiceRequest.current_status= utilityProgressServices.service_request_status
            AND customers.is_deleted = 'false' 
            AND customers.is_active = 'true'

            AND utilityServiceSubTypes.id=utilityServiceRequest.utility_service_sub_type_id
            AND subUtilities.utility_id=utilities.id
            AND (request_number LIKE ? OR  customers.mobile LIKE ? OR utilityServiceProviders.first_name like ? OR customers.first_name like ?) and utilityServiceRequest.is_deleted='false' group by utilityServiceRequest.id order by utilityServiceRequest.id DESC`;

      para = [
        login_user_id,
        "%" + req.body.search + "%",
        "%" + req.body.search + "%",
        "%" + req.body.search + "%",
        "%" + req.body.search + "%",
      ];
    }

    conn.query(quer, para, (err, customer) => {
      console.log("=-=-=-", err);
      if (err) {
        res.status(400).send({ err: err });
        return false;
      } else {
        res.status(200).send({ success: true, data: customer });
      }
    });
  });
};
/*
 * @author: Sanjeev
 * @api url : /utilityServiceRequest/add
 * @description: This function is used to save the utilityServiceRequest
 *  @type : POST
 * @Prameters : service_id ,customer_id , date , time ,service_provider_id ,note */
controller.save = async (req, res) => {
  try {
    var provider_id_with_admin_id = await managetServiceRequest.get_provider_of_admin(
      req
    );
  } catch (error) {
    console.log(error);
    res.status(400).send(error);
    return false;
  }

  const { id } = req.params;
  data = req.body;

  let admin_full_name = data.admin_full_name;
  let customer_full_name = data.customer_full_name;
  let customer_email = data.customer_email;
  let admin_email = data.admin_email;
  delete data.admin_full_name;
  delete data.customer_full_name;
  delete data.customer_email;
  delete data.admin_email;
  console.log("body-->", data);
  var newCustomer = {};
  var ProgressService = {};

  newCustomer.customer_id = req.body.customer_id;
  newCustomer.service_type_id = req.body.service_type_id;
  newCustomer.cost = req.body.cost;
  newCustomer.customer_note = req.body.customer_note;
  (newCustomer.utility_id = req.body.utility_id),
    (newCustomer.subUtility_id = req.body.subUtility_id),
    (newCustomer.utility_service_sub_type_id =
      req.body.utility_service_sub_type_id),
    (newCustomer.date = req.body.date);
  newCustomer.current_status = 2;
  (newCustomer.time = req.body.time),
    (newCustomer.etime = req.body.etime),
    (newCustomer.created_by_user_type = req.headers.decoded.user_type),
    //newCustomer.utility_provider_id = req.headers.decoded.user_id
    (newCustomer.utility_provider_id = provider_id_with_admin_id),
    (newCustomer.created_by = req.headers.decoded.user_id);
  newCustomer.created_at = moment().format("YYYY-MM-DD HH:mm:ss");
  newCustomer.modified_at = moment().format("YYYY-MM-DD HH:mm:ss");
  console.log("------------------>", req.body.customer_id);
  console.log("new customer===>", newCustomer);

  ProgressService.provider_notes = req.body.provider_note;
  //created by provider
  newCustomer.created_by = req.headers.decoded.user_id;
  ProgressService.service_provider_id = req.body.service_provider_id;
  ProgressService.service_request_status = 2;

  ProgressService.created_at = moment().format("YYYY-MM-DD HH:mm:ss");
  ProgressService.modified_at = moment().format("YYYY-MM-DD HH:mm:ss");

  req.getConnection((err, conn) => {
    conn.query(
      'select request_number from utilityServiceRequest where request_number != ""  ORDER BY  request_number DESC limit 1',
      data,
      (err, r_number) => {
        console.log("new err===>", err);
        if (err) {
          res.status(400).send({ error: err });
          return false;
        }

        if (r_number.length > 0) {
          var reqNumber = Number(r_number[0].request_number);
          newCustomer.request_number = Number(reqNumber) + 1;
        } else {
          newCustomer.request_number = 10000;
        }
        conn.query(
          "INSERT INTO utilityServiceRequest set ?",
          [newCustomer],
          (err, rows) => {
            console.log("new err===>", err);
            if (err) {
              res.status(400).send({ error: err });
              return false;
            }
            console.log("-----------------------sdsdsdsdsdsd", rows);
            ProgressService.service_request_id = rows.insertId;
            // notification.save_notification(req, 1, data.utility_provider_id, 'provider', login_user_id, 'customer')

            conn.query(
              "insert into utilityProgressServices set ? ",
              [ProgressService],
              (err, rows) => {
                console.log("new err===>", err);
                if (err) {
                  res.status(400).send({ error: err });
                  return false;
                }
                let serviceRequestData = {
                  num: newCustomer.request_number,
                  date: req.body.date,
                  time: req.body.time,
                  admin_full_name: admin_full_name,
                  customer_full_name: customer_full_name,
                };
                emailService.sendEmail(
                  req,
                  res,
                  2,
                  admin_email,
                  null,
                  null,
                  serviceRequestData,
                  (finalRes) => {
                    let serviceRequestData1 = {
                      num: newCustomer.request_number,
                      date: req.body.date,
                      time: req.body.time,
                      admin_full_name: customer_full_name,
                      customer_full_name:
                        "you by " + "<b>" + admin_full_name + "</b>",
                    };
                    emailService.sendEmail(
                      req,
                      res,
                      2,
                      customer_email,
                      null,
                      null,
                      serviceRequestData1,
                      (finalRes1) => {
                        res.status(200).send({ success: true, data: rows });
                      }
                    );
                  }
                );
              }
            );
          }
        );
      }
    );
  });
};

controller.updateRequestStatus = async (req, res) => {
  const id = Buffer.from(req.body.id, "base64").toString();
  let data = req.body;
  req.getConnection((err, conn) => {
    conn.query(
      "UPDATE utilityServiceRequest set current_status=7 where id = ?",
      [id],
      (err, rows) => {
        if (err) {
          res.status(400).send({ error: err });
          return false;
        }
        var ProgressService = {};
        ProgressService.service_request_status = 7;
        ProgressService.provider_notes = "";
        ProgressService.service_provider_id = 0;
        ProgressService.service_request_id = id;
        ProgressService.notes = data.notes;
        ProgressService.created_at = new Date();

        conn.query(
          "insert into utilityProgressServices set ? ",
          [ProgressService],
          (err, rows) => {
            if (err) {
              res.status(400).send({ error: err });
              return false;
            }
            res.status(200).send({ success: true, data: rows });
          }
        );
      }
    );
  });
};

/*
 * @author: Sanjeev
 * @api url : /utilityServiceRequest/markJobDone
 * @description: This function is used to save the utilityServiceRequest
 *  @type : POST
 * @Prameters : service_id ,customer_id , date , time ,service_provider_id ,note */
controller.markJobDone = async (req, res) => {
  const id = Buffer.from(req.body.id, "base64").toString();
  let data = req.body;
  console.log("body-->", data, id);
  var serviceRequest = {};
  serviceRequest.current_status = 4;
  serviceRequest.cost = data.cost;

  req.getConnection((err, conn) => {
    conn.query(
      "UPDATE utilityServiceRequest set ? where id = ?",
      [serviceRequest, id],
      (err, rows) => {
        if (err) {
          res.status(400).send({ error: err });
          return false;
        }
        var ProgressService = {};
        ProgressService.service_request_status = 3;
        ProgressService.provider_notes = data.provider_notes;
        ProgressService.service_provider_id = data.service_provider_id;
        ProgressService.service_request_id = id;
        ProgressService.notes = data.notes;
        ProgressService.created_at = new Date();

        conn.query(
          "insert into utilityProgressServices set ? ",
          [ProgressService],
          (err, rows) => {
            if (err) {
              res.status(400).send({ error: err });
              return false;
            }
            var ProgressService2 = {};
            ProgressService2.service_request_status = 4;
            ProgressService2.provider_notes = data.provider_notes;
            ProgressService2.service_provider_id = data.service_provider_id;
            ProgressService2.service_request_id = id;
            ProgressService2.notes = data.description;
            ProgressService2.created_at = new Date();
            conn.query(
              "insert into utilityProgressServices set ? ",
              [ProgressService2],
              (err, rows) => {
                if (err) {
                  res.status(400).send({ error: err });
                  return false;
                }
                res.status(200).send({ success: true, data: rows });
              }
            );
          }
        );
      }
    );
  });
};

/*
 * @author: Sanjeev
 * @api url : /utilityServiceRequest/edit/:id
 * @description: This function is used to get single utilityServiceRequest information
 *  @type : GET
 * @Prameters : */
controller.edit = (req, res) => {
  const { id } = req.params;
  var new_id = Buffer.from(id, "base64").toString();
  req.getConnection((err, conn) => {
    if (err) {
      res.status(400).send({ error: err });
    }

    let query = `SELECT *,utilityServiceProviderRating.rating,utilityServiceProviderRating.comments, utilityServiceProviders.first_name as utilityServiceProviders_first_name, utilityServiceProviders.last_name as utilityServiceProviders_last_name , utilityStatus.status as taskStatus, utilityServiceRequest.id as id,utilityProgressServices.service_provider_id,utilityProgressServices.service_request_status, customers.first_name as first_name,customers.last_name as last_name, customers.email as cust_email, customers.address as cust_address, customers.city as cust_city, customers.state as cust_state, customers.country as cust_country, customers.zip as cust_zip, customers.mobile as cust_mobile,utilities.title as utilityServiceTypes_title,subUtilities.title as subUtilityServiceTypes_title,utilityServiceSubTypes.sub_category_title,utilityServiceSubTypes.hourly_rate as jobType,utilityServiceSubTypes.flat_rate as optionCost    FROM utilityServiceRequest INNER JOIN utilities on utilities.id = utilityServiceRequest.utility_id 
        INNER JOIN subUtilities on subUtilities.id = utilityServiceRequest.subUtility_id
       INNER JOIN utilityProviders on utilityProviders.id = utilityServiceRequest.utility_provider_id 
       INNER JOIN utilityServiceTypes on utilityServiceTypes.id = utilityServiceRequest.service_type_id 
       INNER JOIN utilityServiceSubTypes on utilityServiceSubTypes.service_type_id = utilityServiceTypes.id 
       INNER JOIN customers on customers.id = utilityServiceRequest.customer_id
       LEFT JOIN utilityProgressServices on utilityProgressServices.service_request_id = utilityServiceRequest.id
       LEFT JOIN utilityServiceProviders on utilityServiceProviders.id = utilityProgressServices.service_provider_id
       LEFT JOIN utilityStatus on utilityStatus.id = utilityServiceRequest.current_status
       LEFT JOIN utilityServiceProviderRating on utilityServiceProviderRating.service_request_id=utilityServiceRequest.id
       where utilityServiceRequest.id = ? 
       AND utilityServiceSubTypes.id=utilityServiceRequest.utility_service_sub_type_id AND subUtilities.utility_id=utilities.id AND utilityServiceRequest.current_status = utilityProgressServices.service_request_status `;
    conn.query(query, [new_id], (err, rows) => {
      //

      console.log("ssss", err, JSON.stringify(rows));
      if (err) {
        res.status(400).send({ error: err });
        return false;
      }
      res.status(200).send({ success: true, data: rows[0] });
    });
  });
};

/*
 * @author: Sanjeev
 * @api url : /utilityServiceRequest/getServiceRequestHistory/:id
 * @description: This function is used to get single utilityServiceRequest information
 *  @type : GET
 * @Prameters : */
controller.getServiceRequestHistory = (req, res) => {
  const { id } = req.params;
  var new_id = Buffer.from(id, "base64").toString();
  req.getConnection((err, conn) => {
    if (err) {
      res.status(400).send({ error: err });
    }
    let query = `SELECT * FROM utilityProgressServices LEFT JOIN utilityStatus on 
        utilityStatus.id = utilityProgressServices.service_request_status
       where utilityProgressServices.service_request_id = ?`;
    conn.query(query, [new_id], (err, rows) => {
      if (err) {
        res.status(400).send({ error: err });
        return false;
      }
      res.status(200).send({ success: true, data: rows });
    });
  });
};

/*
 * @author: Sanjeev
 * @api url : /utilityServiceRequest/update/1
 * @description: This function is used to update the customer with id
 * @Prameters : service_id ,customer_id , date , time ,service_provider_id ,note
 *  @type : POST
 */
controller.update = (req, res) => {
  const { id } = req.params;
  data = req.body;
  console.log("body-->", data);
  var newCustomer = {};
  var ProgressService = {};
  newCustomer.date = moment(req.body.date).format("YYYY-MM-DD");
  newCustomer.time = req.body.time;
  newCustomer.etime = req.body.etime;
  newCustomer.customer_id = req.body.customer_id;
  newCustomer.current_status = 2;
  newCustomer.cost = req.body.cost;
  ProgressService.service_request_id = id;
  ProgressService.service_provider_id = req.body.service_provider_id;
  ProgressService.service_request_status = 2;
  ProgressService.provider_notes = req.body.provider_notes;
  ProgressService.created_at = new Date();

  req.getConnection((err, conn) => {
    conn.query(
      "UPDATE utilityServiceRequest set ? where id = ?",
      [newCustomer, id],
      (err, rows) => {
        console.log("error=", err);
        if (err) {
          res.status(400).send({ error: err });
          return false;
        }

        conn.query(
          "insert into utilityProgressServices set ? ",
          [ProgressService],
          (err, rows) => {
            console.log("error=", err);
            if (err) {
              res.status(400).send({ error: err });
              return false;
            }

            /*********************notification start ************************************/
            /**@notifiction prameters template : req,notification_id,to_id,to_type,from,from_type */
            /**for @customer */
            notification.save_notification(
              req,
              2,
              newCustomer.customer_id,
              "customer",
              req.headers.decoded.user_id,
              "provider"
            );
            /*for service @ provider */
            notification.save_notification(
              req,
              3,
              req.body.service_provider_id,
              "service_provider",
              req.headers.decoded.user_id,
              "provider"
            );
            /*********************notification end **********************************/

            res.status(200).send({ success: true, data: rows });
          }
        );
      }
    );
  });
};
/*
 * @author: Sanjeev
 * @api url : /utilityServiceRequest/multi_activeInactive
 * @description: This function is used to delete ,active and deavtivate utilityServiceRequest
 * @Prameters : dataId in array e.g [1,2] and action = delete or activate or deactivate
 * @type : POST
 */
controller.multi_activeInactive = (req, res) => {
  console.log("multiUpdate sanjeev-----", req.body);
  var selectedIds = [];
  if (req.body.dataId.length > 0) {
    for (let i = 0; i < req.body.dataId.length; i++) {
      selectedIds.push(Buffer.from(req.body.dataId[i], "base64").toString());
    }
  }

  console.log("=====selectedIds====", selectedIds);
  if (req.body.action == "delete") {
    console.log("in delete");

    req.getConnection((err, connection) => {
      connection.query(
        "update utilityServiceRequest set is_deleted=? where id IN(?)",
        ["true", selectedIds],
        (err, result) => {
          if (err) {
            res.json(err);
            res.status(500).json({ status: "error", error: err });
          }
          res.status(200).send(result);
        }
      );
    });
  } else if (req.body.action == "activate") {
    console.log("deactive---------->", req.body.dataId);
    req.getConnection((err, connection) => {
      connection.query(
        "update utilityServiceRequest set is_active=? where id IN(?)",
        ["true", selectedIds],
        (err, result) => {
          if (err) {
            res.json(err);
            res.status(500).json({ status: "error", error: err });
          }
          res.status(200).send(result);
        }
      );
    });
  } else if (req.body.action == "deactivate") {
    console.log("deactive---------->", req.body.dataId);
    req.getConnection((err, connection) => {
      connection.query(
        "update utilityServiceRequest set is_active=? where id IN(?)",
        ["false", selectedIds],
        (err, result) => {
          if (err) {
            res.json(err);
            res.status(500).json({ status: "error", error: err });
          }
          res.status(200).send(result);
        }
      );
    });
  } else {
  }
};

/*
 * @api url : /utilityServiceRequest/getUtilityServiceTypes?keyword=
 * @description: It Contain functions list the getUtilityServiceTypes and searh with keyword
 *  @type : GET
 * @author: Sanjeev
 */
controller.getUtilityServiceTypes = (req, res) => {
  req.getConnection((err, conn) => {
    if (err) {
      res.status(400).send({ err: err });
    }
    console.log("asdasdsad");
    conn.query(
      "SELECT * FROM utilityServiceTypes where (title LIKE ? or description LIKE ? ) and is_deleted = ?",
      ["%" + req.query.keyword + "%", "%" + req.query.keyword + "%", "false"],
      (err, customer) => {
        if (err) {
          res.status(400).send({ err: err });
        }

        res.status(200).send({ success: true, data: customer });
      }
    );
  });
};

/*
 * @api url : /utilityServiceRequest/listServiceStatus
 * @description: It Contain functions list the getUtilityServiceTypes and searh with keyword
 *  @type : GET
 * @author: Sanjeev
 */
controller.listServiceStatus = (req, res) => {
  req.getConnection((err, conn) => {
    if (err) {
      res.status(400).send({ err: err });
    }
    conn.query("SELECT * FROM utilityStatus", (err, status) => {
      if (err) {
        res.status(400).send({ err: err });
      }

      res.status(200).send({ success: true, data: status });
    });
  });
};

/*
 * @api url : /utilityServiceRequest/getserviceProviders?keyword=
 * @description: It Contain functions list the getserviceProviders and searh with keyword
 *  @type : POST
 * @author: Sanjeev
 */
controller.getserviceProviders = async (req, res) => {
  console.log(req.body);
  try {
    var provider_id_with_admin_id = await managetServiceRequest.get_provider_of_admin(
      req
    );
  } catch (error) {
    res.status(400).send(error);
    return false;
  }
  req.getConnection((err, conn) => {
    req.body.reqDate = moment(req.body.reqDate).format("YYYY-MM-DD");
    let currentTime = moment().format("HH:mm:ss");
    console.log("============rsmssnnananan=======", req.body, currentTime);

    if (req.body.AvailableFrom > currentTime) {
      console.log("--------less than");
    } else {
      console.log("--------greater than");
    }

    query = `Select usp.id,usp.first_name,usp.last_name from utilityServiceProviders as usp LEFT JOIN utilityProviderServices as ups on usp.id=ups.service_provider_id LEFT JOIN utilityServiceProviderAvailability as uspa on uspa.service_provider_id=ups.service_provider_id where ups.service_id = ? AND usp.id IN (select service_provider_id from utilityServiceProviderAvailability where ((day_index=?) or (day_index = ? AND (availableFrom < ? and availableTo > ?)))) 
        and usp.id NOT IN (select utilityProgressServices.service_provider_id from utilityServiceRequest LEFT JOIN utilityProgressServices on utilityServiceRequest.id = utilityProgressServices.service_request_id where (utilityServiceRequest.current_status > 1 and utilityServiceRequest.current_status < 4) and utilityServiceRequest.date=? and ? < ? and utilityServiceRequest.current_status=utilityProgressServices.service_request_status and utilityProgressServices.service_provider_id>0  and utilityServiceRequest.is_deleted='false' and utilityServiceRequest.is_active='true')         
        AND usp.utility_provider_id = ? and usp.is_deleted='false' and usp.is_active='true'  group by usp.id`;

    conn.query(
      query,
      [
        req.body.service_id,
        req.body.day_index,
        req.body.day_index,
        req.body.AvailableFrom,
        req.body.AvailableTo,
        req.body.reqDate,
        req.body.AvailableFrom,
        currentTime,
        provider_id_with_admin_id,
      ],
      (err, customer) => {
        console.log("---errrorrr", err, JSON.stringify(customer));

        if (err) {
          res.status(400).send({ err: err });
          return false;
        }
        res.status(200).send({ success: true, data: customer });
      }
    );
  });
};

/*
 * @api url : /utilityServiceRequest/calendarInDates
 * @description:
 *  @type : post
 * @author: Sanjeev
 */
controller.calendarInDates = async (req, res) => {
  const id = req.body.service_provider_id;
  var new_id = Buffer.from(id, "base64").toString();
  console.log(
    "req.body.start_date==>",
    req.body.start_date,
    "req.body.end===>",
    req.body.end_date
  );
  try {
    var provider_id_with_admin_id = await managetServiceRequest.get_provider_of_admin(
      req
    );
  } catch (error) {
    console.log(error);
    res.status(400).send(error);
    return false;
  }
  var login_provider_id = provider_id_with_admin_id;
  req.getConnection((err, conn) => {
    if (req.body.service_request_type == "job") {
      var service_request_status = "";
      if (req.body.service_request_status) {
        service_request_status = `AND utilityServiceRequest.current_status = ${req.body.service_request_status}`;
      }
      var query = `Select *, (SELECT DAYNAME(utilityServiceRequest.date)) as day_name,
            utilityServiceRequest.date as customer_date, 
            utilityServiceRequest.id as id,
            customers.first_name as customer_first_name,
            customers.last_name as customer_last_name
            ,utilityStatus.status as taskStatus,utilityStatus.id as taskStatusId,
            utilityServiceTypes.title as utilityServiceTypes_title
            from  utilityServiceRequest 
            LEFT JOIN customers on customers.id =  utilityServiceRequest.customer_id
            LEFT JOIN utilityProgressServices on utilityProgressServices.service_request_id =  utilityServiceRequest.id
            LEFT JOIN utilityServiceProviders on utilityServiceProviders.id =  utilityProgressServices.service_provider_id
            LEFT JOIN utilityServiceTypes on utilityServiceTypes.id = utilityServiceRequest.service_type_id 
            LEFT JOIN utilityStatus on utilityStatus.id = utilityServiceRequest.current_status
            where utilityServiceRequest.current_status = utilityProgressServices.service_request_status AND (utilityServiceRequest.utility_provider_id = ?  AND utilityProgressServices.service_provider_id = ?) and (utilityServiceRequest.date >= ? AND utilityServiceRequest.date <= ?) ${service_request_status}  ORDER BY utilityServiceRequest.id DESC`;
    } else if (req.body.service_request_type == "incident") {
      var service_request_status = "";
      if (req.body.service_request_status) {
        service_request_status = `AND utilityServiceRequest.current_status = ${req.body.service_request_status}`;
      }
      var query = `Select *, (SELECT DAYNAME(utilityServiceRequest.date)) as day_name,
            utilityServiceRequest.date as customer_date, 
            utilityServiceRequest.id as id,
            customers.first_name as customer_first_name,
            customers.last_name as customer_last_name,
            utilityServiceIncidents.created_at as utilityServiceIncidents_created_at,
            utilityServiceIncidents.id as utilityServiceIncidents_id,         
            (SELECT COUNT(utilityServiceIncidents_id)) as total_rows,
            utilityServiceTypes.title as utilityServiceTypes_title,utilityStatus.status as taskStatus,utilityStatus.id as taskStatusId
            from  utilityServiceRequest 
            LEFT JOIN customers on customers.id =  utilityServiceRequest.customer_id
            LEFT JOIN utilityProgressServices on utilityProgressServices.service_request_id =  utilityServiceRequest.id
            LEFT JOIN utilityServiceProviders on utilityServiceProviders.id =  utilityProgressServices.service_provider_id
            LEFT JOIN utilityServiceTypes on utilityServiceTypes.id = utilityServiceRequest.service_type_id 
            LEFT JOIN utilityStatus on utilityStatus.id = utilityServiceRequest.current_status
            INNER JOIN utilityServiceIncidents on utilityServiceIncidents.service_request_id = utilityServiceRequest.id
            where utilityServiceRequest.current_status = utilityProgressServices.service_request_status AND (utilityServiceRequest.utility_provider_id = ?  AND utilityProgressServices.service_provider_id = ?) and (utilityServiceRequest.date >= ? AND utilityServiceRequest.date <= ?) ${service_request_status}  `;
    } else if (req.body.service_request_type == "payment") {
      var service_request_status = "";
      if (req.body.service_request_status) {
        service_request_status = `AND utilityServiceRequest.current_status = ${req.body.service_request_status}`;
      }
      var query = `Select *, (SELECT DAYNAME(utilityServiceRequest.date)) as day_name,
            utilityServiceRequest.date as customer_date, 
            utilityServiceRequest.id as id,
            customers.first_name as customer_first_name,
            customers.last_name as customer_last_name,
            payments.created_at as payments_created_at,
            payments.id as payments_id,         
            (SELECT COUNT(payments_id)) as total_rows,
            utilityServiceTypes.title as utilityServiceTypes_title,utilityStatus.status as taskStatus,utilityStatus.id as taskStatusId
            from  utilityServiceRequest 
            LEFT JOIN customers on customers.id =  utilityServiceRequest.customer_id
            LEFT JOIN utilityProgressServices on utilityProgressServices.service_request_id =  utilityServiceRequest.id
            LEFT JOIN utilityServiceProviders on utilityServiceProviders.id =  utilityProgressServices.service_provider_id
            LEFT JOIN utilityServiceTypes on utilityServiceTypes.id = utilityServiceRequest.service_type_id 
            LEFT JOIN utilityStatus on utilityStatus.id = utilityServiceRequest.current_status
            INNER JOIN payments on payments.service_request_id = utilityServiceRequest.id
            where utilityServiceRequest.current_status = utilityProgressServices.service_request_status AND (utilityServiceRequest.utility_provider_id = ?  AND utilityProgressServices.service_provider_id = ?) and (utilityServiceRequest.date >= ? AND utilityServiceRequest.date <= ?)  ${service_request_status} `;
    }
    conn.query(
      query,
      [login_provider_id, new_id, req.body.start_date, req.body.end_date],
      (err, customer) => {
        if (err) {
          res.status(400).send({ err: err });
          return false;
        }
        res.status(200).send({ success: true, data: customer });
        // conn.query(total_rows, [login_provider_id, new_id, req.body.start_date, req.body.end_date], (err, total_rows_count) => {
        //     if (err) {
        //         res.status(400).send({ err: err })
        //         return false
        //     }
        //     res.status(200).send({ "success": true, data: customer })
        // });
      }
    );
  });
};
module.exports = controller;
