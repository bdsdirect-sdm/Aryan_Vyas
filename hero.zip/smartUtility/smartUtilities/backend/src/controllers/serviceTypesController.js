const controller = {};
const managetServiceRequest = require('../services/manageAdminService')

controller.getserviceType = async (req, res) => {
    try {
        var provider_id_with_admin_id = await managetServiceRequest.get_provider_of_admin(req)
    } catch (error) { 
        console.log(error)
       res.status(400).send(error)
       return false
    }
    //console.log("rAN--",req.query)
    console.log('provider_id_with_admin_id--->',provider_id_with_admin_id)    
    let utility_provider_id=provider_id_with_admin_id;
    if(req.query.is_active){
        req.getConnection((err, conn) => {
            conn.query("SELECT utilityServiceTypes.id,utilityServiceTypes.is_active,utilityServiceTypes.title as serviceTypeTitle,subUtilities.title as subcategory,utilityServiceTypes.seach_keyword,utilities.title as category FROM utilityServiceTypes LEFT JOIN utilities on utilityServiceTypes.utilitY_id=utilities.id  LEFT JOIN subUtilities on subUtilities.id=utilityServiceTypes.subUtility_id  where utilityServiceTypes.is_active='true' and subUtilities.utilitY_id=utilities.id  and utilityServiceTypes.is_deleted='false' and utilityServiceTypes.utility_provider_id=? order by utilityServiceTypes.id DESC",[utility_provider_id], (err, result) => {
                if (err) {
                    res.json(err);
                    res.status(500).json({status: 'error',error:err});
                }
                console.log("-=-=-result is active=--=",JSON.stringify(result));
                res.status(200).send(result)
            });
        });
    }else{
        req.getConnection((err, conn) => {
            conn.query("SELECT utilityServiceTypes.id,utilityServiceTypes.is_active,utilityServiceTypes.title as serviceTypeTitle,subUtilities.title as subcategory,utilityServiceTypes.seach_keyword,utilities.title as category FROM utilityServiceTypes LEFT JOIN utilities on utilityServiceTypes.utilitY_id=utilities.id LEFT JOIN subUtilities on subUtilities.id=utilityServiceTypes.subUtility_id where utilityServiceTypes.is_deleted='false' and subUtilities.utilitY_id=utilities.id  and utilityServiceTypes.utility_provider_id=? order by utilityServiceTypes.id DESC",[utility_provider_id],(err, result) => {
                console.log("-=-=-result=--=",err,JSON.stringify(result));
                if (err) {
                    res.json(err);
                    res.status(500).json({status: 'error',error:err});
                }
                
                res.status(200).send(result)
            });
        });
    }
};

controller.getserviceTypeDetails = (req, res) => {
    console.log("-=-=rgetserviceTypeDetails-==-",req.query.id);
    req.query.id=Buffer.from(req.query.id, 'base64').toString();
    req.getConnection((err, connection) => {
        connection.query('SELECT utilityServiceTypes.*,utilityServiceSubTypes.sub_category_title,utilityServiceSubTypes.hourly_rate,utilityServiceSubTypes.flat_rate FROM utilityServiceTypes LEFT JOIN utilityServiceSubTypes on utilityServiceTypes.id=utilityServiceSubTypes.service_type_id where utilityServiceTypes.id=?  and utilityServiceTypes.is_deleted=?', 
            [req.query.id,'false'], (err, result) => {
                 console.log("-----",err,result);
          if (err) {
                res.json(err);
                res.status(500).json({status: 'error',error:err});
            }
           
            let subServices=[];

           
            for(let i=0;i<result.length;i++){
                subServices.push({
                      title:result[i].sub_category_title,
                      hourly_rate:result[i].hourly_rate,
                      flat_rate:result[i].flat_rate
                    })
            }
            let output={};
            output.subServices=subServices;
            output.data=result;
            res.status(200).send(output)
        });
    });
};

controller.addserviceType = async (req, res) => {
   console.log("-=-=-=-=--addserviceType.=---=--",JSON.stringify(req.body));
    try {
        var provider_id_with_admin_id = await managetServiceRequest.get_provider_of_admin(req)
    } catch (error) { 
        console.log(error)
    res.status(400).send(error)
    return false
    }
    let utility_id=req.body.utility_id;
    let utility_provider_id=provider_id_with_admin_id;
    req.getConnection((err, connection) => {

        connection.query('SELECT * FROM utilityServiceTypes where subUtility_id=? and is_deleted=? and utility_id =? and utility_provider_id=?', 
                        [req.body.subUtility_id,'false',utility_id,utility_provider_id], (err, result) => {
          if (err) {
                res.json(err);
                res.status(500).json({status: 'error',error:err});
            }

        if(result.length>0){
            res.status(300).json({status: 'error',msg:'Service already exists.Please select another'});
            return false
        }

        const query = connection.query('insert into utilityServiceTypes(title,hourly_rate,flat_rate,seach_keyword,utility_id,utility_provider_id,subUtility_id) values(?,?,?,?,?,?,?)', [req.body.title,req.body.hourly_rate,req.body.flat_rate,req.body.seach_keyword,utility_id,utility_provider_id,req.body.subUtility_id], (err, result) => {
            console.log("-=-=-=-=--addserviceType.=-err--=--",err);
             if (err) {
                res.json(err);
                res.status(500).json({status: 'error',error:err});
            }
            let serviceTypeId=result.insertId;
            console.log("-=-=-=-=--serviceTypeId.=-err--=--",serviceTypeId,req.body.subServices);
            if(serviceTypeId && req.body.subServices.length>0){

                        var sql = "INSERT INTO utilityServiceSubTypes (service_type_id,sub_category_title,price,hourly_rate,flat_rate,is_active) VALUES ?";
                        var records = [];
                        for(let i=0;i<req.body.subServices.length;i++){
                           records.push([serviceTypeId,req.body.subServices[i].title,req.body.subServices[i].hourly_rate,req.body.subServices[i].hourly_rate,req.body.subServices[i].flat_rate,'true']);
                         }
                       
                        console.log("-=-=new rsqlecords-=",records);
                        const query = connection.query(sql, [records], (err, result) => {  
                        console.log("---=-=err-=-",err);                
                             if (err) {
                                res.json(err);
                                res.status(500).json({status: 'error',error:err});
                            }
                            res.status(200).send(result)
            
                        })     

                    }else{
                        res.status(200).send(result)
                    } 
            })
        })
    })
};

controller.updateserviceType  = async (req, res) => {  
    console.log("-=-=-=-=--updateserviceType.=---=--",JSON.stringify(req.body))

         try {
            var provider_id_with_admin_id = await managetServiceRequest.get_provider_of_admin(req)
            } catch (error) { 
                console.log(error)
            res.status(400).send(error)
            return false
            }
            let utility_id=req.body.utility_id;
            let utility_provider_id=provider_id_with_admin_id;

            var dbsubCategories= req.body.dbsubCategories;

             req.getConnection((err, conn) => {


                conn.query('SELECT * FROM utilityServiceTypes where subUtility_id=? and is_deleted=? and id=? and utility_id=? and utility_provider_id=?', 
                        [req.body.subUtility_id,'false',req.body.id,utility_id,utility_provider_id], (err, result) => {
                            console.log("------errrr",err);
                      if (err) {
                            res.json(err);
                            res.status(500).json({status: 'error',error:err});
                            return false
                        }

                    if(result.length>0){
                       // res.status(300).json({status: 'error',msg:'Service already exists'});
                       // return false
                    }
                conn.query("update utilityServiceTypes set title=?,description=?,hourly_rate=?,flat_rate=?,seach_keyword=?,subUtility_id=? where id=?", [req.body.title,req.body.description,req.body.hourly_rate,req.body.flat_rate,req.body.seach_keyword,req.body.subUtility_id,req.body.id], (err, result) => {
                    if (err) {
                        res.json(err);
                        res.status(500).json({status: 'error',error:err});
                        return false
                    }
                    let serviceTypeId=req.body.id;
                   if(serviceTypeId && req.body.subServices.length>0){

                    let deleteCats=[];
                    if(dbsubCategories && dbsubCategories.length>0){

                        var tempdbsubCategories=[];
                        for(let i=0;i<dbsubCategories.length;i++){
                            tempdbsubCategories.push(dbsubCategories[i].title)
                        }

                        var tempsubServices=[];
                        for(let i=0;i<req.body.subServices.length;i++){
                            tempsubServices.push(req.body.subServices[i].title)
                        }

                        deleteCats= arr_diff(tempsubServices,tempdbsubCategories);
                    }
                    console.log("===req.body.subServices==",req.body.subServices);
                    console.log("===dbsubCategories==",dbsubCategories);
                    console.log("===dbcats==",deleteCats);
                   // return false;
                    updateSubcategoriesConditionaly(0, req.body.subServices, conn, serviceTypeId, finalRes => {
                        if(finalRes && finalRes.success) {

                            if (deleteCats && deleteCats.length > 0) {
                                deleteSubcategoriesConditionaly(0, deleteCats, conn, serviceTypeId, finalRes2 => {
                                    if(finalRes2 && finalRes2.success) {        
                                        
                                        res.status(200).send({ "success": true, data: [] })
                                    } else {
                                        res.status(400).send({ "success": false, error: finalRes2.error })
                                    }
                                    
                                    });
                                }else{
                                    res.status(200).send({ "success": true, data: [] })
                                }

                        } else {
                            res.status(400).send({ "success": false, error: finalRes.error })
                        }
                        
                        });

                    }else{
                        res.status(200).send(result)
                    } 
                });
            });
     });
};

function arr_diff (a1, a2) {

    var a = [], diff = [];

    for (var i = 0; i < a1.length; i++) {
        a[a1[i]] = true;
    }

    for (var i = 0; i < a2.length; i++) {
        if (a[a2[i]]) {
            delete a[a2[i]];
        } else {
            a[a2[i]] = true;
        }
    }

    for (var k in a) {
        diff.push(k);
    }

    return diff;
}



function updateSubcategoriesConditionaly(i, data, conn, serviceTypeId, callback) {
	if (i < data.length) {
		conn.query('select * from utilityServiceSubTypes where service_type_id = ? and sub_category_title=?', [serviceTypeId, data[i].title], (err, rows) => {
			console.log("=-=-updateSubcategoriesConditionaly=--=", err, rows);

			if (rows.length == 0) {

                var sql = "INSERT INTO utilityServiceSubTypes (service_type_id,sub_category_title,price,hourly_rate,flat_rate,is_active) VALUES ?";
                var records = [];
                records.push([serviceTypeId,data[i].title,data[i].hourly_rate,data[i].hourly_rate,data[i].flat_rate,'true']);
				console.log("-=-=new rsqlecords-=", records);
				let query = conn.query(sql, [records], (err, result) => {
					console.log("---=-=essssrr-=-", err);
					if (err) {
						let finalData = {
							success : false,
							error: err
						}
						callback(finalData)
					}
					i = i + 1;
					updateSubcategoriesConditionaly(i, data, conn, serviceTypeId, callback)
				});
			}else{
                i = i + 1;
                updateSubcategoriesConditionaly(i, data, conn, serviceTypeId, callback)
            }
		});

	} else {
		let finalData = {
			success : true,
			data: data
		}
		callback(finalData);
	}
}

function deleteSubcategoriesConditionaly(i, data, conn, id, callback) {
	if (i < data.length) {
		conn.query('delete from utilityServiceSubTypes where service_type_id = ? and sub_category_title=?', [id, data[i]], (err, rows) => {
                    
                    i = i + 1;
                    deleteSubcategoriesConditionaly(i, data, conn, id, callback);
                    
				});

	} else {
		let finalData = {
			success : true,
			data: data
		}
		callback(finalData);
	}
}

controller.findserviceType = async (req, res) => {
   console.log("findserviceType-----",req.body);
    try {
        var provider_id_with_admin_id = await managetServiceRequest.get_provider_of_admin(req)
    } catch (error) { 
        console.log(error)
    res.status(400).send(error)
    return false
    }

    let utility_provider_id = provider_id_with_admin_id;
    req.getConnection((err, conn) => {

        conn.query('SELECT utilityServiceTypes.id,utilityServiceTypes.is_active,utilityServiceTypes.title as serviceTypeTitle,utilityServiceTypes.hourly_rate,utilityServiceTypes.flat_rate,utilityServiceTypes.seach_keyword,utilities.title as category FROM utilityServiceTypes LEFT JOIN utilities on utilityServiceTypes.utilitY_id=utilities.id where (utilityServiceTypes.title LIKE ? or utilities.title LIKE ?) and utilityServiceTypes.is_deleted=? and utilityServiceTypes.utility_provider_id=?  order by utilityServiceTypes.id DESC' , ['%'+req.body.keyword+'%','%'+req.body.keyword+'%','false',utility_provider_id], (err, result) => {
             if (err) {
                res.json(err);
                res.status(500).json({status: 'error',error:err});
            }
            res.status(200).send(result)
        });
    });
};

controller.deleteServiceType = (req, res) => {
    console.log("deleteServiceType-----",req.body);
    req.body.id=Buffer.from(req.body.id, 'base64').toString();
    req.getConnection((err, connection) => {
        connection.query('update utilityServiceTypes set is_deleted=? where id =?', ['true',req.body.id], (err, result) => {
             if (err) {
                res.json(err);
                res.status(500).json({status: 'error',error:err});
            }
            res.status(200).send(result)
        });
    });
};


controller.multiUpdate = (req, res) => {
    console.log("multiUpdate-----",req.body);
    let encodedIds=[];
    for(let i=0;i<req.body.dataId.length;i++){
        encodedIds.push(Buffer.from(req.body.dataId[i], 'base64').toString())
    }
    req.body.dataId=encodedIds;
    if(req.body.action=='delete'){
        req.getConnection((err, connection) => {
            connection.query('update utilityServiceTypes set is_deleted=? where id IN(?)', 
                ['true',req.body.dataId], (err, result) => {
                 if (err) {
                    res.json(err);
                    res.status(500).json({status: 'error',error:err});
                }
                res.status(200).send(result)
            });
        });
    }else if(req.body.action=='activate'){
        req.getConnection((err, connection) => {
            connection.query('update utilityServiceTypes set is_active=? where id IN(?)', 
                ['true',req.body.dataId], (err, result) => {
                 if (err) {
                    res.json(err);
                    res.status(500).json({status: 'error',error:err});
                }
                res.status(200).send(result)
            });
        });
    }else if(req.body.action=='deactivate'){
        req.getConnection((err, connection) => {
            connection.query('update utilityServiceTypes set is_active=? where id IN(?)', 
                ['false',req.body.dataId], (err, result) => {
                 if (err) {
                    res.json(err);
                    res.status(500).json({status: 'error',error:err});
                }
                res.status(200).send(result)
            });
        });
    }else{
        
    }
};

module.exports = controller;
