const controller = {};
const manageAdminService = require('../services/manageAdminService')
const emailService = require('../services/emailService')
/*
 * @api url : /subscriptions/list?keyword=
 * @description: list subscriptions with search keyword
 *  @type : GET
 * @author: Sanjeev
 */
controller.list = async (req, res) => {
    console.log(req.query.keyword)
    req.getConnection((err, conn) => {
        conn.query('SELECT * FROM subscriptions where title LIKE ? and is_deleted=? ORDER BY id DESC;', ['%' + req.query.keyword + '%', 'false'], (err, subscriptions) => {
            if (err) {
                res.status(400).send({ err: err })
                return false
            }
            res.status(200).send({ "success": true, data: subscriptions })
        });
    });
};
/*
 * @author: Sanjeev
 * @api url : /subscriptions/save
 * @description: This function is used to save the subscriptions
 * @type : POST
 * @Prameters : title , description
*/
controller.save = async (req, res) => {
    const data = req.body;
    data['is_deleted'] = "false"
    data['is_active'] = "true"
    data['created_at'] = new Date;
    data['modified_at'] = new Date;
    console.log(req.body)
    req.getConnection((err, connection) => {

        connection.query('SELECT * FROM subscriptions where title=? and is_deleted=? ', 
                        [data['title'],'false'], (err, result) => {
          if (err) {
                res.json(err);
                res.status(500).json({status: 'error',error:err});
            }

        if(result.length>0){
            res.status(300).json({status: 'error',msg:'Subscription title already exists'});
            return false
        }


        connection.query('INSERT INTO subscriptions set ?', data, (err, subscriptions) => {
            if (err) {
                res.status(400).send({ "error": err })
                return false
            }
            res.status(200).send({ "success": true, data: subscriptions })
        })
    })
    })
};
/*
 * @author: Sanjeev
 * @api url :/subscriptions/edit/:id
 * @description: This function is used to get single subscriptions information
 * @type : GET
 * @Prameters : */
controller.edit = (req, res) => {
    var id = req.params.id
    id = Buffer.from(id, 'base64').toString();
    
    req.getConnection((err, conn) => {
        if (err) {
            res.status(400).send({ 'err': err })
            return false
        }
        conn.query("SELECT * FROM subscriptions WHERE id = ?", [id], (err, rows) => {
            if (err) {
                res.status(400).send({ "err": err })
                return false
            }
            res.status(200).send({ success: true, data: rows[0] })
        })
    })
}

/*
 * @author: Sanjeev
 * @api url : /subscriptions/update
 * @description: This function is used to update the subscriptions with id
 * @Prameters : title or description
 *  @type : POST
 */
controller.update = (req, res) => {
    var id = req.body.id
    delete (req.body.id)
    data = req.body
    const utility = req.body;
    //id = Buffer.from(id, 'base64').toString();
    req.getConnection((err, conn) => {
        conn.query('UPDATE subscriptions set ? where id = ?', [utility, id], (err, rows) => {
            if (err) {
                res.status(400).send({ "error": err })
                return false
            }
            res.status(200).send({ success: true, data: rows })
        });
    });
};
/*
 * @author: Sanjeev
 * @api url : /subscriptions/multi_activeInactive
 * @description: This function is used to delete ,active and deavtivate subscriptions
 * @Prameters : dataId in array e.g [1,2] and action = delete or activate or deactivate
 * @type : POST
 */
controller.multi_activeInactive = (req, res) => {
    console.log("multiUpdate sanjeev-----", req.body);
    let encodedIds = [];
    for (let i = 0; i < req.body.dataId.length; i++) {
        encodedIds.push(Buffer.from(req.body.dataId[i], 'base64').toString())
    }
    req.body.dataId = encodedIds;
    if (req.body.action == 'delete') {

        req.getConnection((err, connection) => {
            connection.query('update subscriptions set is_deleted=? where id IN(?)',
                ['true', req.body.dataId], (err, result) => {
                    if (err) {
                        res.json(err);
                        res.status(500).json({ status: 'error', error: err });
                    }
                    res.status(200).send(result)
                });
        });
    } else if (req.body.action == 'activate') {
        console.log('deactive---------->', req.body.dataId);
        req.getConnection((err, connection) => {
            if (err) {
                res.status(400).send({ err: err })
                return
            }
            connection.query('update subscriptions set is_active=? where id IN(?)',
                ['true', req.body.dataId], (err, result) => {
                    if (err) {
                        res.json(err);
                        res.status(500).json({ status: 'error', error: err });
                    }
                    res.status(200).send(result)
                });
        });
    } else if (req.body.action == 'deactivate') {
        console.log('deactive---------->', req.body.dataId);
        req.getConnection((err, connection) => {
            connection.query('update subscriptions set is_active=? where id IN(?)',
                ['false', req.body.dataId], (err, result) => {
                    if (err) {
                        res.json(err);
                        res.status(500).json({ status: 'error', error: err });
                    }
                    res.status(200).send(result)
                });
        });
    } else {

    }
};

module.exports = controller;
