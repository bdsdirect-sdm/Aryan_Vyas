/*
 * @file: icons.js
 * @description: this is for update permessins.
 */
exports.updateRolPer = function (req, res, id, module_id) {
      console.log("-------------module_id--->", module_id)
      req.getConnection((err, conn) => {
            if (err) {
                  res.status(400).send({ "error": err })
                  return false
            }
            console.log('id---->', id)
            conn.query('DELETE FROM utilityRolesPermission where utility_sub_admin_id = ? ', [id], (err, admins) => {
                  if (err) {
                        res.status(400).send({ "error": err })
                        return false
                  }
                  module_id = module_id.map(Number);

                  if (module_id.length > 0) {
                        /**saving the permessins for admin.. */
                        conn.query('SELECT id FROM modules where parent_module_id IN (?) ', [module_id], (err, childModules) => {
                              if (err) {
                                    res.status(400).send({ "error": err })
                                    return false
                              }
                              //let module_id_childModules =[...module_id,...childModules]
                              console.log("module_id_childModules---->", childModules);
                              childModules.map((obj) => {
                                    module_id.push(obj.id)
                              })
                              console.log("--->module_id-->", module_id)
                              module_id.map(m_id => {
                                    let permession_data = {
                                          module_id: m_id,
                                          utility_id: 1,
                                          utility_sub_admin_id: id,
                                          created_at: new Date()
                                    }
                                    conn.query('INSERT INTO utilityRolesPermission set ?', permession_data, (err, data) => {
                                          if (err) {
                                                res.status(400).send({ "error": err })
                                                return false
                                          } else {
                                                //console.log('===?', data)
                                          }
                                    });
                              });

                        })

                  }
                  // if (module_id.length > 0) {

                  //       /**updating the per for admin.. */
                  //       module_id.map(m_id => {
                  //             let permession_data = {
                  //                   module_id: m_id,
                  //                   utility_id: 1,
                  //                   utility_sub_admin_id: id,
                  //                   created_at: new Date()
                  //             }
                  //             conn.query('INSERT INTO utilityRolesPermission set ?', permession_data, (err) => {
                  //                   if (err) {
                  //                         res.status(400).send({ "error": err})
                  //                         return false
                  //                     }
                  //             });
                  //       });
                  // }
            });

      });
};

exports.get_provider_of_admin = function (req) {
      return new Promise((resolve, rej) => {
            req.getConnection((err, conn) => {

                  console.log(req.headers)

                  if (req.headers.decoded.user_type == "utilitySubAdmins") {
                        conn.query(`select * from utilitySubAdmins where id = ?`, [req.headers.decoded.user_id], (err, provider) => {
                              if (err) {
                                    rej(err)
                              } else {
                                    resolve(provider[0].utility_provider_id)
                              }
                        });
                  } else {
                        resolve(req.headers.decoded.user_id)
                  }
            })
      })
};

exports.AddutilityModulesProviders = function (req, res, Newadmin) {
      return new Promise((resolve, reject) => {
            req.getConnection((err, connection) => {
                  connection.query('select * from modules where parent_module_id = 0', [], (err, modules) => {
                        if (err) {
                              reject(err)
                        }
                        console.log('module dtaa---->', modules)
                        modules.map((data) => {
                              let module_data = {
                                    utility_id: 1,
                                    module_id: data.id,
                                    is_active: "true",
                                    utility_provider_id: Newadmin
                              }
                              console.log('module data to insert--->',module_data);
                              
                              connection.query('insert into utilityModulesProviders set ?', module_data, (err) => {
                                    if (err) {
                                          reject(err)
                                    }
                                    resolve(true)
                              })
                        })
                  })
            })
      })
};

exports.UpdateutilityProvidermodules = function (req, res, id, module_id,category_id) {
      console.log("-------------module_id--->", module_id)
      req.getConnection((err, conn) => {
            if (err) {
                  res.status(400).send({ "error": err })
                  return false
            }
            console.log('id---->', id)
            conn.query('DELETE FROM utilityModulesProviders where utility_provider_id = ? ', [id], (err, admins) => {
                  if (err) {
                        res.status(400).send({ "error": err })
                        return false
                  }
                  module_id = module_id.map(Number);

                  if (module_id.length > 0) {
                        /**saving the permessins for admin.. */
                        conn.query('SELECT id FROM modules where id IN (?) ', [module_id], (err, childModules) => {
                              if (err) {
                                    res.status(400).send({ "error": err })
                                    return false
                              }
                              //let module_id_childModules =[...module_id,...childModules]
                               console.log("module_id_childModules---->", childModules);
                              // childModules.map((obj) => {
                              //       module_id.push(obj.id)
                              // })
                              console.log("--->module_id-->", module_id)
                              module_id.map(m_id => {
                                   
                                    category_id.map(c_id => {
                                          let permession_data = {
                                                module_id: m_id,
                                                utility_id: c_id,
                                                utility_provider_id: id,
                                          }
                                    
                                    conn.query('INSERT INTO utilityModulesProviders set ?', permession_data, (err, data) => {
                                          if (err) {
                                                res.status(400).send({ "error": err })
                                                return false
                                          } else {
                                                console.log('===>>', data)
                                          }
                                    });
                              });

                        });

                        })

                  }
                  
            });

      });
};

exports.getSettings = function (req) {
      return new Promise((resolve, reject) => {
            req.getConnection((err, connection) => {
                  connection.query('select * from settings where id =  1', [], (err, modules) => {
                        if (err) {
                              reject(err)
                        }
                        resolve(modules[0])
                  })
            })
      })
};