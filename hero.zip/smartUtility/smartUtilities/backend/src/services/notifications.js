exports.save_notification = async function (req,notification_id,to_id,to_type,from,from_type) {
    let notification_data =  new Promise((resolve, reject) => {
          req.getConnection((err, connection) => {
                connection.query('select * from notification  where id = ?', [notification_id], (err, modules) => {
                      if (err) {
                            reject(err)
                      }
                      console.log('modules==============<>',modules)
                      console.log('modules==============<>with 0 =====>',modules[0])
                      resolve(modules[0])
                })
          })
    })
    let notification =  await notification_data
    let save_data = {
        to : to_id,
        to_type: to_type,
        from : from,
        from_type : from_type,
        notification_id : notification.id, 
        status : 0,
        created_at : new Date,
        modified_at : new Date,
        
    }
    req.getConnection((err, connection) => {
        connection.query('insert into notifications set  ?', save_data, (err, modules) => {
              if (err) {
                    console.log("=============err--------->",err)
                    return false
              }
              console.log("=============nnoti data--------->",modules)
        })
  })
    
};