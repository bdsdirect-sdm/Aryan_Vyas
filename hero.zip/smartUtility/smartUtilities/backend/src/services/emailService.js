const nodemailer = require("nodemailer");

/*send email password **/
exports.sendEmailProfile = async (req, res, user_data) => {

  let testAccount = {
    user: 'ezystayzapps@gmail.com',
    pass: 'csnkzqgpstvaeehz'
  }
  let transporter = nodemailer.createTransport({

    host: "smtp.gmail.com",
    port: 587,
    secure: false, // true for 465, false for other ports
    auth: {
      user: testAccount.user, // generated ethereal user
      pass: testAccount.pass // generated ethereal password
    },
    tls: {
      rejectUnauthorized: false
    }
  });

  req.getConnection((err, connection) => {
    connection.query('select * from emailTemplates where id = ?', [1], async (err, email_data) => {
      if (err) {
        res.status(400).send({ "error": err })
        return false
      }
      var content_for_Replace = email_data[0].content
      content_for_Replace = content_for_Replace.replace("{email}", user_data.email)
      content_for_Replace = content_for_Replace.replace("{password}", user_data.password)
      console.log('content_for_Replace=---', content_for_Replace)
      var info = await transporter.sendMail({
        from: '"smartUtilities " <info@smartutilities.com>',
        to: user_data.email,
        subject: "Welcome to smartUtilities",
        html: content_for_Replace
      });
      console.log("------info--------->", info)
      //res.status(200).send(info)
    })
  })
  // return info
  //res.status(200).json(successAction(info.messageI, "-----email message..."));
  //console.log("Message sent: %s", info.messageId);
  // Message sent: <b658f8ca-6296-ccf4-8306-87d57a0b4321@example.com>
  // Preview only available when sending through an Ethereal account
  //.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
  // Preview URL: https://ethereal.email/message/WaQKMgKddxQDoou...
}
exports.sendEmailRequest = async (req, res, user_data) => {

  let testAccount = {
    user: 'ezystayzapps@gmail.com',
    pass: 'csnkzqgpstvaeehz'
  }
  let transporter = nodemailer.createTransport({

    host: "smtp.gmail.com",
    port: 587,
    secure: false, // true for 465, false for other ports
    auth: {
      user: testAccount.user, // generated ethereal user
      pass: testAccount.pass // generated ethereal password
    },
    tls: {
      rejectUnauthorized: false
    }
  });

  req.getConnection((err, connection) => {
    connection.query('select * from emailTemplates where id = ?', [2], async (err, email_data) => {
      if (err) {
        res.status(400).send({ "error": err })
        return false
      }
      var content_for_Replace = email_data[0].content

      content_for_Replace = content_for_Replace.replace("{request_number}", user_data.request_number)
      content_for_Replace = content_for_Replace.replace("{notes}", user_data.notes)
      content_for_Replace = content_for_Replace.replace("{date}", user_data.date)
      content_for_Replace = content_for_Replace.replace("{time}", user_data.time)
      //service_name customer_notes date_time
      console.log('content_for_Replace=---', content_for_Replace)
      var info = await transporter.sendMail({
        from: '"smartUtilities " <info@smartUtilities.com>',
        to: user_data.email,
        subject: "Welcome to smartUtilities",
        html: content_for_Replace
      });
      console.log("------info--------->", info)
      //res.status(200).send(info)
    })
  })
}
exports.SendTestEmail = async (accountLink) => {

  let testAccount = {
    user: 'ezystayzapps@gmail.com',
    pass: 'csnkzqgpstvaeehz'
  }
  let transporter = nodemailer.createTransport({

    host: "smtp.gmail.com",
    port: 587,
    secure: false, // true for 465, false for other ports
    auth: {
      user: testAccount.user, // generated ethereal user
      pass: testAccount.pass // generated ethereal password
    },
    tls: {
      rejectUnauthorized: false
    }
  });
  console.log('accountLink------->', accountLink)
  var info = await transporter.sendMail({
    from: '"smartUtilities " <info@smartutilities.com>',
    to: 'kumarsanju54@gmail.com',
    subject: "Welcome to smartUtilities",
    html: `<a href=${accountLink.url} >click</a>`
  });
  console.log("info--->", info)
  //res.status(200).json(successAction(info.messageI, "-----email message..."));
  //console.log("Message sent: %s", info.messageId);
  // Message sent: <b658f8ca-6296-ccf4-8306-87d57a0b4321@example.com>
  // Preview only available when sending through an Ethereal account
  //.log("Preview URL: %s", nodemailer.getTestMessageUrl(info));
  // Preview URL: https://ethereal.email/message/WaQKMgKddxQDoou...
}

exports.sendEmail = async (req, res, template_id, to_email, user_password, userName, requestData, callback) => {

  let testAccount = {
    user: 'bhuvin1025.be20@chitkarauniversity.edu.in',
    pass: 'kuvvnjsafiffrlcu'
    // user: 'ezystayzapps@gmail.com',
    // pass: 'csnkzqgpstvaeehz'
  }
  let transporter = nodemailer.createTransport({

    host: "smtp.gmail.com",
    port: 587,
    secure: false, // true for 465, false for other ports
    auth: {
      user: testAccount.user, // generated ethereal user
      pass: testAccount.pass // generated ethereal password
    },
    tls: {
      rejectUnauthorized: false
    }
  });

  req.getConnection((err, connection) => {
    connection.query('select * from emailTemplates where id = ?', [template_id], async (err, email_data) => {
      if (err) {
        res.status(400).send({ "error": err })
        return false
      }

      var content_for_Replace = email_data[0].content;
      if (requestData) {
        content_for_Replace = content_for_Replace.replace("{fromName}", requestData.admin_full_name);
        content_for_Replace = content_for_Replace.replace("{toName}", requestData.customer_full_name);
        content_for_Replace = content_for_Replace.replace("{request_number}", requestData.num);
        content_for_Replace = content_for_Replace.replace("{date}", requestData.date);
        content_for_Replace = content_for_Replace.replace("{time}", requestData.time);
      }
      if (userName) {
        content_for_Replace = content_for_Replace.replace("{userName}", userName);
      }
      if (user_password) {
        content_for_Replace = content_for_Replace.replace("{password}", user_password);
        content_for_Replace = content_for_Replace.replace("{email}", to_email);
      }

      var info = await transporter.sendMail({
        from: '"smartUtilities " <info@smartutilities.com>',
        to: to_email,
        subject: "Welcome to smartUtilities",
        html: content_for_Replace
      });
      console.log("------info--------->", info)
      callback(info);
    });
  })
}