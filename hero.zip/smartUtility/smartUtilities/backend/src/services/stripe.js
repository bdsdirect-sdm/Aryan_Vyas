const stripe = require('stripe')('sk_test_swguQjhPgXoeIfGjYP0C4L7f00OtliGZ3h');
const emailService = require('../services/emailService')
var fs = require('fs');
var path = require('path');
var createProviderAndBankAccount = (req, callback) => {

  try {
    stripe.customers.create({
      email: req.body.formdata.email,
      name: 'Providers/Staff - ' + req.body.formdata.first_name + ' ' + req.body.formdata.last_name,
      phone: req.body.formdata.phone,
    })
      .then(function (customer) {

        console.log("---customer----", customer);
        stripe.tokens.create(
          {
            bank_account: {
              country: 'US',
              currency: 'USD',
              account_holder_name: req.body.formdata.first_name + ' ' + req.body.formdata.last_name,
              account_holder_type: 'individual',
              routing_number: '110000000',
              account_number: '000123456789',
            },
          },
          function (err, token) {
            console.log("---token----", err, token);

            stripe.customers.createSource(
              customer.id,
              { source: token.id },
              function (err, bankAccount) {
                console.log("---bankAccount----", err, bankAccount);
                var result = {}
                result.cust_id = customer.id;
                result.bank_id = bankAccount.id;
                callback(result)

              }
            );

          }
        );
      })
  } catch (error) {
    callback(error);
  }

};

exports.createProviderAndBankAccount = createProviderAndBankAccount;


var paymentByExistingCustomer = async (req, res, stripe_id, customerId, customerData, serviceData, utilityProviders, callback) => {
  var data = req.body;
  console.log("req.body===", JSON.stringify(req.body), stripe_id)

  try {

    stripe.customers.retrieve(
      stripe_id,
      function (err, customer) {
        // asynchronously called
        console.log("---customer---", customer.default_source);
        let cost = serviceData[0].cost * 100;
        stripe.charges.create(

          {
            amount: cost,
            currency: 'usd',
            customer: stripe_id,
            source: customer.default_source,
            description: 'Paid to smartutilities Super Admin',
          },
          function (err, charge) {

            var result = {}
            result = charge;


            if (err) {
              callback({
                status: 400,
                error: err
              });
            }

            stripe.balance.retrieve(function (err, balance) {
              console.log("==balance===", err, JSON.stringify(balance));

              stripe.payouts.create(
                {
                  amount: cost,
                  currency: 'usd',
                  method: 'instant',
                  description: 'payout by super admin to utility provider',

                  source_type: 'bank_account'
                }, {
                stripeAccount: utilityProviders[0].stripe_account_id,
              },
                function (error, payout) {
                  if (!error) {
                    result.transaction_id = payout.id;
                  }
                  callback(result);
                });

            });



          });

      });

  } catch (err) {
    if (err) {
      callback({
        status: 400,
        error: err
      });
    }
  }
}
exports.paymentByExistingCustomer = paymentByExistingCustomer;




var paymentByNewCustomer = (req, customerData, serviceData, utilityProviders, callback) => {

  var data = req.body;
  console.log("req.body===", JSON.stringify(req.body))

  try {
    stripe.customers.create({
      email: req.body.email,
      name: 'Customer - ' + customerData[0].first_name + ' ' + customerData[0].last_name,
      phone: customerData[0].mobile,

    })
      .then(function (customer) {
        console.log("-=-=customer-=-=", JSON.stringify(customer));

        let cost = serviceData[0].cost * 100;
        stripe.customers.createSource(
          customer.id,
          { source: data.token.id },
          function (err, cardOutput) {
            console.log("==cardOutput===", JSON.stringify(cardOutput));
            stripe.charges.create(

              {
                amount: cost,
                currency: 'usd',
                customer: customer.id,
                source: cardOutput.id,
                description: 'Paid for service #' + serviceData[0].request_number,
              },
              function (err, charge) {

                if (err) {
                  callback({
                    status: 400,
                    error: err
                  });
                }
                console.log("==charge===", JSON.stringify(charge));

                var result = {}
                result.cust_id = customer.id;
                result.charge_id = charge.id;

                stripe.balance.retrieve(function (err, balance) {
                  console.log("==balance===", err, JSON.stringify(balance));
                  stripe.payouts.create(
                    {
                      amount: 1000,
                      currency: 'usd',
                      method: 'standard',
                      description: 'payout by super admin to utility provider for service #' + serviceData[0].request_number,

                      source_type: 'bank_account'
                    }, {
                    stripeAccount: utilityProviders[0].stripe_account_id,

                  },
                    function (error, payout) {

                      console.log("==payout===", JSON.stringify(payout), JSON.stringify(error.message));

                      if (error) {
                        callback({
                          status: 400,
                          error: error
                        });
                      } else {

                        result.transaction_id = payout.id;
                      }
                      callback(result);

                    });

                });




              })
          }
        );
      })

  } catch (error) {
    if (error) {
      callback({
        status: 400,
        error: error
      });
    }
  }


};



exports.paymentByNewCustomer = paymentByNewCustomer;

var createConnectedAccount = async (req) => {
  //for front document

  var req_data = JSON.parse(req.body.data)
  console.log('req_data=-x==-----------------------=>', req_data, typeof req_data)
  console.log('req_data.first_name=====================>', req_data.first_name);
  var dob = req_data.dob.split('-')
  var ssn = req_data.ssn.split('-')
  var ddd = req.files[0].path
  var fp = fs.readFileSync(ddd);
  var file = await stripe.files.create({
    purpose: 'identity_document',
    file: {
      data: fp,
      name: req.files[1].filename,
      type: 'application/octet-stream',
    },
  });
  //for back document
  var ddd = req.files[1].path
  var fp = fs.readFileSync(ddd);
  var file2 = await stripe.files.create({
    purpose: 'identity_document',
    file: {
      data: fp,
      name: req.files[1].filename,
      type: 'application/octet-stream',
    },
  });
  var fiel_id = file.id
  var fiel_id2 = file2.id

  return new Promise((resolve, reject) => {
    // var dateob = req_data.dob.split('-')
    stripe.accounts.create(
      {
        type: 'custom',
        country: 'US',
        email: req_data.email,
        business_type: 'individual',
        individual: {
          address: {
            line1: req_data.address, // 'Metropolitan Life North Building',
            // line2 : req_data.address, //'11 Madison Ave',
            state: req_data.state, //'New York',
            city: req_data.city, //'New York',
            postal_code: req_data.zip
          },
          dob: {
            day: 1, //dob[0],
            month: 2, //dob[1],
            year: 1990,//dob[2]
          },
          ssn_last_4: ssn[2],
          email: req_data.email,
          first_name: req_data.first_name,
          last_name: req_data.last_name,
          phone: req_data.phone,
          gender: "male",
          verification: {
            document: {
              front: fiel_id,
              back: fiel_id2
            }
          }
        },
        requested_capabilities: [
          'card_payments',
          'transfers',
        ],
      },
      function (err, account) {
        if (err) {
          console.log('errrrr----dd-------->', err)
          reject(err)

          return false
        }
        var accountnum = account.id
        if (err) {
          console.log('errrrr-------ss----->', err)
          reject(err)
        }
        // stripe.accountLinks.create(
        //   {
        //     account: accountnum,
        //     failure_url: 'http://54.190.192.105:6002/#/',
        //     success_url: 'http://54.190.192.105:6002/#/',
        //     type: 'custom_account_verification',
        //   },
        //   function(err, accountLink) {
        //      if(err){
        //        console.log(err)
        //      }
        //      emailService.SendTestEmail(accountLink)
        //      console.log("create link---->",accountLink)
        //   }
        // );
        resolve(account)
      }
    );

  })
};

exports.createConnectedAccount = createConnectedAccount


