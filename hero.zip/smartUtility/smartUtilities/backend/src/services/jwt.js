var jwt = require('jsonwebtoken');
exports.createToken = function (email, uuid, user_id,user_type) {
	var token = jwt.sign({ email: email, user_id: user_id, user_type : user_type , token: uuid, iat: Math.floor(Date.now() / 1000), exp: Math.floor(Date.now() / 1000) + (60 * 600) }, 'smartUtilities@2020@RK@SDM');
	return token;
}
exports.verifyToken = function (req, res, next) {
	//console.log('token check------------->',req.headers);
	
	jwt.verify(req.headers.authorization, 'smartUtilities@2020@RK@SDM', function (err, decoded) {
		if (err) {
			return res.status(403).json({
				msg: 'Token expired. Please login again'
			})
		} else {
			req.headers.decoded = decoded;
			next();
		}
	});
}
