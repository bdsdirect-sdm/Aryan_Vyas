This project was bootstrapped with [Create Angular App]

## Available Scripts

In the project directory, you can run:

### `npm install`

Runs the app in the development mode.<br />
Open [http://localhost:4200](http://localhost:4200) to view it in the browser.

The page will reload if you make edits.<br />
You will also see any lint errors in the console.

### `ng test`



### `ng build`


