import { Component, OnInit, TemplateRef } from '@angular/core';
import { FormGroup, Validators } from "@angular/forms";
import { ActivatedRoute, Params, Router } from '@angular/router';
import { UtilityService } from "../services/utility.service";
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { CookieService } from 'ngx-cookie';
import { CommonService } from '../services/common.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class loginComponent implements OnInit {
  utility: any;
  loginAs: any;
  constructor(private activatedRoute: ActivatedRoute, private router: Router, private toastr: ToastrService,
    private spinner: NgxSpinnerService, private utilityService: UtilityService,
    private _cookieservice: CookieService, private commonService: CommonService) {
    this.utility = {};
    this.loginAs = 'utilityprovider';
  }

  ngOnInit() {
    this._cookieservice.removeAll();
  }

  login() {
    if (this.loginAs == 'utilityprovider') {
      this.utilityService.utilityProviderLogin(this.utility).subscribe(result => {
        this.toastr.success('Welcome to the Utility Admin Panel', 'Success');
        this.router.navigate(['/utility/dashboard']);
        result.data[0]['type'] = 'utilityprovider';
        this._cookieservice.put('token', JSON.stringify(result.data[0]));
      }, err => {
        this.utility = {};
        this.commonService.handleError(err);
      });
    } else {
      this.utilityService.subAdminLogin(this.utility).subscribe(result => {
        this.toastr.success('Welcome to the Sub Admin Panel', 'Success');
        this.router.navigate(['/utility/dashboard']);
        result.data[0]['type'] = 'subadmin';
        this._cookieservice.put('token', JSON.stringify(result.data[0]));
      }, err => {
        this.utility = {};
        this.commonService.handleError(err);
      });
    }


  }

}
