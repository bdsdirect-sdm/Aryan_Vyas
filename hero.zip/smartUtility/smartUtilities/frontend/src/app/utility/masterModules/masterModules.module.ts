import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { masterModulesRoutingModule } from './masterModules-routing.module';
import { masterModulesComponent } from './masterModules.component';
import { leftBarComponent } from './leftBar/leftBar.component';
import { HeaderComponent } from './header/header.component';
import { dashboardComponent } from './dashboard/dashboard.component';
import { serviceTypesListComponent } from './manageServiceTypes/list/serviceTypes-list.component';
import { serviceTypesAddComponent } from './manageServiceTypes/add/serviceTypes-add.component';
import { serviceTypesEditComponent } from './manageServiceTypes/edit/serviceTypes-edit.component';
import { subAdminListComponent } from './manageSubAdmins/list/subAdmins-list.component';
import { subAdminAddComponent } from './manageSubAdmins/add/subAdmins-add.component';
import { subAdminEditComponent } from './manageSubAdmins/edit/subAdmins-edit.component';

import {NgxMaterialTimepickerModule} from 'ngx-material-timepicker';
import { serviceProvidersListComponent } from './manageServiceProviders/list/serviceProviders-list.component';
import { serviceProvidersAddComponent } from './manageServiceProviders/add/serviceProviders-add.component';
import { serviceProvidersEditComponent } from './manageServiceProviders/edit/serviceProviders-edit.component';

import { customerAddComponent } from './manageCustomers/add/customers-add.component';
import { customerEditComponent } from './manageCustomers/edit/customers-edit.component';
import { customerListComponent } from './manageCustomers/list/customers-list.component';

import { serviceRequestsAddComponent } from './manageServiceRequests/add/serviceRequests-add.component';
import { serviceRequestsEditComponent } from './manageServiceRequests/edit/serviceRequests-edit.component';
import { serviceRequestsListComponent } from './manageServiceRequests/list/serviceRequests-list.component';

import { incidentsProblemsViewComponent } from './manageIncidentsProblems/view/incidentsProblems-view.component';

import { incidentsProblemsListComponent } from './manageIncidentsProblems/list/incidentsProblems-list.component';

import { ratingListComponent } from './ratingManagement/list/rating-list.component';

import { CalenderComponent } from './manageCalender/calender.component';

import { AppSharedModule } from '../../shared/app-shared.module';
import { GooglePlacesDirective } from '../../shared/googlePlace.directive';
import { CalendarModule, DateAdapter } from 'angular-calendar';
import { adapterFactory } from 'angular-calendar/date-adapters/date-fns';
import { CalenderOtherComponent } from './manageCalenderother/calender.component';
import { serviceRequestsViewComponent } from './manageServiceRequests/view/serviceRequests-view.component';
import { PaymentComponent } from './managePayments/payment.component';
import { profileComponent } from './profile/profile.component';


@NgModule({
  declarations: [
    masterModulesComponent,
    leftBarComponent,
    HeaderComponent,
    dashboardComponent,
    serviceTypesListComponent,
    serviceTypesAddComponent,
    serviceTypesEditComponent,
    subAdminListComponent,
    subAdminAddComponent,
    subAdminEditComponent,
    serviceProvidersListComponent,
    serviceProvidersAddComponent,
    serviceProvidersEditComponent,
    customerListComponent,
    customerEditComponent,
    customerAddComponent,
    serviceRequestsListComponent,
    serviceRequestsEditComponent,
    serviceRequestsAddComponent,
    serviceRequestsViewComponent,
    CalenderComponent,
    CalenderOtherComponent,
    GooglePlacesDirective,
    incidentsProblemsViewComponent,
    incidentsProblemsListComponent,
    ratingListComponent,
    PaymentComponent,
    profileComponent
  ],
  imports: [
    BrowserModule,
    AppSharedModule,
    BrowserAnimationsModule,
    HttpClientModule,
    masterModulesRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    NgxMaterialTimepickerModule,
    CommonModule,
    CalendarModule.forRoot({
      provide: DateAdapter,
      useFactory: adapterFactory,
    }),
  ],
  providers: [],
  bootstrap: [masterModulesComponent]
})
export class masterModulesModule { }
