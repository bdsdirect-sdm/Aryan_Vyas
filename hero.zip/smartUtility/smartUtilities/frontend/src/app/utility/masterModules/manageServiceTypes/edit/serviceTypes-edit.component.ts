import { Component, OnInit } from '@angular/core';
import { serviceTypesService } from '../../../../utility/masterModules/services/serviceTypes.service';

import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { CommonService } from '../../../services/common.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { environment } from '../../../../../environments/environment';
@Component({
  selector: 'serviceTypes-edit-tutorial',
  templateUrl: './serviceTypes-edit.component.html',
  styleUrls: ['./serviceTypes-edit.component.css']
})
export class serviceTypesEditComponent implements OnInit {
  utilityServiceTypes: any = {};
  submitted = false;
  subServiceTitle: string = "";
  currency: string;
  subServices: any = [];
  subServiceHourlyPrice: string = "";
  subServiceFlatPrice:string="";
  environment: any = environment;
  defaultCurrency: any;
  allCategories: any;
  dbsubCategories:any;
  subCategories:any;
  constructor(private serviceTypesService: serviceTypesService, private route: ActivatedRoute,
    private toastr: ToastrService, private router: Router, private commonService: CommonService,private spinner: NgxSpinnerService) {
    this.currency = this.environment.currency;
    this.utilityServiceTypes.subServices = [];
  }

  async ngOnInit() {
    this.getDetails();
    this.commonService.notifyOther({ option: 'breadcrumbs', value: 'Manage Service Types' });
    let categories: any = await this.commonService.getCategories();
    this.allCategories=categories;
  }

  async getSubCategories(){
    this.spinner.show();
    console.log("---vaalaa",this.utilityServiceTypes.utility_id);
    this.subCategories= await this.commonService.getSubCategories(this.utilityServiceTypes.utility_id);
    console.log("---subCategories----",this.subCategories);
    this.spinner.hide();
  }

  addSubservice() {
    if (this.subServiceTitle == '') {
      this.toastr.error('Please enter service type', 'Error');
      return false;
    }
    if (this.subServiceHourlyPrice == '') {
      this.toastr.error('Please enter sub service hourly price', 'Error');
      return false;
    }

    if (!this.subServiceHourlyPrice) {
      this.toastr.error('Please enter sub service hourly price', 'Error');
      return false;
    }

    if (this.subServiceHourlyPrice == '0') {
      this.toastr.error('Zero value is not allowed', 'Error');
      return false;
    }


    if (this.subServiceFlatPrice == '') {
      this.toastr.error('Please enter sub service flat price', 'Error');
      return false;
    }

    if (!this.subServiceFlatPrice) {
      this.toastr.error('Please enter sub service flat price', 'Error');
      return false;
    }

    if (this.subServiceFlatPrice == '0') {
      this.toastr.error('Zero value is not allowed in sub service flat price', 'Error');
      return false;
    }
    if (this.subServices.indexOf(this.subServiceTitle) >= 0) {
      this.toastr.error(this.subServiceTitle + ' already exists in sub services list', 'Error');
      return false;
    }
    this.subServices.push({
      title:this.subServiceTitle,
      hourly_rate:this.subServiceHourlyPrice,
      flat_rate:this.subServiceFlatPrice
    });
    this.subServiceTitle = "";
    this.subServiceHourlyPrice = "";
    this.subServiceFlatPrice="";
  }

  removeSubService(subServiceVal) {
    console.log("-=-==-", subServiceVal);
    this.subServices = this.subServices.filter(e => e !== subServiceVal);
  }
  async getDetails() {
    let superAdminSettings: any = await this.commonService.getSuperAdminDetails();
    this.defaultCurrency = superAdminSettings.default_currency;
    this.serviceTypesService.getserviceTypeDetails(this.route.snapshot.params.id)
      .subscribe(
        response => {
          this.subServices = response.subServices;
          this.utilityServiceTypes = response.data[0];
          console.log("-=-=-response-=-=", this.utilityServiceTypes);
          this.dbsubCategories=response.subServices;
          this.getSubCategories();
        },
        err => {
          // this.spinner.hide();
          this.commonService.handleError(err);
        });
  }
  update() {
    this.utilityServiceTypes.subServices = this.subServices;
    this.utilityServiceTypes.dbsubCategories = this.dbsubCategories;
    const data = this.utilityServiceTypes;
    console.log("before save", data);
    

    if (data.utility_id == '') {
      this.toastr.error('Please select service main category', 'Error');
      return false;
    }

    if (data.subUtility_id == '') {
      this.toastr.error('Please select service sub category', 'Error');
      return false;
    }


    this.serviceTypesService.update(data)
      .subscribe(
        response => {
          this.toastr.success('Service Type has been update successfully', 'Success');
          this.router.navigate(['/utility/manageServiceTypes']);
          this.submitted = true;
        },
        err => {
          // this.spinner.hide();
          this.commonService.handleError(err);
        });
  }


}
