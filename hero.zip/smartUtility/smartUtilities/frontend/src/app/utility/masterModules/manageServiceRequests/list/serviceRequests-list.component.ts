import { Component, OnInit, TemplateRef } from '@angular/core';
import { CommonService } from '../../../services/common.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import * as _ from 'underscore';
import * as moment from 'moment';
import { serviceRequestService } from '../../services/serviceRequests.service';
import { serviceProvidersService } from '../../services/serviceProviders.service';
import { customerService } from '../../services/customers.service';
import { ActivatedRoute } from '@angular/router';

@Component({
  selector: 'serviceRequests-list',
  templateUrl: './serviceRequests-list.component.html',
  styleUrls: ['./serviceRequests-list.component.css']
})
export class serviceRequestsListComponent implements OnInit {
  modalRef: BsModalRef;
  serviceRequestList: any;
  title = '';
  dataIds: any = [];
  action: any;
  itemValue: any;
  jobDone: any;
  showDropdown: any;
  provider_filter: any;
  customer_filter: any;
  utilityCustomerList: any;
  utilityProvidersList: any;
  selectedAll: any;
  checked = false;
  showCustomerFilter: boolean;
  showProviderFilter: boolean;
  recordsPerPage: unknown;
  date_format: any;
  time_format: any;
  serviceStatus: any;
  defaultCurrency: any;
  constructor(private serviceRequestService: serviceRequestService, private spinner: NgxSpinnerService,
    private modalService: BsModalService, private toastr: ToastrService, private customerService: customerService,
    private serviceProvidersService: serviceProvidersService,
    private activatedRoute: ActivatedRoute, private commonService: CommonService) {
    this.showDropdown = false;
    this.provider_filter = '';
    this.customer_filter = '';
    this.selectedAll = false;
    this.showCustomerFilter = false;
    this.showProviderFilter = false;
    this.jobDone = {};
    this.activatedRoute.params.subscribe(paramid => {
      if (activatedRoute.snapshot.routeConfig.path.includes('manageServiceRequests/customer')) {
        this.customer_filter = atob(paramid.id);
        this.showCustomerFilter = true;
        this.showProviderFilter = true;
        this.showAll(atob(paramid.id), '');
      } else if (activatedRoute.snapshot.routeConfig.path.includes('manageServiceRequests/provider')) {
        this.showCustomerFilter = true;
        this.showProviderFilter = true;
        this.provider_filter = atob(paramid.id);
        this.showAll('', atob(paramid.id));
      } else {
        this.showAll('', '');
        this.showCustomerFilter = false;
        this.showProviderFilter = false;
      }
    });
  }

  ngOnInit() {
    this.providersList();
    this.customerList();
    this.getAllServiceStatus();
    this.commonService.notifyOther({ option: 'breadcrumbs', value: 'Manage Service Requests' });
  }

  async showAll(cust_id, prov_id) {
    this.spinner.show();
    let json = {
    }
    if (cust_id && cust_id != '') {
      json['customer_id'] = cust_id
    }
    if (prov_id && prov_id != '') {
      json['service_provider_id'] = prov_id
    }

    let superAdminSettings: any = await this.commonService.getSuperAdminDetails();
    this.recordsPerPage = superAdminSettings.records_per_page;
    this.date_format = superAdminSettings.default_date_format;
    this.time_format = superAdminSettings.time_format;
    this.defaultCurrency = superAdminSettings.default_currency;
    this.serviceRequestService.getAllServiceRequests(json).subscribe(result => {
      this.serviceRequestList = result.data;
      _.each(this.serviceRequestList, obj => {
        obj['id'] = btoa(obj['id']);
        obj['date'] = moment(obj['date']).format(this.date_format);
        if (this.time_format == '12hours') {
          obj['time'] = moment(obj['time'], ["HH:mm"]).format("h:mm A");
          obj['etime'] = moment(obj['etime'], ["HH:mm"]).format("h:mm A");
        } else {
          obj['time'] = moment(obj['time'], ["HH:mm"]).format("HH:mm");
          obj['etime'] = moment(obj['etime'], ["HH:mm"]).format("h:mm A");
        }
        obj['modified_date'] = moment(obj['modified_date']).format(this.date_format);
      });
      console.log('---------------vv', this.serviceRequestList)
      this.spinner.hide();
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
  }

  getAllServiceStatus() {
    this.serviceRequestService.listServiceStatus().subscribe(result => {
      this.serviceStatus = result.data;
    }, err => {
      this.commonService.handleError(err);
    });
  }

  onKeydownEvent(e, cost) {
    if (!((e.keyCode > 95 && e.keyCode < 105)
      || (e.keyCode > 47 && e.keyCode < 58)
      || e.keyCode == 8)) {
      return false;
    } else {
      if (cost && cost.toString().length > 3) {
        return false;
      }
    }
  }

  tConvert(time) {
    // Check correct time format and split into components
    time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time];

    if (time.length > 1) { // If time format correct
      time = time.slice(1);  // Remove full string match value
      time[5] = +time[0] < 12 ? ' AM' : ' PM'; // Set AM/PM
      time[0] = +time[0] % 12 || 12; // Adjust hours
    }
    delete time[3]
    return time.join(''); // return adjusted time or original string
  }

  providersList() {
    let inputJson = {};
    inputJson['page'] = 1;
    inputJson['limit'] = 10;
    inputJson['sort'] = { 'title': 'asc' };
    this.serviceProvidersService.getAll(inputJson).subscribe(result => {
      this.utilityProvidersList = result;
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
  }

  customerList() {
    this.customerService.getAllCustomers('').subscribe(result => {
      this.utilityCustomerList = result.data;
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
  }

  countCurrentPageRows() {
    let oRows = document.getElementById('tableBody').getElementsByTagName('tr');
    let iRowCount = oRows.length;
    return iRowCount;

  }

  multiUpdate() {
    if (this.dataIds.length > 0) {
      this.spinner.show();
      let data = {
        action: this.action,
        dataId: this.dataIds
      };
      this.serviceRequestService.multiUpdate(data).subscribe(response => {
        this.showAll('', '');
        this.modalRef.hide();
        this.spinner.hide();
        this.showDropdown = false;
        this.toastr.success('Selected records have been ' + this.action + 'ed successfully', 'Success');
      }, err => {
        this.spinner.hide();
        this.commonService.handleError(err);
      });
    } else {
      this.toastr.info('Please select an record first', 'Info');
      this.modalRef.hide();
    }
  }

  searchTitle() {
    this.spinner.show();
    let json = {
      search: this.title
    }
    this.serviceRequestService.getAllServiceRequests(json).subscribe(result => {
      this.serviceRequestList = result.data;
      this.spinner.hide();
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
  }

  openModal(template: TemplateRef<any>, data, action) {
    this.modalRef = this.modalService.show(template);
    this.itemValue = data;
    this.action = action;
  }

  closeModal() {
    this.modalRef.hide();
  }

  openModalConfirm(template: TemplateRef<any>, data) {
    if (this.dataIds.length == 0) {
      this.toastr.error('Please select atleast one item', 'Error');
      return false;
    }
    this.modalRef = this.modalService.show(template);
    this.action = data;
  }

  changeStatusDelete() {
    let data = {
      action: this.action,
      dataId: [this.itemValue.id]
    };
    this.serviceRequestService.multiUpdate(data).subscribe(response => {
      this.showAll('', '');
      this.modalRef.hide();
      this.spinner.hide();
      this.showDropdown = false;
      this.toastr.success('Record ' + this.action + 'ed successfully', 'Success');
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
  }
  unselectAll() {
    this.checked = false;
  }

  selectall(event) {
    if (event.target.checked) {
      const selectedIds = [];
      this.serviceRequestList.forEach(val => { selectedIds.push(val.id) });
      this.dataIds = selectedIds;
    } else {
      this.dataIds = [];
    }
  }

  markJobDone() {
    this.spinner.show();
    let json = {
      id: this.itemValue.id,
      service_provider_id: this.itemValue.service_provider_id,
      provider_notes: this.itemValue.provider_notes,
      cost: this.itemValue.cost,
      notes: this.jobDone.description
    }
    this.serviceRequestService.markJobDone(json).subscribe(result => {
      this.modalRef.hide();
      this.spinner.hide();
      this.showAll('', '');
      this.toastr.success('Job completed successfully', 'Success');
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
  }

}
