
import { Injectable, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import 'rxjs/add/operator/map';
import { CookieService } from 'ngx-cookie';

@Injectable({
  providedIn: 'root'
})
export class PaymentsService {
  constructor(private http: HttpClient, public router: Router,
    private _cookieservice: CookieService) {

  }

  getHeaders() {
    let headerOption = environment.headerOption;
    if (this._cookieservice.get('token')) {
      const loggedInUtility = JSON.parse(this._cookieservice.get('token'));
      headerOption['Authorization'] = loggedInUtility.access_token;
    }
    const headers = new HttpHeaders(headerOption);
    const options = { headers };
    return options
  }

  getAll(data) {

    return this.http.post(environment.apiEndPoint + 'payment/list', data, this.getHeaders()).map(res =>
      res as any);
  }



}
