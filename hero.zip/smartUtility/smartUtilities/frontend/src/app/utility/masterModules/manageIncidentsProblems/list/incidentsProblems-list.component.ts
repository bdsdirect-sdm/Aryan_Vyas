import { Component, OnInit, TemplateRef } from '@angular/core';
import { incidentsService } from '../../../../utility/masterModules/services/incidents.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import * as CryptoJS from 'crypto-js';
import { CommonService } from '../../../services/common.service';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { environment } from '../../../../../environments/environment';
import * as moment from 'moment';

@Component({
  selector: 'incidents-list',
  templateUrl: './incidentsProblems-list.component.html',
  styleUrls: ['./incidentsProblems-list.component.css']
})
export class incidentsProblemsListComponent implements OnInit {
  title = 'Incidents';
  incidents: any;
  modalRef: BsModalRef;
  itemValue: any;
  recordsPerPage: unknown;
  date_format: any;
  time_format: any;
  resolution: any;
  constructor(private incidentsService: incidentsService, private spinner: NgxSpinnerService, private modalService: BsModalService,
    private toastr: ToastrService, private activatedRoute: ActivatedRoute, private router: Router, private commonService: CommonService
  ) {
    this.resolution = {};
    this.resolution.status = 'resolved';
    this.activatedRoute.params.subscribe(paramid => {
      if (activatedRoute.snapshot.routeConfig.path.includes('manageIncidents/requests')) {
        this.getRequestsIncidents(paramid.id);
      } else {
        this.getList();
      }
    });
  }

  ngOnInit() {

  }

  searchTitle() {
    let keyword = this.title;
    this.incidentsService.search(keyword)
      .subscribe(
        data => {
          this.incidents = data;
          console.log(data);
        },
        err => {
          this.spinner.hide();
          this.commonService.handleError(err);
        });
  }

  async getRequestsIncidents(request_id) {
    this.spinner.show();

    let superAdminSettings: any = await this.commonService.getSuperAdminDetails();
    this.recordsPerPage = superAdminSettings.records_per_page;
    this.date_format = superAdminSettings.default_date_format;
    this.time_format = superAdminSettings.time_format;

    this.incidentsService.incidentDetail(request_id).subscribe(result => {
      this.incidents = result.data;
      this.incidents.forEach((tmpObj, k) => {

        this.incidents[k]['sortid'] = this.incidents[k].id;
        this.incidents[k].id = btoa(this.incidents[k].id);
        this.incidents[k]['raised_at'] = moment(this.incidents[k].created_at).format(this.date_format);
        if (this.time_format == '12hours') {
          this.incidents[k]['time'] = moment(this.incidents[k].created_at).format('h:mm A');
        } else {
          this.incidents[k]['time'] = moment(this.incidents[k].created_at).format('HH:mm');
        }
      });
      this.spinner.hide();
    }, err => {
      console.log("error from api");
    });
  }

  async getList() {
    this.spinner.show();

    let superAdminSettings: any = await this.commonService.getSuperAdminDetails();
    this.recordsPerPage = superAdminSettings.records_per_page;
    this.date_format = superAdminSettings.default_date_format;
    this.time_format = superAdminSettings.time_format;

    this.incidentsService.getAll().subscribe(result => {
      this.incidents = result.data;
      this.incidents.forEach((tmpObj, k) => {

        this.incidents[k]['sortid'] = this.incidents[k].id;
        this.incidents[k].id = btoa(this.incidents[k].id);
        this.incidents[k]['raised_at'] = moment(this.incidents[k].created_at).format(this.date_format);
        if (this.time_format == '12hours') {
          this.incidents[k]['time'] = moment(this.incidents[k].created_at).format('h:mm A');
        } else {
          this.incidents[k]['time'] = moment(this.incidents[k].created_at).format('HH:mm');
        }
      });
      this.spinner.hide();
    }, err => {
      console.log("error from api");
    });
    this.title = '';
  }


  deleteRow() {
    this.spinner.show();
    this.modalRef.hide();
    this.incidentsService.deleteIncident(this.itemValue.id).subscribe(result => {
      this.getList();
      this.toastr.success('Service Type has been deleted successfully', 'Success');
    }, err => {
      console.log("error from api");
      this.toastr.error('Something went wrong', 'Error');
    });
  }

  openModal(template: TemplateRef<any>, data) {
    this.modalRef = this.modalService.show(template);
    this.itemValue = data;
  }

  closeModal() {
    this.modalRef.hide();
  }

  viewRequest(id) {
    this.router.navigate(['/utility/manageServiceRequests/view', btoa(id)]);
  }

  markResolved() {
    this.spinner.show();
    let json = {
      id: this.itemValue.id,
      resolution_description: this.resolution.description,
      incident_status: this.resolution.status
    }
    this.incidentsService.markResolved(json).subscribe(result => {
      this.modalRef.hide();
      this.spinner.hide();
      this.getList();
      this.toastr.success('Incident ' + this.resolution.status + ' successfully', 'Success');
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
  }
}
