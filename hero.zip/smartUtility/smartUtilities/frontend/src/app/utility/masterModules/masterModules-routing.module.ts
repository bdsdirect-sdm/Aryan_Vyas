import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { masterModulesComponent } from './masterModules.component';
import { leftBarComponent } from './leftBar/leftBar.component';
import { dashboardComponent } from './dashboard/dashboard.component';
import { serviceTypesListComponent } from './manageServiceTypes/list/serviceTypes-list.component';
import { serviceTypesAddComponent } from './manageServiceTypes/add/serviceTypes-add.component';
import { serviceTypesEditComponent } from './manageServiceTypes/edit/serviceTypes-edit.component';
import { subAdminListComponent } from './manageSubAdmins/list/subAdmins-list.component';
import { subAdminAddComponent } from './manageSubAdmins/add/subAdmins-add.component';
import { subAdminEditComponent } from './manageSubAdmins/edit/subAdmins-edit.component';

import { serviceProvidersListComponent } from './manageServiceProviders/list/serviceProviders-list.component';
import { serviceProvidersAddComponent } from './manageServiceProviders/add/serviceProviders-add.component';
import { serviceProvidersEditComponent } from './manageServiceProviders/edit/serviceProviders-edit.component';

import { customerAddComponent } from './manageCustomers/add/customers-add.component';
import { customerEditComponent } from './manageCustomers/edit/customers-edit.component';
import { customerListComponent } from './manageCustomers/list/customers-list.component';

import { serviceRequestsAddComponent } from './manageServiceRequests/add/serviceRequests-add.component';
import { serviceRequestsEditComponent } from './manageServiceRequests/edit/serviceRequests-edit.component';
import { serviceRequestsListComponent } from './manageServiceRequests/list/serviceRequests-list.component';

import { incidentsProblemsListComponent } from './manageIncidentsProblems/list/incidentsProblems-list.component';
import { incidentsProblemsViewComponent } from './manageIncidentsProblems/view/incidentsProblems-view.component';

import { ratingListComponent } from './ratingManagement/list/rating-list.component';

import { CalenderComponent } from './manageCalender/calender.component';

import { AuthGuard } from '../../shared/auth.guard';
import { CalenderOtherComponent } from './manageCalenderother/calender.component';
import { serviceRequestsViewComponent } from './manageServiceRequests/view/serviceRequests-view.component';
import { PaymentComponent } from './managePayments/payment.component';
import { profileComponent } from './profile/profile.component';

export const routes: Routes = [
  {
    path: 'utility', component: masterModulesComponent,
    children: [
      {
        path: 'dashboard',
        canActivate: [AuthGuard],
        component: dashboardComponent
      },
      {
        path: 'profile',
        canActivate: [AuthGuard],
        component: profileComponent
      },
      {
        path: 'manageServiceTypes',
        canActivate: [AuthGuard],
        component: serviceTypesListComponent
      },
      {
        path: 'manageServiceTypes/add',
        canActivate: [AuthGuard],
        component: serviceTypesAddComponent
      },
      {
        path: 'manageServiceTypes/edit/:id',
        canActivate: [AuthGuard],
        component: serviceTypesEditComponent
      },
      {
        path: 'manageSubAdmins',
        canActivate: [AuthGuard],
        component: subAdminListComponent
      },
      {
        path: 'manageSubAdmins/add',
        canActivate: [AuthGuard],
        component: subAdminAddComponent
      },
      {
        path: 'manageSubAdmins/edit/:id',
        canActivate: [AuthGuard],
        component: subAdminEditComponent
      },
      {
        path: 'manageServiceProviders',
        canActivate: [AuthGuard],
        component: serviceProvidersListComponent
      },
      {
        path: 'manageServiceProviders/add',
        canActivate: [AuthGuard],
        component: serviceProvidersAddComponent
      },
      {
        path: 'manageServiceProviders/edit/:id',
        canActivate: [AuthGuard],
        component: serviceProvidersEditComponent
      },
      {
        path: 'manageCustomers',
        canActivate: [AuthGuard],
        component: customerListComponent
      },
      {
        path: 'manageCustomers/add',
        canActivate: [AuthGuard],
        component: customerAddComponent
      },
      {
        path: 'manageCustomers/edit/:id',
        canActivate: [AuthGuard],
        component: customerEditComponent
      },
      {
        path: 'manageServiceRequests',
        canActivate: [AuthGuard],
        component: serviceRequestsListComponent
      },
      {
        path: 'manageServiceRequests/view/:id',
        canActivate: [AuthGuard],
        component: serviceRequestsViewComponent
      },
      {
        path: 'manageServiceRequests/customer/:id',
        canActivate: [AuthGuard],
        component: serviceRequestsListComponent
      },
      {
        path: 'manageServiceRequests/provider/:id',
        canActivate: [AuthGuard],
        component: serviceRequestsListComponent
      },
      {
        path: 'manageServiceRequests/add/:id',
        canActivate: [AuthGuard],
        component: serviceRequestsAddComponent
      },
      {
        path: 'manageServiceRequests/edit/:id',
        canActivate: [AuthGuard],
        component: serviceRequestsEditComponent
      },
      {
        path: 'manageCalender/:id',
        canActivate: [AuthGuard],
        component: CalenderComponent
      },
      {
        path: 'manageIncidents',
        canActivate: [AuthGuard],
        component: incidentsProblemsListComponent
      },
      {
        path: 'manageIncidents/requests/:id',
        canActivate: [AuthGuard],
        component: incidentsProblemsListComponent
      },
      {
        path: 'manageRating',
        canActivate: [AuthGuard],
        component: ratingListComponent
      },

      {
        path: 'manageCalenderOther/:id',
        canActivate: [AuthGuard],
        component: CalenderOtherComponent
      },
      {
        path: 'managePayment',
        canActivate: [AuthGuard],
        component: PaymentComponent
      },
      {
        path: 'managePayment/providers/:id',
        canActivate: [AuthGuard],
        component: PaymentComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class masterModulesRoutingModule { }
