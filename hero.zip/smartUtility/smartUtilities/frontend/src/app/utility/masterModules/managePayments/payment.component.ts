import { Component, OnInit } from '@angular/core';
import { CommonService } from '../../services/common.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import * as _ from 'underscore';
import { ToastrService } from 'ngx-toastr';
import { PaymentsService } from '../services/payments.service';

@Component({
  selector: 'payment-root',
  templateUrl: './payment.component.html',
  styleUrls: ['./payment.component.css']
})
export class PaymentComponent implements OnInit {
  title = '';
  recordsPerPage: any;
  paymentList: any;
  date_format: any;
  time_format: any;
  defaultCurrency: any;

  constructor(private commonService: CommonService, private paymentService: PaymentsService,
    private spinner: NgxSpinnerService, private router: Router, private toastr: ToastrService, private activatedRoute: ActivatedRoute) {
      this.activatedRoute.params.subscribe(paramid => {
        if (activatedRoute.snapshot.routeConfig.path.includes('managePayment/providers')) {
          this.getList(paramid.id);
        } else {
          this.getList('');
        }
      });
  }

  ngOnInit() {
    this.commonService.notifyOther({ option: 'breadcrumbs', value: 'Manage Calender' });
  }

  async getList(provider_id) {
    this.spinner.show();
    let json = {
    }
    if (provider_id && provider_id != '') {
      json['provider_id'] = provider_id
    }
    let superAdminSettings: any = await this.commonService.getSuperAdminDetails();
    this.recordsPerPage = superAdminSettings.records_per_page;
    this.date_format = superAdminSettings.default_date_format;
    this.time_format = superAdminSettings.time_format;
    this.defaultCurrency = superAdminSettings.default_currency;
    this.paymentService.getAll(json).subscribe(result => {
      console.log('---------------ssssss', result)
      this.paymentList = result.data;
      _.each(this.paymentList, obj => {
        obj['id'] = btoa(obj['id']);
        obj['payment_date'] = moment(obj['payment_date']).format(this.date_format);
        if (this.time_format == '12hours') {
          obj['time'] = moment(obj['time']).format("h:mm A");
        } else {
          obj['time'] = moment(obj['time']).format("HH:mm");
        }
      });
      this.spinner.hide();
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
  }

  viewRequest(id) {
    this.router.navigate(['/utility/manageServiceRequests/view', btoa(id)]);
  }


   searchTitle() {
    let keyword = this.title;
    let json = {
    }
    if (keyword && keyword != '') {
      json['keyword'] = keyword
    }
    this.paymentService.getAll(json).subscribe(result => {
      console.log('---------------ssssss', result)
      this.paymentList = result.data;
      _.each(this.paymentList, obj => {
        obj['id'] = btoa(obj['id']);
        obj['payment_date'] = moment(obj['payment_date']).format(this.date_format);
        if (this.time_format == '12hours') {
          obj['time'] = moment(obj['time']).format("h:mm A");
        } else {
          obj['time'] = moment(obj['time']).format("HH:mm");
        }
      });
      this.spinner.hide();
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
  }

}
