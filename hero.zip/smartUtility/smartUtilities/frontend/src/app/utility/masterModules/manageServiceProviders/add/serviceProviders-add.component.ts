import { Component, OnInit } from '@angular/core';
import { serviceProvidersService } from '../../../../utility/masterModules/services/serviceProviders.service';
import { serviceTypesService } from '../../../../utility/masterModules/services/serviceTypes.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { HttpClient, HttpEventType } from '@angular/common/http';
import { environment } from '../../../../../environments/environment';
import { CommonService } from '../../../services/common.service';
@Component({
  selector: 'serviceProviders-add-tutorial',
  templateUrl: './serviceProviders-add.component.html',
  styleUrls: ['./serviceProviders-add.component.css']
})
export class serviceProvidersAddComponent implements OnInit {
  utilityServiceProviders: any = {};
  utilityServiceTypes: any;
  responseServices: any = [];
  responseAvailability: any = [];
  submitted = false;
  mobNumberPattern = "^((\\+[0-999])|0)?[0-9]{10}$";
  dataIds: any = [];
  daysIds: any = [];
  baseUrl = "";
  experience: any = [];
  currency: string;
  filePhotoStatus = false;
  fileProofStatus = false;
  environment: any = environment;
  checked = false;
  imageTypes: any = {

    "allowedMimeTypes": [
      "image/jpeg",
      "image/png",
      "image/gif",
      "image/bmp",
      "image/jpg"
    ],
  }
  days: any = {

    "availability": [
      {
        "day": "Monday",
        "day_short": "Mon",
        "day_index": 1,
        "timeFrom": { hour: "", minute: "" },
        "timeTo": { hour: "", minute: "" }
      },
      {
        "day": "Tuesday",
        "day_short": "Tue",
        "day_index": 2,
        "timeFrom": { hour: "", minute: "" },
        "timeTo": { hour: "", minute: "" }
      },
      {
        "day": "Wednesday",
        "day_short": "Wed",
        "day_index": 3,
        "timeFrom": { hour: "", minute: "" },
        "timeTo": { hour: "", minute: "" }
      },
      {
        "day": "Thursday",
        "day_short": "Thur",
        "day_index": 4,
        "timeFrom": { hour: "", minute: "" },
        "timeTo": { hour: "", minute: "" }
      },
      {
        "day": "Friday",
        "day_short": "Fri",
        "day_index": 5,
        "timeFrom": { hour: "", minute: "" },
        "timeTo": { hour: "", minute: "" }
      },
      {
        "day": "Saturday",
        "day_short": "Sat",
        "day_index": 6,
        "timeFrom": { hour: "", minute: "" },
        "timeTo": { hour: "", minute: "" }
      },
      {
        "day": "Sunday",
        "day_short": "Sun",
        "day_index": 7,
        "timeFrom": { hour: "", minute: "" },
        "timeTo": { hour: "", minute: "" }
      },
    ]
  }

  fileData: File = null;
  previewPhotoUrl: any = "";
  previewProofUrl: any = "";
  fileUploadProgress: string = null;
  uploadedFilePath: string = null;

  constructor(private serviceTypesService: serviceTypesService,
    private commonService: CommonService, private route: ActivatedRoute, private toastr: ToastrService, private router: Router, private serviceProvidersService: serviceProvidersService, private spinner: NgxSpinnerService) {

    this.utilityServiceProviders = {};
    this.utilityServiceTypes = {};
    this.baseUrl = this.environment.apiEndPoint;

    this.currency = this.environment.currency;

    for (let i = 0; i <= 30; i++) {
      this.experience.push(i)
    }
  }

  ngOnInit() {
    this.getServices();
    this.commonService.notifyOther({ option: 'breadcrumbs', value: 'Manage Service Providers' });
  }

  selectall() {

    if (this.days.availability.length == this.daysIds.length) {
      this.daysIds = [];
      this.days.availability.forEach(val => { val.timeFrom = "" });
    } else {
      this.daysIds = [];
      this.days.availability.forEach(val => { this.daysIds.push(val.day) });
    }
  }
  getServices() {
    let inputJson = {};
    inputJson['page'] = 1;
    inputJson['limit'] = 100;
    inputJson['sort'] = { 'title': 'asc' };
    inputJson['is_active'] = 1;
    this.serviceTypesService.getAll(inputJson).subscribe(result => {

      this.utilityServiceTypes = result;
      console.log("utilityServiceTypes==", this.utilityServiceTypes);

    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
  }

  unselectAll() {
    this.checked = false;

  }

  onUpload(file: any, fieldName) {
    this.fileData = file.target.files[0];
    var mimeType = this.fileData.type;
    if (mimeType.match(/image\/*/) == null) {
      this.toastr.error('Please upload image only', 'Error');
      return;
    }
    var reader = new FileReader();
    reader.readAsDataURL(this.fileData);
    reader.onload = (_event) => {
      if (fieldName == 'photo') {
        this.previewPhotoUrl = reader.result;
      } else {
        this.previewProofUrl = reader.result;
      }
      const formData = new FormData();
      formData.append('file', this.fileData);
      console.log("-=-=formData=-=-", formData);
      this.serviceProvidersService.uploadFile(formData).subscribe(events => {
        if (events.success) {
          console.log("---------------inside", events);
          if (fieldName == 'photo') {
            this.utilityServiceProviders.photo = events.data.filename;
            this.filePhotoStatus = true;
          } else {
            this.utilityServiceProviders.identityproof = events.data.filename;
            this.fileProofStatus = true;
          }
        }

      })

    }
  }


  previewAndUpload(event, fieldName) {
    (this.filePhotoStatus == true) ? true : false;
    (this.fileProofStatus == true) ? true : false;
    const allowedImageMimeTypes = this.imageTypes.allowedMimeTypes;
    if (event && event.target && event.target.files && event.target.files.length > 0) {
      if (allowedImageMimeTypes.indexOf(event.target.files[0].type) == -1) {
        this.toastr.error('Wrong file type', 'Error');
        return false;
      } else if (event.target.files[0].size > 5242880) {
        this.toastr.error('Image size should not exceed 5MB', 'Error');
        return false;
      } else {
        this.onUpload(event, fieldName)
      }
    }
  }


  save() {

    if (this.filePhotoStatus == false) {
      this.toastr.error('Please upload profile photo', 'Error');
      return false;
    }
    if (this.fileProofStatus == false) {
      this.toastr.error('Please upload ID proof photo', 'Error');
      return false;
    }

    if(this.daysIds.length==0){
      this.toastr.error('Please set your availablity', 'Error');
      return false;
    }
    this.spinner.hide();

    console.log("-=-this.days.availability-==-", this.days.availability);

    if (this.dataIds.length == 0) {
      this.toastr.error('Please select service type', 'Error');
      return false;
    }
    var userAvail = [];
    for (let i = 0; i < this.days.availability.length; i++) {

      for (let j = 0; j < this.daysIds.length; j++) {

        if (this.daysIds[j] == this.days.availability[i].day) {

          if (this.days.availability[i].timeFrom != null && this.days.availability[i].timeTo == null) {

            this.toastr.error('Please enter end time for ' + this.daysIds[j], 'Error');
            return false;

          } else if (this.days.availability[i].timeFrom == null && this.days.availability[i].timeTo != null) {

            this.toastr.error('Please enter start time for ' + this.daysIds[j], 'Error');
            return false;

          } else {

            if (this.days.availability[i].timeFrom.hour != "" && this.days.availability[i].timeFrom.hour >= 0 && this.days.availability[i].timeTo.hour == "") {
              this.toastr.error('Please enter end time for ' + this.daysIds[j], 'Error');
              return false;

            }

            if (this.days.availability[i].timeTo.hour != "" && this.days.availability[i].timeTo.hour >= 0 && this.days.availability[i].timeFrom.hour == "") {
              this.toastr.error('Please enter start time for ' + this.daysIds[j], 'Error');
              return false;
            }

            console.log("index is ==", userAvail.findIndex(x => x.day === this.daysIds[j]))
            if (userAvail.findIndex(x => x.day === this.daysIds[j]) < 0) {


              if (this.days.availability[i].timeFrom.hour == 'undefined') {
                userAvail.push({
                  day: this.daysIds[j],
                  timeFrom: ":",
                  timeTo: ":"
                });

              } else {

                if (this.days.availability[i].timeTo.minute > 0 && this.days.availability[i].timeFrom.minute > 0) {

                  let stime = this.days.availability[i].timeFrom.hour + "." + this.days.availability[i].timeFrom.minute;

                  let etime = this.days.availability[i].timeTo.hour + "." + this.days.availability[i].timeTo.minute;


                  if (parseFloat(etime) <= parseFloat(stime)) {
                    this.toastr.error('Time range is not valid for ' + this.daysIds[j], 'Error');
                    return false;

                  }
                }

                userAvail.push({
                  day: this.daysIds[j],
                  timeFrom: this.days.availability[i].timeFrom.hour + ":" + this.days.availability[i].timeFrom.minute,
                  timeTo: this.days.availability[i].timeTo.hour + ":" + this.days.availability[i].timeTo.minute
                });
              }
            }
          }
        }
      }
    }

    this.utilityServiceProviders['first_name'] = this.commonService.titleCase(this.utilityServiceProviders.first_name);
    this.utilityServiceProviders['last_name'] = this.commonService.titleCase(this.utilityServiceProviders.last_name);

    var data = {
      formdata: this.utilityServiceProviders,
      serviceTypes: this.dataIds,
      availability: userAvail
    }

    this.serviceProvidersService.create(data)
      .subscribe(
        response => {
          this.toastr.success('Service Provider has been added successfully', 'Success');
          this.router.navigate(['/utility/manageServiceProviders']);
        },
        err => {
          this.spinner.hide();
          this.commonService.handleError(err);

        });
  }


}
