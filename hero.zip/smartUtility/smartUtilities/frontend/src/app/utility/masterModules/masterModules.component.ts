import { Component, OnInit } from '@angular/core';
import { CommonService } from '../services/common.service';

@Component({
  selector: 'masterModules-root',
  templateUrl: './masterModules.component.html',
  styleUrls: ['./masterModules.component.css']
})
export class masterModulesComponent implements OnInit{
  title = 'frontend';
  active_link_name: any;

  constructor(private commonService: CommonService) {
  }

  ngOnInit() {
    this.commonService.notifyObservable$.subscribe((res) => {
      if (res.hasOwnProperty('option') && res.option === 'breadcrumbs' && res.value !== undefined) {
        this.active_link_name = res.value;
      }
    });
  }


}
