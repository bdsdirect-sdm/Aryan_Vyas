import { Component, OnInit } from '@angular/core';


@Component({
  selector: 'incidentsProblems-view',
  templateUrl: './incidentsProblems-view.component.html',
  styleUrls: ['./incidentsProblems-view.component.css']
})
export class incidentsProblemsViewComponent implements OnInit {
  
  constructor() {
    
  }

  ngOnInit() {
    
  }

  

  
}
