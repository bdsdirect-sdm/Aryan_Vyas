import { Component, OnInit, TemplateRef } from '@angular/core';
import { incidentsService } from '../../../../utility/masterModules/services/incidents.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import * as CryptoJS from 'crypto-js';
import { CommonService } from '../../../services/common.service';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { environment } from '../../../../../environments/environment';
import * as moment from 'moment';

@Component({
  selector: 'rating-list',
  templateUrl: './rating-list.component.html',
  styleUrls: ['./rating-list.component.css']
})
export class ratingListComponent implements OnInit {
  title = 'Incidents';
  rating: any;
  modalRef: BsModalRef;
  recordsPerPage: unknown;
  date_format: any;
  time_format: any;
  constructor(private incidentsService: incidentsService, private spinner: NgxSpinnerService, private modalService: BsModalService,
    private toastr: ToastrService, private router: Router, private commonService: CommonService
  ) {
  }

  ngOnInit() {
  	this.getList();
  }

 searchTitle() {
    let keyword = this.title;
    this.incidentsService.searchRating(keyword)
      .subscribe(
        data => {
          this.rating = data;
          console.log(data);
        },
        err => {
          this.spinner.hide();
          this.commonService.handleError(err);
        });
  }
 
  async getList() {
    this.spinner.show(); 
    let inputJson = {};
    inputJson['page'] = 1;
    inputJson['limit'] = 10;
    inputJson['sort'] = { 'title': 'asc' };
    let superAdminSettings: any = await this.commonService.getSuperAdminDetails();
    this.recordsPerPage = superAdminSettings.records_per_page;
    this.date_format = superAdminSettings.default_date_format;
    this.time_format = superAdminSettings.time_format;
    
    this.incidentsService.getAllRating(inputJson).subscribe(result => {
      console.log("--list data--", result)
      this.rating = result.data;
      this.rating.forEach((tmpObj, k) => {      
        this.rating[k].id=btoa(this.rating[k].id);
        if(this.time_format == '12hours') {
          this.rating[k]['time'] = moment(this.rating[k].created_at).format('h:mm A');
        } else {
          this.rating[k]['time'] = moment(this.rating[k].created_at).format('HH:mm');
        }
        this.rating[k]['created_at']=moment(this.rating[k].created_at).format(this.date_format);
      });
      this.spinner.hide();
    }, err => {
      console.log("error from api");
    });
    this.title='';
  }

  viewRequest(id) {
    this.router.navigate(['/utility/manageServiceRequests/view', btoa(id)]);
  }

}
