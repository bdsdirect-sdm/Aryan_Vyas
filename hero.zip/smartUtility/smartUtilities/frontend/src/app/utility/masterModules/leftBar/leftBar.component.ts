import { Component, OnInit } from '@angular/core';
import { subAdminsService } from '../services/subAdmins.service';
import { UtilityService } from '../../services/utility.service';
import { Router, ActivatedRoute } from '@angular/router';
import { CookieService } from 'ngx-cookie';
import { CommonService } from '../../services/common.service';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-utility-sidebar',
  templateUrl: './leftBar.component.html',
  styleUrls: ['./leftBar.component.css']
})
export class leftBarComponent implements OnInit {
  title = 'frontend';
  loggedInUser: any;
  sidebarList: any;
  currentRoter: any;

  constructor(private subAdminService: subAdminsService, private utilityService: UtilityService,
    private router: Router, private activatedRoute: ActivatedRoute, private commonService: CommonService,
    private _cookieservice: CookieService, private toastr: ToastrService) {
    this.loggedInUser = JSON.parse(this._cookieservice.get('token'));
    this.currentRoter = activatedRoute.snapshot.firstChild.url[0].path;
  }

  ngOnInit() {
    if (this.loggedInUser.type == 'subadmin') {
      this.getSidebarList();
    } else {
      this.getAllModules();
    }
    this.commonService.notifyObservable$.subscribe((res) => {
      if (res.hasOwnProperty('option') && res.option === 'sidebar-active' && res.value !== undefined) {
        this.currentRoter = res.value;
      }
    });
  }

  getSidebarList() {
    this.utilityService.getModulesDetails(btoa(this.loggedInUser.id)).subscribe(result => {
      this.sidebarList = result;
      if(this.sidebarList.length == 0) {
        this.toastr.info('No permission given to you. Please contact admin', 'Info')
      }
    }, err => {
      this.commonService.handleError(err);
    });
  }

  getAllModules() {
    this.subAdminService.getAllModules().subscribe(result => {
      this.sidebarList = result;
    }, err => {
      this.commonService.handleError(err);
    });

  }

  changeRoute(router) {
    this.currentRoter = router;
  }

}
