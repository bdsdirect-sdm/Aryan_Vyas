import { Component, OnInit } from '@angular/core';
import { CommonService } from '../../services/common.service';
import { UtilityService } from '../../services/utility.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import * as _ from 'underscore';
import * as moment from 'moment';

import { serviceRequestService } from '../services/serviceRequests.service';

@Component({
  selector: 'dashboard-root',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class dashboardComponent implements OnInit {
  title = 'frontend';
  notificationsList: any;
  notiCount: any;
  pageNumber: any;
  requestedServices:any;
  assignedServices:any;
  inProgressServices:any;
  completedServices:any;
  paidServices:any;
  cancelledServices:any;
  recordsPerPage: unknown;
  date_format: any;
  time_format: any;
  defaultCurrency: any;
  listLimit = 5;
  constructor(private commonService: CommonService,
     private utilityService: UtilityService,
     private spinner: NgxSpinnerService,
    private toastr: ToastrService,private serviceRequestService: serviceRequestService) {
    this.notificationsList = [];
    this.pageNumber = 1;
  }

  ngOnInit() {
    this.commonService.notifyOther({ option: 'breadcrumbs', value: 'Dashboard' });
   
    this.showAll();
    
  }
  async showAll(){

    let superAdminSettings: any = await this.commonService.getSuperAdminDetails();
    this.recordsPerPage = superAdminSettings.records_per_page;
    this.date_format = superAdminSettings.default_date_format;
    this.time_format = superAdminSettings.time_format;
    this.defaultCurrency = superAdminSettings.default_currency;
    this.getJobs(1);
    this.getJobs(2);
    this.getJobs(3);
    this.getJobs(4);
    this.getJobs(5);
    this.getJobs(6);

  }

  getJobs(status){  
     let json = {}
      json['status'] = status;
      json['limit'] = this.listLimit;
      this.serviceRequestService.getAllServiceGroup(json).subscribe(result => {

        _.each(result.data, obj => {
          obj['id'] = btoa(obj['id']);
          obj['date'] = moment(obj['date']).format(this.date_format);
          if (this.time_format == '12hours') {
            obj['time'] = moment(obj['time'], ["HH:mm"]).format("h:mm A");
          } else {
            obj['time'] = moment(obj['time'], ["HH:mm"]).format("HH:mm");
          }
        });

        if(status==1){
          this.requestedServices  = result.data;
        }
        else if(status==2){
          this.assignedServices   = result.data;
        }
        else if(status==3){
          this.inProgressServices = result.data;
        }
        else if(status==4){
          this.completedServices  = result.data;
        }
        else if(status==5){
          this.paidServices       = result.data;
        }
        else if(status==6){
          this.cancelledServices  = result.data;
        }
        else {       
        }
      
      });
  }
 
  getNotifications() {
    this.utilityService.getNotification().subscribe(result => {
      this.notificationsList = result.data;
      _.each(this.notificationsList, (obj: any) => {
        obj['timeAgo'] = this.timeSince(obj.created_at);
      });

      console.log('-----------sss', this.notificationsList)

    }, err => {
      this.commonService.handleError(err);
    });
  }

  /*________________________________________________________________________

   * @Method :        timeSince
   * Modified On:     -
   * @Purpose:        Convert time format
   * Input:
   * Output:          Time in ago format
   _________________________________________________________________________
  */
  timeSince(time) {
    switch (typeof time) {
      case 'number':
        break;
      case 'string':
        time = +new Date(time);
        break;
      case 'object':
        if (time.constructor === Date) { time = time.getTime(); }
        break;
      default:
        time = +new Date();
    }
    const time_formats = [
      [60, 'seconds', 1], // 60
      [120, '1 minute ago', '1 minute from now'], // 60*2
      [3600, 'minutes', 60], // 60*60, 60
      [7200, '1 hour ago', '1 hour from now'], // 60*60*2
      [86400, 'hours', 3600], // 60*60*24, 60*60
      [172800, 'Yesterday', 'Tomorrow'], // 60*60*24*2
      [604800, 'days', 86400], // 60*60*24*7, 60*60*24
      [1209600, 'Last week', 'Next week'], // 60*60*24*7*4*2
      [2419200, 'weeks', 604800], // 60*60*24*7*4, 60*60*24*7
      [4838400, 'Last month', 'Next month'], // 60*60*24*7*4*2
      // [29030400, messagesConstants.months, 2419200], // 60*60*24*7*4*12, 60*60*24*7*4
      [58060800, 'Last year', 'Next year'], // 60*60*24*7*4*12*2
      [2903040000, 'years', 29030400], // 60*60*24*7*4*12*100, 60*60*24*7*4*12
      [5806080000, 'Last century', 'Next century'], // 60*60*24*7*4*12*100*2
      [58060800000, 'centuries', 2903040000] // 60*60*24*7*4*12*100*20, 60*60*24*7*4*12*100
    ];
    let seconds = (+new Date() - time) / 1000,
      token = 'ago',
      list_choice = 1;

    if (seconds == 0) {
      return 'Just now';
    }
    if (seconds < 0) {
      seconds = Math.abs(seconds);
      token = 'from now';
      list_choice = 2;
    }
    let i = 0,
      format;
    while (format = time_formats[i++]) {
      if (seconds < format[0]) {
        if (typeof format[2] == 'string') {
          return format[list_choice];
        }
        else {
          return Math.floor(seconds / format[2]) + ' ' + format[1] + ' ' + token;
        }
      }
    }
    return time;
  }
}
