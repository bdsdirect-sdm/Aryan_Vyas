import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { customerService } from '../../services/customers.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { Address } from 'ngx-google-places-autocomplete/objects/address';
import { GooglePlaceDirective } from 'ngx-google-places-autocomplete';
import { CommonService } from '../../../services/common.service';

@Component({
  selector: 'subAdmins-add-tutorial',
  templateUrl: './customers-add.component.html',
  styleUrls: ['./customers-add.component.css']
})
export class customerAddComponent implements OnInit {
  customer: any;
  @ViewChild("placesRef") placesRef: GooglePlaceDirective;

  constructor(private customerService: customerService, private spinner: NgxSpinnerService,
    private toastr: ToastrService, private router: Router, private commonService: CommonService) {
    this.customer = {};
    this.commonService.notifyOther({ option: 'breadcrumbs', value: 'Manage Customers' });
  }

  ngOnInit() {
  }

  save() {
    this.spinner.show();
    this.customer['first_name'] = this.commonService.titleCase(this.customer.first_name);
    this.customer['last_name'] = this.commonService.titleCase(this.customer.last_name);
    this.customerService.createCustomer(this.customer).subscribe(response => {
      this.spinner.hide();
      this.toastr.success('Customer added successfully', 'Success');
      this.router.navigate(['/utility/manageCustomers']);
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
  }

  handleAddressChange(place: Address) {
    this.spinner.show();
    const location_obj = {};
    location_obj['lat'] = (place.geometry && place.geometry.location && place.geometry.location.lat()) ? place.geometry.location.lat() : '';
    location_obj['lng'] = (place.geometry && place.geometry.location && place.geometry.location.lng()) ? place.geometry.location.lng() : '';
    for (const i in place.address_components) {
      const item = place.address_components[i];
      location_obj['formatted_address'] = place.formatted_address;
      location_obj['full_address'] = place.name + ', ' + place.formatted_address;
      if ((item.types.indexOf('locality') > -1) || (item.types.indexOf('sublocality_level_1') > -1) || (item.types.indexOf('administrative_area_level_2') > -1)) {
        location_obj['city'] = item.long_name;
      } else if (item.types.indexOf('administrative_area_level_1') > -1) {
        location_obj['state'] = item.long_name;
      } else if (item.types.indexOf('street_number') > -1) {
        location_obj['street_number'] = item.short_name;
      } else if (item.types.indexOf('route') > -1) {
        location_obj['route'] = item.long_name;
      } else if (item.types.indexOf('country') > -1) {
        location_obj['country'] = item.long_name;
      } else if (item.types.indexOf('postal_code') > -1) {
        location_obj['postal_code'] = item.short_name;
      }

    }
    this.customer['city'] = location_obj['city'];
    this.customer['state'] = location_obj['state'];
    this.customer['country'] = location_obj['country'];
    this.customer['zip'] = location_obj['postal_code'];
    this.customer['address'] = location_obj['formatted_address'];
    this.spinner.hide();
  }

  addServiceRequest() {
    this.spinner.show();
    this.customer['first_name'] = this.commonService.titleCase(this.customer.first_name);
    this.customer['last_name'] = this.commonService.titleCase(this.customer.last_name);
    this.customerService.createCustomer(this.customer).subscribe(response => {
      this.spinner.hide();
      this.toastr.success('Customer added successfully', 'Success');
      this.router.navigate(['/utility/manageServiceRequests/add', btoa(response.data.insertId)]);
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
  }

}
