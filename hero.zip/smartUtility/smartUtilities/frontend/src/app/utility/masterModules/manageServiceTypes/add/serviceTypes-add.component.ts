import { Component, OnInit } from '@angular/core';
import { serviceTypesService } from '../../../../utility/masterModules/services/serviceTypes.service';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { HttpClient, HttpEventType } from '@angular/common/http';
import { CommonService } from '../../../services/common.service';
import { environment } from '../../../../../environments/environment';
@Component({
  selector: 'serviceTypes-add-tutorial',
  templateUrl: './serviceTypes-add.component.html',
  styleUrls: ['./serviceTypes-add.component.css']
})
export class serviceTypesAddComponent implements OnInit {
  utilityServiceTypes: any = {};
  submitted = false;
  subServiceTitle: string = "";
  currency: string;
  subServices: any = [];  
  subServiceHourlyPrice: string = "";
  subServiceFlatPrice:string="";
  environment: any = environment;
  defaultCurrency: any;
  allCategories: any;
  subCategories:any;
  
  constructor(private serviceTypesService: serviceTypesService,
    private toastr: ToastrService, private router: Router, private commonService: CommonService,private spinner: NgxSpinnerService) {

    this.currency = this.environment.currency;
    this.utilityServiceTypes.subServices = {};
    
  }

  async ngOnInit() {
    let superAdminSettings: any = await this.commonService.getSuperAdminDetails();
    this.defaultCurrency = superAdminSettings.default_currency;
    this.commonService.notifyOther({ option: 'breadcrumbs', value: 'Manage Service Types' });

    let categories: any = await this.commonService.getCategories();
    this.allCategories=categories;

    //console.log("---this.allCategories----",this.allCategories);

  }

  async getSubCategories(){
    this.spinner.show();
    console.log("---vaalaa",this.utilityServiceTypes.utility_id);
    this.subCategories= await this.commonService.getSubCategories(this.utilityServiceTypes.utility_id);
    console.log("---subCategories----",this.subCategories);
    this.spinner.hide();
  }


  addSubservice() {
    if (this.subServiceTitle == '') {
      this.toastr.error('Please enter service type', 'Error');
      return false;
    }
    if (this.subServiceHourlyPrice == '') {
      this.toastr.error('Please enter sub service hourly price', 'Error');
      return false;
    }

    if (!this.subServiceHourlyPrice) {
      this.toastr.error('Please enter sub service hourly price', 'Error');
      return false;
    }

    if (this.subServiceHourlyPrice == '0') {
      this.toastr.error('Zero value is not allowed', 'Error');
      return false;
    }


    if (this.subServiceFlatPrice == '') {
      this.toastr.error('Please enter sub service flat price', 'Error');
      return false;
    }

    if (!this.subServiceFlatPrice) {
      this.toastr.error('Please enter sub service flat price', 'Error');
      return false;
    }

    if (this.subServiceFlatPrice == '0') {
      this.toastr.error('Zero value is not allowed in sub service flat price', 'Error');
      return false;
    }
    if (this.subServices.indexOf(this.subServiceTitle) >= 0) {
      this.toastr.error(this.subServiceTitle + ' already exists in sub services list', 'Error');
      return false;
    }
    this.subServices.push({
      title:this.subServiceTitle,
      hourly_rate:this.subServiceHourlyPrice,
      flat_rate:this.subServiceFlatPrice
    });
    this.subServiceTitle = "";
    this.subServiceHourlyPrice = "";
    this.subServiceFlatPrice="";
  }
  removeSubService(subServiceVal) {
    console.log("-=-==-", subServiceVal);
    this.subServices = this.subServices.filter(e => e !== subServiceVal);
  }
  save() {
    this.utilityServiceTypes.subServices = this.subServices;
    const data = this.utilityServiceTypes;
   

    if (data.utility_id == '') {
      this.toastr.error('Please select service main category', 'Error');
      return false;
    }

    if (data.subUtility_id == '') {
      this.toastr.error('Please select service sub category', 'Error');
      return false;
    }

    if (this.subServices.length == 0) {
      this.toastr.error('Please add atleast on sub service', 'Error');
      return false;
    }

    this.serviceTypesService.create(data)
      .subscribe(
        response => {
          console.log("---response", response);
          this.toastr.success('Service Type has been added successfully', 'Success');
          this.router.navigate(['/utility/manageServiceTypes']);
        },
        err => {
          // this.spinner.hide();
          this.commonService.handleError(err);

        });
  }


}
