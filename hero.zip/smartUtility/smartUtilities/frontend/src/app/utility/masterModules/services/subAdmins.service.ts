
import { Injectable, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import 'rxjs/add/operator/map';
import { CookieService } from 'ngx-cookie';

@Injectable({
  providedIn: 'root'
})
export class subAdminsService {
  constructor(private http: HttpClient, public router: Router, 
    private _cookieservice: CookieService) {

  }

  getHeaders() {
    let headerOption = environment.headerOption;
    if (this._cookieservice.get('token')) {
      const loggedInUtility = JSON.parse(this._cookieservice.get('token'));
      headerOption['Authorization'] = loggedInUtility.access_token;
    }
    const headers = new HttpHeaders(headerOption);
    const options = { headers };
    return options
  }

  getAllModules() {

    return this.http.get(environment.apiEndPoint + 'admin/getModules', this.getHeaders()).map(res =>
      res as any);
  }

  getSubModules() {

    return this.http.get(environment.apiEndPoint + 'admin/getModulesSubAdmin', this.getHeaders()).map(res =>
      res as any);
  }

  getsubAdminDetail(id) {

    return this.http.get(environment.apiEndPoint + 'admin/edit/' + id, this.getHeaders()).map(res =>
      res as any);
  }

  getAllSubAdmins(search) {

    return this.http.get(environment.apiEndPoint + 'admin/list?keyword=' + search, this.getHeaders()).map(res =>
        res as any);
  }

  getserviceTypeDetails(objId) {

    return this.http.get(environment.apiEndPoint + '/getserviceTypeDetails?id=' + objId, this.getHeaders()).map(res => res as any);

  }

  createSubAdmin(data) {

    return this.http.post(environment.apiEndPoint + 'admin/add', data, this.getHeaders()).map(res => res as any);
  }

  updateSubAdmin(data) {

    return this.http.post(environment.apiEndPoint + 'admin/update/' + btoa(data.id), data, this.getHeaders()).map(res => res as any);
  }


  multiUpdate(data) {

    return this.http.post(environment.apiEndPoint + 'admin/multi_activeInactive', data, this.getHeaders()).map(res => res as any);
  }

  deleteSubAdmin(id) {

    return this.http.delete(environment.apiEndPoint + 'admin/delete/' + id, this.getHeaders()).map(res => res as any);
  }


}
