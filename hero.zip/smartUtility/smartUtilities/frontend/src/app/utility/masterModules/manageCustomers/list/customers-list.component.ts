import { Component, OnInit, TemplateRef } from '@angular/core';
import { CommonService } from '../../../services/common.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { customerService } from '../../services/customers.service';
import { Router } from '@angular/router';

@Component({
  selector: 'customers-list',
  templateUrl: './customers-list.component.html',
  styleUrls: ['./customers-list.component.css']
})
export class customerListComponent implements OnInit {
  modalRef: BsModalRef;
  customerList: any;
  title = '';
  dataIds: any = [];
  action: any;
  itemValue: any;
  showDropdown: any;
  selectedAll: any;
  checked = false;
  recordsPerPage: any;

  constructor(private customerService: customerService, private spinner: NgxSpinnerService,
    private modalService: BsModalService, private router: Router, private toastr: ToastrService, private commonService: CommonService) {
    this.showDropdown = false;
    this.selectedAll = false;
  }

  ngOnInit() {
    this.getList();
    this.commonService.notifyOther({ option: 'breadcrumbs', value: 'Manage Customers' });
  }

  async getList() {
    this.spinner.show();
    let superAdminSettings: any = await this.commonService.getSuperAdminDetails();
    this.recordsPerPage = superAdminSettings.records_per_page;
    this.customerService.getAllCustomers('').subscribe(result => {
      this.customerList = result['data'];
      this.customerList.forEach((tmpObj, k) => {
        this.customerList[k].id = btoa(this.customerList[k].id);
      });
      this.spinner.hide();
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
    this.title = '';
  }

  countCurrentPageRows() {
    let oRows = document.getElementById('tableBody').getElementsByTagName('tr');
    let iRowCount = oRows.length;
    return iRowCount;

  }

  multiUpdate() {
    if (this.dataIds.length > 0) {
      this.spinner.show();
      let data = {
        action: this.action,
        dataId: this.dataIds
      };
      this.customerService.multiUpdate(data).subscribe(response => {
        this.getList();
        this.modalRef.hide();
        this.spinner.hide();
        this.showDropdown = false;
        this.toastr.success('Selected records have been ' + this.action + 'ed successfully', 'Success');
      }, err => {
        this.spinner.hide();
        this.commonService.handleError(err);
      });
    } else {
      this.toastr.info('Please select an record first', 'Info');
      this.modalRef.hide();
    }
  }

  searchTitle() {
    this.spinner.show();
    this.customerService.getAllCustomers(this.title).subscribe(result => {
      this.customerList = result['data'];
      this.customerList.forEach((tmpObj, k) => {
        this.customerList[k].id = btoa(this.customerList[k].id);
      });
      this.spinner.hide();
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
  }

  openModal(template: TemplateRef<any>, data, action) {
    this.modalRef = this.modalService.show(template);
    this.itemValue = data;
    this.action = action;
  }

  closeModal() {
    this.modalRef.hide();
  }

  openModalConfirm(template: TemplateRef<any>, data) {
    this.modalRef = this.modalService.show(template);
    this.action = data;
  }

  changeStatusDelete() {
    let data = {
      action: this.action,
      dataId: [this.itemValue.id]
    };
    this.customerService.multiUpdate(data).subscribe(response => {
      this.getList();
      this.modalRef.hide();
      this.spinner.hide();
      this.showDropdown = false;
      this.toastr.success('Record ' + this.action + 'ed successfully', 'Success');
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
  }

  selectall(event) {
    if (event.target.checked) {
      const selectedIds = [];
      this.customerList.forEach(val => { selectedIds.push(val.id) });
      this.dataIds = selectedIds;
    } else {
      this.dataIds = [];
    }
  }

  unselectAll() {
    this.checked = false;
  }

  viewRequests(id) {
    this.router.navigate(['/utility/manageServiceRequests', 'customer', id]);
  }

}
