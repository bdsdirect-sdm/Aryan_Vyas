import { LOCALE_ID, Inject, Injectable } from '@angular/core';
import { CalendarEventTitleFormatter, CalendarEvent } from 'angular-calendar';
import { DatePipe } from '@angular/common';
import * as moment from 'moment';

@Injectable()
export class CustomEventTitleFormatter extends CalendarEventTitleFormatter {
  constructor(@Inject(LOCALE_ID) private locale: string) {
    super();
  }

  // you can override any of the methods defined in the parent class

  month(event): string {
    if (event.data.key == 'service') {
      return `<b> SRN-${event.id} </b> ${event.title} for <b> ${event.data.customer_first_name + ' ' + event.data.customer_last_name} </b> @ <b> ${event.data.time}</b> - ${event.data.taskStatus}`;
    } else if (event.data.key == 'incident') {
      let created_at = moment(event.data.created_at).format('DD-MM-YYYY');
      return `<b> SRN-${event.data.request_number} </b> - ${event.title} raised by <b> ${event.data.customer_first_name + ' ' + event.data.customer_last_name} </b> on <b> ${created_at}</b> for ${event.data.utilityServiceTypes_title}`;
    } else {
      let payment_date = moment(event.data.payment_date).format('DD-MM-YYYY');
      return `<b> SRN-${event.id} </b> - Paymeny of $${event.data.cost} is Done By <b> ${event.data.customer_first_name + ' ' + event.data.customer_last_name} </b> on <b> ${payment_date}</b> for ${event.data.utilityServiceTypes_title}`;
    }

  }

  week(event: CalendarEvent): string {
    return `<b>${new DatePipe(this.locale).transform(
      event.start,
      'h:m a',
      this.locale
    )}</b> ${event.title}`;
  }

  day(event: CalendarEvent): string {
    return `<b>${new DatePipe(this.locale).transform(
      event.start,
      'h:m a',
      this.locale
    )}</b> ${event.title}`;
  }
}
