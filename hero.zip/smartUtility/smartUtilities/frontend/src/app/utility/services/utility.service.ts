import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Subject } from 'rxjs/Subject';
import { environment } from '../../../environments/environment';
import { map } from 'rxjs/operators';
import { CookieService } from 'ngx-cookie';

@Injectable({
    providedIn: 'root'
})
export class UtilityService {

    private notify = new Subject<any>();
    /**
     * Observable string streams
     */
    notifyObservable$ = this.notify.asObservable();
    constructor(private http: HttpClient, private _cookieservice: CookieService) {
    }
    public notifyOther(data: any) {
        this.notify.next(data);
    }

    getHeaders() {
        let headerOption = environment.headerOption;
        if (this._cookieservice.get('token')) {
          const loggedInUtility = JSON.parse(this._cookieservice.get('token'));
          headerOption['Authorization'] = loggedInUtility.access_token;
        }
        const headers = new HttpHeaders(headerOption);
        const options = { headers };
        return options
      }

    utilityProviderLogin(data) {
        const headers = new HttpHeaders(environment.headerOption);
        const options = { headers };

        return this.http.post(environment.apiEndPoint + 'shared/login', data, options).map(res => res as any);
    }

    subAdminLogin(data) {
        const headers = new HttpHeaders(environment.headerOption);
        const options = { headers };

        return this.http.post(environment.apiEndPoint + 'shared/utilityAdminslogin', data, options).map(res => res as any);
    }

    getModulesDetails(id) {

        return this.http.get(environment.apiEndPoint + 'admin/getSubAdminPermession/' + id, this.getHeaders()).map(res => res as any);
    }

    getNotification() {
        return this.http.get(environment.apiEndPoint + 'notification/Utilitylist', this.getHeaders()).map(res => res as any);
    }

    notifyStatus(data) {
        return this.http.post(environment.apiEndPoint + 'shared/notificationStatus', data, this.getHeaders()).map(res => res as any);
        
    }

   
}