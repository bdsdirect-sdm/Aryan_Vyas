import { Injectable, Inject } from '@angular/core';
import { Subject } from 'rxjs/Subject';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { map } from 'rxjs/operators';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie';
import { ToastrService } from 'ngx-toastr';

@Injectable({
    providedIn: 'root'
})
export class CommonService {
    private notify = new Subject<any>();
    /**
     * Observable string streams
     */
    notifyObservable$ = this.notify.asObservable();

    constructor(private http: HttpClient, private router: Router,
        private _cookieservice: CookieService, private toastr: ToastrService) {
    }

    public notifyOther(data: any) {
        this.notify.next(data);
    }

    getHeaders() {
        let headerOption = environment.headerOption;
        if (this._cookieservice.get('token')) {
            const loggedInUtility = JSON.parse(this._cookieservice.get('token'));
            headerOption['Authorization'] = loggedInUtility.access_token;
        }
        const headers = new HttpHeaders(headerOption);
        const options = { headers };
        return options
    }

    titleCase(str) {
        var splitStr = str.toLowerCase().split(' ');
        for (var i = 0; i < splitStr.length; i++) {
            splitStr[i] = splitStr[i].charAt(0).toUpperCase() + splitStr[i].substring(1);
        }
        return splitStr.join(' ');
    }

    getSubAdminModule(id) {

        return new Promise((resolve) => {
            this.http.get(environment.apiEndPoint + 'admin/getSubAdminPermession/' + id, this.getHeaders()).map(res => res as any).subscribe(res => {
                let myModules = [];
                res.forEach(element => {
                    myModules.push(element.routerLink)
                });
                resolve(myModules);
            }, err => {
                resolve(err.error);
            });
        });


    }

    getAllModules() {

        return new Promise((resolve) => {
            this.http.get(environment.apiEndPoint + 'admin/getModules', this.getHeaders()).map((res: Response) => res).subscribe(res => {
                resolve(res);
            }, err => {
                resolve(err.error);
            });
        });

    }

    getSuperAdminDetails() {
        return new Promise((resolve) => {
            this.http.get(environment.apiEndPoint + 'superAdmin/settings/edit', this.getHeaders()).map((res: Response) => res).subscribe((res: any) => {
                resolve(res.data);
            }, err => {
                resolve(err.error);
            });
        });
    }

    getCategories(){ 
         
        return new Promise((resolve) => {
            this.http.get(environment.apiEndPoint + 'superAdmin/getCategories', this.getHeaders()).map((res: Response) => res).subscribe((res: any) => {
                resolve(res.data);
            }, err => {
                resolve(err.error);
            });
        });
    }



    getSubCategories(id){ 
         
        return new Promise((resolve) => {
            this.http.get(environment.apiEndPoint + 'superAdmin/getSubCategories/' + id, this.getHeaders()).map((res: Response) => res).subscribe((res: any) => {
                resolve(res.data);
            }, err => {
                resolve(err.error);
            });
        });

        
    }

   

    getOptions(data) {
        const headers = new HttpHeaders(environment.headerOption);
        const options = { headers };

        return this.http.post(environment.apiEndPoint + 'superAdmin/getOptions', data, options).map(res => res as any);
    }

    getAllCategories(){ 
         
        return new Promise((resolve) => {
            this.http.get(environment.apiEndPoint + 'superAdmin/getAllCategories', this.getHeaders()).map((res: Response) => res).subscribe((res: any) => {
                resolve(res.data);
            }, err => {
                resolve(err.error);
            });
        });
    }


    handleError(err) {
        if (err && err.status && err.status == 403 && err.statusText && err.statusText == 'Forbidden') {
            this._cookieservice.removeAll();
            this.router.navigate(['/utility/login']);
            this.toastr.error(err.error.msg, 'Error');
        } else if (err && err.msg) {
            this.toastr.error(err.msg, 'Error');
        } else if (err && err.error && err.error.msg) {
            this.toastr.error(err.error.msg, 'Error');
        } else {
            this.toastr.error('Something Went wrong. Please try again', 'Error');
        }
    }

    handleCustomerError(err) {
        if (err && err.status && err.status == 403 && err.statusText && err.statusText == 'Forbidden') {
            this._cookieservice.removeAll();
            this.router.navigate(['/home']);
            this.notifyOther({ option: 'customer-header', value: null });
            this.toastr.error('Please Login again to proceed futher', 'Error');
        } else if (err && err.error && err.error.msg) {
            this.toastr.error(err.error.msg, 'Error');
        } else if (err && err.msg) {
            this.toastr.error(err.msg, 'Error');
        } else {
            this.toastr.error('Something Went wrong. Please try again', 'Error');
        }
    }

    handleSuperAdminError(err) {
        if (err && err.status && err.status == 403 && err.statusText && err.statusText == 'Forbidden') {
            this._cookieservice.removeAll();
            this.router.navigate(['/admin']);
            this.toastr.error(err.error.msg, 'Error');
        } else if (err && err.error && err.error.msg) {
            this.toastr.error(err.error.msg, 'Error');
        } else if (err && err.msg) {
            this.toastr.error(err.msg, 'Error');
        } else {
            this.toastr.error('Something Went wrong. Please try again', 'Error');
        }
    }

}