import { Component } from '@angular/core';

@Component({
  selector: 'utility-root',
  templateUrl: './utility.component.html',
  styleUrls: ['./utility.component.css']
})
export class utilityComponent {
  title = 'frontend';
}
