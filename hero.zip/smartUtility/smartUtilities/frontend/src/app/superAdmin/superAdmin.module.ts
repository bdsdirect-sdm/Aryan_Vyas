import { BrowserModule } from "@angular/platform-browser";
import { NgModule } from "@angular/core";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { HttpClientModule } from "@angular/common/http";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { CommonModule } from "@angular/common";
import { superAdminComponent } from "./superAdmin.component";
import { superAdminloginComponent } from "./login/login.component";
import { SuperAdminRoutingModule } from "./superAdmin-routing.module";
import { dashboardComponent } from "./afterLoginModules/dashboard/dashboard.component";
import { AdminHeaderComponent } from "./afterLoginModules/header/header.component";
import { AdminleftBarComponent } from "./afterLoginModules/leftBar/leftBar.component";
import { AppSharedModule } from "../shared/app-shared.module";
import { utilityProvidersListComponent } from "./afterLoginModules/manageUtilityProviders/list/utilityProviders-list.component";
import { utilityProvidersAddComponent } from "./afterLoginModules/manageUtilityProviders/add/utilityProviders-add.component";
import { utilityProvidersEditComponent } from "./afterLoginModules/manageUtilityProviders/edit/utilityProviders-edit.component";
import { utilityEditComponent } from "./afterLoginModules/manageUtility/edit/utility-edit.component";
import { utilityListComponent } from "./afterLoginModules/manageUtility/list/utility-list.component";
import { utilityAddComponent } from "./afterLoginModules/manageUtility/add/utility-add.component";
import { superAdminProfileComponent } from "./afterLoginModules/profile/profile.component";
import { subscriptionListComponent } from "./afterLoginModules/manageSubscriptions/list/subscription-list.component";
import { subscriptionEditComponent } from "./afterLoginModules/manageSubscriptions/edit/subscription-edit.component";
import { subscriptionAddComponent } from "./afterLoginModules/manageSubscriptions/add/subscription-add.component";

@NgModule({
  declarations: [
    superAdminComponent,
    superAdminloginComponent,
    dashboardComponent,
    AdminHeaderComponent,
    AdminleftBarComponent,
    utilityProvidersListComponent,
    utilityProvidersAddComponent,
    utilityProvidersEditComponent,
    utilityEditComponent,
    utilityAddComponent,
    utilityListComponent,
    superAdminProfileComponent,
    subscriptionListComponent,
    subscriptionEditComponent,
    subscriptionAddComponent,
  ],
  imports: [
    HttpClientModule,
    SuperAdminRoutingModule,
    FormsModule,
    CommonModule,
    AppSharedModule,
  ],
  providers: [],
  bootstrap: [],
})
export class superAdminModule {}
