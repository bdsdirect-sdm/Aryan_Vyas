import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from '../../../../utility/services/common.service';
import { SuperAdminSubscriptionService } from '../../../../services/superAdmin/admin-subscription.service';

@Component({
  selector: 'subscription-add',
  templateUrl: './subscription-add.component.html',
  styleUrls: ['./subscription-add.component.css']
})
export class subscriptionAddComponent implements OnInit {
  subscription: any;

  constructor(private adminService: SuperAdminSubscriptionService, private spinner: NgxSpinnerService,
    private toastr: ToastrService, private router: Router, private commonService: CommonService) {
    this.subscription = {};
    this.subscription.recurrence = 'onetime';
  }

  ngOnInit() {
    this.commonService.notifyOther({ option: 'breadcrumbs', value: 'Manage Subscriptions' });
  }


  save() {
    this.spinner.show();
    this.adminService.create(this.subscription).subscribe(response => {
      this.spinner.hide();
      this.toastr.success('Subscription added successfully', 'Success');
      this.router.navigate(['/admin/subscription']);
    }, err => {
      this.spinner.hide();
      this.commonService.handleSuperAdminError(err);
    });
  }

  onKeydownEvent(e, cost) {
    if (!((e.keyCode > 95 && e.keyCode < 105)
      || (e.keyCode > 47 && e.keyCode < 58)
      || e.keyCode == 8)) {
      return false;
    } else {
      if (cost && cost.toString().length > 3) {
        return false;
      }
    }
  }

}
