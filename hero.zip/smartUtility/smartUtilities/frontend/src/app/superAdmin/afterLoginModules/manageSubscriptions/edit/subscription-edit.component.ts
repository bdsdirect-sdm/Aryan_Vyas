import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from '../../../../utility/services/common.service';
import { environment } from '../../../../../environments/environment';
import { SuperAdminSubscriptionService } from '../../../../services/superAdmin/admin-subscription.service';

@Component({
  selector: 'subscription-edit',
  templateUrl: './subscription-edit.component.html',
  styleUrls: ['./subscription-edit.component.css']
})
export class subscriptionEditComponent implements OnInit {
  subscription: any;

  constructor(private adminService: SuperAdminSubscriptionService, private spinner: NgxSpinnerService,
    private toastr: ToastrService, private router: Router,
    private commonService: CommonService, private activatedRoute: ActivatedRoute) {
    this.subscription = {};
  }

  ngOnInit() {
    this.getDetails();
    this.commonService.notifyOther({ option: 'breadcrumbs', value: 'Manage Subscriptions' });
  }


  getDetails() {
    this.spinner.show();
    this.adminService.getDetails(this.activatedRoute.snapshot.params.id).subscribe(result => {
      this.subscription = result.data;
      this.spinner.hide();
    }, err => {
      this.spinner.hide();
      this.commonService.handleSuperAdminError(err);
    });

  }


  update() {
    this.spinner.show();
    let json = {
      recurrence: this.subscription.recurrence,
      id: this.subscription.id,
      title: this.subscription.title,
      price: this.subscription.price,
    }

    this.adminService.update(json).subscribe(response => {
      this.spinner.hide();
      this.toastr.success('Subscription edited successfully', 'Success');
      this.router.navigate(['/admin/subscription']);
    }, err => {
      this.spinner.hide();
      this.commonService.handleSuperAdminError(err);
    });
  }

  onKeydownEvent(e, cost) {
    if (!((e.keyCode > 95 && e.keyCode < 105)
      || (e.keyCode > 47 && e.keyCode < 58)
      || e.keyCode == 8)) {
      return false;
    } else {
      if (cost && cost.toString().length > 3) {
        return false;
      }
    }
  }

}
