import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from '../../../../utility/services/common.service';
import { environment } from '../../../../../environments/environment';
import { SuperAdminUtilityService } from '../../../../services/superAdmin/admin-utility.service';

@Component({
  selector: 'utility-edit-tutorial',
  templateUrl: './utility-edit.component.html',
  styleUrls: ['./utility-edit.component.css']
})
export class utilityEditComponent implements OnInit {
  utility: any;
  subCategories=[];
  dbsubCategories=[];
  subCategoriestitle:string="";
  constructor(private adminService: SuperAdminUtilityService, private spinner: NgxSpinnerService,
    private toastr: ToastrService, private router: Router,
    private commonService: CommonService, private activatedRoute: ActivatedRoute) {
    this.utility = {};
  }

  ngOnInit() {
    this.getDetails();
    this.commonService.notifyOther({ option: 'breadcrumbs', value: 'Manage Categories' });
  }


  addSubCategory(){
    if (this.subCategories && this.subCategories.length>0 && this.subCategories.indexOf(this.subCategoriestitle) >= 0) {
      this.toastr.error(this.subCategoriestitle + ' already exists in sub category list', 'Error');
      return false;
    }

    if (this.utility.title==this.subCategoriestitle) {
      this.toastr.error('Sub category name can not be same as main category name', 'Error');
      return false;
    }

    console.log("+++++",this.subCategories);
    this.subCategories.push(
      this.subCategoriestitle
    );
   
    this.subCategoriestitle = "";
  }

  removeSubCat(subServiceVal){

    this.subCategories = this.subCategories.filter(e => e !== subServiceVal);
  }

  getDetails() {
    this.spinner.show();
    this.adminService.getDetails(this.activatedRoute.snapshot.params.id).subscribe(result => {
      this.utility = result.data;
     // this.subCategories = result.subCategories;

     
      if(result.subCategories.length>0){
        var temp=[];
        for(let i=0;i<result.subCategories.length;i++){
          temp.push(
            result.subCategories[i].title
          );          
        }
        this.subCategories=temp;
        this.dbsubCategories=temp;
      }
      
      this.spinner.hide();
    }, err => {
      this.spinner.hide();
      this.commonService.handleSuperAdminError(err);
    });

  }


  update() {
    this.spinner.show();
    this.utility['title'] = this.commonService.titleCase(this.utility.title);
    let json = {
      description : this.utility.description,
      id : this.utility.id,
      title : this.utility.title,
      subCategories:this.subCategories,
      dbsubCategories:this.dbsubCategories
    }

    this.adminService.update(json).subscribe(response => {
      this.spinner.hide();
      this.toastr.success('Utility edited successfully', 'Success');
      this.router.navigate(['/admin/utility']);
    }, err => {
      this.spinner.hide();
      this.commonService.handleSuperAdminError(err);
    });
  }

}
