import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from '../../../utility/services/common.service';
import { SuperAdminService } from '../../../services/superAdmin/admin.service';
import { environment } from '../../../../environments/environment';
@Component({
  selector: 'superadmin-profile-tutorial',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class superAdminProfileComponent implements OnInit {
  admin: any;
  adminLogo: any;
  adminLogoName: string | ArrayBuffer;
  imageUrl: string;

  constructor(private adminService: SuperAdminService, private spinner: NgxSpinnerService,
    private toastr: ToastrService, private router: Router,
    private commonService: CommonService, private activatedRoute: ActivatedRoute) {
    this.admin = {};
    this.admin.time_format = '12hours';
    this.admin.default_currency = 'USD';
    this.imageUrl = environment.apiEndPoint + 'uploads/';
  }

  ngOnInit() {
    this.getDetails();
    this.commonService.notifyOther({ option: 'breadcrumbs', value: 'Profile Settings' });
  }


  getDetails() {
    this.spinner.show();
    this.adminService.getDetails().subscribe(result => {
      this.admin = result.data;
      if(result.data.logo && result.data.logo != '') {
        this.adminLogoName = this.imageUrl + result.data.logo
      }
      this.spinner.hide();
    }, err => {
      this.spinner.hide();
      this.commonService.handleSuperAdminError(err);
    });

  }

  onUpload(event) {
    const allowedImageMimeTypes = [
      "image/jpeg",
      "image/png",
      "image/gif",
      "image/bmp",
      "image/jpg"
    ];
    if (event && event.target && event.target.files && event.target.files.length > 0) {
      if (allowedImageMimeTypes.indexOf(event.target.files[0].type) == -1) {
        this.toastr.error("Please upload an image with one of the following extensions : '.jpeg','.jpg','.gif','.png','.png','.bmp'", 'Error');
        return false;
      } else if (event.target.files[0].size > 5242880) {
        this.toastr.error("Too large image, Please upload profile image of size 5mb or less.", 'Error');
        return false;
      } else {
        this.adminLogo = event.target.files[0];

        var mimeType = this.adminLogo.type;
        if (mimeType.match(/image\/*/) == null) {
          this.toastr.error('Please upload image only', 'Error');
          return;
        }
        var reader = new FileReader();
        reader.readAsDataURL(this.adminLogo);
        reader.onload = (_event) => {
          this.adminLogoName = reader.result;
        }
      }
    }
  }


  update() {
    const formdata = new FormData();
    this.spinner.show();
    delete this.admin.password;
    delete this.admin.id;
    this.admin['title'] = this.commonService.titleCase(this.admin.title);
    formdata.append('file', this.adminLogo);
    formdata.append('data', JSON.stringify(this.admin));

    this.adminService.update(formdata).subscribe(response => {
      this.spinner.hide();
      this.toastr.success('Settings updated successfully', 'Success');
      this.router.navigate(['/admin/dashboard']);
    }, err => {
      this.spinner.hide();
      this.commonService.handleSuperAdminError(err);
    });
  }

}
