import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Params, Router } from "@angular/router";
import { CookieService } from "ngx-cookie";
import { UserIdleService } from "angular-user-idle";
@Component({
  selector: "app-admin-header",
  templateUrl: "./header.component.html",
  styleUrls: ["./header.component.css"],
})
export class AdminHeaderComponent implements OnInit {
  title = "frontend";
  showDropdown: any;
  loggedInAdmin: any;

  constructor(
    private router: Router,
    private _cookieservice: CookieService,
    private userIdle: UserIdleService
  ) {
    this.showDropdown = false;
    if (this._cookieservice.get("admin-data")) {
      this.loggedInAdmin = JSON.parse(this._cookieservice.get("admin-data"));
    }
  }

  ngOnInit() {
    this.userIdle.startWatching();
    console.log("----");

    // Start watching when user idle is starting.
    this.userIdle.onTimerStart().subscribe((count) => console.log(count));

    // Start watch when time is up.
    this.userIdle.onTimeout().subscribe(() => this.logout());
  }
  logout() {
    this._cookieservice.removeAll();
    this.router.navigate(["/admin/login"]);
  }
}
