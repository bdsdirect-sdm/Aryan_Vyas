import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { superAdminComponent } from './superAdmin.component';
import { superAdminloginComponent } from './login/login.component';
import { dashboardComponent } from './afterLoginModules/dashboard/dashboard.component';
import { utilityProvidersListComponent } from './afterLoginModules/manageUtilityProviders/list/utilityProviders-list.component';
import { utilityProvidersAddComponent } from './afterLoginModules/manageUtilityProviders/add/utilityProviders-add.component';
import { utilityProvidersEditComponent } from './afterLoginModules/manageUtilityProviders/edit/utilityProviders-edit.component';
import { utilityListComponent } from './afterLoginModules/manageUtility/list/utility-list.component';
import { utilityAddComponent } from './afterLoginModules/manageUtility/add/utility-add.component';
import { utilityEditComponent } from './afterLoginModules/manageUtility/edit/utility-edit.component';
import { superAdminProfileComponent } from './afterLoginModules/profile/profile.component';
import { subscriptionAddComponent } from './afterLoginModules/manageSubscriptions/add/subscription-add.component';
import { subscriptionEditComponent } from './afterLoginModules/manageSubscriptions/edit/subscription-edit.component';
import { subscriptionListComponent } from './afterLoginModules/manageSubscriptions/list/subscription-list.component';


export const routes: Routes = [
  {
    path: 'admin',
    children: [
      {
        path: 'login',
        component: superAdminloginComponent
      }
    ]
  },
  {
    path: 'admin',
    component: superAdminComponent,
    children: [
      {
        path: 'dashboard',
        component: dashboardComponent
      },
      {
        path: 'profile',
        component: superAdminProfileComponent
      },
      {
        path: 'utility',
        component: utilityListComponent
      },
      {
        path: 'utility/add',
        component: utilityAddComponent
      },
      {
        path: 'utility/edit/:id',
        component: utilityEditComponent
      },
      {
        path: 'utilitiyProvider',
        component: utilityProvidersListComponent
      },
      {
        path: 'utilitiyProvider/add',
        component: utilityProvidersAddComponent
      },
      {
        path: 'utilitiyProvider/edit/:id',
        component: utilityProvidersEditComponent
      },
      {
        path: 'subscription',
        component: subscriptionListComponent
      },
      {
        path: 'subscription/add',
        component: subscriptionAddComponent
      },
      {
        path: 'subscription/edit/:id',
        component: subscriptionEditComponent
      },
    ]
  },


];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class SuperAdminRoutingModule { }
