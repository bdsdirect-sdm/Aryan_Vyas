import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { providerProfileComponent } from './afterLoginModules/providerProfile/providerProfile.component';
import { customerserviceRequestsListComponent } from './afterLoginModules/serviceRequests/list/serviceRequests-list.component';
import { customerComponent } from './customer.component';
import { customerServiceRequestsViewComponent } from './afterLoginModules/serviceRequests/view/serviceRequests-view.component';
import { CustomerAuthGuard } from '../shared/customer-auth.guard';
import { HomeComponent } from './home/home.component';
import { FormWizardComponent } from './form-wizard/form-wizard.component';

export const routes: Routes = [
  {
    path: '',
    component: customerComponent,
    canActivate: [CustomerAuthGuard],
    children: [
              
    ]
  },
  {
    path: 'home',
    component: HomeComponent
  },
  {
        path: 'service-request',
        component: customerserviceRequestsListComponent
  },
  
  {
        path: 'service-request/view/:id',
        component: customerServiceRequestsViewComponent
  },  
  {
    path: 'provider/view/:id',
    component: providerProfileComponent
  },
 {
    path: 'service-type/:searched/:zipcode',
    component: FormWizardComponent
  },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class CustomerRoutingModule { }
