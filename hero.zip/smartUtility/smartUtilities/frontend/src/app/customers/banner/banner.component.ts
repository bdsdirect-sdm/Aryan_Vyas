import { Component, OnInit, ViewChild } from "@angular/core";
import { environment } from "../../../environments/environment";
import { CustomerService } from "../../services/customers/customer.service";
import { NgxSpinnerService } from "ngx-spinner";
import { ToastrService } from "ngx-toastr";
import { CommonService } from "../../utility/services/common.service";

import { Address } from "ngx-google-places-autocomplete/objects/address";
import { GooglePlaceDirective } from "ngx-google-places-autocomplete";
import { Router } from "@angular/router";
import { CookieService } from "ngx-cookie";

import * as _ from "underscore";
@Component({
  selector: "app-banner",
  templateUrl: "./banner.component.html",
  styleUrls: ["./banner.component.scss"],
})
export class BannerComponent implements OnInit {
  @ViewChild("placesRef") placesRef: GooglePlaceDirective;
  serviceList: any;
  service_type: any;
  apiEndPoint = environment.apiEndPoint;
  isServiceTypeSelected: boolean;
  searchedKeyword: any;
  selectedServiceType: any;
  searchedEntity: string = "";
  zipcode: string = "";
  searchLocation: any = {
    city: "",
    state: "",
    country: "",
    postal_code: "",
  };
  allCategories: any;
  placeholderText: string = "";
  constructor(
    private customerService: CustomerService,
    private spinner: NgxSpinnerService,
    private commonService: CommonService,
    private router: Router,
    private toastr: ToastrService,
    private _cookieservice: CookieService
  ) {
    this.isServiceTypeSelected = false;
  }

  ngOnInit() {
    this.getUtilitiesList();
  }

  async getUtilitiesList() {
    this.allCategories = await this.commonService.getAllCategories();

    console.log("==this.allCategories==", this.allCategories);

    if (this.allCategories.length > 0) {
      this.placeholderText += this.allCategories[0].title;
    }
    if (this.allCategories.length > 1) {
      this.placeholderText += ", " + this.allCategories[1].title;
    }
    if (this.allCategories.length > 2) {
      this.placeholderText += ", " + this.allCategories[2].title;
    }
  }

  onTagFocused(event) {
    if (event.length >= 2 && this.zipcode.length >= 3) {
      if (this.zipcode == "") {
        this.toastr.error("Please enter zip code", "Error");
        this.serviceList = [];
        return false;
      }

      this._cookieservice.remove("searched-service-type");

      //this.spinner.show();
      let json = {
        keyword: event,
        zipcode: this.zipcode,
      };

      this.customerService.getProvidersList(json).subscribe(
        (response) => {
          this.serviceList = _.groupBy(response.data, "utilitiesTitle");
          console.log("===this.serviceList===", this.serviceList);
          this.searchedEntity = response.type;
          if (response.data.length > 0) {
            this.searchedKeyword = event;
          }
          //this.spinner.hide();
        },
        (err) => {
          this.spinner.hide();
          this.commonService.handleCustomerError(err);
        }
      );
    } else {
      this.serviceList = [];
      this.searchedEntity = "";
      this.selectedServiceType = "";
    }
  }

  setvalue(item, catType) {
    this.service_type = item;
    this.serviceList = [];

    console.log("===this.service_type===", this.service_type);
    this.searchNext();
  }

  searchNext() {
    if (this.service_type) {
      this.router.navigate(["/service-type", this.service_type, this.zipcode]);
    } else {
      this.toastr.warning("No Service Found for the searched Item", "Warning");
    }
  }
}
