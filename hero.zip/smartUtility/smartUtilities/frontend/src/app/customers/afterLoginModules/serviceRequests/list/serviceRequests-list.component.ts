import { Component, OnInit, TemplateRef } from '@angular/core';
import { CommonService } from '../../../../utility/services/common.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { CookieService } from 'ngx-cookie';
import * as _ from 'underscore';
import * as moment from 'moment';
import * as CryptoJS from 'crypto-js';
import { Router } from '@angular/router';
import { environment } from '../../../../../environments/environment';
import { CustomerService } from '../../../../services/customers/customer.service';

@Component({
  selector: 'cust-serviceRequests-list',
  templateUrl: './serviceRequests-list.component.html',
  styleUrls: [
    './serviceRequests-list.component.scss',
    '../../../scss/app.scss'
  ]
})
export class customerserviceRequestsListComponent implements OnInit {
  modalRef: BsModalRef;
  serviceRequestList: any;
  title = '';
  dataIds: any = [];
  action: any;
  itemValue: any;
  showDropdown: any;
  customer: any;
  recordsPerPage: unknown;
  date_format: any;
  time_format: any;
  apiEndPoint = environment.apiEndPoint;
  currency = environment.currency;
  constructor(private customerService: CustomerService, private spinner: NgxSpinnerService,
    private modalService: BsModalService, private toastr: ToastrService,
    private commonService: CommonService, private _cookieservice: CookieService,
    private router: Router) {
    this.showDropdown = false;
    this.customer = JSON.parse(this._cookieservice.get('customer-data'));
  }

  ngOnInit() {
    this.showAll();
  }

  

  async showAll() {
    this.spinner.show();
    let superAdminSettings: any = await this.commonService.getSuperAdminDetails();
    this.recordsPerPage = superAdminSettings.records_per_page;
    this.date_format = superAdminSettings.default_date_format;
    this.time_format = superAdminSettings.time_format;
    
    this.customerService.listServiceRequest().subscribe(result => {
      this.serviceRequestList = result.data;
      console.log("----this.serviceRequestList--",this.serviceRequestList);
      _.each(this.serviceRequestList, obj => {
        obj['id'] = btoa(obj['id']);
        obj['date'] = moment(obj['date']).format(this.date_format);
        if (this.time_format == '12hours') {
          obj['time'] = moment(obj['time'], ["HH:mm"]).format("h:mm A");
          obj['etime'] = moment(obj['etime'], ["HH:mm"]).format("h:mm A");
        } else {
          obj['time'] = moment(obj['time'], ["HH:mm"]).format("HH:mm");
          obj['etime'] = moment(obj['etime'], ["HH:mm"]).format("HH:mm");
        }

       obj['modified_date'] = moment(obj['modified_date']).format(this.date_format);
      });
      this.spinner.hide();
    }, err => {
      this.spinner.hide();
      this.commonService.handleCustomerError(err);
    });
  }

  tConvert(time) {
    // Check correct time format and split into components
    time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time];

    if (time.length > 1) { // If time format correct
      time = time.slice(1);  // Remove full string match value
      time[5] = +time[0] < 12 ? ' AM' : ' PM'; // Set AM/PM
      time[0] = +time[0] % 12 || 12; // Adjust hours
    }
    delete time[3]
    return time.join(''); // return adjusted time or original string
  }

  countCurrentPageRows() {
    let oRows = document.getElementById('tableBody').getElementsByTagName('tr');
    let iRowCount = oRows.length;
    return iRowCount;

  }


  searchTitle() {
    //   this.spinner.show();
    //   this.serviceRequestService.getAllCustomers(this.title).subscribe(result => {
    //     this.serviceRequestList = result.data;
    //     this.spinner.hide();
    //   }, error => {
    //     console.log(error);
    //   });
  }

  openModal(template: TemplateRef<any>, data) {
    this.modalRef = this.modalService.show(template);
    this.itemValue = data;
  }

  closeModal() {
    this.modalRef.hide();
  }


  cancelServiceRequest() {
    this.modalRef.hide()
  }

  redirectToAdd() {
    const stringToEncrypt = this.customer.id.toString();
    const encryptedString = CryptoJS.AES.encrypt(stringToEncrypt.trim(), environment.cryptoPassword.trim()).toString();
    this.router.navigate(['/service-request/add', encryptedString]);
  }

}
