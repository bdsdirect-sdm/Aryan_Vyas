import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-my-services',
  templateUrl: './my-services.component.html',
  styleUrls: [
    './my-services.component.scss',
    '../../scss/app.scss'
  ]
})
export class MyServicesComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
