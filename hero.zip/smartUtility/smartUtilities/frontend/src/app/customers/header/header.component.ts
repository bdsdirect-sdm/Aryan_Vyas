import { Component, OnInit, TemplateRef, OnDestroy, ViewChild } from '@angular/core';
import { environment } from '../../../environments/environment';
import { CustomerService } from '../../services/customers/customer.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from '../../utility/services/common.service';
import { Router, ActivatedRoute } from '@angular/router';
import { CookieService } from 'ngx-cookie';
import { BsModalService, BsModalRef, ModalDirective } from 'ngx-bootstrap/modal';
import { NgForm } from '@angular/forms';
import { GooglePlaceDirective } from 'ngx-google-places-autocomplete';
import { Address } from 'ngx-google-places-autocomplete/objects/address';
import * as _ from 'underscore';
import * as moment from 'moment';
import { any } from 'underscore';
@Component({
	selector: 'customer-header',
	templateUrl: './header.component.html',
	styleUrls: [
		'./header.component.scss'
	]
})
export class CustomerHeaderComponent implements OnInit, OnDestroy {
	@ViewChild('staticModal') public staticModal: ModalDirective;
	@ViewChild('parentModal', { static: false }) parentModal: ModalDirective;
	@ViewChild('childModal', { static: false }) childModal: ModalDirective;
	@ViewChild("placesRef") placesRef: GooglePlaceDirective;
	loggedInUser: any;
	modalRef: BsModalRef | null;
	modalRef2: BsModalRef;
	customer: any;
	serviceList: any;
	service_type: any;
	isServiceTypeSelected: boolean;
	searchedKeyword: any;
	selectedServiceType: any;
	notificationsList: any;
	notiCount: any;
	pageNumber: any;
	menuToggle: boolean
	userInitial: string = '';
	currentRoter: any;
	settings: any = {};
	utilityProvider: any;
	providerTypeList: any;
	profileImageName: any;
	moduleIds: any = [];
	multipleFiles: any = [];
	modulesList: any;
	maxDate: Date;
	utlityList: any;
	idProofFrontName: any;
	idProofBackName: any;
	allCategories: any;
	dataIds: any = [];
	savedSuccess = 0;
	zipcode: any=[];
	constructor(private customerService: CustomerService, private spinner: NgxSpinnerService,
		private commonService: CommonService, private router: Router, private modalService: BsModalService,
		private toastr: ToastrService, private _cookieservice: CookieService, private activatedRoute: ActivatedRoute,
	) {
		this.notificationsList = [];
		this.pageNumber = 1;
		this.customer = {};
		if (this._cookieservice.get('customer-data')) {
			this.loggedInUser = JSON.parse(this._cookieservice.get('customer-data'));
			this.userInitial = this.loggedInUser.first_name.charAt(0) + '' + this.loggedInUser.last_name.charAt(0)
			this.getNotifications();
		}

		
		
		this.isServiceTypeSelected = false;
		this.currentRoter = this.router.url;
		this.utilityProvider = {};
		this.utilityProvider.provider_type = '';
		this.maxDate = new Date();
		this.providerTypeList = [{
			id: 'Company',
			name: 'Company'
		}, {
			id: 'Freelancer',
			name: 'Freelancer'
		}]

		this.moduleIds = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
	}
	memuClickEvent() {
		this.menuToggle = !this.menuToggle;
	}

	openModal(template: TemplateRef<any>) {
		this.modalRef = this.modalService.show(template, { class: 'login-modal-wrapper  common-modal-wrapper' });
	}
	openModal2(template: TemplateRef<any>) {
		this.modalRef2 = this.modalService.show(template, { class: 'signup-modal-wrapper  common-modal-wrapper' });
	}
	closeFirstModal() {
		if (!this.modalRef) {
			return;
		}

		this.modalRef.hide();
		this.modalRef = null;
	}


	ngOnInit() {
		this.showAll();
		this.commonService.notifyObservable$.subscribe((res) => {
			if (res.hasOwnProperty('option') && res.option === 'customer-header' && res.value !== undefined) {
				this.loggedInUser = JSON.parse(res.value);
			}
		});
		this.getUtilitiesList();


	}

	async getUtilitiesList() {
		this.allCategories = await this.commonService.getAllCategories();
	}

	async showAll() {
		this.settings = await this.commonService.getSuperAdminDetails();
	}

	ngOnDestroy() {
		if (this.modalRef) this.modalRef.hide();
	}

	logout() {
		this.spinner.show();
		this._cookieservice.removeAll();
		this.loggedInUser = null;
		this.spinner.hide();
		this.router.navigate(['/']);
	}

	login(loginForm: NgForm) {
		this.spinner.show();
		this._cookieservice.removeAll();
		this.customerService.customerLogin(this.customer).subscribe(result => {
			this._cookieservice.put('customer-data', JSON.stringify(result.data[0]));
			this.loggedInUser = JSON.parse(this._cookieservice.get('customer-data'));
			this.closeFirstModal();
			loginForm.resetForm();
			this.spinner.hide();
			this.toastr.success('Welcome to the Customer Panel', 'Success');
			let currentUrl=this.router.url;
			this.router.navigateByUrl('/', { skipLocationChange: true }).then(() =>
				this.router.navigate([currentUrl]));


		}, err => {
			this.closeFirstModal();
			loginForm.resetForm();
			this.spinner.hide();
			this.commonService.handleCustomerError(err);
		});
	}

	save() {
		this.savedSuccess = 0;
		const formdata = new FormData();
		this.spinner.show();
		this.utilityProvider['module_id'] = this.moduleIds;
		this.utilityProvider['category_id'] = this.dataIds;
		this.utilityProvider['is_active'] = 'false';
		this.utilityProvider['first_name'] = this.commonService.titleCase(this.utilityProvider.first_name);
		this.utilityProvider['last_name'] = this.commonService.titleCase(this.utilityProvider.last_name);
		this.utilityProvider['dob'] = moment(this.utilityProvider.dob).format('YYYY-MM-DD');
		const files: Array<File> = this.multipleFiles;
		for (let i = 0; i < files.length; i++) {
			formdata.append("files[]", files[i], files[i]['imageTypeName']);
		}
		formdata.append('data', JSON.stringify(this.utilityProvider));
		this.customerService.createProvider(formdata).subscribe(response => {
			this.spinner.hide();
			this.toastr.success('Service Provider added successfully', 'Success');
			this.savedSuccess = 1;
			this.closeFirstModal();
			//this.router.navigate(['/admin/utilitiyProvider']);
		}, err => {
			this.spinner.hide();
			this.commonService.handleSuperAdminError(err);
		});
	}

	getNotifications() {
		this.customerService.getNotification().subscribe(result => {
			console.log('------------------sss', result)
			if (result.data.length > 100) {
				this.notiCount = '100+';
			} else {
				this.notiCount = result.data.length;
			}

			let mainArray = [];
			_.each(result.data, (obj: any) => {
				let temp;
				temp = obj;
				temp['timeAgo'] = this.timeSince(obj.created_at);
				mainArray.push(temp);
			});
			this.notificationsList = this.paginate(mainArray, 5, this.pageNumber);

		}, err => {
			this.commonService.handleCustomerError(err);
		});
	}



	manageNotification(not, status) {
		this.spinner.show();
		let json = {
			status: status,
			id: btoa(not.id)
		}
		this.customerService.notifyStatus(json).subscribe(result => {
			this.spinner.hide();
			if (status == 1) {
				this.toastr.success('Notification Readed Successfully', 'Success');
			} else {
				this.toastr.success('Notification Removed Successfully', 'Success');
			}


		}, err => {
			this.commonService.handleError(err);
		});
	}

	paginate(array, page_size, page_number) {
		return array.slice((page_number - 1) * page_size, page_number * page_size);
	}

	/*________________________________________________________________________
	
	 * @Method :        nextPage
	 * Modified On:     -
	 * @Purpose:        Load next 5 notifications
	 * Input:
	 * Output:          Call getNotifications() function
	 _________________________________________________________________________
	*/
	nextPage() {
		this.pageNumber = this.pageNumber + 1;
		this.getNotifications();
	}

	/*________________________________________________________________________
	
	 * @Method :        timeSince
	 * Modified On:     -
	 * @Purpose:        Convert time format
	 * Input:
	 * Output:          Time in ago format
	 _________________________________________________________________________
	*/
	timeSince(time) {
		switch (typeof time) {
			case 'number':
				break;
			case 'string':
				time = +new Date(time);
				break;
			case 'object':
				if (time.constructor === Date) { time = time.getTime(); }
				break;
			default:
				time = +new Date();
		}
		const time_formats = [
			[60, 'seconds', 1], // 60
			[120, '1 minute ago', '1 minute from now'], // 60*2
			[3600, 'minutes', 60], // 60*60, 60
			[7200, '1 hour ago', '1 hour from now'], // 60*60*2
			[86400, 'hours', 3600], // 60*60*24, 60*60
			[172800, 'Yesterday', 'Tomorrow'], // 60*60*24*2
			[604800, 'days', 86400], // 60*60*24*7, 60*60*24
			[1209600, 'Last week', 'Next week'], // 60*60*24*7*4*2
			[2419200, 'weeks', 604800], // 60*60*24*7*4, 60*60*24*7
			[4838400, 'Last month', 'Next month'], // 60*60*24*7*4*2
			// [29030400, messagesConstants.months, 2419200], // 60*60*24*7*4*12, 60*60*24*7*4
			[58060800, 'Last year', 'Next year'], // 60*60*24*7*4*12*2
			[2903040000, 'years', 29030400], // 60*60*24*7*4*12*100, 60*60*24*7*4*12
			[5806080000, 'Last century', 'Next century'], // 60*60*24*7*4*12*100*2
			[58060800000, 'centuries', 2903040000] // 60*60*24*7*4*12*100*20, 60*60*24*7*4*12*100
		];
		let seconds = (+new Date() - time) / 1000,
			token = 'ago',
			list_choice = 1;

		if (seconds == 0) {
			return 'Just now';
		}
		if (seconds < 0) {
			seconds = Math.abs(seconds);
			token = 'from now';
			list_choice = 2;
		}
		let i = 0,
			format;
		while (format = time_formats[i++]) {
			if (seconds < format[0]) {
				if (typeof format[2] == 'string') {
					return format[list_choice];
				}
				else {
					return Math.floor(seconds / format[2]) + ' ' + format[1] + ' ' + token;
				}
			}
		}
		return time;
	}


	onTagFocused(event) {
		this._cookieservice.remove('searched-service-type');
		if (event.length > 1) {
			//this.spinner.show();
			let json = {
				keyword: event
			}

			this.customerService.getProvidersList(json).subscribe(response => {
				this.serviceList = _.groupBy(response.data, 'utilitiesTitle');

				console.log("==this.serviceList ==",this.serviceList );
				if (response.data.length > 0) {
					this.searchedKeyword = event;
				}
				this.spinner.hide();
			}, err => {
				this.spinner.hide();
				this.commonService.handleCustomerError(err);
			});
		} else {
			this.serviceList = [];
			this.selectedServiceType = '';
		}
	}

	setvalue(item,catType) {
		this.service_type = item;
		this.selectedServiceType = item.id;
		this.isServiceTypeSelected = true;
		this.serviceList = [];
		this.searchNext();
	}

	searchNext() {
		console.log("==this.service_type==",this.service_type);
		if (this.service_type) {
			console.log("==this.service_type==232",this.service_type);
			this.router.navigate(['/service-type', this.service_type]);
		} else {
			console.log("==this.service_type==",this.service_type);
			this.toastr.warning('No Service Found for the searched Item', 'Warning')
		}
	}

	register(registerForm: NgForm) {
		this.spinner.show();
		this.customer['first_name'] = this.commonService.titleCase(this.customer.first_name);
		this.customer['last_name'] = this.commonService.titleCase(this.customer.last_name);
		this.customerService.createCustomer(this.customer).subscribe(response => {
			this.modalRef2.hide();
			this.modalRef2 = null;
			this.spinner.hide();
			this.toastr.success('Customer Registered successfully', 'Success');
			this.login(registerForm);
		}, err => {
			//this.childModal.hide();
			this.modalRef2.hide();
			this.modalRef2 = null;
			registerForm.resetForm();
			this.spinner.hide();
			this.commonService.handleCustomerError(err);
		});
	}

	handleAddressChange(place: Address) {
		this.spinner.show();
		const location_obj = {};
		location_obj['lat'] = (place.geometry && place.geometry.location && place.geometry.location.lat()) ? place.geometry.location.lat() : '';
		location_obj['lng'] = (place.geometry && place.geometry.location && place.geometry.location.lng()) ? place.geometry.location.lng() : '';
		for (const i in place.address_components) {
			const item = place.address_components[i];
			location_obj['formatted_address'] = place.formatted_address;
			location_obj['full_address'] = place.name + ', ' + place.formatted_address;
			if ((item.types.indexOf('locality') > -1) || (item.types.indexOf('sublocality_level_1') > -1) || (item.types.indexOf('administrative_area_level_2') > -1)) {
				location_obj['city'] = item.long_name;
			} else if (item.types.indexOf('administrative_area_level_1') > -1) {
				location_obj['state'] = item.long_name;
			} else if (item.types.indexOf('street_number') > -1) {
				location_obj['street_number'] = item.short_name;
			} else if (item.types.indexOf('route') > -1) {
				location_obj['route'] = item.long_name;
			} else if (item.types.indexOf('country') > -1) {
				location_obj['country'] = item.long_name;
			} else if (item.types.indexOf('postal_code') > -1) {
				location_obj['postal_code'] = item.short_name;
			}

		}
		this.customer['city'] = location_obj['city'];
		this.customer['state'] = location_obj['state'];
		this.customer['country'] = location_obj['country'];
		this.customer['zip'] = location_obj['postal_code'];
		this.customer['address'] = location_obj['formatted_address'];
		this.spinner.hide();
	}

	handleAddressChangeProvider(place: Address) {
		this.spinner.show();
		const location_obj = {};
		location_obj['lat'] = (place.geometry && place.geometry.location && place.geometry.location.lat()) ? place.geometry.location.lat() : '';
		location_obj['lng'] = (place.geometry && place.geometry.location && place.geometry.location.lng()) ? place.geometry.location.lng() : '';
		for (const i in place.address_components) {
			const item = place.address_components[i];
			location_obj['formatted_address'] = place.formatted_address;
			location_obj['full_address'] = place.name + ', ' + place.formatted_address;
			if ((item.types.indexOf('locality') > -1) || (item.types.indexOf('sublocality_level_1') > -1) || (item.types.indexOf('administrative_area_level_2') > -1)) {
				location_obj['city'] = item.long_name;
			} else if (item.types.indexOf('administrative_area_level_1') > -1) {
				location_obj['state'] = item.long_name;
			} else if (item.types.indexOf('street_number') > -1) {
				location_obj['street_number'] = item.short_name;
			} else if (item.types.indexOf('route') > -1) {
				location_obj['route'] = item.long_name;
			} else if (item.types.indexOf('country') > -1) {
				location_obj['country'] = item.long_name;
			} else if (item.types.indexOf('postal_code') > -1) {
				location_obj['postal_code'] = item.short_name;
			}

		}
		this.utilityProvider['address'] = location_obj['formatted_address'];

		this.utilityProvider['city'] = location_obj['city'];
		this.utilityProvider['state'] = location_obj['state'];
		this.utilityProvider['country'] = location_obj['country'];
		this.utilityProvider['zip'] = location_obj['postal_code'];


		this.spinner.hide();
	}

	onUpload(event) {
		const allowedImageMimeTypes = [
			"image/jpeg",
			"image/png",
			"image/gif",
			"image/bmp",
			"image/jpg"
		];
		if (event && event.target && event.target.files && event.target.files.length > 0) {
			if (allowedImageMimeTypes.indexOf(event.target.files[0].type) == -1) {
				this.toastr.error("Please upload an image with one of the following extensions : '.jpeg','.jpg','.gif','.png','.png','.bmp'", 'Error');
				return false;
			} else if (event.target.files[0].size > 5242880) {
				this.toastr.error("Too large image, Please upload profile image of size 5mb or less.", 'Error');
				return false;
			} else {
				event.target.files[0]['imageTypeName'] = 'logo';
				this.multipleFiles.push(event.target.files[0]);
				var mimeType = event.target.files[0].type;
				if (mimeType.match(/image\/*/) == null) {
					this.toastr.error('Please upload image only', 'Error');
					return;
				}
				var reader = new FileReader();
				reader.readAsDataURL(event.target.files[0]);
				reader.onload = (_event) => {
					this.profileImageName = reader.result;
				}
			}
		}
	}

	onIdUpload(event: any, title) {
		const allowedImageMimeTypes = [
			"image/jpeg",
			"image/png",
			"image/gif",
			"image/bmp",
			"image/jpg"
		];
		if (event && event.target && event.target.files && event.target.files.length > 0) {
			if (allowedImageMimeTypes.indexOf(event.target.files[0].type) == -1) {
				this.toastr.error("Please upload an image with one of the following extensions : '.jpeg','.jpg','.gif','.png','.png','.bmp'", 'Error');
				return false;
			} else if (event.target.files[0].size > 5242880) {
				this.toastr.error("Too large image, Please upload profile image of size 5mb or less.", 'Error');
				return false;
			} else {
				if (title == 'front') {
					event.target.files[0]['imageTypeName'] = 'idfront';
					this.multipleFiles.push(event.target.files[0]);
					var mimeType = event.target.files[0].type;
					if (mimeType.match(/image\/*/) == null) {
						this.toastr.error('Please upload image only', 'Error');
						return;
					}
					var reader = new FileReader();
					reader.readAsDataURL(event.target.files[0]);
					reader.onload = (_event) => {
						this.idProofFrontName = reader.result;
					}
				}
				if (title == 'back') {
					event.target.files[0]['imageTypeName'] = 'idback';
					this.multipleFiles.push(event.target.files[0]);
					var mimeType = event.target.files[0].type;
					if (mimeType.match(/image\/*/) == null) {
						this.toastr.error('Please upload image only', 'Error');
						return;
					}
					var reader = new FileReader();
					reader.readAsDataURL(event.target.files[0]);
					reader.onload = (_event) => {
						this.idProofBackName = reader.result;
					}
				}
			}
		}
	}

}
