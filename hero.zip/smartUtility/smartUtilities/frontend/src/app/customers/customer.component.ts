import { Component, TemplateRef } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CustomerService } from '../services/customers/customer.service';
import { CookieService } from 'ngx-cookie';

@Component({
  selector: 'customer-root',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.css',
    '../../assets/css/bootstrap.min.css',
    '../../assets/css/style.css',
		'./scss/app.scss'

  ]
})
export class customerComponent {
  title = 'frontend';
  modalRef: BsModalRef;
  
  constructor(private modalService: BsModalService,
    private router: Router, private toastr: ToastrService,
    private customerService: CustomerService, private _cookieservice: CookieService) {
   
  }


  
}
