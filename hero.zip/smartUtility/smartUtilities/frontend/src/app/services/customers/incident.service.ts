import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Subject } from 'rxjs/Subject';
import { environment } from '../../../environments/environment';
import { map } from 'rxjs/operators';
import { CookieService } from 'ngx-cookie';

@Injectable({
    providedIn: 'root'
})
export class IncidentService {

    private notify = new Subject<any>();
    /**
     * Observable string streams
     */
    notifyObservable$ = this.notify.asObservable();

    constructor(private http: HttpClient, private _cookieservice: CookieService) {
    }
    public notifyOther(data: any) {
        this.notify.next(data);
    }

    getHeaders() {
        let headerOption = environment.headerOption;
        if (this._cookieservice.get('customer-data')) {
            const loggedInUtility = JSON.parse(this._cookieservice.get('customer-data'));
            headerOption['Authorization'] = loggedInUtility.access_token;
        }
        const headers = new HttpHeaders(headerOption);
        const options = { headers };
        return options
    }

    getRequestDetails(id){
        const headers = new HttpHeaders(environment.headerOption);
        const options = { headers };

        return this.http.get(environment.apiEndPoint + 'customer/getRequestDetails/'+id, options).map(res => res as any);
    }

    incidentDetail(id){  
         const headers = new HttpHeaders(environment.headerOption);
        const options = { headers };
        return this.http.get(environment.apiEndPoint + 'incident/incidentDetail/'+id, options).map(res => res as any);

    }

    saveIncident(data){        
        return this.http.post(environment.apiEndPoint + 'incident/saveIncident/', data,this.getHeaders()).map(res => res as any);
    }

    saveFeedback(data){   
    console.log("====data====",data);     
        return this.http.post(environment.apiEndPoint + 'incident/saveFeedback/', data,this.getHeaders()).map(res => res as any);
    }

   

    

}