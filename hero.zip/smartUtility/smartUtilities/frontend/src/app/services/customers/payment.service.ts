import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Subject } from 'rxjs/Subject';
import { environment } from '../../../environments/environment';
import { map } from 'rxjs/operators';
import { CookieService } from 'ngx-cookie';

@Injectable({
    providedIn: 'root'
})
export class PaymentService {

    private notify = new Subject<any>();
    /**
     * Observable string streams
     */
    notifyObservable$ = this.notify.asObservable();

    constructor(private http: HttpClient, private _cookieservice: CookieService) {
    }
    public notifyOther(data: any) {
        this.notify.next(data);
    }

    getHeaders() {
        let headerOption = environment.headerOption;
        if (this._cookieservice.get('customer-data')) {
            const loggedInUtility = JSON.parse(this._cookieservice.get('customer-data'));
            headerOption['Authorization'] = loggedInUtility.access_token;
        }
        const headers = new HttpHeaders(headerOption);
        const options = { headers };
        return options
    }

    

    payNow(data){        
        return this.http.post(environment.apiEndPoint + 'payment/paynow/', data,this.getHeaders()).map(res => res as any);
    }

    

}