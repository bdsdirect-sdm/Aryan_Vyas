const express = require('express');
const bodyParser = require('body-parser');
const nodemailer = require('nodemailer');
import cors from 'cors';
require('dotenv').config();

const app = express();
const PORT = 4001;

app.use(cors());
app.use(bodyParser.json());

const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST,
  port: process.env.EMAIL_PORT,
  secure: false,
  auth: {
    user: process.env.EMAIL_USER,
    pass: process.env.EMAIL_PASS,
  },
});

app.post('/send-email', async (req:any, res:any) => {
  const { email, cart, totalAmount, deliveryDate } = req.body;

  const cartDetails = cart
    .map((item: { name: string; quantity: number; price: number }) => `<li>${item.name} (x${item.quantity}) - $${item.price * item.quantity}</li>`)
    .join('');

  const mailOptions = {
    from: `"Vyas Store" <${process.env.EMAIL_USER}>`,
    to: email,
    subject: 'Your Order Details',
    html: `
      <h1>Order Details</h1>
      <p>Thank you for your order from Vyas Store! We are pleased to welcome in our family!</p>
      <p>${cartDetails}</p>
      <p><b>Total Amount:</b> $${totalAmount}</p>
      <p><b>Estimated Delivery Date:</b> ${deliveryDate}</p>
      <p><b>We are looking forward to serving you!</b></p>
      <p><b><u>Contact us 24X7 below our details!<u></b><p
      <p><b>Phone Number:7560053521</b><p
      <p><b>E-mail:vyasaryan786@gmail.com</b><p
    `,
  };

  try {
    await transporter.sendMail(mailOptions);
    res.status(200).send('Email sent successfully!');
  } catch (error) {
    console.error(error);
    res.status(500).send('Failed to send email.');
  }
});

app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
