
import { Router } from "express";
import sendMail from "./mailer";



const router = Router();
router.get('/email', (req, res) => {
  const { email, OTP } = req.query;
  sendMail(email as string, OTP as string);
  res.send('Email sent');
});
export default router;
