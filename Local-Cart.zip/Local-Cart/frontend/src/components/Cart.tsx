import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import './Cart.css'

const Cart: React.FC = () => {
  const [cart, setCart] = useState(JSON.parse(localStorage.getItem('cart') || '[]'));

  const handleQuantityChange = (id: number, quantity: number) => {
    if (quantity <= 0) return;
    const updatedCart = cart.map((item: any) =>
      item.id === id ? { ...item, quantity } : item
    );
    setCart(updatedCart);
    localStorage.setItem('cart', JSON.stringify(updatedCart));
  };

  const handleRemove = (id: number) => {
    const confirmed = window.confirm('Are you sure you want to remove this item from the cart?');
    if (confirmed) {
      const updatedCart = cart.filter((item: any) => item.id !== id);
      setCart(updatedCart);
      localStorage.setItem('cart', JSON.stringify(updatedCart));
    }
  };
  const handleContinueShopping = () => {
    window.location.href = '/';
};

  const totalCost = cart.reduce((acc: number, item: any) => acc + item.price * item.quantity, 0);

  return (
    <div className="container mt-5">
      <h1 className="text-center mb-4">Your Cart</h1>
      
      {cart.length === 0 ? (
        <div className="alert alert-warning" role="alert">
          Your cart is empty.
        </div>
      ) : (
        <div className="row">
          {cart.map((item: any) => (
            <div key={item.id} className="col-lg-4 col-md-6 mb-4">
              <div className="card shadow-sm">
                <img src={item.image} alt={item.name} className="card-img-top" style={{ height: '200px',width:'375px', objectFit: 'cover' }} />
                <div className="card-body">
                  <h5 className="card-title">{item.name}</h5>
                  <p className="card-text">Price: ${item.price}</p>
                  <div className="form-group">
                    <label>Quantity:</label>
                    <input
                      type="number"
                      className="form-control"
                      value={item.quantity}
                      min="1"
                      onChange={(e) => handleQuantityChange(item.id, parseInt(e.target.value))}
                    />
                  </div>
                  <button className="btn btn-danger mt-2" onClick={() => handleRemove(item.id)}>
                    Remove
                  </button>
                </div>
              </div>
            </div>
          ))}
           <div className="d-grid gap-2 col-12 mx-auto">
          <button className="btn btn-primary text-center" onClick={handleContinueShopping}>Explore More Go Back</button>
          </div>
        </div>
      )}
      {cart.length > 0 && (
        <div className="d-flex justify-content-between align-items-center mt-4">
          <h3 className="text-info">Total Cost: ${totalCost.toFixed(2)}</h3>
          <a href="/checkout" className="btn btn-primary btn-lg">Proceed to Checkout</a>
        </div>
      )}
    </div>
  );
};

export default Cart;
