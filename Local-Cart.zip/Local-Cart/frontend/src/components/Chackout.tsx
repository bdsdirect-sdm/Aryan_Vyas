import React, { useState } from 'react';
import { Formik, Field, Form } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';
import 'bootstrap/dist/css/bootstrap.min.css';
import './CheckOut.css';

// Function to check if the expiry date is in the future
const isFutureDate = (date: string) => {
  const [month, year] = date.split('/').map((str) => parseInt(str, 10));
  const currentYear = new Date().getFullYear() % 100; // Get last 2 digits of the year
  const currentMonth = new Date().getMonth() + 1; // Months are 0-indexed

  if (year < currentYear) return false;
  if (year === currentYear && month < currentMonth) return false;
  return true;
};

const validationSchema = Yup.object({
  email: Yup.string().email('Invalid email format').required('Email is required'),
  cardNumber: Yup.string().length(16, 'Card number must be 16 digits').required('Card number is required'),
  expiryDate: Yup.string()
    .matches(/^(0[1-9]|1[0-2])\/\d{2}$/, 'Expiry date must be in MM/YY format')
    .test('is-future-date', 'Expiry date must be in the future', (value) => isFutureDate(value || ''))
    .required('Expiry date is required'),
  cvv: Yup.string().length(3, 'CVV must be 3 digits').required('CVV is required'),
});

const handleContinueShopping = () => {
  window.location.href = '/';
};

const Checkout: React.FC = () => {
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (values: any) => {
    setLoading(true);
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    const totalAmount = cart.reduce((acc: number, item: any) => acc + item.price * item.quantity, 0);
    const deliveryDate = new Date();
    deliveryDate.setDate(deliveryDate.getDate() + 10);

    try {
      await axios.post('http://localhost:4001/send-email', {
        email: values.email,
        cart,
        totalAmount,
        deliveryDate: deliveryDate.toDateString(),
      });

      alert('Order placed successfully! Confirmation email sent.');
      localStorage.removeItem('cart');
      window.location.href = '/success';
    } catch (error) {
      console.error(error);
      alert('Failed to place the order.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="container mt-5">
      <h1 className="text-center mb-4">Checkout</h1>
      <Formik
        initialValues={{ email: '', cardNumber: '', expiryDate: '', cvv: '' }}
        validationSchema={validationSchema}
        onSubmit={handleSubmit}
      >
        {({ errors, touched }) => (
          <Form className="checkout-form">
            <div className="form-group">
              <label>Email<span className="star">*</span></label>
              <Field
                name="email"
                type="email"
                placeholder="Enter Your Email"
                className={`form-control ${errors.email && touched.email ? 'is-invalid' : ''}`}
              />
              {errors.email && touched.email && <div className="invalid-feedback">{errors.email}</div>}
            </div>

            <div className="form-group">
              <label>Card Number<span className="star">*</span></label>
              <Field
                name="cardNumber"
                type="text"
                placeholder="**** **** **** ****"
                maxLength={16}
                className={`form-control ${errors.cardNumber && touched.cardNumber ? 'is-invalid' : ''}`}
              />
              {errors.cardNumber && touched.cardNumber && <div className="invalid-feedback">{errors.cardNumber}</div>}
            </div>

            <div className="form-group">
              <label>Expiry Date (MM/YY)<span className="star">*</span></label>
              <Field
                name="expiryDate"
                type="text"
                placeholder="MM/YY"
                className={`form-control ${errors.expiryDate && touched.expiryDate ? 'is-invalid' : ''}`}
              />
              {errors.expiryDate && touched.expiryDate && <div className="invalid-feedback">{errors.expiryDate}</div>}
            </div>

            <div className="form-group">
              <label>CVV<span className="star">*</span></label>
              <Field
                name="cvv"
                type="text"
                placeholder="Enter CVV"
                maxLength={3}
                className={`form-control ${errors.cvv && touched.cvv ? 'is-invalid' : ''}`}
              />
              {errors.cvv && touched.cvv && <div className="invalid-feedback">{errors.cvv}</div>}
            </div>

            <button type="submit" className="btn btn-primary btn-lg" disabled={loading}>
              {loading ? (
                <span className="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>
              ) : (
                'Pay Now'
              )}
            </button>

            <div className="d-grid gap-2 col-12 mx-auto">
              <button className="btn btn-primary text-center mt-4" onClick={handleContinueShopping}>
                Explore More Cancel Checkout And Go Back
              </button>
            </div>
          </Form>
        )}
      </Formik>
    </div>
  );
};

export default Checkout;
