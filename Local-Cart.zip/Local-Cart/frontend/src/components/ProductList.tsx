import React, { useState } from 'react';
import products from '../Data/products.json';
import 'bootstrap/dist/css/bootstrap.min.css';
import './ProductList.css';

const ProductsList: React.FC = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const productsPerPage = 6;

  const startIndex = (currentPage - 1) * productsPerPage;
  const paginatedProducts = products.slice(startIndex, startIndex + productsPerPage);

  const handleAddToCart = (product: any) => {
    const cart = JSON.parse(localStorage.getItem('cart') || '[]');
    localStorage.setItem('cart', JSON.stringify([...cart, { ...product, quantity: 1 }]));
    alert('Added to cart!');
  };

  return (
    <div className="container mt-5">
      <h1 className="text-center mb-4">Check Our exciting
      Products</h1>
      
      <div className="d-flex justify-content-end mb-3">
        <button className="btn btn-outline-primary" onClick={() => window.location.href = '/cart'}>View Cart</button>
      </div>

      <div className="row">
        {paginatedProducts.map((product) => (
          <div key={product.id} className="col-lg-4 col-md-6 mb-4">
            <div className="card product-card">
              <img src={product.image} alt={product.name} className="product-image" />
              <div className="card-body">
                <h5 className="card-title">{product.name}</h5>
                <p className="card-text">{product.description}</p>
                <p className="card-text"><strong>Rating: </strong>{product.rating} &#11088;</p>
                <p className="card-text"><strong>Price: </strong>${product.price}</p>
                <button className="btn btn-outline-primary" onClick={() => handleAddToCart(product)}>
                  Add to Cart
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      <div className="d-flex justify-content-evenly">
        <button className="btn btn-primary" disabled={currentPage === 1} onClick={() => setCurrentPage(currentPage - 1)}>
          Previous
        </button>
        <button className="btn btn-primary" disabled={startIndex + productsPerPage >= products.length} onClick={() => setCurrentPage(currentPage + 1)}>
          Next
        </button>
      </div>
    </div>
  );
};

export default ProductsList;
