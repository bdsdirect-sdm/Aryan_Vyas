import React from 'react';
import './Sucess.css';

const Success: React.FC = () => {
    const handleContinueShopping = () => {
        window.location.href = '/';
    };

    return (
        <div className="success-page-container">
            <div className="success-card">
                <div className="success-icon">
                    <i className="fas fa-check-circle"></i>
                </div>
                <h1 className="success-title">Order Placed Successfully!</h1>
                <p className="success-description">Thank you for your purchase! Your order is on its way.</p>
                <button className="btn-continue" onClick={handleContinueShopping}>Continue Shopping</button>
            </div>
        </div>
    );
};

export default Success;
