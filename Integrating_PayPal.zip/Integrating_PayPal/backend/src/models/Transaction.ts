import { DataTypes, Model } from "sequelize";
import sequelize from "../config/database";

class Transaction extends Model {
  public id!: number;
  public orderId!: string;
  public payerId!: string;
  public payerName!: string;
  public payerEmail!: string;
  public currency!: string;
  public amount!: string;
  public status!: string;
  public phoneNumber!: string;
  public readonly createdAt!: Date;
  public readonly updatedAt!: Date;
}

Transaction.init(
  {
    id: {
      type: DataTypes.INTEGER,
      primaryKey: true,
      autoIncrement: true,
      allowNull: false,
    },
    orderId: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    payerId: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    payerName: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    payerEmail: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    currency: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    amount: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    status: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    phoneNumber: {
      type: DataTypes.STRING,
      allowNull: true,
    },
  },
  {
    sequelize,
    modelName: "Transaction",
    tableName: "transactions",
    timestamps: true,
  }
);

export default Transaction;
