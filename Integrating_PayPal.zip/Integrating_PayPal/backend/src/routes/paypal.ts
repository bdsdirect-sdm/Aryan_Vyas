import express from "express";
import { saveTransaction } from "../controllers/paymentController";

const router = express.Router();

router.post("/save-transaction", saveTransaction);

export default router;
