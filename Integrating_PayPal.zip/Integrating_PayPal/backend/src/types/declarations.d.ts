declare module '@paypal/checkout-server-sdk' {
    export = paypal;
    namespace paypal {
      export namespace core {
        class PayPalHttpClient {
          constructor(environment: Environment);
          execute(request: any): Promise<any>;
        }
        
        class SandboxEnvironment {
          constructor(clientId: string, clientSecret: string);
        }
        
        class LiveEnvironment {
          constructor(clientId: string, clientSecret: string);
        }
        
        type Environment = SandboxEnvironment | LiveEnvironment;
      }
  
      export namespace orders {
        class OrdersCreateRequest {
          requestBody(body: any): void;
        }
  
        class OrdersCaptureRequest {
          constructor(orderId: string);
          requestBody(body: any): void;
        }
      }
    }
  }
  