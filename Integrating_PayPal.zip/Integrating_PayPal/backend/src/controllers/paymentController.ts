import { Request, Response } from "express";
import Transaction from "../models/Transaction";

export const saveTransaction = async (req: Request, res: Response) => {
  try {
    console.log("Incoming Request Body:", req.body);

    const { orderId, payerId, payerName, payerEmail, currency, amount, status, phoneNumber } = req.body;
    console.log("Extracted Fields:", { orderId, payerId, payerName, payerEmail, currency, amount, status, phoneNumber });
    if (!orderId || !payerId || !payerEmail || !currency || !amount || !status) {
      console.log("Missing required fields");
      return res.status(400).json({ error: "Missing required transaction fields" });
    }
    console.log("Attempting to create transaction...");

    const transaction = await Transaction.create({
      orderId,
      payerId,
      payerName,
      payerEmail,
      currency,
      amount,
      status,
      phoneNumber,
    });
    
    console.log("Transaction Created:", transaction.dataValues);

    console.log("Transaction Data:", transaction.dataValues);

    return res.status(201).json({ message: "Transaction saved successfully", transaction });
  } catch (error) {

    console.error("Error saving transaction:", error);
  
    return res.status(500).json({ error: "Internal Server Error" });
  }
};
