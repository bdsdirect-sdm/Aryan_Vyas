/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useEffect, useState } from "react";
import { PayPalButtons } from "@paypal/react-paypal-js";
import axios from "axios";

const PaypalButton = () => {
  const [orderId, setOrderId] = useState<string | null>(null);

  const createOrder = async (data: any, actions: any) => {
    try {
      const response = await axios.post("http://localhost:5000/api/paypal/create-order", {
        amount: "10.00",
      });
      const orderID = response.data.id;
      setOrderId(orderID);
      return orderID;
    } catch (error) {
      console.error("Error creating PayPal order", error);
      throw new Error("Unable to create PayPal order");
    }
  };
  const onApprove = async (data: any, actions: any) => {
    try {
      const response = await axios.post("http://localhost:5000/api/paypal/capture-order", {
        orderId: orderId,
      });
      const details = response.data;
      alert("Transaction completed by " + details.payer.name.given_name);
    } catch (error) {
      console.error("Error capturing PayPal order", error);
      alert("Transaction failed");
    }
  };

  return (
    <div>
      <PayPalButtons createOrder={createOrder} onApprove={onApprove} />
    </div>
  );
};

export default PaypalButton;
