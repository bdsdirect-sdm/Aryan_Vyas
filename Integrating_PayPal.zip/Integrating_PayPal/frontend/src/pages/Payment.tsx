/* eslint-disable @typescript-eslint/no-unused-vars */
/* eslint-disable no-constant-binary-expression */
/* eslint-disable @typescript-eslint/no-explicit-any */
import React, { useState } from "react";
import { PayPalButtons } from "@paypal/react-paypal-js";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import "../styles/Payment.css";

const Payment = () => {
  const navigate = useNavigate();
  const [cardNumber, setCardNumber] = useState("");
  const [expiryDate, setExpiryDate] = useState("");
  const [cvv, setCvv] = useState("");
  const [error, setError] = useState("");
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const amount = "37.00";

  const isCardNumberValid = cardNumber.length === 19 && /^[0-9-]+$/.test(cardNumber);
  const isCvvValid = cvv.length === 3 && /^[0-9]+$/.test(cvv);
  const isExpiryDateValid = /^([0-9]{2})\/([0-9]{2})$/.test(expiryDate);

  const isExpiryDateFuture = (): boolean => {
    const [month, year] = expiryDate.split("/").map((val) => parseInt(val, 10));
    const now = new Date();
    const currentMonth = now.getMonth() + 1;
    const currentYear = now.getFullYear() % 100;
    return year > currentYear || (year === currentYear && month >= currentMonth);
  };

  const isFormValid = isCardNumberValid && isCvvValid && isExpiryDateValid && isExpiryDateFuture();

  const handleCardNumberChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, "");
    if (value.length > 4) value = value.replace(/(\d{4})(?=\d)/g, "$1-");
    setCardNumber(value);
  };

  const handleExpiryDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    let value = e.target.value.replace(/\D/g, "");
    if (value.length >= 3) value = value.slice(0, 2) + "/" + value.slice(2, 4);
    setExpiryDate(value);
  };

  const handleSubmit = () => {
    if (!isExpiryDateFuture()) {
      setError("Expiry date cannot be in the past.");
    } else {
      setError("");
    }
  };

  const saveTransactionDetails = async (transactionData: any) => {
    try {
      const response = await axios.post("http://localhost:5000/api/paypal/save-transaction", transactionData);

      console.log("Transaction saved successfully:", response.data);
    } catch (error) {
      console.error("Error saving transaction:", error);
    }
  };

  const handlePaymentSuccess = async (data: any, actions: any): Promise<void> => {
    try {
      const orderData = await actions.order.capture();
      if (!orderData.payer) {
        console.error("Payer data is missing");
        return;
      }

      const transactionData = {
        orderId: orderData.id,
        payerId: orderData.payer?.payer_id || "N/A",
        payerName: `${orderData.payer?.name?.given_name} ${orderData.payer?.name?.surname}` || "N/A",
        payerEmail: orderData.payer?.email_address || "N/A",
        currency: orderData.purchase_units?.[0]?.amount?.currency_code || "USD",
        amount: amount,
        status: orderData.status || "FAILED",
        phoneNumber: orderData.payer.phone_number?.national_number || "1-800-671-4332",
      };

      await saveTransactionDetails(transactionData);
      setPaymentSuccess(true);
      alert("Payment Successful!");
      navigate("/success");
    } catch (error) {
      console.error("Error capturing the order:", error);
    }
  };

  return (
    <div className="payment-container">
      <h2>Payment Page</h2>

      <div style={{ marginRight: 20 }}>

        <label>
          Card Number:
          <input
            type="text"
            value={cardNumber}
            onChange={handleCardNumberChange}
            placeholder="Enter your card number"
            required
            maxLength={19}
          />
        </label>
        {cardNumber && !isCardNumberValid && (
          <div className="error-message">Card number must be 16 digits.</div>
        )}

        <label>
          Expiry Date (MM/YY):
          <input
            type="text"
            value={expiryDate}
            onChange={handleExpiryDateChange}
            placeholder="MM/YY"
            required
            maxLength={5}
            onBlur={handleSubmit}
          />
        </label>
        {expiryDate && !isExpiryDateValid && (
          <div className="error-message">Expiry date is invalid. Use MM/YY format.</div>
        )}
        {expiryDate && !isExpiryDateFuture() && (
          <div className="error-message">Expiry date cannot be in the past.</div>
        )}


        <label>
          CVV:
          <input
            type="password"
            value={cvv}
            onChange={(e) => setCvv(e.target.value)}
            placeholder="CVV"
            required
            maxLength={3}
          />
        </label>
        {cvv && !isCvvValid && (
          <div className="error-message">CVV must be 3 digits.</div>
        )}

        <div className="paypal-button-container">
          <PayPalButtons
            createOrder={(data, actions) => {
              return actions.order.create({
                intent: "CAPTURE",
                purchase_units: [
                  {
                    amount: {
                      currency_code: "USD",
                      value: amount,
                    },
                  },
                ],
              });
            }}
            onApprove={handlePaymentSuccess}
            // disabled={!isFormValid}
          />
        </div>

        {paymentSuccess && <div className="payment-success">Payment was successful!</div>}
      </div>
    </div>
  );
};

export default Payment;
