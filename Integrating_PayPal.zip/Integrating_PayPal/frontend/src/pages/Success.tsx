import React from 'react'

export const Success = () => {
  return (
    <div>Payment Successfully Done</div>
  )
}
