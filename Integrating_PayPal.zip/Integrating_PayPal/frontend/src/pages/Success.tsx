import React from 'react'
import { useNavigate } from "react-router-dom";
import "../styles/Success.css";

export const Success:React.FC = () => {
  const navigate = useNavigate();

  const handleBack = () => {
    navigate('/');
  };

  return (
    <div className="success-container">
      <div className="content">
        <h1 className="success-heading">Payment Successfully Done</h1>
        <p className="success-message">Thank you for your payment. Your transaction was completed successfully.</p>
        <button className="cta-button" onClick={handleBack}>Go To Home Page</button>
      </div>
    </div>
  );
}
