import React from "react";

const Error = () => {
  return (
    <div>
      <h2>Something Went Wrong!</h2>
      <p>Please try again later or contact support.</p>
    </div>
  );
};

export default Error;
