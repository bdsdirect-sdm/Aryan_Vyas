import React from "react";
import { useNavigate } from "react-router-dom";
import "../styles/Home.css";

const Home = () => {
  const navigate = useNavigate();

  const handlePayment = () => {
    navigate('/payment');
  };

  return (
    <div className="home-container">
      <div className="content">
        <h1 className="heading">Welcome to PayPal Integration Demo</h1>
        <p className="subheading">Explore the functionality of PayPal integration on our platform.</p>
        <button className="cta-button" onClick={handlePayment}>Click Here To See Demo</button>
      </div>
    </div>
  );
};

export default Home;
