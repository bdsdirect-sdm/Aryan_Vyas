import React from "react";

const Home = () => {
  return (
    <div>
      <h1>Welcome to PayPal Integration Demo</h1>
      <p>Explore the functionality of PayPal integration on our platform.</p>
    </div>
  );
};

export default Home;
