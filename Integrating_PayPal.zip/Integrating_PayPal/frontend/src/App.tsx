// import React from "react";
// import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
// import Home from "./pages/Home";
// import Products from "./pages/Product";
// import Payment from "./pages/Payment";
// import TransactionHistory from "./pages/TransactionHistory";
// import Error from "./pages/Error";

// const App = () => {
//   return (
//     <Router>
//       <div>
//         <header>
//           <nav>
//             <ul>
//               <li><a href="/">Home</a></li>
//               <li><a href="/products">Products</a></li>
//               <li><a href="/payment">Payment</a></li>
//               <li><a href="/transactions">Transaction History</a></li>
//             </ul>
//           </nav>
//         </header>

//         <main>
//           <Routes>
//             <Route path="/" element={<Home />} />
//             <Route path="/products" element={<Products />} />
//             <Route path="/payment" element={<Payment />} />
//             <Route path="/transactions" element={<TransactionHistory />} />
//             <Route path="*" element={<Error />} />
//           </Routes>
//         </main>
//       </div>
//     </Router>
//   );
// };

// export default App;



// App.tsx or App.js

import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Payment from "./pages/Payment";
import { PayPalScriptProvider } from "@paypal/react-paypal-js";
import { Success } from "./pages/Success";
import Home from "./pages/Home";

const App = () => {
  return (
    <PayPalScriptProvider options={{ "client-id": "AeC0Eq4zGlez1yWtFJ_ZJZy5-_dKijce1xsrzx0EqsCjKqaWpk2A6I-zOV-OlUePxTHH351I0dykKerx" }}>
      <Router>
        <Routes>
        <Route path="/" element={<Home />} />
          <Route path="/payment" element={<Payment />} />
          <Route path="*" element={<div>Page Not Found</div>} />
          <Route path="/success" element={<Success />} />

        </Routes>
      </Router>
    </PayPalScriptProvider>
  );
};

export default App;


