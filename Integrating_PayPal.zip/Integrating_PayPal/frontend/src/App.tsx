import React from "react";
import { BrowserRouter as Router, Route, Routes } from "react-router-dom";
import Payment from "./pages/Payment";
import { PayPalScriptProvider } from "@paypal/react-paypal-js";
import { Success } from "./pages/Success";
import Home from "./pages/Home";

const App:React.FC = () => {
  return (
    <PayPalScriptProvider options={{clientId: "AeC0Eq4zGlez1yWtFJ_ZJZy5-_dKijce1xsrzx0EqsCjKqaWpk2A6I-zOV-OlUePxTHH351I0dykKerx" }}>
      <Router>
        <Routes>
        <Route path="/" element={<Home />} />
          <Route path="/payment" element={<Payment />} />
          <Route path="*" element={<div>Page Not Found</div>} />
          <Route path="/success" element={<Success />} />

        </Routes>
      </Router>
    </PayPalScriptProvider>
  );
};

export default App;


