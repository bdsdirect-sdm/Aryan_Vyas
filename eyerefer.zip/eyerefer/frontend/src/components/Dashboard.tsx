/* eslint-disable @typescript-eslint/no-unused-vars */
import { useQuery } from '@tanstack/react-query';
import { Local } from '../environment/env';
import api from '../api/axiosInstance';
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify'; // Optional: For showing error messages
import "./Dashboard.css";

const Dashboard: React.FC = () => {
    const navigate = useNavigate();
    const token = localStorage.getItem("token");

    // Redirect to login if no token exists
    useEffect(() => {
        if (!token) {
            navigate("/login");
        }
    }, [token, navigate]);

    // Fetch user (doctor) details
    const getUser = async () => {
        try {
            const response = await api.get(`${Local.GET_USER}`, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            return response;
        } catch (err) {
            toast.error("Failed to fetch user data");
        }
    };

    // Fetch patient list data
    const fetchPatientList = async () => {
        try {
            const response = await api.get(`${Local.GET_PATIENT_LIST}`, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            return response.data;
        } catch (err) {
            toast.error("Failed to fetch patient data");
        }
    };

    const { data: userData, isError: userError, error: userErrorMsg, isLoading: userLoading } = useQuery({
        queryKey: ['userData'],
        queryFn: getUser
    });

    const { data: patientData, isError: patientError, error: patientErrorMsg, isLoading: patientLoading } = useQuery({
        queryKey: ['patientData'],
        queryFn: fetchPatientList
    });

    if (userLoading || patientLoading) {
        return (
            <div className="loading-container">
                <div>Loading...</div>
                <div className="spinner-border text-primary" role="status">
                    <span className="visually-hidden">Loading...</span>
                </div>
            </div>
        );
    }

    if (userError || patientError) {
        return (
            <div className="error-container">
                <div>Error: {userErrorMsg?.message || patientErrorMsg?.message}</div>
            </div>
        );
    }

    const { user } = userData?.data || {};
    const { patientList } = patientData || {};


    const totalRefersReceived = patientList?.length || 0;
    const totalRefersCompleted = patientList?.filter((patient: { referalstatus: boolean; }) => patient.referalstatus === true).length || 0;
    const totalOD = patientList?.filter((patient: { doctype: number; }) => patient.doctype === 2).length || 0;
    const totalMD = patientList?.filter((patient: { doctype: number; }) => patient.doctype === 1).length || 0;

    return (
        <div className="dashboard-container">
            <h2 className="dashboard-title">Welcome to Your Dashboard</h2>

           
            <div className="doctor-info">
                <div className="info-item">
                    <b>Doctor Name:</b> {user?.firstname} {user?.lastname}
                </div>
                <div className="info-item">
                    <b>Doctor Type:</b> {user?.doctype === 2 ? 'OD' : 'MD'}
                </div>
            </div>

   
            <div className="metrics-cards">
                <div className="card">
                    <div className="card-body">
                        <div className="card-title">Total Refers Received</div>
                        <div className="card-text">{totalRefersReceived}</div>
                    </div>
                </div>
                <div className="card">
                    <div className="card-body">
                        <div className="card-title">Total Refers Completed</div>
                        <div className="card-text">{totalRefersCompleted}</div>
                    </div>
                </div>
                
                <div className="card">
                    <div className="card-body">
                        <div className="card-title">Total OD & MD Doctors</div>
                        <div className="card-text">
                            <div>OD: {totalOD}</div>
                            <div>MD: {totalMD}</div>
                        </div>
                    </div>
                </div>
            </div>

            {/* Patient List Table */}
            <div className="patient-list-section">
                <div className="patient-table-container">
                    <table className="table">
                        <thead>
                            <tr>
                                <th scope="col">#</th>
                                <th scope="col">Patient Name</th>
                                <th scope="col">Disease</th>
                                <th scope="col">Refer by</th>
                                <th scope="col">Refer to</th>
                                <th scope="col">Refer back</th>
                                <th scope="col">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            {patientList?.map((patient: any, index: number) => (
                                <tr key={index}>
                                    <td className="fw-bold">{index + 1}</td>
                                    <td>{patient.firstname} {patient.lastname}</td>
                                    <td>{patient.disease}</td>
                                    <td>{patient.referedby.firstname} {patient.referedby.lastname}</td>
                                    <td>{patient.referedto.firstname} {patient.referedto.lastname}</td>
                                    <td>{patient.referback ? 'Yes' : 'No'}</td>
                                    <td>
                                        <span className={`badge ${patient.referalstatus ? 'bg-success' : 'bg-warning'}`}>
                                            {patient.referalstatus ? 'Completed' : 'Pending'}
                                        </span>
                                    </td>
                                </tr>
                            ))}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default Dashboard;
