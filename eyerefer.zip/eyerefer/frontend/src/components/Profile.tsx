import React, { useState } from 'react';
import { Modal } from 'react-bootstrap';
import AddAddress from './AddAddress';
import "./Profile.css"
const Profile: React.FC = () => {
  const [showModal, setShowModal] = useState(false);
  const handleOpenModal = () => setShowModal(true);
  const handleCloseModal = () => setShowModal(false);

  return (
    <div className="profile-container">
      {/* Profile heading */}
      <h2 className="profile-title">Profile</h2>

      {/* Button to trigger modal */}
      <button onClick={handleOpenModal} className="btn btn-primary mb-4">
        Add Address
      </button>

      {/* Modal for adding address */}
      <Modal show={showModal} onHide={handleCloseModal} centered>
        <Modal.Header closeButton>
          <Modal.Title>Add New Address</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <AddAddress />
        </Modal.Body>
      </Modal>
    </div>
  );
};

export default Profile;
