import { useQuery } from '@tanstack/react-query';
import { Local } from '../environment/env';
import api from '../api/axiosInstance';
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';

const DoctorList: React.FC = () => {
  const navigate = useNavigate();
  const token = localStorage.getItem('token');

  // Redirect to login if no token exists
  useEffect(() => {
    if (!token) {
      navigate('/login');
    }
  }, [navigate, token]);

  // Fetch doctor list
  const fetchDoctors = async () => {
    try {
      const response = await api.get(`${Local.GET_USER}`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      });
      return response.data;
    } catch (err) {
      toast.error('Error fetching doctor data');
      throw err;
    }
  };

  // React Query hook for fetching doctor list
  const { data: doctors, isLoading, isError, error } = useQuery({
    queryKey: ['doctorList'],
    queryFn: fetchDoctors,
    retry: 1, // Retry once in case of failure
  });

  if (isLoading) {
    return (
      <div>Loading...</div>
    );
  }

  if (isError) {
    return (
      <div className="text-danger">Error: {error?.message}</div>
    );
  }

  return (
    <div>
      <table className="table">
        <thead>
          <tr>
            <th>#</th>
            <th>First Name</th>
            <th>Last Name</th>
            <th>Email</th>
          </tr>
        </thead>
        <tbody>
          {doctors?.doctorList?.map((doctor: any, index: number) => (
            <tr key={doctor.id}>
              <td>{index + 1}</td>
              <td>{doctor.firstname}</td>
              <td>{doctor.lastname}</td>
              <td>{doctor.email}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
};

export default DoctorList;
