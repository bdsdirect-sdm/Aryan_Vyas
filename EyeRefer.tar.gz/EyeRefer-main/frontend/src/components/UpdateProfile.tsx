import React from 'react';

const UpdateProfile:React.FC = () => {
  return (
    <div>UpdateProfile</div>
  )
}

export default UpdateProfile