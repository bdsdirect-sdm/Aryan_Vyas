// import { useQuery } from '@tanstack/react-query';
// import { Local } from '../environment/env';
// import api from '../api/axiosInstance';
// import React, { useEffect } from 'react';
// import { useNavigate } from 'react-router-dom';


// const Dashboard:React.FC = () => {
//     const navigate = useNavigate()
//     const token = localStorage.getItem("token");

//     useEffect(()=>{
//         if(!token){
//             navigate("/login");
//         }
//     },[]);

//     const getUser = async() => {
//         // try{
//             console.log("Hello")
//             const response = await api.get(`${Local.GET_USER}`,{
//                 headers:{
//                     Authorization: `Bearer ${token}`
//                 }
//             });
//             console.log("Response-------->", response);
//             return response;
//         // }
//         // catch(err){
//         //     console.log("Error-------->", err);
//         // }
//     }

//     const { data, isError, error, isLoading } = useQuery({
//         queryKey: ['dashboard'],
//         queryFn: getUser
//     })    

//     if(isLoading){
//         return (
//         <>
//             <div>Loading...</div>
//             <div className="spinner-border text-primary" role="status">
//                 <span className="visually-hidden">Loading...</span>
//             </div>
//         </>
//         )
//     }

//     if(isError){
//         return(
//             <>
//             <div>Error: {error.message}</div>
//             </>
//         )
//     }
//     console.log("Data--------->", data?.data);
//   return (
//     <div>
//         <b>Doctor Name:</b> {data?.data.user.firstname} {data?.data.user.lastname} <br />
//         <b>Doctor Type:</b> {(data?.data.user.doctype == 2) && (<>
//         OD
//         </>)} 
//         {(data?.data.user.doctype == 1) && (<>
//         MD
//         </>)} 
//     </div>
//   )
// }

// export default Dashboard
///////////////////////////////////////////////
import { useQuery } from '@tanstack/react-query';
import { Local } from '../environment/env';
import api from '../api/axiosInstance';
import React, { useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify'; // Optional: For showing error messages
import "./Dashboard.css";
const Dashboard: React.FC = () => {
    const navigate = useNavigate();
    const token = localStorage.getItem("token");

    // Redirect to login if no token exists
    useEffect(() => {
        if (!token) {
            navigate("/login");
        }
    }, [token, navigate]);

    // Fetch user data
    const getUser = async () => {
        try {
            const response = await api.get(`${Local.GET_USER}`, {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            });
            return response;
        } catch (err) {
            toast.error("Failed to fetch user data"); // Optional error handling
        }
    }

    // Use query to fetch the user data
    const { data, isError, error, isLoading } = useQuery({
        queryKey: ['dashboard'],
        queryFn: getUser
    });

    // Handle loading state
    if (isLoading) {
        return (
            <div className="loading-container">
                <div>Loading...</div>
                <div className="spinner-border text-primary" role="status">
                    <span className="visually-hidden">Loading...</span>
                </div>
            </div>
        );
    }

    // Handle error state
    if (isError) {
        return (
            <div className="error-container">
                <div>Error: {error.message}</div>
            </div>
        );
    }

    // Doctor details rendering
    return (
        <div className="dashboard-container">
            <h2 className="dashboard-title">Welcome to Your Dashboard</h2>
            <div className="doctor-info">
                <div className="info-item">
                    <b>Doctor Name:</b> {data?.data.user.firstname} {data?.data.user.lastname}
                </div>
                <div className="info-item">
                    <b>Doctor Type:</b>
                    {data?.data.user.doctype === 2 ? 'OD' : 'MD'}
                </div>
            </div>
        </div>
    );
}

export default Dashboard;
