import React from 'react'

const Chat: React.FC = () => {
    return (
        <div>Chat</div>
    )
}

export default Chat