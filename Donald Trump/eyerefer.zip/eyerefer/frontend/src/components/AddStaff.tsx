import React from 'react'

const AddStaff:React.FC = () => {
  return (
    <div>AddStaff</div>
  )
}

export default AddStaff