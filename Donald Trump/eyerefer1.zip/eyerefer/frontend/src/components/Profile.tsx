/* eslint-disable @typescript-eslint/no-unused-vars */
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Modal } from 'react-bootstrap';
import AddAddress from './AddAddress';
import { Local } from '../environment/env';
import "./Profile.css";

interface Address {
  street: string;
  city: string;
  state: string;
  pincode: string;
  phone: string;
}

interface User {
  uuid: string;
  firstname: string;
  lastname: string;
  email: string;
  doctype: number;
  address?: Address; // address can be undefined
}

interface ProfileData {
  user: User;
  message: string;
  patientCount?: number;
  referredPatients?: Array<any>; 
  referredDoctors?: Array<any>;
  additionalData?: string;
}

const Profile: React.FC = () => {
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [showModal, setShowModal] = useState(false);

  const handleOpenModal = () => setShowModal(true);
  const handleCloseModal = () => setShowModal(false);

  useEffect(() => {
    const token = localStorage.getItem('token');

    if (!token) {
      setError('User not authenticated');
      setLoading(false);
      return;
    }

    axios
      .get(`${Local.BASE_URL}${Local.GET_USER}`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((response) => {
        console.log(response.data);  // Log to check the response structure
        setProfile(response.data); // Set the profile data
        setLoading(false); // Stop loading
      })
      .catch((err) => {
        setError('Error fetching profile');
        setLoading(false);
      });
  }, []);

  // Show loading spinner or message while the data is being fetched
  if (loading) return <div>Loading...</div>;

  // Show error message if the data fetch fails
  if (error) return <div>{error}</div>;

  if (!profile) return null;

  const { user, message, referredPatients, referredDoctors, patientCount, additionalData } = profile;

  return (
    <div className="profile-container">
      <h2 className="profile-title">Profile</h2>

      <h3>
        {user.firstname} {user.lastname}
      </h3>
      <p>Email: {user.email}</p>

      {/* Conditional rendering for address */}
      <p>
        Address: 
        {user.address ? `${user.address.street}, ${user.address.city}, ${user.address.state} ${user.address.pincode}` : "No address available"}
      </p>

      <p>Type: {user.doctype === 1 ? 'Doctor' : user.doctype === 2 ? 'OD' : 'MD'}</p>

      {user.doctype === 1 && referredPatients && (
        <div>
          <h4>Referred Patients:</h4>
          <ul>
            {referredPatients.map((patient) => (
              <li key={patient.uuid}>
                {patient.firstname} {patient.lastname}
              </li>
            ))}
          </ul>
        </div>
      )}

      {user.doctype === 2 && referredDoctors && (
        <div>
          <h4>Referred Doctors:</h4>
          <ul>
            {referredDoctors.map((doctor) => (
              <li key={doctor.uuid}>
                {doctor.firstname} {doctor.lastname}
              </li>
            ))}
          </ul>
        </div>
      )}

      {/* Display the total number of referred patients for doctors */}
      {user.doctype === 1 && patientCount !== undefined && (
        <div>
          <h4>Total Patients Referred: {patientCount}</h4>
        </div>
      )}

      {/* Admin-specific info */}
      {user.doctype === 3 && additionalData && (
        <div>
          <h4>Admin Data:</h4>
          <p>{additionalData}</p>
        </div>
      )}

      {/* Modal to add a new address */}
      <button onClick={handleOpenModal} className="btn btn-primary mb-4">
        Add Address
      </button>

      <Modal show={showModal} onHide={handleCloseModal} centered>
        <Modal.Header closeButton>
          <Modal.Title>Add New Address</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <AddAddress />
        </Modal.Body>
      </Modal>
    </div>
  );
};

export default Profile;
