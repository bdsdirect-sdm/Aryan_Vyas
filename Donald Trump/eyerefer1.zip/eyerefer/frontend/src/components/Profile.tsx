/* eslint-disable @typescript-eslint/no-unused-vars */
import React, { useState, useEffect } from 'react';
import axios from 'axios';
import { Modal, Form, Button } from 'react-bootstrap';
import AddAddress from './AddAddress';
import { Local } from '../environment/env';
import './Profile.css';

interface Address {
  street: string;
  city: string;
  state: string;
  pincode: string;
  phone: string;
}

interface User {
  uuid: string;
  firstname: string;
  lastname: string;
  email: string;
  phone: string;
  doctype: number;
  Addresses?: Array<Address>;
}

interface ProfileData {
  user: User;
  message: string;
  patientCount?: number;
  referredPatients?: Array<any>;
  referredDoctors?: Array<any>;
  additionalData?: string;
}

const Profile: React.FC = () => {
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [showEditModal, setShowEditModal] = useState(false);
  const [showAddAddressModal, setShowAddAddressModal] = useState(false);
  const [showAddressEditModal, setShowAddressEditModal] = useState(false);
  const [selectedAddress, setSelectedAddress] = useState<Address | null>(null);
  const [formData, setFormData] = useState<User | null>(null);

  const handleOpenEditModal = () => {
    if (profile) {
      setFormData({ ...profile.user });
    }
    setShowEditModal(true);
  };

  const handleCloseEditModal = () => setShowEditModal(false);

  const handleOpenAddAddressModal = () => setShowAddAddressModal(true);
  const handleCloseAddAddressModal = () => setShowAddAddressModal(false);

  useEffect(() => {
    const token = localStorage.getItem('token');

    if (!token) {
      setError('User not authenticated');
      setLoading(false);
      return;
    }

    axios.get(`${Local.BASE_URL}${Local.GET_USER}`, {
        headers: { Authorization: `Bearer ${token}` },
      })
      .then((response) => {
        setProfile(response.data);
        setLoading(false);
      })
      .catch((err) => {
        setError('Error fetching profile');
        setLoading(false);
      });
  }, []);

  const handleProfileSubmit = () => {
    const token = localStorage.getItem('token');
    if (!token || !formData) return;

    axios
      .post(
        `${Local.BASE_URL}${Local.UPDATE_USER}`,
        formData,
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      )
      .then((response) => {
        setProfile((prev) => ({
          ...prev!,
          user: formData,
        }));
        setShowEditModal(false);
        alert('Profile updated successfully');
      })
      .catch((err) => {
        console.error(err);
        alert('Error updating profile');
      });
  };

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (formData) {
      const { name, value } = e.target;
      setFormData({ ...formData, [name]: value });
    }
  };

  const handleOpenAddressEditModal = (address: Address) => {
    setSelectedAddress(address);
    setShowAddressEditModal(true);
  };

  const handleCloseAddressEditModal = () => {
    setSelectedAddress(null);
    setShowAddressEditModal(false);
  };

  const handleAddressSubmit = () => {
    const token = localStorage.getItem('token');
    if (!token || !selectedAddress) return;

    axios
      .post(
        `${Local.BASE_URL}${Local.UPDATE_USER}`,
        { Addresses: profile?.user.Addresses?.map((addr) => (addr.street === selectedAddress.street ? selectedAddress : addr)) },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      )
      .then((response) => {
        setProfile((prev) => ({
          ...prev!,
          user: { ...prev.user, Addresses: prev.user.Addresses.map((addr) => (addr.street === selectedAddress.street ? selectedAddress : addr)) },
        }));
        setShowAddressEditModal(false);
        alert('Address updated successfully');
      })
      .catch((err) => {
        console.error(err);
        alert('Error updating address');
      });
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div>{error}</div>;
  if (!profile) return null;

  const { user, message, referredPatients, referredDoctors, patientCount, additionalData } = profile;

  return (
    <div className="profile-container">
      <h3>
        {user.firstname} {user.lastname}
      </h3>
      <p>Email: {user.email}</p>
      <p>Phone: {user.phone}</p> {/* Display Phone Number */}
      
      <p>
        Address: 
        {
          user.Addresses?.map((add, index) => (
            <div key={index}>
              {`${index + 1}. ${add.street}, ${add.city}, ${add.state}, ${add.pincode}`}
              <img
                src="update.png"
                alt="Update Address"
                className='googleIcon-3'
                onClick={() => handleOpenAddressEditModal(add)} // Open modal on click
              />
              <img src="delete.png" alt="Delete Address" className='googleIcon-3' />
            </div>
          ))
        }
      </p>

      <p>Type: {user.doctype === 2 ? 'OD' : 'MD'}</p>

      {user.doctype === 1 && referredPatients && (
        <div>
          <h4>Referred Patients:</h4>
          <ul>
            {referredPatients.map((patient) => (
              <li key={patient.uuid}>
                {patient.firstname} {patient.lastname}
              </li>
            ))}
          </ul>
        </div>
      )}

      {user.doctype === 2 && referredDoctors && (
        <div>
          <h4>Referred Doctors:</h4>
          <ul>
            {referredDoctors.map((doctor) => (
              <li key={doctor.uuid}>
                {doctor.firstname} {doctor.lastname}
              </li>
            ))}
          </ul>
        </div>
      )}

      {user.doctype === 1 && patientCount !== undefined && (
        <div>
          <h4>Total Patients Referred: {patientCount}</h4>
        </div>
      )}

      {user.doctype === 3 && additionalData && (
        <div>
          <h4>Admin Data:</h4>
          <p>{additionalData}</p>
        </div>
      )}

 
      <button onClick={handleOpenEditModal} className="btn btn-primary mb-4">
        Edit Profile
      </button>

   
      <button onClick={handleOpenAddAddressModal} className="btn btn-secondary mb-4">
        Add Address
      </button>

     
      <Modal show={showEditModal} onHide={handleCloseEditModal} centered>
        <Modal.Header closeButton>
          <Modal.Title>Edit Profile</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {formData && (
            <Form>
              <Form.Group controlId="firstname">
                <Form.Label>First Name</Form.Label>
                <Form.Control
                  type="text"
                  name="firstname"
                  value={formData.firstname}
                  onChange={handleInputChange}
                />
              </Form.Group>

              <Form.Group controlId="lastname">
                <Form.Label>Last Name</Form.Label>
                <Form.Control
                  type="text"
                  name="lastname"
                  value={formData.lastname}
                  onChange={handleInputChange}
                />
              </Form.Group>

              <Form.Group controlId="email">
                <Form.Label>Email</Form.Label>
                <Form.Control
                  type="email"
                  name="email"
                  disabled
                  value={formData.email}
                  onChange={handleInputChange}
                />
              </Form.Group>

              <Form.Group controlId="phone">
                <Form.Label>Phone</Form.Label>
                <Form.Control
                  type="text"
                  name="phone"
                  value={formData.phone}
                  onChange={handleInputChange}
                />
              </Form.Group>
            </Form>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseEditModal}>
            Close
          </Button>
          <Button variant="primary" onClick={handleProfileSubmit}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>

    
      <Modal show={showAddAddressModal} onHide={handleCloseAddAddressModal} centered>
        <Modal.Header closeButton>
          <Modal.Title>Add New Address</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          <AddAddress close={handleCloseAddAddressModal} />
        </Modal.Body>
      </Modal>


   
      <Modal show={showAddressEditModal} onHide={handleCloseAddressEditModal} centered>
        <Modal.Header closeButton>
          <Modal.Title>Edit Address</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {selectedAddress && (
            <Form>
              <Form.Group controlId="street">
                <Form.Label>Street</Form.Label>
                <Form.Control
                  type="text"
                  name="street"
                  value={selectedAddress.street}
                  onChange={(e) => setSelectedAddress({ ...selectedAddress, street: e.target.value })}
                />
              </Form.Group>

              <Form.Group controlId="city">
                <Form.Label>City</Form.Label>
                <Form.Control
                  type="text"
                  name="city"
                  value={selectedAddress.city}
                  onChange={(e) => setSelectedAddress({ ...selectedAddress, city: e.target.value })}
                />
              </Form.Group>

              <Form.Group controlId="state">
                <Form.Label>State</Form.Label>
                <Form.Control
                  type="text"
                  name="state"
                  value={selectedAddress.state}
                  onChange={(e) => setSelectedAddress({ ...selectedAddress, state: e.target.value })}
                />
              </Form.Group>

              <Form.Group controlId="pincode">
                <Form.Label>Pincode</Form.Label>
                <Form.Control
                  type="text"
                  name="pincode"
                  value={selectedAddress.pincode}
                  onChange={(e) => setSelectedAddress({ ...selectedAddress, pincode: e.target.value })}
                />
              </Form.Group>
            </Form>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={handleCloseAddressEditModal}>
            Close
          </Button>
          <Button variant="primary" onClick={handleAddressSubmit}>
            Save Changes
          </Button>
        </Modal.Footer>
      </Modal>
    </div>
  );
};

export default Profile;
