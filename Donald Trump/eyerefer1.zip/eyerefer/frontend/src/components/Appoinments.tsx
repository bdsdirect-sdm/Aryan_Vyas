import React from 'react'

const Appoinments: React.FC = () => {
  return (
    <div>Appoinments</div>
  )
}

export default Appoinments