import { Request, Response } from 'express';
import { classifyPractice } from '../openai/practiceClassifier';
import { StatusCodes } from "../utils/statusCodes";
import SalesClosureReport from '../models/salesClouserReport';
import { Parser } from 'json2csv';

export const downloadCsvController = async (req: Request, res: Response): Promise<void> => {
  try {
    const { jobPost, reportType } = req.body;

    if (!jobPost || typeof jobPost !== 'string') {
      res.status(StatusCodes.BAD_REQUEST).json({
        status: "BAD_REQUEST",
        message: "Missing or invalid required field: jobPost",
      });
      return; 
    }

    const result = await classifyPractice(jobPost);
    const { practice_id: practiceId } = JSON.parse(result);

    if (!practiceId) {
      res.status(StatusCodes.NOT_FOUND).json({
        status: "NOT_FOUND",
        message: "Practice ID could not be determined from jobPost.",
      });
      return;
    }

    const whereCondition: Record<string, any> = { practice_id: practiceId };
    if (reportType) {
      whereCondition.report_type = reportType;
    }
    const matchingReports = await SalesClosureReport.findAll({
      where: whereCondition,
      order: [['addedDate', 'DESC']],
      limit: 20,
    });

    if (!matchingReports.length) {
      res.status(StatusCodes.NOT_FOUND).json({
        status: "NOT_FOUND",
        message: "No matching reports found.",
      });
      return;
    }

    const formattedReports = matchingReports.map(report => {
      const reportData = report.toJSON();
      return {
        ...reportData,
        date: new Date(reportData.date).toLocaleDateString(),
        approval_date: reportData.approval_date ? new Date(reportData.approval_date).toLocaleDateString() : 'Not Approved',
        addedDate: new Date(reportData.addedDate).toLocaleDateString(),
      };
    });

    const parser = new Parser();
    const csv = parser.parse(formattedReports);

    res.header('Content-Type', 'application/vnd.ms-excel');
    res.attachment('matching_reports.xlsx');
    res.send(csv);
    return;
  } catch (error) {
    console.error("Error in downloadCsvController:", error);
    res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
      status: "INTERNAL_SERVER_ERROR",
      message: "Failed to download CSV.",
    });
    return;
  }
};
