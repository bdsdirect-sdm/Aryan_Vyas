import { Request, Response } from 'express';
import { classifyPractice } from '../openai/practiceClassifier';
import { StatusCodes } from "../utils/statusCodes";
import SalesClosureReport from '../models/salesClouserReport';
import { Parser } from 'json2csv';

// export const classifyPracticeController = async (req: Request, res: Response): Promise<void> => {
//   try {
//     console.log("Incoming classifyPractice request body:", req.body);
//     const { jobPost, reportType } = req.body;

//     if (!jobPost) {
//       res.status(StatusCodes.BAD_REQUEST).json({
//         status: "BAD_REQUEST",
//         message: "Missing required field: jobPost",
//       });
//       return;
//     }

//     const result = await classifyPractice(jobPost);
//     const parsedResult = JSON.parse(result);
//     const practiceId = parsedResult.practice_id;

//     const whereCondition: any = { practice_id: practiceId };
//     if (reportType) whereCondition.report_type = reportType;

//     const matchingReports = await SalesClosureReport.findAll({
//       where: whereCondition,
//       order: [['addedDate', 'DESC']],
//       limit: 20,
//     });

//     res.status(StatusCodes.OK).json({
//       status: "SUCCESS",
//       data: {
//         ...parsedResult,
//         matchingReports,
//       },
//     });
//     return;
//   } catch (error) {
//     console.error("Error in classifyPracticeController:", error);
//     res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
//       status: "INTERNAL_SERVER_ERROR",
//       message: "An error occurred while classifying the job post.",
//     });
//     return;
//   }
// };


////////////////////////////////////////////////////////////////////

// export const classifyPracticeController = async (req: Request, res: Response): Promise<void> => {
//   try {
//     console.log("Incoming classifyPractice request body:", req.body);
//     const { jobPost, reportType } = req.body;
//     const wantsCSV = req.query.download === 'true';

//     if (!jobPost) {
//       res.status(StatusCodes.BAD_REQUEST).json({
//         status: "BAD_REQUEST",
//         message: "Missing required field: jobPost",
//       });
//       return;
//     }

//     const result = await classifyPractice(jobPost);
//     const parsedResult = JSON.parse(result);
//     const practiceId = parsedResult.practice_id;

//     const whereCondition: any = { practice_id: practiceId };
//     if (reportType) whereCondition.report_type = reportType;

//     const matchingReports = await SalesClosureReport.findAll({
//       where: whereCondition,
//       order: [['addedDate', 'DESC']],
//       limit: 20,
//     });

//     if (wantsCSV) {
//       const parser = new Parser();
//       const csv = parser.parse(matchingReports.map(r => r.toJSON()));
//       res.header('Content-Type', 'text/csv');
//       res.attachment('matching_reports.csv');
//       res.send(csv);
//       return;
//     }

//     res.status(StatusCodes.OK).json({
//       status: "SUCCESS",
//       data: {
//         ...parsedResult,
//         matchingReports,
//       },
//     });
//     return;
//   } catch (error) {
//     console.error("Error in classifyPracticeController:", error);
//     res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
//       status: "INTERNAL_SERVER_ERROR",
//       message: "An error occurred while classifying the job post.",
//     });
//     return;
//   }
// };


export const classifyPracticeController = async (req: Request, res: Response): Promise<void> => {
  try {
    console.log("Incoming classifyPractice request body:", req.body);
    const { jobPost } = req.body;
    const wantsCSV = req.query.download === 'true';

    if (!jobPost) {
      res.status(StatusCodes.BAD_REQUEST).json({
        status: "BAD_REQUEST",
        message: "Missing required field: jobPost",
      });
      return;
    }

    const result = await classifyPractice(jobPost);
    const parsedResult = JSON.parse(result);
    const practiceId = parsedResult.practice_id;

    const whereCondition: any = {
      practice_id: practiceId,
      report_type: 'closure'
    };

    const matchingReports = await SalesClosureReport.findAll({
      where: whereCondition,
      order: [['addedDate', 'DESC']],
      limit: 20,
    });

    if (wantsCSV) {
      const parser = new Parser();
      const csv = parser.parse(matchingReports.map(r => r.toJSON()));
      res.header('Content-Type', 'text/csv');
      res.attachment('matching_reports.csv');
      res.send(csv);
      return;
    }

    res.status(StatusCodes.OK).json({
      status: "SUCCESS",
      data: {
        ...parsedResult,
        matchingReports,
      },
    });
    return;
  } catch (error) {
    console.error("Error in classifyPracticeController:", error);
    res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
      status: "INTERNAL_SERVER_ERROR",
      message: "An error occurred while classifying the job post.",
    });
    return;
  }
};

