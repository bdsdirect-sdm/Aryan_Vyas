// validations/handleValidationMessages.ts
import Joi from "joi";

export function handleValidationMessages(error: Joi.ValidationError) {
  return {
    status: 'error',
    message: error.details.map((err) => err.message).join(", "),
  };
}
