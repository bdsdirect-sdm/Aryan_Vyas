import Joi from 'joi';

export const adminRegisterValidation = Joi.object({
  adminFirstName: Joi.string().min(2).max(30).required()
    .messages({ "any.required": "First Name is required" }),
  adminLastName: Joi.string().min(2).max(30).required()
    .messages({ "any.required": "Last Name is required" }),
  adminEmail: Joi.string().email().required()
    .messages({ "string.email": "Please enter a valid email" }),
  adminPassword: Joi.string()
    .pattern(new RegExp('^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$'))
    .required()
    .messages({
      'string.pattern.base': 'Password must contain at least 8 characters, one uppercase letter, one lowercase letter, one number, and one special character.',
      "any.required": "Password is required"
    }),
});

    export const adminLoginValidation = Joi.object({
      adminEmail: Joi.string().email().required(),
      adminPassword: Joi.string()
        .pattern(new RegExp('^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d)(?=.*[@$!%*?&])[A-Za-z\\d@$!%*?&]{8,}$'))
        .required()
        .messages({
          'string.pattern.base': 'Password must contain at least 8 characters, one uppercase letter, one lowercase letter, one number, and one special character.',
        }),
    });