import express from 'express';
import { downloadCsvController } from '../controllers/csvDownloadController';

const csvRouter = express.Router();
csvRouter.post('/classify/download', downloadCsvController);

export default csvRouter;