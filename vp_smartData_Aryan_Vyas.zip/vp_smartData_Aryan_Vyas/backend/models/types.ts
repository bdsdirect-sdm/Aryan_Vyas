import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database';

export class Types extends Model{
  TypeId!: number;
  TypeName!: string;
  TypeCode!: string;
}
Types.init({
    TypeId: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    TypeName: {
      type: DataTypes.STRING(20),
      allowNull: false
    },
    TypeCode: {
      type: DataTypes.STRING(10),
      allowNull: false
    }
  }, {
    sequelize,
    tableName: 'Types',
    timestamps: false
  });

  export default Types;