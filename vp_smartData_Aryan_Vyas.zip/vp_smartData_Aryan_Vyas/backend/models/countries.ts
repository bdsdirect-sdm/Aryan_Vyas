import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database';

class Countries extends Model {
  id!: number;
  name!: string;
  code2?: string;
  code3?: string;
}
 Countries.init({
    id: {
      type: DataTypes.SMALLINT.UNSIGNED,
      allowNull: false,
      primaryKey: true,
      comment: "country id"
    },
    name: {
      type: DataTypes.CHAR(40),
      allowNull: false,
      comment: "country name"
    },
    code2: {
      type: DataTypes.CHAR(2),
      allowNull: true,
      comment: "2 char country code"
    },
    code3: {
      type: DataTypes.CHAR(3),
      allowNull: true,
      comment: "3 char country codes"
    }
  }, {
    sequelize,
    tableName: 'countries',
    timestamps: false
  });
export default Countries;
