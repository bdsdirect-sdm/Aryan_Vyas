import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database';

export class Psm extends Model{
  id!: number;
  name!: string;
  practice_id!: number;
  active!: number;
}
 Psm.init({
    id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    name: {
      type: DataTypes.STRING(200),
      allowNull: false
    },
    practice_id: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    active: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 1
    }
  }, {
    sequelize,
    tableName: 'psm',
    timestamps: false
  });

  export default Psm;
