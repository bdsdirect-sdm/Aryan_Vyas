import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database';

class DirectTypes extends Model {
  id!: number;
  name!: string;
  status!: number;
}
 DirectTypes.init({
    id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    name: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    status: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 1
    }
  }, {
    sequelize,
    tableName: 'DirectTypes',
    timestamps: false
  });
export default DirectTypes;
