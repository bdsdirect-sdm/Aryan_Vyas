import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database';

export class Territory extends Model{
  id!: number;
  name!: string;
  new_type!: number;
}
Territory.init({
    id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    name: {
      type: DataTypes.STRING(100),
      allowNull: false
    },
    new_type: {
      type: DataTypes.INTEGER,
      allowNull: false
    }
  }, {
    sequelize,
    tableName: 'Territory',
    timestamps: false
  });

  export default Territory;
