import type { Sequelize } from "sequelize";
import { BusiUnit as _BusiUnit } from "./busiUnit";
import type { BusiUnitAttributes, BusiUnitCreationAttributes } from "./busiUnit";
import { Channels as _Channels } from "./channels";
import type { ChannelsAttributes, ChannelsCreationAttributes } from "./channels";
import { DirectTypes as _DirectTypes } from "./directTypes";
import type { DirectTypesAttributes, DirectTypesCreationAttributes } from "./directTypes";
import { Domains as _Domains } from "./domains";
import type { DomainsAttributes, DomainsCreationAttributes } from "./domains";
import { FollowUpComments as _FollowUpComments } from "./followUpComments";
import type { FollowUpCommentsAttributes, FollowUpCommentsCreationAttributes } from "./followUpComments";
import { Pratice as _Pratice } from "./pratice";
import type { PraticeAttributes, PraticeCreationAttributes } from "./pratice";
import { ProjectStatus as _ProjectStatus } from "./projectStatus";
import type { ProjectStatusAttributes, ProjectStatusCreationAttributes } from "./projectStatus";
import { SalesClouserReport as _SalesClouserReport } from "./salesClouserReport";
import type { SalesClouserReportAttributes, SalesClouserReportCreationAttributes } from "./salesClouserReport";
import { States as _States } from "./states";
import type { StatesAttributes, StatesCreationAttributes } from "./states";
import { Territory as _Territory } from "./territory";
import type { TerritoryAttributes, TerritoryCreationAttributes } from "./territory";
import { Types as _Types } from "./types";
import type { TypesAttributes, TypesCreationAttributes } from "./types";
import { Client as _Client } from "./client";
import type { ClientAttributes, ClientCreationAttributes } from "./client";
import { Countries as _Countries } from "./countries";
import type { CountriesAttributes, CountriesCreationAttributes } from "./countries";
import { LeadStatus as _LeadStatus } from "./leadStatus";
import type { LeadStatusAttributes, LeadStatusCreationAttributes } from "./leadStatus";
import { LeadType as _LeadType } from "./leadType";
import type { LeadTypeAttributes, LeadTypeCreationAttributes } from "./leadType";
import { ProjectGroup as _ProjectGroup } from "./projectGroup";
import type { ProjectGroupAttributes, ProjectGroupCreationAttributes } from "./projectGroup";
import { Psm as _Psm } from "./psm";
import type { PsmAttributes, PsmCreationAttributes } from "./psm";
import { States as _States } from "./states";
import type { StatesAttributes, StatesCreationAttributes } from "./states";

export {
  _BusiUnit as BusiUnit,
  _Channels as Channels,
  _DirectTypes as DirectTypes,
  _Domains as Domains,
  _FollowUpComments as FollowUpComments,
  _Pratice as Pratice,
  _ProjectStatus as ProjectStatus,
  _SalesClouserReport as SalesClouserReport,
  _States as States,
  _Territory as Territory,
  _Types as Types,
  _Client as Client,
  _Countries as Countries,
  _LeadStatus as LeadStatus,
  _LeadType as LeadType,
  _ProjectGroup as ProjectGroup,
  _Psm as Psm,
  _States as States,
};

export type {
  BusiUnitAttributes,
  BusiUnitCreationAttributes,
  ChannelsAttributes,
  ChannelsCreationAttributes,
  DirectTypesAttributes,
  DirectTypesCreationAttributes,
  DomainsAttributes,
  DomainsCreationAttributes,
  FollowUpCommentsAttributes,
  FollowUpCommentsCreationAttributes,
  PraticeAttributes,
  PraticeCreationAttributes,
  ProjectStatusAttributes,
  ProjectStatusCreationAttributes,
  SalesClouserReportAttributes,
  SalesClouserReportCreationAttributes,
  StatesAttributes,
  StatesCreationAttributes,
  TerritoryAttributes,
  TerritoryCreationAttributes,
  TypesAttributes,
  TypesCreationAttributes,
  ClientAttributes,
  ClientCreationAttributes,
  CountriesAttributes,
  CountriesCreationAttributes,
  LeadStatusAttributes,
  LeadStatusCreationAttributes,
  LeadTypeAttributes,
  LeadTypeCreationAttributes,
  ProjectGroupAttributes,
  ProjectGroupCreationAttributes,
  PsmAttributes,
  PsmCreationAttributes,
  StatesAttributes,
  StatesCreationAttributes,
};

export function initModels(sequelize: Sequelize) {
  const BusiUnit = _BusiUnit.initModel(sequelize);
  const Channels = _Channels.initModel(sequelize);
  const DirectTypes = _DirectTypes.initModel(sequelize);
  const Domains = _Domains.initModel(sequelize);
  const FollowUpComments = _FollowUpComments.initModel(sequelize);
  const Pratice = _Pratice.initModel(sequelize);
  const ProjectStatus = _ProjectStatus.initModel(sequelize);
  const SalesClouserReport = _SalesClouserReport.initModel(sequelize);
  const States = _States.initModel(sequelize);
  const Territory = _Territory.initModel(sequelize);
  const Types = _Types.initModel(sequelize);
  const Client = _Client.initModel(sequelize);
  const Countries = _Countries.initModel(sequelize);
  const LeadStatus = _LeadStatus.initModel(sequelize);
  const LeadType = _LeadType.initModel(sequelize);
  const ProjectGroup = _ProjectGroup.initModel(sequelize);
  const Psm = _Psm.initModel(sequelize);
  const States = _States.initModel(sequelize);


  return {
    BusiUnit: BusiUnit,
    Channels: Channels,
    DirectTypes: DirectTypes,
    Domains: Domains,
    FollowUpComments: FollowUpComments,
    Pratice: Pratice,
    ProjectStatus: ProjectStatus,
    SalesClouserReport: SalesClouserReport,
    States: States,
    Territory: Territory,
    Types: Types,
    Client: Client,
    Countries: Countries,
    LeadStatus: LeadStatus,
    LeadType: LeadType,
    ProjectGroup: ProjectGroup,
    Psm: Psm,
    States: States,
  };
}
