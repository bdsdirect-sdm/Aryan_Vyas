import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database';

class Users extends Model {
    public id!: string;
    public firstName!: string;
    public lastName!: string;
    public email!: string;
    public password!: string;
    public userType!: 'retailer' | 'customer';
    public failedLoginAttempts!: number;
    public passwordLock!: boolean;
    public lockedUntil!: Date | null;
}

Users.init(
    {
        id: {
            type: DataTypes.UUID,
            defaultValue: DataTypes.UUIDV4,
            primaryKey: true,
        },
        firstName: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        lastName: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        email: {
            type: DataTypes.STRING,
            unique: true,
            allowNull: false,
        },
        password: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        userType: {
            type: DataTypes.ENUM('retailer', 'customer'),
            allowNull: false,
            },
        failedLoginAttempts: {
            type: DataTypes.INTEGER,
            defaultValue: 0,
        },
        passwordLock: {
            type: DataTypes.BOOLEAN,
            defaultValue: false,
        },
        lockedUntil: {
            type: DataTypes.DATE,
            defaultValue: null,
        },
    },
    {
        sequelize,
        modelName: 'users',
        // paranoid:true,
    }
);
console.log("Table Name>>>>>>>",Users.getTableName());
export default Users;
