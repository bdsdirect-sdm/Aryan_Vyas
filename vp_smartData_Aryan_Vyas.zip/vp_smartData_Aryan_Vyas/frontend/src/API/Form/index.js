import axios from 'axios';
import envConfig from '../../enviroment';

export const createForm = (formData) => {
  return axios.post(`${envConfig.apiUrl}/auth/classify-practice`, formData)
    .then(response => response.data)
    .catch(error => {
      // console.error("Error creating form:", error);
      throw error;
    });
};

