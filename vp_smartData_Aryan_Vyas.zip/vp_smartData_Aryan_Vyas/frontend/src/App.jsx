import React from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import Form from './pages/form/Form';
import LeadFetched from './pages/LeadsFetched/LeadFetched';



const App = () => {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Form />} />
        <Route path="/lead-fetched" element={<LeadFetched />} />
      </Routes>
    </Router>
  );
};

export default App;
