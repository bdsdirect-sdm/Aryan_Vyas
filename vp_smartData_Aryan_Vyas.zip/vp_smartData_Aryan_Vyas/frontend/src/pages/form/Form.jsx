import React from 'react';
import './Form.css';
import { createForm } from '../../API/Form/index';
import { useNavigate } from 'react-router-dom';
import { Formik, Form, Field, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';

const validationSchema = Yup.object({
  jobPost: Yup.string().required('Job Post Description is required'),
  portalUrl: Yup.string().url('Invalid URL'),
});

const FormComponent = () => {
  const navigate = useNavigate();

  const initialValues = {
    jobPost: '',
    portalUrl: '',
  };

  const handleSubmit = async (values) => {
    try {
      await createForm(values);
      toast.success('Classified successfully!');


      setTimeout(() => {
        navigate('/lead-fetched');
      }, 3000);
    } catch (error) {
      toast.error('Error classifying job post');
      console.error('Classification error:', error);
    }
  };

  return (
    <div className="form-container">
      <h2>Classify Job Post</h2>
      <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={handleSubmit}>
        <Form>
          <div className="form-row">
            <div className="full-width">
              <label htmlFor="portalUrl">Job Post URL (Optional)</label>
              <Field type="url" name="portalUrl" />
              <ErrorMessage name="portalUrl" component="div" className="error" />
            </div>
          </div>

          <div className="form-row">
            <div className="full-width">
              <label htmlFor="jobPost">Job Post Description<span style={{ color: "red" }}>*</span></label>
              <Field as="textarea" name="jobPost" rows="6" />
              <ErrorMessage name="jobPost" component="div" className="error" />
            </div>
          </div>

          <button type="submit">Submit</button>
          <ToastContainer position="top-right" autoClose={2000} />
        </Form>
      </Formik>
    </div>
  );
};

export default FormComponent;
