import React from 'react';
import './LeadFetched.css';
import { useNavigate } from 'react-router-dom';

const LeadFetched = () => {
  const navigate = useNavigate();

  const handleReturnHome = () => {
    navigate('/');
  };

  return (
    <div className="lead-fetched-container">
      <div className="lead-fetched-card">
        <div className="lead-fetched-icon">
          <svg
            width="60"
            height="60"
            viewBox="0 0 24 24"
            fill="none"
            stroke="#4caf50"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <path d="M22 11.08V12a10 10 0 1 1-5.93-9.14"></path>
            <polyline points="22 4 12 14.01 9 11.01"></polyline>
          </svg>
        </div>
        <h2>Lead Fetched Successfully</h2>
        <p className="lead-fetched-message">Your form has been submitted successfully.</p>
        <p>We will get back to you soon.</p>
        <button className="lead-fetched-return-button" onClick={handleReturnHome}>
          Return to Home
        </button>
      </div>
      <p className="lead-fetched-copyright">© 2025 Your Company. All rights reserved.</p>
    </div>
  );
};

export default LeadFetched;
