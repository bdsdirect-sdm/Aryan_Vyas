import express from "express";
import { searchDocs } from "../controllers/searchController.js";

const router = express.Router();

router.post("/search", searchDocs);

export default router;
