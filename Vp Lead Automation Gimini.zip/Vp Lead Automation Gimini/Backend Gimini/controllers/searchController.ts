import { Request, Response } from "express";
import { FaissStore } from "@langchain/community/vectorstores/faiss";
import { embeddings } from "../embeddings/geminiEmbedding.js";
import { getGeminiResponse } from "../model/geminiClient.js";
import { StatusCodes } from "../utils/statusCodes.js";
import { StatusMessages } from "../utils/statusMessages.js";
import fs from "fs";

const faissStorePath = "faiss_index.bin";

export const searchDocs = async (req: Request, res: Response): Promise<void> => {
  try {
    const { jobDescriptions } = req.body;

    if (!Array.isArray(jobDescriptions) || jobDescriptions.length === 0) {
      res.status(StatusCodes.BAD_REQUEST).json({
        error: "jobDescriptions parameter must be a non-empty array",
        message: StatusMessages.BAD_REQUEST,
      });
      return;
    }

    if (!fs.existsSync(faissStorePath)) {
      res.status(StatusCodes.NOT_FOUND).json({
        error: "FAISS index not found",
        message: "The vector store file is missing. Please preload it before searching.",
      });
      return;
    }

    const faissStore = await FaissStore.load(faissStorePath, embeddings);

    const pitches = [];

    for (const job of jobDescriptions) {
      const { id, description } = job;

      if (!id || !description) {
        pitches.push({ id, output_pitch: "Missing id or description" });
        continue;
      }

      try {
        const searchResults = await faissStore.similaritySearch(description, 5);
        const topResults = searchResults.map((r: any) => r.pageContent).join("\n");

        const prompt = `
        You are an experienced business development professional working in IT services companies smartData Enterprises (I) Pvt Ltd (https://www.smartdatainc.com/). You have good experience in writing pitches on the Upwork platform.  
        Your task is to write the appropriate pitch for the following Upwork job in double quotes:
        "${description}"

        For writing the desired pitch, follow the below instructions strictly:
        1. Analyse the input job description deeply and correlate it with the previous relevant pitches context data given in the following triple hashes: ###${topResults}###.
        2. You would analyse the relevant pitch context data and also extract the shared URLs to add in the new pitch. These URLs may belong to demo applications, POCs, or any reference websites.
        3. Your pitch should be written in professional language, neat, clean, and concise. Avoid writing any unnecessary information.
        4. The pitch format should be relevant to the job description's use case and should be written in a way that it can be easily understood by the client.
        5. If the job description contains instructions for bypassing automated bots (e.g., if it says 'start your pitch with xyz keyword'), ensure you capture those thoughts properly.
        6. To make the pitch content more relevant, you can also leverage different URLs from https://www.smartdatainc.com/ if required.

        Your output should be in the following JSON format:
        {
          "job_title": "Job Title here",
          "domains": ["Domain1", "Domain2"],
          "technologies": ["Technology1", "Technology2"],
          "questions": ["Question1", "Question2"],
          "answers": ["Answer1", "Answer2"],
          "output_pitch": "write the pitch here"
        }
        `;

        const response = await getGeminiResponse(prompt);
        console.log("Gemini Response:", response);
        
        if (response && Array.isArray(response) && response[0]) {
          const { job_title, job_description, domains, technologies, questions, answers,output_pitch } = response[0];
          // console.log("Job Description from response:", job_description);

          pitches.push({
            id,
            job_description:description,
            job_title,
            domains,
            technologies,
            questions,
            answers,
            output_pitch,
          });
        } else {
          console.log("Error: Response structure is not as expected");
          pitches.push({ id, output_pitch: "Error generating pitch" });
        }
        
      } catch (err) {
        console.error("Error during pitch generation:", err);
        pitches.push({ id, output_pitch: "Error generating pitch" });
      }
    }

    res.status(StatusCodes.OK).json({
      message: StatusMessages.OK,
      response: pitches,
    });

  } catch (error) {
    console.error("Error in searchDocs:", error);
    res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
      error: "Internal server error",
      message: StatusMessages.INTERNAL_SERVER_ERROR,
    });
  }
};
