import { PDFLoader } from "@langchain/community/document_loaders/fs/pdf";
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const loadPdfDocs = async (filePath: string) => {
  const loader = new PDFLoader(filePath);
  const docs = await loader.load();
  return docs;
};

const run = async () => {
  const filePath = path.resolve(__dirname, '../data', 'sample.pdf');
  const rawDocs = await loadPdfDocs(filePath);
  // console.log("Loaded Docs:", rawDocs);
};

run();