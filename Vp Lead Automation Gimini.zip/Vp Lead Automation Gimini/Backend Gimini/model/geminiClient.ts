import axios from 'axios';

const GEMINI_API_KEY = process.env.GEMINI_API_KEY;
const GEMINI_API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`;

export const getGeminiResponse = async (prompt: string) => {
  try {
    const response = await axios.post(
      GEMINI_API_URL,
      {
        contents: [
          {
            parts: [{ text: prompt }]
          }
        ],
        generationConfig: {
          responseMimeType: 'application/json',
          responseSchema: {
            type: 'ARRAY',
            items: {
              type: 'OBJECT',
              properties: {
                job_description:{type: 'STRING'},
                job_title: { type: 'STRING' },
                domains: { type: 'ARRAY', items: { type: 'STRING' } },
                technologies: { type: 'ARRAY', items: { type: 'STRING' } },
                questions: { type: 'ARRAY', items: { type: 'STRING' } },
                answers: { type: 'ARRAY', items: { type: 'STRING' } },
                output_pitch: { type: 'STRING' }
              },
              propertyOrdering: ['job_description','job_title', 'domains', 'technologies', 'questions', 'answers','output_pitch']
            }
          }
        }
      },
      {
        headers: {
          'Content-Type': 'application/json'
        }
      }
    );

    // console.log("Gemini API response:", response.data);

    const resultText = response.data?.candidates?.[0]?.content?.parts?.[0]?.text;

    if (!resultText) {
      console.log("No valid result found in Gemini API response.");
      return "";
    }

    let parsedResult;
    try {
      parsedResult = JSON.parse(resultText);
      // console.log("Parsed Gemini Response:", parsedResult);
    } catch (e) {
      console.error("Error parsing Gemini response:", e);
      return "";
    }

    return parsedResult;
  } catch (err) {
    console.error("Error in getGeminiResponse:", err);
    return "";
  }
};





