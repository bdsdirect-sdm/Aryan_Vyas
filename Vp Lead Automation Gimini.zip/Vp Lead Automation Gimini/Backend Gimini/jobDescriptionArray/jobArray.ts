export const upworkJobDescriptions = [
   {
  "jobDescriptions": [
    {
      "id": "job-001",
      "jobDescription": "Looking for a developer with experience in the healthcare domain to integrate Electronic Medical Records (EMR) systems using .NET Core and HL7/FHIR standards. The solution should securely sync patient data with our internal dashboards and support HIPAA compliance."
    },
    {
      "id": "job-002",
      "jobDescription": "Seeking a frontend developer to build a responsive healthcare appointment booking platform using React and Next.js. Must have experience with component-based architecture, authentication flows, and integrating REST APIs from hospital management systems."
    },
    {
      "id": "job-003",
      "jobDescription": "Need a full stack PHP developer with expertise in Laravel to build a secure portal for clinics. Features include patient registration, document uploads, medical history tracking, and admin reporting. Experience with Vue.js is a plus."
    },
    {
      "id": "job-004",
      "jobDescription": "Looking for a JavaScript developer to work on an interactive patient dashboard for a telehealth platform. Should be skilled in vanilla JS and frameworks like React or Vue. Experience with charts, real-time updates, and accessibility is preferred."
    },
    {
      "id": "job-005",
      "jobDescription": "Seeking a developer to build a claims processing interface for a health insurance company using Next.js on the frontend and PHP (Laravel or custom MVC) for the backend. Knowledge of form validation, secure file uploads, and multilingual support is essential."
    }
  ]
}

  ];
  