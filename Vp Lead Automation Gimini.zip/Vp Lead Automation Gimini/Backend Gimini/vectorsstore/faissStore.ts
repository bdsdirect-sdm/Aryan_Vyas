import { FaissStore } from "@langchain/community/vectorstores/faiss";
// import { embeddings } from "../embeddings/openaiEmbedding.js";
import { embeddings } from "../embeddings/geminiEmbedding.js";

export const createFaissStore = async (docs: any[]) => {
  const store = await FaissStore.fromDocuments(docs, embeddings);
  return store;
};
