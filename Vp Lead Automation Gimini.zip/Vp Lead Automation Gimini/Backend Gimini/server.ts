// import fs from "fs";
// import { loadPdfDocs } from "./loaders/pdfLoader.js";
// import { splitDocs } from "./utils/splitters.js";
// import { createFaissStore } from "./vectorsstore/faissStore.js";
// import { FaissStore } from "@langchain/community/vectorstores/faiss";
// import { embeddings } from "./embeddings/geminiEmbedding.js";
// import { getGeminiResponse } from "./model/geminiClient.js";

// const faissStorePath = "faiss_index.bin";

// const run = async () => {
//   try {
//     let faissStore;
//     if (fs.existsSync(faissStorePath)) {
//       faissStore = await FaissStore.load(faissStorePath, embeddings);
//     } else {
//       const rawDocs = await loadPdfDocs("data/sample.pdf");
//       const chunks = await splitDocs(rawDocs);
//       faissStore = await createFaissStore(chunks);
//       await faissStore.save(faissStorePath);
//     }

//     const query = "What is unsupervised learning?";

//     const searchResults = await faissStore.similaritySearch(query, 5);
//     const topResults = searchResults
//       .map(result => result.pageContent)
//       .join("\n");


//     const prompt = `
// Based on the following question:

// "${query}"

// And this context extracted from the PDF:

// ${topResults}

// Please generate a detailed and concise explanation. Format the answer with headings, bullet points, and comparisons if applicable.
//     `.trim();

//     const polishedResponse = await getGeminiResponse(prompt);
//     console.log("Polished Response from Gemini:\n", polishedResponse);

//   } catch (error) {
//     console.error("Error in processing:", error);
//   }
// };

// run();

import express from "express";
import cors from "cors";
import dotenv from "dotenv";
import searchRouter from "./routes/searchRoute.js";

dotenv.config();

const app = express();
const port = process.env.PORT || 3000;

app.use(cors());
app.use(express.json());

app.use("/api/v1", searchRouter);

app.listen(port, () => {
  console.log(`🚀 Server is running on port ${port}`);
});
