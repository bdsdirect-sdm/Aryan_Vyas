export type ApiResponse = {
  message: string;
  response: {
    output_pitch: string;
  }[];
};
