import axios from 'axios';
import type { ApiResponse } from './types';
import envConfig from '../enviroment';

export const searchQuery = async (jobDescription: string): Promise<ApiResponse> => {
  try {
    const res = await axios.post<ApiResponse>(`${envConfig.apiUrl}/search`, { jobDescription });
    return res.data;
  } catch {
    throw new Error('Error fetching data');
  }
};

