import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import GeneratePitch from './components/GeneratePitch';
import FinalPitch from './components/FinalPitch';

function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<GeneratePitch />} />
        <Route path="/final-pitch" element={<FinalPitch />} />
      </Routes>
    </Router>
  );
}

export default App;
