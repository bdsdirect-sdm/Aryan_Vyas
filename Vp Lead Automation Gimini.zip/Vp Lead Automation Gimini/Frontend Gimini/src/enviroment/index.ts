interface Config {
    baseUrl: string;
    apiUrl: string;
    encryptionkey?: string;
    PORT?: string;
  }
  
  const local: Config = {
    baseUrl: 'http://44.211.113.36:4055',
    apiUrl: 'http://44.211.113.36:4055/api/v1',
    PORT: '',
  };
  const staging: Config = {
    baseUrl: 'http://44.211.113.36:4055/',
    apiUrl: 'http://44.211.113.36:4055/api/v1',
    encryptionkey: '',
    PORT: '',
  };
  
  const production: Config = {
    baseUrl: 'http://44.211.113.36:4055/',
    apiUrl: 'http://44.211.113.36:4055/api/v1',
    encryptionkey: '',
    PORT: '80',
  };
  
  let envConfig: Config;
  
  if (process.env.NODE_ENV === 'development') {
    envConfig = local;
  } else if (process.env.NODE_ENV === 'none') {
    envConfig = staging;
  } else if (process.env.NODE_ENV === 'production') {
    envConfig = production;
  } else {
    envConfig = local;
  }
  
  export default envConfig;
  