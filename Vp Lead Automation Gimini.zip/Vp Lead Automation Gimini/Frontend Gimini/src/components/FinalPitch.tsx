import React, { useState, useEffect } from 'react';
import { searchQuery } from '../API/Response';
import { useNavigate } from 'react-router-dom';
import '../css/FinalPitch.css';
import { FiCopy, FiArrowLeft } from 'react-icons/fi';

const FinalPitch: React.FC = () => {
    const [responseData, setResponseData] = useState<string | null>(null);
    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<string>('');
    const navigate = useNavigate();

    useEffect(() => {
        const storedJobDescription = localStorage.getItem('jobDescription');
        if (storedJobDescription) {
            fetchResponse(storedJobDescription);
        }
    }, []);

    const fetchResponse = (jobDescription: string) => {
        setLoading(true);
        setError('');
        setResponseData(null);

        searchQuery(jobDescription)
            .then((data) => {
                const output = data.response[0].output_pitch;
                const formattedOutput = formatLinks(output.replace(/\\n/g, '\n'));
                setResponseData(formattedOutput);
                setLoading(false);
            })
            .catch(() => {
                setError('Error fetching data');
                setLoading(false);
            });
    };

    // const formatLinks = (text: string): string => {
    //     return text
    //         .replace(/\[([^\]]+)\]\((https?:\/\/[^)]+)\)/g, '<a href="$2" target="_blank" style="color: #007BFF;">$1</a>')
    //         .replace(/\n/g, '<br />');
    // };;

    const formatLinks = (text: string): string => {
        const linkified = text
            .replace(/\[([^\]]+)\]\((https?:\/\/[^)]+)\)/g, '<a href="$2" target="_blank" style="color: #007BFF;">$1</a>');

        const lines = linkified.split('\n');

        let inList = false;
        const formatted = lines.map((line) => {
            if (/^\*\s*\*\*(.+?)\*\*:\s*(.*)/.test(line)) {
                const formattedLine = line.replace(/^\*\s*\*\*(.+?)\*\*:\s*(.*)/, '<li><strong>$1:</strong> $2</li>');
                if (!inList) {
                    inList = true;
                    return '<ul>' + formattedLine;
                }
                return formattedLine;
            } else if (/^\*\s*(.+)/.test(line)) {
                const formattedLine = line.replace(/^\*\s*(.+)/, '<li>$1</li>');
                if (!inList) {
                    inList = true;
                    return '<ul>' + formattedLine;
                }
                return formattedLine;
            } else {
                if (inList) {
                    inList = false;
                    return '</ul><br />' + line + '<br />';
                }
                return line.trim() ? `<br />${line}` : '<br />';
            }
        });

        if (inList) {
            formatted.push('</ul>');
        }

        return formatted.join('');
    };

    const handleBackClick = () => {
        navigate('/');
    };

    // const handleDownload = () => {
    //     if (!responseData) return;
    //     const plainText = responseData
    //         .replace(/<br\s*\/?>/gi, '\n')
    //         .replace(/<a [^>]+>([^<]+)<\/a>/gi, '$1');
    //     const blob = new Blob([plainText], { type: 'text/plain;charset=utf-8' });
    //     const link = document.createElement('a');
    //     link.href = URL.createObjectURL(blob);
    //     link.download = 'AI_Generated_Pitch.txt';
    //     link.click();
    // };


    // const handleCopyToClipboard = () => {
    //     if (!responseData) return;

    //     const plainText = responseData
    //         .replace(/<br\s*\/?>/gi, '\n')
    //         .replace(/<a [^>]+>([^<]+)<\/a>/gi, '$1');

    //     navigator.clipboard.writeText(plainText)
    //         .then(() => {
    //             alert('Pitch copied to clipboard!');
    //         })
    //         .catch(() => {
    //             alert('Failed to copy pitch.');
    //         });
    // };

    const handleCopyToClipboard = () => {
        if (!responseData) return;

        const plainText = responseData
            .replace(/<br\s*\/?>/gi, '\n')
            .replace(/<a [^>]+>([^<]+)<\/a>/gi, '$1');

        if (navigator.clipboard?.writeText) {
            // Modern and secure clipboard API
            navigator.clipboard.writeText(plainText)
                .then(() => {
                    alert('Pitch copied to clipboard!');
                })
                .catch(() => {
                    alert('Failed to copy pitch.');
                });
        } else {
            const textarea = document.createElement('textarea');
            textarea.value = plainText;
            textarea.style.position = 'fixed';
            textarea.style.opacity = '0';
            document.body.appendChild(textarea);
            textarea.select();
            try {
                const successful = document.execCommand('copy');
                alert(successful ? 'Pitch copied to clipboard!' : 'Failed to copy pitch.');
            } catch {
                alert('Copy not supported in this browser.');
            }
            document.body.removeChild(textarea);
        }
    };


    return (
        <div className="final-pitch-container">
            <div className="final-pitch-content">
                <h1 style={{ textAlign: "center" }}>AI Generated Pitch</h1>

                {/* <button className="back-button" onClick={handleBackClick}>
                    Back to Home
                </button> */}

                <button className="back-button" onClick={handleBackClick} title="Back to Home" style={{ borderColor: "transparent", cursor: "pointer", backgroundColor: "#f9f9f9" }}>
                    <FiArrowLeft className="icon-button" />
                </button>

                {loading && (
                    <div className="skeleton-container">
                        <div className="skeleton skeleton-title"></div>
                        <div className="skeleton skeleton-line"></div>
                        <div className="skeleton skeleton-line"></div>
                        <div className="skeleton skeleton-line short"></div>
                    </div>
                )}

                {error && <div className="error-message">{error}</div>}

                {responseData && (
                    <>
                        <div
                            className="response-container"
                            dangerouslySetInnerHTML={{ __html: responseData }}
                        />
                        <div style={{ display: 'flex', justifyContent: 'flex-end' }}>
                            {/* <button className="download-button" onClick={handleDownload}>
                                Download Pitch
                            </button> */}
                            {/* <button className="download-button" onClick={handleCopyToClipboard}>
                                Copy Pitch to Clipboard
                            </button> */}
                            <div className="icon-button-wrapper" title="Copy to Clipboard">
                                <FiCopy className="icon-button" onClick={handleCopyToClipboard} />
                            </div>
                        </div>
                    </>
                )}
            </div>
        </div >
    );
};

export default FinalPitch;