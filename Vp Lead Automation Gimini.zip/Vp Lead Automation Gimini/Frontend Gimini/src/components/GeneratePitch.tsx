import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Formik, Form, ErrorMessage } from 'formik';
import * as Yup from 'yup';
import '../css/GeneratePitch.css';

const GeneratePitch: React.FC = () => {
    const [loading, setLoading] = useState<boolean>(false);
    const [error, setError] = useState<string>('');
    const navigate = useNavigate();

    const initialValues = {
        jobDescription: '',
    };

    const validationSchema = Yup.object({
        jobDescription: Yup.string().required('Job description is required'),
    });

    const handleSubmit = (values: typeof initialValues) => {
        setLoading(true);
        setError('');
        localStorage.setItem('jobDescription', values.jobDescription);
        navigate('/final-pitch');
    };

    return (
        <div className="generate-pitch-container">
            <h1 style={{ textAlign: "center" }}>Generate Pitch</h1>
            <Formik
                initialValues={initialValues}
                validationSchema={validationSchema}
                onSubmit={handleSubmit}
            >
                {({ isSubmitting, values, handleChange }) => (
                    <Form className="generate-pitch-form">
                        <div className="form-field-container">
                            <textarea
                                name="jobDescription"
                                value={values.jobDescription}
                                onChange={handleChange}
                                rows={6}
                                placeholder="Enter job description here..."
                                className="generate-pitch-textarea"
                            />
                            <ErrorMessage
                                name="jobDescription"
                                component="div"
                                className="error-message"
                            />
                        </div>
                        <button type="submit" className="generate-pitch-button" disabled={isSubmitting}>
                            {isSubmitting ? 'Generating...' : 'Generate'}
                        </button>
                    </Form>
                )}
            </Formik>
            {loading && <div>Loading...</div>}
            {error && <div className="error-message">{error}</div>}
        </div>
    );
};

export default GeneratePitch;