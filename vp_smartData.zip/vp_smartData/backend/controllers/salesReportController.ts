import { Request, Response } from "express";
import SalesClouserReport from "../models/salesClouserReport";
import { StatusCodes } from "../utils/statusCodes";

export const getLatestReports = async (req: Request, res: Response): Promise<void> => {
  try {
    console.log("Incoming request query params:", req.query);

    const { practice_id, report_type } = req.query;

    if (!practice_id || !report_type) {
      res.status(StatusCodes.BAD_REQUEST).json({
        status: "BAD_REQUEST",
        message: "Missing required query parameters: practice_id and report_type",
      });
      return;
    }

    const parsedPracticeId = parseInt(practice_id as string, 10);

    console.log("Fetching reports for practice_id:", parsedPracticeId, "report_type:", report_type);

    const whereConditions = {
      practice_id: parsedPracticeId,
      report_type: report_type as string,
    };

    const reports = await SalesClouserReport.findAll({
      where: whereConditions,
      order: [["id", "DESC"]],
      limit: 20,
    });

    res.status(StatusCodes.OK).json({
      status: "SUCCESS",
      data: reports,
    });
    return;

  } catch (error) {
    res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
      status: "INTERNAL_SERVER_ERROR",
      message: "An error occurred while fetching the reports.",
    });
    return;
  }
};
