import { Request, Response } from 'express';
import { classifyPractice } from '../openai/practiceClassifier';

export const classifyPracticeController = async (req: Request, res: Response) => {
  try {
    const { jobPost } = req.body;

    if (!jobPost) return res.status(400).json({ error: 'jobPost is required' });

    const result = await classifyPractice(jobPost);
    res.json({ result });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Internal server error' });
  }
};
