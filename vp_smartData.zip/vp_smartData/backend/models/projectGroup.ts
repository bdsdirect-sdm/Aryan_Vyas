import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database';

export class ProjectGroup extends Model{
  id!: number;
  busi_id!: string;
  short_name!: string;
  name!: string;
  status!: number;
  new_status!: '0' | '1';
  new_status21!: '0' | '1';
  report_order!: number;
  factor_multi!: number;
}
ProjectGroup.init({
    id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    busi_id: {
      type: DataTypes.STRING(10),
      allowNull: false
    },
    short_name: {
      type: DataTypes.STRING(225),
      allowNull: false
    },
    name: {
      type: DataTypes.STRING(225),
      allowNull: false
    },
    status: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    new_status: {
      type: DataTypes.ENUM('0','1'),
      allowNull: false,
      defaultValue: "0",
      comment: "as new groups add in 2020"
    },
    new_status21: {
      type: DataTypes.ENUM('0','1'),
      allowNull: false,
      defaultValue: "0"
    },
    report_order: {
      type: DataTypes.INTEGER,
      allowNull: false,
      comment: "Used to order the group on SQ index dashboard"
    },
    factor_multi: {
      type: DataTypes.FLOAT,
      allowNull: false
    }
  }, {
    sequelize,
    tableName: 'projectGroup',
    timestamps: false
  });

export default ProjectGroup;