import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database';

class Domains extends Model {
  DomainId!: number;
  DomainName!: string;
  shortDomain!: string;
  busiUnitID!: number;
  parent_bunit!: number;
  b_status!: number;
  status!: number;
  closure_status!: number;
  display_order!: number;
}
 Domains.init({
    DomainId: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    DomainName: {
      type: DataTypes.STRING(20),
      allowNull: false
    },
    shortDomain: {
      type: DataTypes.STRING(20),
      allowNull: false
    },
    busiUnitID: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    parent_bunit: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    b_status: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 1,
      comment: "1=>Active,2=>Deactive"
    },
    status: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 1,
      comment: "1=>Active,0=>Deactive"
    },
    closure_status: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 0
    },
    display_order: {
      type: DataTypes.INTEGER,
      allowNull: false
    }
  }, {
    sequelize,
    tableName: 'Domains',
    timestamps: false
  });

export default Domains;