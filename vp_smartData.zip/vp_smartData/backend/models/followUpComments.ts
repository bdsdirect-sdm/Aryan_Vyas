import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database';

export class FollowUpComments extends Model {
  id!: number;
  parent_id?: number;
  closure_id!: number;
  incident_id!: number;
  lead_follow_id!: number;
  assignedById!: number;
  assignedToId!: number;
  OBAId!: number;
  comment!: string;
  doc!: string;
  SOS!: '1' | '0';
  BDGTags!: string;
  communication_type!: '1' | '0';
  tag_read!: number;
  review_request!: string;
  isDeleted!: number;
  readStatus!: number;
  created!: Date;
}
 FollowUpComments.init({
    id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    parent_id: {
      type: DataTypes.INTEGER,
      allowNull: true,
      defaultValue: 0
    },
    closure_id: {
      type: DataTypes.BIGINT,
      allowNull: false
    },
    incident_id: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    lead_follow_id: {
      type: DataTypes.BIGINT,
      allowNull: false
    },
    assignedById: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    assignedToId: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    OBAId: {
      type: DataTypes.INTEGER,
      allowNull: false
    },
    comment: {
      type: DataTypes.TEXT,
      allowNull: false
    },
    doc: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    SOS: {
      type: DataTypes.ENUM('1','0'),
      allowNull: false,
      defaultValue: "0"
    },
    BDGTags: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    communication_type: {
      type: DataTypes.ENUM('1','0'),
      allowNull: false,
      defaultValue: "1",
      comment: "'1' Internal, '0' External "
    },
    tag_read: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 0
    },
    review_request: {
      type: DataTypes.STRING(255),
      allowNull: false
    },
    isDeleted: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 0,
      comment: "0 active, 1 Deleted"
    },
    readStatus: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 0,
      comment: "1=Read, 0 unread"
    },
    created: {
      type: DataTypes.DATE,
      allowNull: false
    }
  }, {
    sequelize,
    tableName: 'FollowUpComments',
    timestamps: false
  });

export default FollowUpComments;