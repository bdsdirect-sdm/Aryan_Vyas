import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database';

export class LeadStatus extends Model {
  id!: number;
  name!: string;
  status!: number;
}
LeadStatus.init({
    id: {
      type: DataTypes.INTEGER,
      allowNull: false,
      primaryKey: true
    },
    name: {
      type: DataTypes.STRING(20),
      allowNull: false
    },
    status: {
      type: DataTypes.TINYINT,
      allowNull: false,
      defaultValue: 1,
      comment: "1=>active,0:deactive"
    }
  }, {
    sequelize,
    tableName: 'lead_status',
    timestamps: false
  });
export default LeadStatus;
