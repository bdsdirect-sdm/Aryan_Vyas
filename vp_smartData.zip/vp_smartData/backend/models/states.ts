import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database';

export class States extends Model{
  id!: number;
  name!: string;
  code?: string;
  country_id!: number;
}
States.init({
    id: {
      type: DataTypes.INTEGER.UNSIGNED,
      allowNull: false,
      primaryKey: true,
      comment: "state id"
    },
    name: {
      type: DataTypes.CHAR(40),
      allowNull: false,
      comment: "state name"
    },
    code: {
      type: DataTypes.CHAR(4),
      allowNull: true,
      comment: "state code"
    },
    country_id: {
      type: DataTypes.SMALLINT.UNSIGNED,
      allowNull: false,
      comment: "country id of the state"
    }
  }, {
    sequelize,
    tableName: 'states',
    timestamps: false
  });

  export default States;
