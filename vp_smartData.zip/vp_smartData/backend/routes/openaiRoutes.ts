import express from 'express';
import { classifyPracticeController } from '../controllers/openaiController';

const router = express.Router();

router.post('/classify-practice', classifyPracticeController);

export default router;
