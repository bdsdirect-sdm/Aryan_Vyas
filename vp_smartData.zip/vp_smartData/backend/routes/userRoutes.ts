import { Router, Request, Response } from "express";
import { login, register } from "../controllers/userController";
import { verifyToken } from "../middleware/verifyToken";
import upload from "../middleware/multer";
// import { createOrUpdateRating } from "../controllers/ratingController";
// import { createProduct,updateProduct,deleteProduct,getProductsForRetailer, getProductsForCustomer } from "../controllers/productController";

const router = Router();

router.post("/auth/register", register);
router.post("/auth/login",login)
// router.post("/auth/createProduct",upload.single('productImage'),verifyToken,createProduct)
// router.put("/auth/updateProduct/:id",upload.single('productImage'),verifyToken,updateProduct)
// router.post("/auth/createOrUpdateRating",verifyToken,createOrUpdateRating)
// router.delete("/auth/deleteProduct/:id",verifyToken,deleteProduct)
// router.get("/auth/getProductsForRetailer",verifyToken,getProductsForRetailer)
// router.get("/auth/getProductsForCustomer",verifyToken,getProductsForCustomer)

export default router;