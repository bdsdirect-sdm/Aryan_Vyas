import { OpenAI } from 'openai';
import Pratice from '../models/pratice';

const openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

export const classifyPractice = async (jobPost: string): Promise<string> => {
  const practices = await Pratice.findAll({
    attributes: ['practice_id', 'practice_name'],
    where: { status: 1 },
    raw: true,
  });

  const practicesFormatted = JSON.stringify(practices, null, 2);

  const systemPrompt = `
You are an AI solution architect with 10 years of experience in building AI-enabled software applications. Your job is to analyze job post content and return the most appropriate practice category from the list below.

\`\`\`${practicesFormatted}\`\`\`

Output format:
{
  "practice_id": [write practice id],
  "practice_name": [write practice name]
}
`;

  const messages = [
    { role: 'system', content: systemPrompt },
    { role: 'user', content: jobPost },
  ];

  const response = await openai.chat.completions.create({
    model: 'gpt-4o',
    messages,
  });

  return response.choices[0].message.content || '';
};
