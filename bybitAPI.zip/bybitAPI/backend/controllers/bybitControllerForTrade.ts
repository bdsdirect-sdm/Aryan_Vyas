import { Request, Response } from "express";
import axios, { AxiosRequestConfig } from 'axios';
import { bybitApi, BYBIT_BASE_URL } from "../services/bybitAPI";
import crypto from "crypto"
import dotenv from "dotenv";
dotenv.config({ path: `./config/.env.${process.env.NODE_ENV}` });

export const getMarketTime = async (req: Request, res: Response):Promise<void> => {
    try {
        const response = await bybitApi.get("/market/time");
        res.json(response.data);
    } catch (error) {
        console.error(error);
        res.status(500).json({ message: "Error fetching Bybit market time", error });
    }
};

export const placeOrder = async (req: Request, res: Response): Promise<void> => {
    try {
        const { category,
            symbol,
            isLeverage,
            side,
            orderType,
            qty,
            price,
            triggerPrice,
            triggerDirection,
            triggerBy,
            orderFilter,
            orderIv,
            timeInForce,
            positionIdx,
            orderLinkId,
            takeProfit,
            stopLoss,
            tpTriggerBy,
            slTriggerBy,
            reduceOnly,
            closeOnTrigger,
            smpType,
            mmp,
            tpslMode,
            tpLimitPrice,
            slLimitPrice,
            tpOrderType,
            slOrderType,
            recvWindow = "5000"
        } = req.body;
        const marketTimeResponse = await bybitApi.get("/market/time");
        const serverTimestamp = marketTimeResponse.data.result.timeNano.toString().slice(0, 13);
        console.log("Server Timestamp (in ms):", serverTimestamp);
        if (!serverTimestamp) {
            res.status(500).json({ message: "Unable to fetch server timestamp" });
            return;
        }

        const apiKey = process.env.BYBIT_API_KEY;
        const apiSecret = process.env.BYBIT_API_SECRET;

        if (!apiKey || !apiSecret) {
            res.status(500).json({ message: "API Key or API Secret is missing" });
            return;
        }
        const params = {
            category,
            symbol,
            isLeverage,
            side,
            orderType,
            qty,
            price,
            triggerPrice,
            triggerDirection,
            triggerBy,
            orderFilter,
            orderIv,
            timeInForce,
            positionIdx,
            orderLinkId,
            takeProfit,
            stopLoss,
            tpTriggerBy,
            slTriggerBy,
            reduceOnly,
            closeOnTrigger,
            smpType,
            mmp,
            tpslMode,
            tpLimitPrice,
            slLimitPrice,
            tpOrderType,
            slOrderType,
            recvWindow,
            timestamp: serverTimestamp
        }
        const paramStr = `${serverTimestamp}${apiKey}${recvWindow}${JSON.stringify(params)}`;
        console.log("Param String:", paramStr);
        const signature = crypto
            .createHmac("sha256", apiSecret)
            .update(paramStr)
            .digest("hex");

        const headers = {
            "X-BAPI-API-KEY": apiKey,
            "X-BAPI-TIMESTAMP": serverTimestamp,
            "X-BAPI-RECV-WINDOW": recvWindow,
            "X-BAPI-SIGN": signature,
        };
        const config = {
            method: 'post',
            url: '/order/create',
            headers: headers,
            data: params,
        };

        const response = await bybitApi(config);

        res.json(response.data);

    } catch (error) {
        console.error('Error in setting leverage:', error);
        res.status(500).json({ message: 'Error setting leverage', error });
    }
};

export const amendOrder = async (req: Request, res: Response): Promise<void> => {
    try {
        const { category, symbol, orderId, orderLinkId, qty, price, orderIv, triggerPrice, tpslmode, takeProfit, stopLoss, triggerBy, tpTriggerBy, slTriggerBy, tpLimitPrice, slLimitPrice, recvWindow = "5000" } = req.body;
        const marketTimeResponse = await bybitApi.get("/market/time");
        const serverTimestamp = marketTimeResponse.data.result.timeNano.toString().slice(0, 13);
        console.log("Server Timestamp (in ms):", serverTimestamp);
        if (!serverTimestamp) {
            res.status(500).json({ message: "Unable to fetch server timestamp" });
            return;
        }

        const apiKey = process.env.BYBIT_API_KEY;
        const apiSecret = process.env.BYBIT_API_SECRET;

        if (!apiKey || !apiSecret) {
            res.status(500).json({ message: "API Key or API Secret is missing" });
            return;
        }
        const params = {
            category,
            symbol,
            orderId,
            orderLinkId,
            qty,
            price,
            orderIv,
            triggerPrice,
            tpslmode,
            takeProfit,
            stopLoss,
            triggerBy,
            tpTriggerBy,
            slTriggerBy,
            tpLimitPrice,
            slLimitPrice,
            timestamp: serverTimestamp,
            recvWindow
        }
        const paramStr = `${serverTimestamp}${apiKey}${recvWindow}${JSON.stringify(params)}`;
        console.log("Param String:", paramStr);
        const signature = crypto
            .createHmac("sha256", apiSecret)
            .update(paramStr)
            .digest("hex");

        const headers = {
            "X-BAPI-API-KEY": apiKey,
            "X-BAPI-TIMESTAMP": serverTimestamp,
            "X-BAPI-RECV-WINDOW": recvWindow,
            "X-BAPI-SIGN": signature,
        };
        const config = {
            method: 'post',
            url: '/order/amend',
            headers: headers,
            data: params,
        };

        const response = await bybitApi(config);

        res.json(response.data);
    } catch (error) {
        console.error('Error in setting leverage:', error);
        res.status(500).json({ message: 'Error setting leverage', error });
    }
}

export const cancelOrder = async (req: Request, res: Response): Promise<void> => {
    try {
        const { category, symbol, orderId, orderLinkId, orderFilter, recvWindow = "5000" } = req.body;
        const marketTimeResponse = await bybitApi.get("/market/time");
        const serverTimestamp = marketTimeResponse.data.result.timeNano.toString().slice(0, 13);
        console.log("Server Timestamp (in ms):", serverTimestamp);
        if (!serverTimestamp) {
            res.status(500).json({ message: "Unable to fetch server timestamp" });
            return;
        }

        const apiKey = process.env.BYBIT_API_KEY;
        const apiSecret = process.env.BYBIT_API_SECRET;

        if (!apiKey || !apiSecret) {
            res.status(500).json({ message: "API Key or API Secret is missing" });
            return;
        }
        const params = {
            category,
            symbol,
            orderId,
            orderLinkId,
            orderFilter,
            timestamp: serverTimestamp,
            recvWindow
        }
        const paramStr = `${serverTimestamp}${apiKey}${recvWindow}${JSON.stringify(params)}`;
        console.log("Param String:", paramStr);
        const signature = crypto
            .createHmac("sha256", apiSecret)
            .update(paramStr)
            .digest("hex");

        const headers = {
            "X-BAPI-API-KEY": apiKey,
            "X-BAPI-TIMESTAMP": serverTimestamp,
            "X-BAPI-RECV-WINDOW": recvWindow,
            "X-BAPI-SIGN": signature,
        };
        const config = {
            method: 'post',
            url: '/order/cancel',
            headers: headers,
            data: params,
        };

        const response = await bybitApi(config);

        res.json(response.data);
    } catch (error) {
        console.error('Error in setting leverage:', error);
        res.status(500).json({ message: 'Error setting leverage', error });
    }
}

export const getOpenOrder = async (req: Request, res: Response): Promise<void> => {
    try {
        const {
            category,
            symbol,
            baseCoin,
            settleCoin,
            orderId,
            orderLinkId,
            orderFilter,
            openOnly,
            limit,
            cursor,
            recvWindow = "5000",
        } = req.query;


        const marketTimeResponse = await bybitApi.get("/market/time");
        const serverTimestamp = marketTimeResponse.data.result.timeNano.toString().slice(0, 13);
        console.log("Server Timestamp (in ms):", serverTimestamp);

        if (!serverTimestamp) {
            res.status(500).json({ message: "Unable to fetch server timestamp" });
            return;
        }

        const apiKey = process.env.BYBIT_API_KEY;
        const apiSecret = process.env.BYBIT_API_SECRET;

        if (!apiKey || !apiSecret) {
            res.status(500).json({ message: "API Key or API Secret is missing" });
            return;
        }

        const params: any = {
            category,
            symbol,
            baseCoin,
            settleCoin,
            orderId,
            orderLinkId,
            orderFilter,
            openOnly,
            limit,
            cursor,
            timestamp: serverTimestamp,
            recvWindow,
        };

        const paramStr = Object.keys(params)
            .map(key => `${key}=${encodeURIComponent((params as { [key: string]: any })[key])}`)
            .join('&');
        console.log("Param String:", paramStr);


        const signature = crypto
            .createHmac("sha256", apiSecret)
            .update(serverTimestamp + apiKey + recvWindow + paramStr)
            .digest("hex");


        const headers = {
            "X-BAPI-API-KEY": apiKey,
            "X-BAPI-TIMESTAMP": serverTimestamp,
            "X-BAPI-RECV-WINDOW": String(recvWindow),
            "X-BAPI-SIGN": signature,
        };


        const url = `/order/realtime?${paramStr}`;
        const response = await bybitApi.get(url, { headers });


        res.json(response.data);
    } catch (error) {
        console.error("Error in getting open orders:", error);
        res.status(500).json({ message: "Error fetching open orders", error });
    }
};

export const cancelAllOrders = async (req: Request, res: Response): Promise<void> => {
    try {
        const { category, symbol, baseCoin, settleCoin, recvWindow = "5000" } = req.body;
        const marketTimeResponse = await bybitApi.get("/market/time");
        const serverTimestamp = marketTimeResponse.data.result.timeNano.toString().slice(0, 13);
        console.log("Server Timestamp (in ms):", serverTimestamp);
        if (!serverTimestamp) {
            res.status(500).json({ message: "Unable to fetch server timestamp" });
            return;
        }

        const apiKey = process.env.BYBIT_API_KEY;
        const apiSecret = process.env.BYBIT_API_SECRET;

        if (!apiKey || !apiSecret) {
            res.status(500).json({ message: "API Key or API Secret is missing" });
            return;
        }
        const params = {
            category,
            symbol,
            baseCoin,
            settleCoin,
            timestamp: serverTimestamp,
            recvWindow
        }
        const paramStr = `${serverTimestamp}${apiKey}${recvWindow}${JSON.stringify(params)}`;
        console.log("Param String:", paramStr);
        const signature = crypto
            .createHmac("sha256", apiSecret)
            .update(paramStr)
            .digest("hex");

        const headers = {
            "X-BAPI-API-KEY": apiKey,
            "X-BAPI-TIMESTAMP": serverTimestamp,
            "X-BAPI-RECV-WINDOW": recvWindow,
            "X-BAPI-SIGN": signature,
        };
        const config = {
            method: 'post',
            url: '/order/cancel-all',
            headers: headers,
            data: params,
        };

        const response = await bybitApi(config);

        res.json(response.data);
    } catch (error) {
        console.error('Error in setting leverage:', error);
        res.status(500).json({ message: 'Error setting leverage', error });
    }
}

export const getOrderHistory = async (req: Request, res: Response): Promise<void> => {
    try {
        const {
            category,
            symbol,
            baseCoin,
            startTime,
            endTime,
            orderStatus,
            orderFilter,
            limit,
            cursor,
            recvWindow = "5000"
        } = req.query;

        const marketTimeResponse = await bybitApi.get("/market/time");
        const serverTimestamp = marketTimeResponse.data.result.timeNano.toString().slice(0, 13);
        console.log("Server Timestamp (in ms):", serverTimestamp);

        if (!serverTimestamp) {
            res.status(500).json({ message: "Unable to fetch server timestamp" });
            return;
        }

        const apiKey = process.env.BYBIT_API_KEY;
        const apiSecret = process.env.BYBIT_API_SECRET;

        if (!apiKey || !apiSecret) {
            res.status(500).json({ message: "API Key or API Secret is missing" });
            return;
        }

        const params: any = {
            category,
            symbol,
            baseCoin,
            startTime,
            endTime,
            orderStatus,
            orderFilter,
            limit,
            cursor,
            timestamp: serverTimestamp,
            recvWindow
        };

        console.log("startTime:", startTime);
        console.log("endTime:", endTime);

        const paramStr = `${serverTimestamp}${apiKey}${recvWindow}category=${category}&symbol=${symbol}&baseCoin=${baseCoin}&startTime=${startTime}&endTime=${endTime}&orderStatus=${orderStatus}&orderFilter=${orderFilter}&limit=${limit}&cursor=${cursor}&timestamp=${serverTimestamp}&recvWindow=${recvWindow}`;

        console.log("Param String:", paramStr);

        const signature = crypto
            .createHmac("sha256", apiSecret)
            .update(paramStr)
            .digest("hex");

        const headers = {
            "X-BAPI-API-KEY": apiKey,
            "X-BAPI-TIMESTAMP": serverTimestamp,
            "X-BAPI-RECV-WINDOW": String(recvWindow),
            "X-BAPI-SIGN": signature,
        };

        const response = await bybitApi.get('/order/history', {
            headers: headers,
            params: params,
        });

        console.log("API Response:", response.data);

        if (!response.data) {
            console.error('Empty response from API');
            res.status(500).json({ message: 'Empty response from API' });
            return;
        }

        res.json(response.data);

    } catch (error) {
        console.error('Error in fetching order history:', error);
        res.status(500).json({ message: 'Error fetching order history', error });
    }
};

export const batchPlaceOrder = async (req: Request, res: Response): Promise<void> => {
    try {
        const { category, request, recvWindow = "5000" } = req.body;

        const marketTimeResponse = await bybitApi.get("/market/time");
        const serverTimestamp = marketTimeResponse.data.result.timeNano.toString().slice(0, 13);
        console.log("Server Timestamp (in ms):", serverTimestamp);
        if (!serverTimestamp) {
            res.status(500).json({ message: "Unable to fetch server timestamp" });
            return;
        }

        const apiKey = process.env.BYBIT_API_KEY;
        const apiSecret = process.env.BYBIT_API_SECRET;

        if (!apiKey || !apiSecret) {
            res.status(500).json({ message: "API Key or API Secret is missing" });
            return;
        }

        const params = {
            category,
            request,
            timestamp: serverTimestamp,
            recvWindow
        };

        let paramStr = `${serverTimestamp}${apiKey}${recvWindow}${JSON.stringify(params)}`;
        console.log("Param String:", paramStr);

        const signature = crypto
            .createHmac("sha256", apiSecret)
            .update(paramStr)
            .digest("hex");

        const headers = {
            "X-BAPI-API-KEY": apiKey,
            "X-BAPI-TIMESTAMP": serverTimestamp,
            "X-BAPI-RECV-WINDOW": recvWindow,
            "X-BAPI-SIGN": signature,
        };

        const config = {
            method: 'post',
            url: '/order/create-batch',
            headers: headers,
            data: params,
        };

        const response = await bybitApi(config);

        res.json(response.data);
    } catch (error) {
        console.error('Error in placing batch orders:', error);
        res.status(500).json({ message: 'Error placing batch orders', error });
    }
};

export const batchAmendOrder = async (req: Request, res: Response): Promise<void> => {
    try {
        const { category, request, recvWindow = "5000" } = req.body;

        const marketTimeResponse = await bybitApi.get("/market/time");
        const serverTimestamp = marketTimeResponse.data.result.timeNano.toString().slice(0, 13);
        console.log("Server Timestamp (in ms):", serverTimestamp);
        if (!serverTimestamp) {
            res.status(500).json({ message: "Unable to fetch server timestamp" });
            return;
        }

        const apiKey = process.env.BYBIT_API_KEY;
        const apiSecret = process.env.BYBIT_API_SECRET;

        if (!apiKey || !apiSecret) {
            res.status(500).json({ message: "API Key or API Secret is missing" });
            return;
        }

        const params = {
            category,
            request,
            timestamp: serverTimestamp,
            recvWindow
        };

        let paramStr = `${serverTimestamp}${apiKey}${recvWindow}${JSON.stringify(params)}`;
        console.log("Param String:", paramStr);

        const signature = crypto
            .createHmac("sha256", apiSecret)
            .update(paramStr)
            .digest("hex");

        const headers = {
            "X-BAPI-API-KEY": apiKey,
            "X-BAPI-TIMESTAMP": serverTimestamp,
            "X-BAPI-RECV-WINDOW": recvWindow,
            "X-BAPI-SIGN": signature,
        };

        const config = {
            method: 'post',
            url: '/order/amend-batch',
            headers: headers,
            data: params,
        };

        const response = await bybitApi(config);

        res.json(response.data);
    } catch (error) {
        console.error('Error in placing batch orders:', error);
        res.status(500).json({ message: 'Error placing batch orders', error });
    }
};

export const batchCancelOrder = async (req: Request, res: Response): Promise<void> => {
    try {
        const { category, request, recvWindow = "5000" } = req.body;

        const marketTimeResponse = await bybitApi.get("/market/time");
        const serverTimestamp = marketTimeResponse.data.result.timeNano.toString().slice(0, 13);
        console.log("Server Timestamp (in ms):", serverTimestamp);
        if (!serverTimestamp) {
            res.status(500).json({ message: "Unable to fetch server timestamp" });
            return;
        }

        const apiKey = process.env.BYBIT_API_KEY;
        const apiSecret = process.env.BYBIT_API_SECRET;

        if (!apiKey || !apiSecret) {
            res.status(500).json({ message: "API Key or API Secret is missing" });
            return;
        }

        const params = {
            category,
            request,
            timestamp: serverTimestamp,
            recvWindow
        };

        let paramStr = `${serverTimestamp}${apiKey}${recvWindow}${JSON.stringify(params)}`;
        console.log("Param String:", paramStr);

        const signature = crypto
            .createHmac("sha256", apiSecret)
            .update(paramStr)
            .digest("hex");

        const headers = {
            "X-BAPI-API-KEY": apiKey,
            "X-BAPI-TIMESTAMP": serverTimestamp,
            "X-BAPI-RECV-WINDOW": recvWindow,
            "X-BAPI-SIGN": signature,
        };

        const config = {
            method: 'post',
            url: '/order/cancel-batch',
            headers: headers,
            data: params,
        };

        const response = await bybitApi(config);

        res.json(response.data);
    } catch (error) {
        console.error('Error in placing batch orders:', error);
        res.status(500).json({ message: 'Error placing batch orders', error });
    }
};

export const getBorrowQuota = async (req: Request, res: Response): Promise<void> => {
    try {
        const { category, symbol, side, recvWindow = "5000" } = req.query;

        const marketTimeResponse = await bybitApi.get("/market/time");
        const serverTimestamp = marketTimeResponse.data.result.timeNano.toString().slice(0, 13);

        if (!serverTimestamp) {
            res.status(500).json({ message: "Unable to fetch server timestamp" });
            return;
        }

        const apiKey = process.env.BYBIT_API_KEY;
        const apiSecret = process.env.BYBIT_API_SECRET;

        if (!apiKey || !apiSecret) {
            res.status(500).json({ message: "API Key or API Secret is missing" });
            return;
        }

        const queryString = new URLSearchParams({
            category: String(category),
            symbol: String(symbol),
            side: String(side),
            timestamp: serverTimestamp,
            recvWindow: String(recvWindow),
        }).toString();


        const stringToSign = `${serverTimestamp}${apiKey}${recvWindow}${queryString}`;
        console.log("String to Sign:", stringToSign);

        const signature = crypto
            .createHmac("sha256", apiSecret)
            .update(stringToSign)
            .digest("hex");

        const headers = {
            "X-BAPI-API-KEY": apiKey,
            "X-BAPI-TIMESTAMP": serverTimestamp,
            "X-BAPI-RECV-WINDOW": String(recvWindow),
            "X-BAPI-SIGN": signature,
        };
        const response = await bybitApi.get('/order/spot-borrow-check', {
            headers,
            params: {
                category,
                symbol,
                side,
                timestamp: serverTimestamp,
                recvWindow,
            }
        });

        res.json(response.data);
    } catch (error) {
        console.error('Error in fetching borrow quota:', error);
        res.status(500).json({ message: 'Error fetching borrow quota', error });
    }
};
