import { Request, Response } from "express";
import axios, { AxiosRequestConfig } from 'axios';
import crypto from "crypto"
import { RestClientV5 } from 'bybit-api';
import { bybitApi, BYBIT_BASE_URL } from "../services/bybitAPI";
import dotenv from "dotenv";
dotenv.config({ path: `./config/.env.${process.env.NODE_ENV}` });

export const getMarketTime = async (req: Request, res: Response):Promise<void> => {
  try {
    const response = await bybitApi.get("/market/time");
    res.json(response.data);
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error fetching Bybit market time", error });
  }
};

export const getBybitPositions = async (req: Request, res: Response): Promise<void> => {
  try {
    const { recvWindow = "5000", category, symbol, baseCoin, settleCoin, limit, cursor } = req.body;
    const marketTimeResponse = await bybitApi.get("/market/time");
    const serverTimestamp = marketTimeResponse.data.result.timeNano.toString().slice(0, 13);
    console.log("Server Timestamp (in ms):", serverTimestamp);
    if (!serverTimestamp) {
      res.status(500).json({ message: "Unable to fetch server timestamp" });
      return;
    }

    const apiKey = process.env.BYBIT_API_KEY;
    const apiSecret = process.env.BYBIT_API_SECRET;

    if (!apiKey || !apiSecret) {
      res.status(500).json({ message: "API Key or API Secret is missing" });
      return;
    }

    const params = {
      category,
      symbol,
      baseCoin,
      settleCoin,
      limit,
      cursor,
      timestamp: serverTimestamp,
      recvWindow,
    };

    const queryString = Object.keys(params)
      .map((key) => `${key}=${params[key as keyof typeof params]}`)
      .join("&");
    console.log("Sorted Query Parameters:", queryString);

    const paramStr = `${serverTimestamp}${apiKey}${recvWindow}${queryString}`;
    console.log("Generated Param String:", paramStr);

    const signature = crypto
      .createHmac("sha256", apiSecret)
      .update(paramStr)
      .digest("hex");
    console.log("Generated Signature (SHA256):", signature);

    const headers = {
      "X-BAPI-API-KEY": apiKey,
      "X-BAPI-TIMESTAMP": serverTimestamp,
      "X-BAPI-RECV-WINDOW": recvWindow,
      "X-BAPI-SIGN": signature,
    };
    console.log("Request Headers:", headers);

    const config = {
      method: "get",
      url: "/position/list",
      headers: headers,
      params: params,
    };

    const response = await bybitApi(config);
    console.log("Raw API Response:", response.data);

    const positionData = response.data.result.list;
    console.log("Position Data:", JSON.stringify(positionData, null, 2));

    res.json(response.data);

  } catch (error) {
    console.error("Error in Bybit API request:", error);
    res.status(500).json({ message: "Error fetching Bybit positions", error });
  }
};

export const setLeverage = async (req: Request, res: Response): Promise<void> => {
  try {
    const { category, symbol, buyLeverage, sellLeverage, recvWindow = "5000" } = req.body;
    const apiKey = process.env.BYBIT_API_KEY;
    const apiSecret = process.env.BYBIT_API_SECRET;
    if (!apiKey || !apiSecret) {
      res.status(500).json({ message: "API Key or API Secret is missing" });
      return;
    }

    const marketTimeResponse = await bybitApi.get("/market/time");

    const serverTimestamp = marketTimeResponse.data.result.timeNano.toString().slice(0, 13);
    console.log("Server Timestamp (in ms):", serverTimestamp);

    if (!serverTimestamp) {
      res.status(500).json({ message: "Unable to fetch server timestamp" });
      return;
    }

    const params = {
      category,
      symbol,
      buyLeverage,
      sellLeverage,
      timestamp: serverTimestamp,
      recvWindow,
    };

    const paramStr = `${serverTimestamp}${apiKey}${recvWindow}${JSON.stringify(params)}`;

    console.log("Param String:", paramStr);
    const signature = crypto
      .createHmac("sha256", apiSecret)
      .update(paramStr)
      .digest("hex");

    const headers = {
      "X-BAPI-API-KEY": apiKey,
      "X-BAPI-TIMESTAMP": serverTimestamp,
      "X-BAPI-RECV-WINDOW": recvWindow,
      "X-BAPI-SIGN": signature,
    };

    const config = {
      method: 'post',
      url: '/position/set-leverage',
      headers: headers,
      data: params,
    };

    const response = await bybitApi(config);

    res.json(response.data);

  } catch (error) {
    console.error('Error in setting leverage:', error);
    res.status(500).json({ message: 'Error setting leverage', error });
  }
};

export const switchCrossOrIsolatedMargin = async (req: Request, res: Response): Promise<void> => {
  try {
    const { category, symbol, tradeMode, buyLeverage, sellLeverage, recvWindow = "5000" } = req.body;
    const marketTimeResponse = await bybitApi.get("/market/time");
    const serverTimestamp = marketTimeResponse.data.result.timeNano.toString().slice(0, 13);
    console.log("Server Timestamp (in ms):", serverTimestamp);
    if (!serverTimestamp) {
      res.status(500).json({ message: "Unable to fetch server timestamp" });
      return;
    }
    const apiKey = process.env.BYBIT_API_KEY;
    const apiSecret = process.env.BYBIT_API_SECRET;

    if (!apiKey || !apiSecret) {
      res.status(500).json({ message: "API Key or API Secret is missing" });
      return;
    }

    const params = {
      category,
      symbol,
      tradeMode,
      buyLeverage,
      sellLeverage,
      timestamp: serverTimestamp,
      recvWindow,
    };

    const queryString = Object.keys(params)
      .map((key) => `${key}=${params[key as keyof typeof params]}`)
      .join("&");
    console.log("Sorted Query Parameters:", queryString);

    const paramStr = `${serverTimestamp}${apiKey}${params.recvWindow}${JSON.stringify(params)}`;
    console.log("Generated Param String:", paramStr);

    const signature = crypto
      .createHmac("sha256", apiSecret)
      .update(paramStr)
      .digest("hex");
    console.log("Generated Signature (SHA256):", signature);

    const headers = {
      "X-BAPI-API-KEY": apiKey,
      "X-BAPI-TIMESTAMP": serverTimestamp,
      "X-BAPI-RECV-WINDOW": recvWindow,
      "X-BAPI-SIGN": signature,
    };

    console.log("Request Headers:", headers);

    const config = {
      method: "post",
      url: "/position/switch-isolated",
      headers: headers,
      data: params,
    };

    const response = await bybitApi(config);
    console.log("API Response:", response.data);

    res.json(response.data);

  } catch (error) {
    console.error("Error in Bybit API request:", error);
    res.status(500).json({ message: "Error switching margin mode", error });
  }
};

export const setTakeProfitStopLoss = async (req: Request, res: Response): Promise<void> => {
  try {
    const { category, symbol, tpSlMode, recvWindow = "5000" } = req.body;
    const apiKey = process.env.BYBIT_API_KEY;
    const apiSecret = process.env.BYBIT_API_SECRET;

    if (!apiKey || !apiSecret) {
      res.status(500).json({ message: "API Key or API Secret is missing" });
      return;
    }
    const marketTimeResponse = await bybitApi.get("/market/time");
    const serverTimestamp = marketTimeResponse.data.result.timeNano.toString().slice(0, 13);

    if (!serverTimestamp) {
      res.status(500).json({ message: "Unable to fetch server timestamp" });
      return;
    }

    const params = { category, symbol, tpSlMode };
    const paramStr = `${serverTimestamp}${apiKey}${recvWindow}${JSON.stringify(params)}`;
    const signature = crypto.createHmac("sha256", apiSecret).update(paramStr).digest("hex");

    const headers = {
      "X-BAPI-API-KEY": apiKey,
      "X-BAPI-TIMESTAMP": serverTimestamp,
      "X-BAPI-RECV-WINDOW": recvWindow,
      "X-BAPI-SIGN": signature,
    };

    const response = await bybitApi.post("/position/set-tpsl-mode", params, {
      headers,
    });

    if (response.data.retCode === 10001 && response.data.retMsg.includes("same tp sl mode")) {
      res.json({
        message: `✅ No changes were made. Your TP/SL mode is already set to: **${tpSlMode}**.`,
      });
      return;
    }

    res.json(response.data);
  } catch (error) {
    if (axios.isAxiosError(error)) {
      console.error("Error setting TP/SL mode:", error.response?.data || error.message);

      if (error.response?.data?.retCode === 10001 && error.response?.data?.retMsg.includes("same tp sl mode")) {
        res.json({
          message: `✅ No changes were made. Your TP/SL mode is already set to: **${req.body.tpSlMode}**.`,
        });
        return;
      }

      res.status(500).json({ message: "Bybit API error", error: error.response?.data || error.message });
    } else {
      console.error("Unexpected error:", error);
      res.status(500).json({ message: "Bybit API error", error: String(error) });
    }
  }
};

export const switchMode = async (req: Request, res: Response): Promise<void> => {
  try {
    const { category, symbol, coin, mode, recvWindow = "5000" } = req.body;

    const apiKey = process.env.BYBIT_API_KEY;
    const apiSecret = process.env.BYBIT_API_SECRET;

    if (!apiKey || !apiSecret) {
      res.status(500).json({ message: "API Key or API Secret is missing" });
      return;
    }

    const marketTimeResponse = await bybitApi.get('/market/time');
    const serverTimestamp = marketTimeResponse.data.result.timeNano.toString().slice(0, 13);
    console.log("Server Timestamp (in ms):", serverTimestamp);

    if (!serverTimestamp) {
      res.status(500).json({ message: "Unable to fetch server timestamp" });
      return;
    }

    const params = {
      category,
      symbol,
      coin,
      mode,
      timestamp: serverTimestamp,
      recvWindow,
    };

    const paramStr = `${serverTimestamp}${apiKey}${recvWindow}${JSON.stringify(params)}`;
    console.log("Generated Param String:", paramStr);

    const signature = crypto
      .createHmac('sha256', apiSecret)
      .update(paramStr)
      .digest('hex');
    console.log("Generated Signature (SHA256):", signature);

    const headers = {
      'X-BAPI-API-KEY': apiKey,
      'X-BAPI-TIMESTAMP': serverTimestamp,
      'X-BAPI-RECV-WINDOW': recvWindow,
      'X-BAPI-SIGN': signature,
    };

    console.log("Request Headers:", headers);
    const positionResponse = await bybitApi.get('/position/list', {
      headers: headers,
    });

    const currentMode = positionResponse.data.result?.[0]?.category;
    const currentPositionMode = positionResponse.data.result?.[0]?.mode;

    if (currentPositionMode === mode) {
      res.json({ message: "Position mode is already set to the requested mode." });
      return;
    }

    const switchModeConfig = {
      method: 'post',
      url: '/position/switch-mode',
      headers: headers,
      data: params,
    };

    const switchModeResponse = await bybitApi(switchModeConfig);
    console.log("Switch Mode Response:", switchModeResponse.data);

    if (switchModeResponse.data.retCode !== 0) {
      console.error("Error switching position mode:", switchModeResponse.data.retMsg);
      res.status(500).json({ message: switchModeResponse.data.retMsg });
      return;
    }

    res.json(switchModeResponse.data);

  } catch (error) {
    console.error("Error in integrated mode:", error);
    res.status(500).json({ message: "Error integrating Bybit API", error });
  }
};

export const setRiskLimit = async (req: Request, res: Response): Promise<void> => {
  try {
    const { category, symbol, riskId, positionIdx, recvWindow = "5000" } = req.body;
    const apiKey = process.env.BYBIT_API_KEY;
    const apiSecret = process.env.BYBIT_API_SECRET;

    if (!apiKey || !apiSecret) {
      res.status(500).json({ message: "API Key or API Secret is missing" });
      return;
    }

    const marketTimeResponse = await bybitApi.get('/market/time');
    const serverTimestamp = marketTimeResponse.data.result.timeNano.toString().slice(0, 13);
    console.log("Server Timestamp (in ms):", serverTimestamp);

    if (!serverTimestamp) {
      res.status(500).json({ message: "Unable to fetch server timestamp" });
      return;
    }

    const params = {
      category,
      symbol,
      riskId,
      positionIdx,
      timestamp: serverTimestamp,
      recvWindow,
    };

    const paramStr = `${serverTimestamp}${apiKey}${recvWindow}${JSON.stringify(params)}`;
    console.log("Generated Param String:", paramStr);

    const signature = crypto
      .createHmac('sha256', apiSecret)
      .update(paramStr)
      .digest('hex');
    console.log("Generated Signature (SHA256):", signature);

    const headers = {
      'X-BAPI-API-KEY': apiKey,
      'X-BAPI-TIMESTAMP': serverTimestamp,
      'X-BAPI-RECV-WINDOW': recvWindow,
      'X-BAPI-SIGN': signature,
    };
    const config = {
      method: 'post',
      url: '/position/set-risk-limit',
      headers: headers,
      data: params,
    };

    const response = await bybitApi(config);

    res.json(response.data);
  } catch (error) {
    console.error("Error in integrated mode:", error);
    res.status(500).json({ message: "Error integrating Bybit API", error });
  }
}

export const setTradingStop = async (req: Request, res: Response): Promise<void> => {
  try {
    const {
      category,
      symbol,
      takeProfit,
      stopLoss,
      tpSize,
      slSize,
      tpTriggerBy,
      slTriggerBy,
      trailingStop,
      activePrice,
      positionIdx,
      tpLimitPrice,
      slLimitPrice,
      tpOrderType,
      slOrderType,
      recvWindow = "5000"
    } = req.body;

    const apiKey = process.env.BYBIT_API_KEY;
    const apiSecret = process.env.BYBIT_API_SECRET;

    if (!apiKey || !apiSecret) {
      res.status(500).json({ message: "API Key or API Secret is missing" });
      return;
    }

    const marketTimeResponse = await bybitApi.get('/market/time');
    const serverTimestamp = marketTimeResponse.data.result.timeNano.toString().slice(0, 13);
    console.log("Server Timestamp (in ms):", serverTimestamp);

    if (!serverTimestamp) {
      res.status(500).json({ message: "Unable to fetch server timestamp" });
      return;
    }
    const params: any = {
      category,
      symbol,
      positionIdx,
      timestamp: serverTimestamp,
      recvWindow
    };

    if (takeProfit) params.takeProfit = takeProfit;
    if (stopLoss) params.stopLoss = stopLoss;
    if (tpSize) params.tpSize = tpSize;
    if (slSize) params.slSize = slSize;
    if (tpTriggerBy) params.tpTriggerBy = tpTriggerBy;
    if (slTriggerBy) params.slTriggerBy = slTriggerBy;
    if (trailingStop) params.trailingStop = trailingStop;
    if (activePrice) params.activePrice = activePrice;
    if (tpLimitPrice) params.tpLimitPrice = tpLimitPrice;
    if (slLimitPrice) params.slLimitPrice = slLimitPrice;
    if (tpOrderType) params.tpOrderType = tpOrderType;
    if (slOrderType) params.slOrderType = slOrderType;

    const paramStr = `${serverTimestamp}${apiKey}${recvWindow}${JSON.stringify(params)}`;
    console.log("Generated Param String:", paramStr);

    const signature = crypto
      .createHmac('sha256', apiSecret)
      .update(paramStr)
      .digest('hex');
    console.log("Generated Signature (SHA256):", signature);

    const headers = {
      'X-BAPI-API-KEY': apiKey,
      'X-BAPI-TIMESTAMP': serverTimestamp,
      'X-BAPI-RECV-WINDOW': recvWindow,
      'X-BAPI-SIGN': signature,
    };

    const config = {
      method: 'post',
      url: '/position/trading-stop',
      headers: headers,
      data: params,
    };

    const response = await bybitApi(config);

    res.json(response.data);
  } catch (error) {
    console.error("Error in integrated mode:", error);

    if (axios.isAxiosError(error)) {
      res.status(500).json({ message: "Error integrating Bybit API", error: error.response?.data || error.message });
    } else {
      res.status(500).json({ message: "Error integrating Bybit API", error: String(error) });
    }
  }
};

export const setAutoAddMargin = async (req: Request, res: Response): Promise<void> => {
  try {
    const { category, symbol, autoAddMargin, positionIdx, recvWindow = "5000" } = req.body;
    const apiKey = process.env.BYBIT_API_KEY;
    const apiSecret = process.env.BYBIT_API_SECRET;

    if (!apiKey || !apiSecret) {
      res.status(500).json({ message: "API Key or API Secret is missing" });
      return;
    }

    const marketTimeResponse = await bybitApi.get('/market/time');
    const serverTimestamp = marketTimeResponse.data.result.timeNano.toString().slice(0, 13);
    console.log("Server Timestamp (in ms):", serverTimestamp);

    if (!serverTimestamp) {
      res.status(500).json({ message: "Unable to fetch server timestamp" });
      return;
    }

    const params = {
      category,
      symbol,
      autoAddMargin,
      positionIdx,
      timestamp: serverTimestamp,
      recvWindow,
    };

    const paramStr = `${serverTimestamp}${apiKey}${recvWindow}${JSON.stringify(params)}`;
    console.log("Generated Param String:", paramStr);

    const signature = crypto
      .createHmac('sha256', apiSecret)
      .update(paramStr)
      .digest('hex');
    console.log("Generated Signature (SHA256):", signature);

    const headers = {
      'X-BAPI-API-KEY': apiKey,
      'X-BAPI-TIMESTAMP': serverTimestamp,
      'X-BAPI-RECV-WINDOW': recvWindow,
      'X-BAPI-SIGN': signature,
    };
    const config = {
      method: 'post',
      url: '/position/set-auto-add-margin',
      headers: headers,
      data: params,
    };

    const response = await bybitApi(config);

    res.json(response.data);
  } catch (error) {
    console.error("Error in integrated mode:", error);
    res.status(500).json({ message: "Error integrating Bybit API", error });
  }
}


export const addOrReduceMargin = async (req: Request, res: Response): Promise<void> => {
  try {
    const { category, symbol, margin, positionIdx, recvWindow = "5000" } = req.body;
    const apiKey = process.env.BYBIT_API_KEY;
    const apiSecret = process.env.BYBIT_API_SECRET;

    if (!apiKey || !apiSecret) {
      res.status(500).json({ message: "API Key or API Secret is missing" });
      return;
    }

    const marketTimeResponse = await bybitApi.get('/market/time');
    const serverTimestamp = marketTimeResponse.data.result.timeNano.toString().slice(0, 13);
    console.log("Server Timestamp (in ms):", serverTimestamp);

    if (!serverTimestamp) {
      res.status(500).json({ message: "Unable to fetch server timestamp" });
      return;
    }

    const params = {
      category,
      symbol,
      margin,
      positionIdx,
      timestamp: serverTimestamp,
      recvWindow,
    };

    const paramStr = `${serverTimestamp}${apiKey}${recvWindow}${JSON.stringify(params)}`;
    console.log("Generated Param String:", paramStr);

    const signature = crypto
      .createHmac('sha256', apiSecret)
      .update(paramStr)
      .digest('hex');
    console.log("Generated Signature (SHA256):", signature);

    const headers = {
      'X-BAPI-API-KEY': apiKey,
      'X-BAPI-TIMESTAMP': serverTimestamp,
      'X-BAPI-RECV-WINDOW': recvWindow,
      'X-BAPI-SIGN': signature,
    };
    const config = {
      method: 'post',
      url: '/position/add-margin',
      headers: headers,
      data: params,
    };

    const response = await bybitApi(config);

    res.json(response.data);
  } catch (error) {
    console.error("Error in integrated mode:", error);
    res.status(500).json({ message: "Error integrating Bybit API", error });
  }
}

export const getExecution = async (req: Request, res: Response): Promise<void> => {
  try {
    const { category, symbol, baseCoin, orderId, orderLinkId, startTime, endTime, execType, limit = 50, cursor, recvWindow = "5000" } = req.query;

    const apiKey = process.env.BYBIT_API_KEY;
    const apiSecret = process.env.BYBIT_API_SECRET;

    if (!apiKey || !apiSecret) {
      res.status(500).json({ message: "API Key or API Secret is missing" });
      return;
    }

    const marketTimeResponse = await bybitApi.get('/market/time');
    const serverTimestamp = marketTimeResponse.data.result.timeNano.toString().slice(0, 13);
    console.log("Server Timestamp (in ms):", serverTimestamp);

    if (!serverTimestamp) {
      res.status(500).json({ message: "Unable to fetch server timestamp" });
      return;
    }

    const queryParams: any = {
      category,
      symbol,
      baseCoin,
      orderId,
      orderLinkId,
      startTime,
      endTime,
      execType,
      limit,
      cursor,
      recvWindow,
      timestamp: serverTimestamp,
    };

    const paramStr = `${serverTimestamp}${apiKey}${recvWindow}category=${category}&symbol=${symbol}&baseCoin=${baseCoin}&orderId=${orderId}&orderLinkId=${orderLinkId}&startTime=${startTime}&endTime=${endTime}&execType=${execType}&limit=${limit}&cursor=${cursor}&recvWindow=${recvWindow}&timestamp=${serverTimestamp}`;

    console.log("Generated Param String:", paramStr);

    const signature = crypto
      .createHmac('sha256', apiSecret)
      .update(paramStr)
      .digest('hex');
    console.log("Generated Signature (SHA256):", signature);

    const headers = {
      'X-BAPI-API-KEY': apiKey,
      'X-BAPI-TIMESTAMP': serverTimestamp,
      'X-BAPI-RECV-WINDOW': String(recvWindow),
      'X-BAPI-SIGN': signature,
    };
    const response = await bybitApi.get('/execution/list', {
      headers,
      params: queryParams,
    });

    res.json(response.data);
  } catch (error) {
    console.error("Error in integrated mode:", error);
    res.status(500).json({ message: "Error integrating Bybit API", error });
  }
};

export const getClosePnL = async (req: Request, res: Response): Promise<void> => {
  try {
    const { category, symbol, startTime, endTime, limit = 50, cursor, recvWindow = "5000" } = req.query;

    const apiKey = process.env.BYBIT_API_KEY;
    const apiSecret = process.env.BYBIT_API_SECRET;

    if (!apiKey || !apiSecret) {
      res.status(500).json({ message: "API Key or API Secret is missing" });
      return;
    }

    const marketTimeResponse = await bybitApi.get('/market/time');
    const serverTimestamp = marketTimeResponse.data.result.timeNano.toString().slice(0, 13);
    console.log("Server Timestamp (in ms):", serverTimestamp);

    if (!serverTimestamp) {
      res.status(500).json({ message: "Unable to fetch server timestamp" });
      return;
    }

    const queryParams: any = {
      category,
      symbol,
      startTime,
      endTime,
      limit,
      cursor,
      recvWindow,
      timestamp: serverTimestamp,
    };

    const paramStr = `${serverTimestamp}${apiKey}${recvWindow}category=${category}&symbol=${symbol}&startTime=${startTime}&endTime=${endTime}&limit=${limit}&cursor=${cursor}&recvWindow=${recvWindow}&timestamp=${serverTimestamp}`;
    console.log("Generated Param String:", paramStr);

    const signature = crypto
      .createHmac('sha256', apiSecret)
      .update(paramStr)
      .digest('hex');
    console.log("Generated Signature (SHA256):", signature);

    const headers = {
      'X-BAPI-API-KEY': apiKey,
      'X-BAPI-TIMESTAMP': serverTimestamp,
      'X-BAPI-RECV-WINDOW': String(recvWindow),
      'X-BAPI-SIGN': signature,
    };

    const response = await bybitApi.get('/position/closed-pnl', {
      headers: headers,
      params: queryParams,
    });

    res.json(response.data);
  } catch (error) {
    console.error("Error in integrated mode:", error);
    res.status(500).json({ message: "Error integrating Bybit API", error });
  }
};