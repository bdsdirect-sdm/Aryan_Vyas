import { Request, Response } from "express";
import axios, { AxiosRequestConfig } from 'axios';
import crypto from "crypto"
import { RestClientV5 } from 'bybit-api';
import dotenv from "dotenv";
dotenv.config({ path: `./config/.env.${process.env.NODE_ENV}` });
export const getMarketTime = async (req: Request, res: any) => {
    try {

      const response = await axios.get("https://api.bybit.com/v5/market/time");
      res.json(response.data);
    } catch (error) {
      console.error(error);
      res.status(500).json({ message: "Error fetching Bybit market time", error });
    }
  }; 
 
  
  export const getBybitPositions = async (req: Request, res: Response):Promise<void> => {
    try {
      const marketTimeResponse = await axios.get("https://api.bybit.com/v5/market/time");
      const serverTimestamp = marketTimeResponse.data.result.timeNano.toString().slice(0, 13);
      console.log("Server Timestamp (in ms):", serverTimestamp);
      if (!serverTimestamp) {
        res.status(500).json({ message: "Unable to fetch server timestamp" });
        return;
      }
  
      const apiKey = process.env.BYBIT_API_KEY;
      const apiSecret = process.env.BYBIT_API_SECRET;
  
      if (!apiKey || !apiSecret) {
        res.status(500).json({ message: "API Key or API Secret is missing" });
        return;
      }
  
      const recvWindow = "5000";
      const params = {
        category: "linear",
        symbol: "BTCUSDT",
        timestamp: serverTimestamp,
        recv_window: recvWindow,
      };
  
      const queryString = Object.keys(params)
        .map((key) => `${key}=${params[key as keyof typeof params]}`)
        .join("&");
      console.log("Sorted Query Parameters:", queryString);
  
      const paramStr = `${serverTimestamp}${apiKey}${recvWindow}${queryString}`;
      console.log("Generated Param String:", paramStr);
  
      const signature = crypto
        .createHmac("sha256", apiSecret)
        .update(paramStr)
        .digest("hex");
      console.log("Generated Signature (SHA256):", signature);
  
      const headers = {
        "X-BAPI-API-KEY": apiKey,
        "X-BAPI-TIMESTAMP": serverTimestamp,
        "X-BAPI-RECV-WINDOW": recvWindow,
        "X-BAPI-SIGN": signature,
      };
      console.log("Request Headers:", headers);
  
      const config = {
        method: "get",
        url: "https://api.bybit.com/v5/position/list",
        headers: headers,
        params: params,
      };
  
      const response = await axios(config);
      console.log("Raw API Response:", response.data);
  
      const positionData = response.data.result.list;
      console.log("Position Data:", JSON.stringify(positionData, null, 2));
  
      res.json(response.data);
  
    } catch (error) {
      console.error("Error in Bybit API request:", error);
      res.status(500).json({ message: "Error fetching Bybit positions", error });
    }
  };
  
  
  
/////addeded levrage/////////////////

// export const getBybitPositions = async (req: Request, res: Response) => {
//   try {
//     const marketTimeResponse = await axios.get("https://api.bybit.com/v5/market/time");

//     const serverTimestamp = marketTimeResponse.data.result.timeNano.toString().slice(0, 13);
//     console.log("Server Timestamp (in ms):", serverTimestamp);

//     if (!serverTimestamp) {
//       res.status(500).json({ message: "Unable to fetch server timestamp" });
//       return;
//     }

//     const apiKey = "5r9p2J92JH32IBprj5";
//     const apiSecret = "qTfmUyG0o6T46lowtPCfdpgTIvP1LWYcjrrZ";
//     const recvWindow = "5000";

//     const params = {
//       category: "linear",
//       symbol: "BTCUSDT",
//       timestamp: serverTimestamp,
//       recv_window: recvWindow,
//     };

//     const queryString = Object.keys(params)
//       .map((key) => `${key}=${params[key as keyof typeof params]}`)
//       .join("&");

//     console.log("Sorted Query Parameters:", queryString);

//     const paramStr = `${serverTimestamp}${apiKey}${recvWindow}${queryString}`;
//     console.log("Generated Param String:", paramStr);

//     const signature = crypto
//       .createHmac("sha256", apiSecret)
//       .update(paramStr)
//       .digest("hex");

//     console.log("Generated Signature (SHA256):", signature);

//     const headers = {
//       "X-BAPI-API-KEY": apiKey,
//       "X-BAPI-TIMESTAMP": serverTimestamp,
//       "X-BAPI-RECV-WINDOW": recvWindow,
//       "X-BAPI-SIGN": signature,
//     };

//     console.log("Request Headers:", headers);

//     const config = {
//       method: "get",
//       url: "https://api.bybit.com/v5/position/list",
//       headers: headers,
//       params: params,
//     };

//     const response = await axios(config);

//     const positions = response.data.result.list;

//     // Extract leverage value (assuming the response contains a leverage field)
//     const leverage = positions.length > 0 ? positions[0].leverage : "N/A";

//     console.log("Leverage:", leverage);

//     // Send back the response with leverage included
//     res.json({
//       positions,
//       leverage,
//     });

//   } catch (error) {
//     console.error("Error in Bybit API request:", error);
//     res.status(500).json({ message: "Error fetching Bybit positions", error });
//   }
// };


export const setLeverage = async (req: Request, res: Response): Promise<void> => {
  try {
    const { symbol, buyLeverage, sellLeverage } = req.body; 

    const apiKey = process.env.BYBIT_API_KEY;
    const apiSecret = process.env.BYBIT_API_SECRET;
    if (!apiKey || !apiSecret) {
      res.status(500).json({ message: "API Key or API Secret is missing" });
      return;
    }
    const recvWindow = '20000';

    const marketTimeResponse = await axios.get("https://api.bybit.com/v5/market/time");

    const serverTimestamp = marketTimeResponse.data.result.timeNano.toString().slice(0, 13);
    console.log("Server Timestamp (in ms):", serverTimestamp);

    if (!serverTimestamp) {
      res.status(500).json({ message: "Unable to fetch server timestamp" });
      return;
    }

    const params = {
      category: 'linear',
      symbol,
      buyLeverage,
      sellLeverage,
      timestamp: serverTimestamp,
      recv_window: recvWindow,
    };


  //   const params = {
  //   category: 'linear',
  //   symbol: "BTCUSDT",
  //   buyLeverage: "10",
  //   sellLeverage: "10",    
  //   timestamp: serverTimestamp,
  //   recv_window: recvWindow,
  // };

    const queryString = Object.keys(params)
      .map((key) => `${key}=${params[key as keyof typeof params]}`)
      .join("&");

    const paramStr = `${serverTimestamp}${apiKey}${recvWindow}${queryString}`;
    const signature = crypto
      .createHmac("sha256", apiSecret)
      .update(paramStr)
      .digest("hex");

    const headers = {
      "X-BAPI-API-KEY": apiKey,
      "X-BAPI-TIMESTAMP": serverTimestamp,
      "X-BAPI-RECV-WINDOW": recvWindow,
      "X-BAPI-SIGN": signature,
    };

    const config = {
      method: 'post',
      url: 'https://api.bybit.com/v5/position/set-leverage',
      headers: headers,
      data: params,
    };

    const response = await axios(config);

    res.json(response.data);

  } catch (error) {
    console.error('Error in setting leverage:', error);
    res.status(500).json({ message: 'Error setting leverage', error });
  }
};


export const switchCrossOrIsolatedMargin = async (req: Request, res: Response): Promise<void> => {
  try {
    const marketTimeResponse = await axios.get("https://api.bybit.com/v5/market/time");
    const serverTimestamp = marketTimeResponse.data.result.timeNano.toString().slice(0, 13);
    console.log("Server Timestamp (in ms):", serverTimestamp);
    if (!serverTimestamp) {
      res.status(500).json({ message: "Unable to fetch server timestamp" });
      return;
    }

    const apiKey = process.env.BYBIT_API_KEY;
    const apiSecret = process.env.BYBIT_API_SECRET;

    if (!apiKey || !apiSecret) {
      res.status(500).json({ message: "API Key or API Secret is missing" });
      return;
    }
    const params = {
      category: "linear",  
      symbol: req.body.symbol || "BTCUSDT", 
      tradeMode: req.body.tradeMode || 0, 
      buyLeverage: req.body.buyLeverage || "10", 
      sellLeverage: req.body.sellLeverage || "10",
      timestamp: serverTimestamp,
      recv_window: "5000",
    };
    const queryString = Object.keys(params)
      .map((key) => `${key}=${params[key as keyof typeof params]}`)
      .join("&");
    console.log("Sorted Query Parameters:", queryString);

    const paramStr = `${serverTimestamp}${apiKey}${params.recv_window}${queryString}`;
    console.log("Generated Param String:", paramStr);

    const signature = crypto
      .createHmac("sha256", apiSecret)
      .update(paramStr)
      .digest("hex");
    console.log("Generated Signature (SHA256):", signature);
    const headers = {
      "X-BAPI-API-KEY": apiKey,
      "X-BAPI-TIMESTAMP": serverTimestamp,
      "X-BAPI-RECV-WINDOW": params.recv_window,
      "X-BAPI-SIGN": signature,
    };

    console.log("Request Headers:", headers);

    const config = {
      method: "post",
      url: "https://api.bybit.com/v5/position/switch-isolated",
      headers: headers,
      data: params,
    };

    const response = await axios(config);
    console.log("API Response:", response.data);

    res.json(response.data);

  } catch (error) {
    console.error("Error in Bybit API request:", error);
    res.status(500).json({ message: "Error switching margin mode", error });
  }
};





export const getIntegratedMode = async (req: Request, res: Response): Promise<void> => {
  try {

    const apiKey = process.env.BYBIT_API_KEY; 
    const apiSecret = process.env.BYBIT_API_SECRET; 

    if (!apiKey || !apiSecret) {
      res.status(500).json({ message: "API Key or API Secret is missing" });
      return;
    }

    const marketTimeResponse = await axios.get('https://api.bybit.com/v5/market/time');
    const serverTimestamp = marketTimeResponse.data.result.timeNano.toString().slice(0, 13);
    console.log("Server Timestamp (in ms):", serverTimestamp);

    if (!serverTimestamp) {
      res.status(500).json({ message: "Unable to fetch server timestamp" });
      return;
    }

    const client = new RestClientV5({
      testnet: true,
      key: apiKey,
      secret: apiSecret,
    });

    const tradingStopResponse = await client.setTradingStop({
      category: 'linear',
      symbol: 'XRPUSDT',
      takeProfit: '0.6',
      stopLoss: '0.2',
      tpTriggerBy: 'MarkPrice',
      slTriggerBy: 'IndexPrice',
      tpslMode: 'Partial',
      tpOrderType: 'Limit',
      slOrderType: 'Limit',
      tpSize: '50',
      slSize: '50',
      tpLimitPrice: '0.57',
      slLimitPrice: '0.21',
      positionIdx: 0,
    });

    console.log("Trading Stop Response:", tradingStopResponse);


    const data = {
      category: 'linear',
      symbol: 'ETHUSDT',
      coin: 'USDT',
      mode: 0,  
    };

    const recvWindow = '20000'; 
    const params = { ...data, timestamp: serverTimestamp, recv_window: recvWindow };
    const queryString = Object.keys(params)
      .map((key) => `${key}=${params[key as keyof typeof params]}`)
      .join('&');

    const signature = crypto
      .createHmac('sha256', apiSecret)
      .update(serverTimestamp + apiKey + queryString)
      .digest('hex');

    const headers = {
      'X-BAPI-API-KEY': apiKey,
      'X-BAPI-TIMESTAMP': serverTimestamp,
      'X-BAPI-RECV-WINDOW': recvWindow,
      'X-BAPI-SIGN': signature,
    };

    const switchModeConfig = {
      method: 'post',
      url: 'https://api.bybit.com/v5/position/switch-mode',
      headers: headers,
      data: queryString,
    };

    const switchModeResponse = await axios(switchModeConfig);
    console.log("Switch Mode Response:", switchModeResponse.data);

    res.json({
      tradingStopResponse,
      switchModeResponse: switchModeResponse.data,
    });
    
  } catch (error) {
    console.error("Error in integrated mode:", error);
    res.status(500).json({ message: "Error integrating Bybit API", error });
  }
};
