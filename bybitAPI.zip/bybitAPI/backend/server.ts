import app from "./app";
import dotenv from "dotenv";
import sequelize from "./config/database";
dotenv.config();
// dotenv.config({ path: `./config/.env.${process.env.NODE_ENV}` });

const PORT = process.env.PORT || 3000;

sequelize.sync({ alter: false })
  .then(() => {
    console.log('Database synchronized');
    app.listen(PORT, () => {
      console.log(`Server is running on port ${PORT}`);
    });
  })
  .catch((error) => {
    console.error('Unable to synchronize the database:', error);
  });