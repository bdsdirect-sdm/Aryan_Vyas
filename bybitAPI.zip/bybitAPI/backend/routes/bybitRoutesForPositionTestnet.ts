import express from "express";
import { getMarketTimeTestnet, getBybitPositionsTestnet, setLeverageTestnet, switchCrossOrIsolatedMarginTestnet, setTakeProfitStopLossTestnet, switchModeTestnet, setRiskLimitTestnet, setTradingStopTestnet, setAutoAddMarginTestnet, addOrReduceMarginTestnet, getExecutionTestnet, getClosePnLTestnet } from "../controllers/bybitControllerForPositionTestnet";

const routerForPositionTestnet = express.Router();

routerForPositionTestnet.get("/bybit/getMarketTimeTestnet", getMarketTimeTestnet);
routerForPositionTestnet.get("/bybit/getPositionsTestnet", getBybitPositionsTestnet);
routerForPositionTestnet.post("/bybit/setLeverageTestnet", setLeverageTestnet);
routerForPositionTestnet.post("/bybit/switchCrossOrIsolatedMarginTestnet", switchCrossOrIsolatedMarginTestnet)
routerForPositionTestnet.post("/bybit/setTakeProfitStopLossTestnet", setTakeProfitStopLossTestnet);
routerForPositionTestnet.post("/bybit/switchModeTestnet", switchModeTestnet);
routerForPositionTestnet.post("/bybit/setRiskLimitTestnet", setRiskLimitTestnet);
routerForPositionTestnet.post("/bybit/setTradingStopTestnet", setTradingStopTestnet);
routerForPositionTestnet.post("/bybit/setAutoAddMarginTestnet", setAutoAddMarginTestnet);
routerForPositionTestnet.post("/bybit/addOrReduceMarginTestnet", addOrReduceMarginTestnet);
routerForPositionTestnet.get("/bybit/getExecutionTestnet", getExecutionTestnet);
routerForPositionTestnet.get("/bybit/getClosePnLTestnet", getClosePnLTestnet);

export default routerForPositionTestnet;