import express from "express";
import { getBybitPositions,getIntegratedMode,getMarketTime, setLeverage, switchCrossOrIsolatedMargin } from "../controllers/bybitController";

const router = express.Router();

router.get("/bybit/market-time", getMarketTime);
router.get("/bybit/positions", getBybitPositions);
router.post("/bybit/setLeverage",setLeverage);
router.post("/bybit/switchCrossOrIsolatedMargin",switchCrossOrIsolatedMargin);
router.post("/bybit/getIntegratedMode",getIntegratedMode)
export default router;
