import express from "express";
import { getMarketTimeTestnet, placeOrderTestnet, amendOrderTestnet, cancelOrderTestnet, getOpenOrderTestnet, cancelAllOrdersTestnet, getOrderHistoryTestnet, batchPlaceOrderTestnet, batchAmendOrderTestnet, batchCancelOrderTestnet, getBorrowQuotaTestnet } from "../controllers/bybitControllerForTradeTestnet";

const routerForTradeTestnet = express.Router();

routerForTradeTestnet.get("/bybit/getMarketTimeTestnet", getMarketTimeTestnet);
routerForTradeTestnet.post("/bybit/placeOrderTestnet", placeOrderTestnet);
routerForTradeTestnet.post("/bybit/amendOrderTestnet", amendOrderTestnet);
routerForTradeTestnet.post("/bybit/cancelOrderTestnet", cancelOrderTestnet);
routerForTradeTestnet.get("/bybit/getOpenOrderTestnet", getOpenOrderTestnet);
routerForTradeTestnet.post("/bybit/cancelAllOrdersTestnet", cancelAllOrdersTestnet);
routerForTradeTestnet.get("/bybit/getOrderHistoryTestnet", getOrderHistoryTestnet);
routerForTradeTestnet.post("/bybit/batchPlaceOrderTestnet", batchPlaceOrderTestnet);
routerForTradeTestnet.post("/bybit/batchAmendOrderTestnet", batchAmendOrderTestnet);
routerForTradeTestnet.post("/bybit/batchCancelOrderTestnet", batchCancelOrderTestnet);
routerForTradeTestnet.get("/bybit/getBorrowQuotaTestnet", getBorrowQuotaTestnet);

export default routerForTradeTestnet;