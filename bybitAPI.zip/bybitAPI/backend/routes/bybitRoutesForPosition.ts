import express from "express";
import { getBybitPositions, switchMode, getMarketTime, setLeverage, switchCrossOrIsolatedMargin, setTakeProfitStopLoss, setRiskLimit, setTradingStop, setAutoAddMargin, addOrReduceMargin, getExecution, getClosePnL } from "../controllers/bybitControllerForPosition";

const routerForPosition = express.Router();

routerForPosition.get("/bybit/market-time", getMarketTime);
routerForPosition.get("/bybit/positions", getBybitPositions);
routerForPosition.post("/bybit/setLeverage", setLeverage);
routerForPosition.post("/bybit/switchCrossOrIsolatedMargin", switchCrossOrIsolatedMargin);
routerForPosition.post("/bybit/setTakeProfitStopLoss", setTakeProfitStopLoss);
routerForPosition.post("/bybit/switchMode", switchMode);
routerForPosition.post("/bybit/setRiskLimit", setRiskLimit);
routerForPosition.post("/bybit/setTradingStop", setTradingStop);
routerForPosition.post("/bybit/setAutoAddMargin", setAutoAddMargin);
routerForPosition.post("/bybit/addOrReduceMargin", addOrReduceMargin);
routerForPosition.get("/bybit/getExecution", getExecution);
routerForPosition.get("/bybit/getClosePnL", getClosePnL);

export default routerForPosition;