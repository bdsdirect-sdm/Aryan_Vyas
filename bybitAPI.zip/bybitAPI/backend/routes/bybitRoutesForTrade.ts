import express from "express";
import { getMarketTime,placeOrder,amendOrder,cancelOrder,getOpenOrder,cancelAllOrders,getOrderHistory,batchPlaceOrder,batchAmendOrder,batchCancelOrder,getBorrowQuota } from "../controllers/bybitControllerForTrade";

const routerForTrade = express.Router();

routerForTrade.get("/bybit/getMarketTime", getMarketTime);
routerForTrade.post("/bybit/placeOrder", placeOrder);
routerForTrade.post("/bybit/amendOrder", amendOrder);
routerForTrade.post("/bybit/cancelOrder", cancelOrder);
routerForTrade.get("/bybit/getOpenOrder", getOpenOrder);
routerForTrade.post("/bybit/cancelAllOrders", cancelAllOrders);
routerForTrade.get("/bybit/getOrderHistory", getOrderHistory);
routerForTrade.post("/bybit/batchPlaceOrder", batchPlaceOrder);
routerForTrade.post("/bybit/batchAmendOrder", batchAmendOrder);
routerForTrade.post("/bybit/batchCancelOrder", batchCancelOrder);
routerForTrade.get("/bybit/getBorrowQuota", getBorrowQuota);
export default routerForTrade;
