import axios from "axios";

const BYBIT_BASE_URL = "https://api.bybit.com/v5";

const bybitApi = axios.create({
    baseURL: BYBIT_BASE_URL,
});

export { bybitApi, BYBIT_BASE_URL };
