import axios from "axios";

const BYBIT_TESTNET_BASE_URL = "https://api-testnet.bybit.com/v5";

const bybitApi = axios.create({
    baseURL: BYBIT_TESTNET_BASE_URL,
});

export { bybitApi, BYBIT_TESTNET_BASE_URL };
