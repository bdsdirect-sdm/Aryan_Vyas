import express, { Request, Response } from "express";
import path from "path";
import cors from "cors";
import router from "./routes/bybitRoutes";
import dotenv from "dotenv";
dotenv.config({ path: `./config/.env.${process.env.NODE_ENV}` });


const app = express();

// Middleware
app.use(cors({ origin: "*" }));
app.use(express.json());

// Routes
app.use("/api/v1", router);

// Static file serving
app.use(
  "/uploads",
  express.static(path.join(__dirname, "uploads"), {
    setHeaders: (res) => {
      res.set("Cross-Origin-Resource-Policy", "cross-origin");
    },
  })
);

console.log(path.join(__dirname, "uploads"));

export default app;
