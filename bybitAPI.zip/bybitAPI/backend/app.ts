import express, { Request, Response } from "express";
import path from "path";
import cors from "cors";
import routerForPosition from "./routes/bybitRoutesForPosition";
import routerForTrade from "./routes/bybitRoutesForTrade";
import dotenv from "dotenv";
import routerForTradeTestnet from "./routes/bybitRoutesForTradeTestnet";
import routerForPositionTestnet from "./routes/bybitRoutesForPositionTestnet";
dotenv.config({ path: `./config/.env.${process.env.NODE_ENV}` });

const app = express();

// Middleware
app.use(cors({ origin: "*" }));
app.use(express.json());

// Routes
app.use("/api/v1", routerForTrade);
app.use("/api/v1", routerForPosition);
app.use("/api/v1", routerForTradeTestnet);
app.use("/api/v1", routerForPositionTestnet)

// Static file serving
app.use(
  "/uploads",
  express.static(path.join(__dirname, "uploads"), {
    setHeaders: (res) => {
      res.set("Cross-Origin-Resource-Policy", "cross-origin");
    },
  })
);

console.log(path.join(__dirname, "uploads"));

export default app;