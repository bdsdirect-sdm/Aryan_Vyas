import React, { useState } from 'react';
import { Formik, Field, Form, ErrorMessage } from 'formik';
import { useMutation } from '@tanstack/react-query';
import * as yup from 'yup';
import { useNavigate, Link } from 'react-router-dom';
import { toast } from 'react-toastify';
import { signupUser } from '../../API/Auth';

const Signup: React.FC = () => {
  const navigate = useNavigate();
  const [btnLoading, setBtnLoading] = useState(false);

  const signupMutation = useMutation({
    mutationKey: ['signup'],
    mutationFn: signupUser,
    onSuccess: (data) => {
      toast.success(data?.message || 'Signup successful');
      navigate('/auth/login');
    },
    onError: (err: any) => {
      toast.error(err.response?.data?.message || 'Something went wrong');
    },
  });
  return (
    <div>
      <h1>Signup</h1>
      <Formik
        initialValues={{
          firstName: '',
          lastName: '',
          email: '',
          password: '',
          confirmPassword: '',
          userType: 'retailer',
        }}
        validationSchema={yup.object({
          firstName: yup
            .string()
            .max(20, 'Must be 20 characters or less')
            .required('First Name is required')
            .matches(/^$|^\S+.*/, 'Only blank spaces are not valid.'),
          lastName: yup
            .string()
            .max(20, 'Must be 20 characters or less')
            .required('Last Name is required')
            .matches(/^$|^\S+.*/, 'Only blank spaces are not valid.'),
          email: yup
            .string()
            .email('Invalid email format')
            .required('Email is required')
            .matches(/^$|^\S+.*/, 'Only blank spaces are not valid.'),
          password: yup
            .string()
            .min(8, 'Password must be at least 8 characters long')
            .required('Password is required')
            .matches(
              /[a-z]/,
              'Password must contain at least one lowercase letter',
            )
            .matches(
              /[A-Z]/,
              'Password must contain at least one uppercase letter',
            )
            .matches(/\d/, 'Password must contain at least one number')
            .matches(
              /[`~!@#$%^&*()"?<>|:{}(),.]/,
              'Password must contain at least one special Character',
            ),
          confirmPassword: yup
            .string()
            .required('Confirm Password is required')
            .oneOf([yup.ref('password')], 'Passwords must match'),
          userType: yup
            .string()
            .oneOf(
              ['retailer', 'customer'],
              'User Type must be either retailer or customer',
            )
            .required('User Type is required'),
        })}
        onSubmit={(values, { setSubmitting }) => {
          setBtnLoading(true);
          const { confirmPassword, ...data } = values;
          signupMutation.mutate({
            ...data,
            email: data.email.toLowerCase(),
          });
          setSubmitting(false);
        }}
      >
        {({ isSubmitting }) => (
          <Form>
            <div>
              <Field name="firstName" type="text" placeholder="First Name" />
              <ErrorMessage
                name="firstName"
                component="div"
                className="error"
              />
            </div>
            <div>
              <Field name="lastName" type="text" placeholder="Last Name" />
              <ErrorMessage name="lastName" component="div" className="error" />
            </div>
            <div>
              <Field name="email" type="email" placeholder="Email" />
              <ErrorMessage name="email" component="div" className="error" />
            </div>
            <div>
              <Field name="password" type="password" placeholder="Password" />
              <ErrorMessage name="password" component="div" className="error" />
            </div>
            <div>
              <Field
                name="confirmPassword"
                type="password"
                placeholder="Confirm Password"
              />
              <ErrorMessage
                name="confirmPassword"
                component="div"
                className="error"
              />
            </div>
            <div>
              <label htmlFor="userType">User Type</label>
              <Field as="select" name="userType">
                <option value="retailer">Retailer</option>
                <option value="customer">Customer</option>
              </Field>
              <ErrorMessage name="userType" component="div" className="error" />
            </div>
            <button type="submit" disabled={isSubmitting || btnLoading}>
              {btnLoading ? 'Signing Up...' : 'Sign Up'}
            </button>
          </Form>
        )}
      </Formik>
      <Link to="/auth/login">Already have an account? Login</Link>
    </div>
  );
};

export default Signup;
