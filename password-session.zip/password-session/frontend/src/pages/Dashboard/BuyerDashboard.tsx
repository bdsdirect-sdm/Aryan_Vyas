import React from 'react';

const BuyerDashboard = () => {
  return <div>Buyer Dashboard</div>;
};

export default BuyerDashboard;
