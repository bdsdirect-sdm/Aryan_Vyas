import React from 'react';

const RetailerDashBoard = () => {
  return <div>Retailer DashBoard</div>;
};

export default RetailerDashBoard;
