import React, { useState } from 'react';
import * as yup from 'yup';
import { useFormik } from 'formik';
import { useMutation } from '@tanstack/react-query';
import { Link, useNavigate } from 'react-router-dom';
import { loginUser } from '../../API/Auth';
import storage from '../../utils/storage';
import { toast } from 'react-toastify';
import { Button } from '@mui/material';

const Login: React.FC = () => {
  const navigate = useNavigate();
  const [btnLoading, setBtnLoading] = useState(false);

  const loginMutation = useMutation({
    mutationKey: ['login'],
    mutationFn: loginUser,
    onSuccess: (res: any) => {
      console.log('user data', res.data);
      toast.success(res?.data?.message || 'Login successful');
      storage.setToken(res?.data?.token);
      storage.setUser(res?.data);

      if (res?.data?.userType === 'retailer') {
        navigate('/app/retailerdashboard');
      } else if (res?.data?.userType === 'customer') {
        navigate('/app/buyerdashboard');
      } else if (res?.data?.userType === 'admin') {
        navigate('/app/admindashboard');
      } else {
        navigate('/app/retailerdashboard');
      }
    },
    onError: (err: any) => {
      toast.error(err?.response?.data?.message || 'Login failed');
    },
  });

  const formik = useFormik({
    initialValues: {
      email: '',
      password: '',
    },
    validationSchema: yup.object({
      email: yup
        .string()
        .email('Invalid email format')
        .required('Email is required')
        .matches(/^$|^\S+.*/, 'Only blank spaces are not valid.'),
      password: yup
        .string()
        .required('Password is required')
        .matches(
          /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*])(?=.{8,})/,
          'Must contain at least 8 characters, one uppercase, one lowercase, one number, and one special character.',
        ),
    }),
    onSubmit: async (values) => {
      setBtnLoading(true);
      loginMutation.mutate({
        email: values.email.toLowerCase(),
        password: values.password,
      });
      setBtnLoading(false);
    },
  });

  return (
    <form className="auth-form" onSubmit={formik.handleSubmit}>
      <div className="input-field">
        <label htmlFor="email">User Email</label>
        <input
          type="email"
          id="email"
          name="email"
          placeholder="User email"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          value={formik.values.email}
          className={formik.touched.email && formik.errors.email ? 'error' : ''}
        />
        {formik.touched.email && formik.errors.email && (
          <div className="error-text">{formik.errors.email}</div>
        )}
      </div>

      <div className="input-field">
        <label htmlFor="password">Password</label>
        <input
          type="password"
          id="password"
          name="password"
          placeholder="Password"
          onChange={formik.handleChange}
          onBlur={formik.handleBlur}
          value={formik.values.password}
          className={
            formik.touched.password && formik.errors.password ? 'error' : ''
          }
        />
        {formik.touched.password && formik.errors.password && (
          <div className="error-text">{formik.errors.password}</div>
        )}
      </div>

      <div className="forget-div">
        <Link to="/auth/forgot-password" title="Forgot Password">
          Forgot Password?
        </Link>
      </div>

      <div className="btn-wrap">
        <Button
          type="submit"
          className="custom-btn"
          style={{ width: '100%' }}
          disabled={btnLoading}
        >
          {btnLoading ? 'Logging in...' : 'Login'}
        </Button>
      </div>

      <div className="privacy-div">
        <p>
          {"Don't have an account?"}
          <span>
            <Link to="/auth/signup" title="signup">
              Sign up
            </Link>
          </span>
        </p>
      </div>
    </form>
  );
};

export default Login;
