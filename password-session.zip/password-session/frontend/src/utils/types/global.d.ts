export interface Style {}

export type BaseEntity = {
  id: string;
  createdAt: number;
};

export type Address = {
  uuid?: string;
  street: string;
  city: string;
  state: string;
  country: string;
  zipCode: string;
  addressTitle: string;
  phoneNumber: string;
  faxNumber: string;
};

export type UserType = 'admin' | 'customer' | 'retailer';

export type User = {
  id: number;
  uuid: string;
  firstName: string;
  lastName: string;
  fullName: string;
  email: string;
  dob: string;
  phoneNumber: string;
  gender: string;
  userType: UserType;
  profileImage: string | null;
  status: boolean;
  isVerified: boolean;
  isDeleted: boolean;
  deletedAt: string | null;
  createdAt: string;
  updatedAt: string;
  role: 'retailer' | 'cudtomer' | 'admin';
  location: string;
  addresses: Address[];
  hasAddress: boolean;
  userId: number;
} & BaseEntity;

export interface APIResponse {
  status: number;
  message: string;
  data: any;
}

export interface TableActionsMethod {
  action: string;
  data: any;
}

export type ParamsType = {
  search?: string;
  sort?: string;
  order?: string;
  page?: number;
  limit?: number;
  isDashboard?: boolean;
};
