import axios from 'axios';
import { UserResponse } from '../types';
import envConfig from '../../enviroment';

export type SignupCredentialsDTO = {
  email: string;
  password: string;
  firstName: string;
  lastName: string;
  userType: string;
};
export type LoginCredentialsDTO = {
  email: string;
  password: string;
};

export const signupUser = (
  data: SignupCredentialsDTO,
): Promise<UserResponse> => {
  return axios.post(`${envConfig.apiUrl}/auth/register`, data);
};
export const loginUser = (data: LoginCredentialsDTO): Promise<UserResponse> => {
  return axios.post(`${envConfig.apiUrl}/auth/login`, data);
};
