import { User } from '../utils/types/global';

export type UserResponse = {
  message: string;
  data: any;
  token: string;
  user: User;
};
