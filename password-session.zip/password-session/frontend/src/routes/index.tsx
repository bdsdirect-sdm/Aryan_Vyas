import React, { lazy, Suspense, useEffect } from 'react';
import {
  Route,
  Routes,
  Navigate,
  useLocation,
  useNavigate,
} from 'react-router-dom';
import storage from '../utils/storage';
import { FullPageSpinner } from '../components/common/Spinner/fullPageSpinner';
import AdminDashboard from '../pages/Dashboard/AdminDashboard';

const Signup = lazy(() => import('../pages/Signup/Signup'));
const Login = lazy(() => import('../pages/Login/Login'));
const BuyerDashboard = lazy(() => import('../pages/Dashboard/BuyerDashboard'));
const RetailerDashboard = lazy(
  () => import('../pages/Dashboard/RetailerDashBoard'),
);
const Unauthorized = lazy(() => import('../pages/Unauthorized/Unauthorized'));

interface RouteItem {
  path: string;
  element: React.ReactElement;
}

const authRoutes: RouteItem[] = [
  {
    path: '/auth/login',
    element: <Login />,
  },
  {
    path: '/auth/signup',
    element: <Signup />,
  },
];

const protectedRoutes: RouteItem[] = [
  {
    path: '/app/buyerdashboard',
    element: <BuyerDashboard />,
  },
  {
    path: '/app/retailerdashboard',
    element: <RetailerDashboard />,
  },
  {
    path: '/app/admindashboard',
    element: <AdminDashboard />,
  },
];

export default function AppRoutes() {
  const navigate = useNavigate();
  const location = useLocation();
  const isUserLogedIn = !!storage.getToken();
  const navigatePath = isUserLogedIn ? '/app/dashboard' : '/auth/login';

  useEffect(() => {
    // Only navigate if the user tries to access a route that's not defined
    if (
      ![...authRoutes, ...protectedRoutes]
        .map((item) => item.path)
        .includes(location.pathname) &&
      location.pathname !== '/unauthorized' // Prevent redirect loop for unauthorized route
    ) {
      navigate(navigatePath);
    }
  }, [isUserLogedIn, location.pathname, navigate]);

  return (
    <Routes>
      {/* Auth Routes */}
      {authRoutes.map((route, index) => (
        <Route
          key={index}
          path={route.path}
          element={
            isUserLogedIn ? <Navigate to="/app/dashboard" /> : route.element
          }
        />
      ))}

      {/* Protected Routes */}
      {isUserLogedIn && (
        <Route>
          {protectedRoutes.map((route, index) => (
            <Route
              key={index}
              path={route.path}
              element={
                <Suspense fallback={<FullPageSpinner />}>
                  {route.element}
                </Suspense>
              }
            />
          ))}
          {/* Redirect to /app/dashboard if user is logged in */}
          <Route path="/app" element={<Navigate to={navigatePath} />} />
        </Route>
      )}

      {/* Unauthorized Route */}
      <Route path="/unauthorized" element={<Unauthorized />} />

      {/* Fallback for unknown routes */}
      <Route path="*" element={<Navigate to={navigatePath} />} />
    </Routes>
  );
}
