import { Request, Response } from "express";
import { StatusCodes } from "../utils/statusCodes";
import { StatusMessages } from "../utils/statusMessages";
import { Users, Products, ProductRatings } from "../models";
import { v4 as uuidv4 } from "uuid";
import { ratingValidation } from '../validations/rating.validation';
import dotenv from "dotenv";
dotenv.config({ path: `./config/.env.${process.env.NODE_ENV}` });

export const createOrUpdateRating = async (req: Request, res: Response): Promise<void> => {
    try {
        const { error } = ratingValidation.validate(req.body);
        if (error) {
             res.status(StatusCodes.BAD_REQUEST).json({
                status: StatusMessages.BAD_REQUEST,
                message: error.details[0].message,
            });
            return;
        }
        const { rating, productId } = req.body;
        const user = req.user as Users;
        console.log("user>>>>>>>>>", user);

        if (!user) {
            res.status(StatusCodes.UNAUTHORIZED).json({
                status: StatusMessages.UNAUTHORIZED,
                message: "Access Denied",
            });
            return;
        }

        if (user.userType !== 'customer') {
            res.status(StatusCodes.FORBIDDEN).json({
                status: StatusMessages.FORBIDDEN,
                message: "Only customers can rate products",
            });
            return;
        }

        const product = await Products.findOne({
            where: {
                id: productId,
            },
        });

        if (!product) {
            res.status(StatusCodes.NOT_FOUND).json({
                status: StatusMessages.NOT_FOUND,
                message: "Product not found",
            });
            return;
        }

        const ratingExist = await ProductRatings.findOne({
            where: {
                userId: user.id,
                productId,
            },
        });

        if (ratingExist) {
            ratingExist.rating = rating;
            await ratingExist.save();

            res.status(StatusCodes.OK).json({
                status: StatusMessages.OK,
                message: "Rating updated successfully",
            });
        } else {
            await ProductRatings.create({
                id: uuidv4(),
                userId: user.id,
                productId,
                rating,
            });

            res.status(StatusCodes.CREATED).json({
                status: StatusMessages.CREATED,
                message: "Rating created successfully",
            });
        }
    } catch (error) {
        const errorMessage = (error instanceof Error) ? error.message : "An unknown error occurred";
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            status: StatusMessages.INTERNAL_SERVER_ERROR,
            message: errorMessage,
        });
    }
};