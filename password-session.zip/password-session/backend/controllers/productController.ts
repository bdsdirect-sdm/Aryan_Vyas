import { Request, Response } from "express";
import bcrypt from "bcrypt";
import { StatusCodes } from "../utils/statusCodes";
import { StatusMessages } from "../utils/statusMessages";
import { Users, Products, ProductRatings } from "../models";
import { v4 as uuidv4 } from "uuid";
import { createProductValidation } from "../validations/createProduct.validation";
import jwt from "jsonwebtoken";
import dotenv from "dotenv";
import { Op } from "sequelize";
dotenv.config({ path: `./config/.env.${process.env.NODE_ENV}` });

// export const createOrUpdateProduct = async (req: Request, res: Response): Promise<void> => {
//     try {
//         const { error } = createProductValidation.validate(req.body);
//         if (error) {
//             res.status(StatusCodes.BAD_REQUEST).json({
//                 status: "BAD_REQUEST",
//                 message: error.details[0].message,
//             });
//             return;
//         }

//         const { name, description, price, stock, category, brand } = req.body;
//         const user = req.user as Users;

//         console.log("User in request:", user);

//         if (!user) {
//             res.status(StatusCodes.UNAUTHORIZED).json({
//                 status: "UNAUTHORIZED",
//                 message: "User not found",
//             });
//             return;
//         }

//         if (user.userType !== "retailer") {
//             res.status(StatusCodes.FORBIDDEN).json({
//                 status: "FORBIDDEN",
//                 message: "Only retailers can add or update products",
//             });
//             return;
//         }

//         const imgPath = req.file ? req.file.path : null;
//         let parsedPrice: number;

//         if (price.includes(".")) {
//             parsedPrice = parseFloat(price.trim());
//         } else {
//             parsedPrice = parseInt(price.trim(), 10);
//         }

//         if (isNaN(parsedPrice)) {
//             res.status(StatusCodes.BAD_REQUEST).json({
//                 status: "BAD_REQUEST",
//                 message: "Invalid price value",
//             });
//             return;
//         }

//         console.log("Parsed Price:", parsedPrice);


//         const existingProduct = await Products.findOne({
//             where: { sellerId: user.id, name, brand },
//         });

//         if (existingProduct) {

//             await existingProduct.update({
//                 description,
//                 price: parsedPrice,
//                 stock,
//                 category,
//                 productImage: imgPath || existingProduct.productImage,
//             });

//             console.log("Product updated:", existingProduct);
//             res.json({
//                 status: "OK",
//                 message: "Product updated successfully",
//                 product: existingProduct,
//             });
//         } else {

//             const newProduct = await Products.create({
//                 name,
//                 description,
//                 price: parsedPrice,
//                 stock,
//                 category,
//                 brand,
//                 sellerId: user.id,
//                 productImage: imgPath,
//             });

//             console.log("Product created:", newProduct);
//             res.json({
//                 status: "OK",
//                 message: "Product added successfully",
//                 product: newProduct,
//             });
//         }
//     } catch (error) {
//         console.error("Error in adding/updating product:", error);
//         res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
//             status: "INTERNAL_SERVER_ERROR",
//             message: (error as Error).message,
//         });
//     }
// };

export const createProduct = async (req: Request, res: Response): Promise<void> => {
    try {
        const { error } = createProductValidation.validate(req.body);
        if (error) {
            res.status(StatusCodes.BAD_REQUEST).json({
                status: "BAD_REQUEST",
                message: error.details[0].message,
            });
            return;
        }

        const { name, description, price, stock, category, brand } = req.body;
        const user = req.user as Users;

        if (!user) {
            res.status(StatusCodes.UNAUTHORIZED).json({
                status: "UNAUTHORIZED",
                message: "User not found",
            });
            return;
        }

        if (user.userType !== "retailer") {
            res.status(StatusCodes.FORBIDDEN).json({
                status: "FORBIDDEN",
                message: "Only retailers can add products",
            });
            return;
        }

        const imgPath = req.file ? req.file.path : null;
        let parsedPrice: number;

        if (price.includes(".")) {
            parsedPrice = parseFloat(price.trim());
        } else {
            parsedPrice = parseInt(price.trim(), 10);
        }

        if (isNaN(parsedPrice)) {
            res.status(StatusCodes.BAD_REQUEST).json({
                status: "BAD_REQUEST",
                message: "Invalid price value",
            });
            return;
        }

        const newProduct = await Products.create({
            name,
            description,
            price: parsedPrice,
            stock,
            category,
            brand,
            sellerId: user.id,
            productImage: imgPath,
        });

        res.json({
            status: "OK",
            message: "Product added successfully",
            product: newProduct,
        });
    } catch (error) {
        console.error("Error in creating product:", error);
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            status: "INTERNAL_SERVER_ERROR",
            message: (error as Error).message,
        });
    }
};

export const updateProduct = async (req: Request, res: Response): Promise<void> => {
    try {
        const { id } = req.params;
        const { name, description, price, stock, category, brand, productImage } = req.body;
        const user = req.user as Users;

        if (!user) {
            res.status(StatusCodes.UNAUTHORIZED).json({
                status: "UNAUTHORIZED",
                message: "User not found",
            });
            return;
        }

        if (user.userType !== "retailer") {
            res.status(StatusCodes.FORBIDDEN).json({
                status: "FORBIDDEN",
                message: "Only retailers can update products",
            });
            return;
        }

        const product = await Products.findOne({
            where: { id, sellerId: user.id },
        });

        if (!product) {
            res.status(StatusCodes.NOT_FOUND).json({
                status: "NOT_FOUND",
                message: "Product not found or unauthorized",
            });
            return;
        }

        const imgPath = req.file ? req.file.path : product.productImage;
        let parsedPrice: number;

        if (price.includes(".")) {
            parsedPrice = parseFloat(price.trim());
        } else {
            parsedPrice = parseInt(price.trim(), 10);
        }

        if (isNaN(parsedPrice)) {
            res.status(StatusCodes.BAD_REQUEST).json({
                status: "BAD_REQUEST",
                message: "Invalid price value",
            });
            return;
        }


        await product.update({
            name,
            description,
            price: parsedPrice,
            stock,
            category,
            brand,
            productImage: imgPath,
        });

        res.json({
            status: "OK",
            message: "Product updated successfully",
            product,
        });
    } catch (error) {
        console.error("Error in updating product:", error);
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            status: "INTERNAL_SERVER_ERROR",
            message: (error as Error).message,
        });
    }
};

export const deleteProduct = async (req: Request, res: Response): Promise<void> => {
    try {
        const { id } = req.params;
        const user = req.user as Users;

        if (!user) {
            res.status(StatusCodes.UNAUTHORIZED).json({
                status: "UNAUTHORIZED",
                message: "User not found",
            });
            return;
        }
        if (user.userType !== "retailer") {
            res.status(StatusCodes.FORBIDDEN).json({
                status: "FORBIDDEN",
                message: "Only retailers can delete products",
            });
            return;
        }

        const product = await Products.findOne({ where: { id, sellerId: user.id } });

        if (!product) {
            res.status(StatusCodes.NOT_FOUND).json({
                status: "NOT_FOUND",
                message: "Product not found or unauthorized",
            });
            return;
        }

        await product.destroy();

        res.json({
            status: "OK",
            message: "Product deleted successfully",
        });
    } catch (error) {
        console.error("Error in deleting product:", error);
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            status: "INTERNAL_SERVER_ERROR",
            message: (error as Error).message,
        });
    }
};

export const getProductsForRetailer = async (req: Request, res: Response): Promise<void> => {
    try {
        const user = req.user as Users;

        if (!user) {
            res.status(StatusCodes.UNAUTHORIZED).json({
                status: "UNAUTHORIZED",
                message: "User not found",
            });
            return;
        }

        if (user.userType !== "retailer") {
            res.status(StatusCodes.FORBIDDEN).json({
                status: "FORBIDDEN",
                message: "Only retailers can view products",
            });
            return;
        }

        const searchQuery = req.query.search as string || "";
        const page = parseInt(req.query.page as string) || 1;
        const limit = 10;
        const offset = (page - 1) * limit;

        const searchPrice = parseFloat(searchQuery);
        const isPriceValid = !isNaN(searchPrice);

        const products = await Products.findAndCountAll({
            where: {
                [Op.or]: [
                    { name: { [Op.like]: `%${searchQuery}%` } },
                    { description: { [Op.like]: `%${searchQuery}%` } },
                    { category: { [Op.like]: `%${searchQuery}%` } },
                    { brand: { [Op.like]: `%${searchQuery}%` } },
                    ...(isPriceValid
                        ? [{ price: { [Op.between]: [searchPrice - 0.00, searchPrice + 0.01] } }]
                        : []),
                ],
            },
            limit,
            offset,
            include: [
                {
                    model: ProductRatings,
                    as: "productRating",
                    include: [
                        {
                            model: Users,
                            as: "ratingUser",
                            attributes: ["firstName", "lastName"],
                        },
                    ],
                    attributes: ["rating", "createdAt", "updatedAt"],
                },
            ],
        });

        const totalPages = Math.ceil(products.count / limit);

        if (products.count === 0) {
            res.status(StatusCodes.NOT_FOUND).json({
                status: "NOT_FOUND",
                message: "No products found",
                products: [],
                currentPage: page,
                totalPages: 0,
                totalProducts: 0,
            });
            return;
        }

        res.json({
            status: "SUCCESS",
            products: products.rows,
            currentPage: page,
            totalPages,
            totalProducts: products.count,
        });

    } catch (error) {
        console.error("Error in getting products for retailer:", error);
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            status: "INTERNAL_SERVER_ERROR",
            message: (error as Error).message,
        });
    }
};

export const getProductsForCustomer = async (req: Request, res: Response): Promise<void> => {
    try {
        const user = req.user as Users;

        if (!user) {
            res.status(StatusCodes.UNAUTHORIZED).json({
                status: "UNAUTHORIZED",
                message: "User not found",
            });
            return;
        }

        if (user.userType !== "customer") {
            res.status(StatusCodes.FORBIDDEN).json({
                status: "FORBIDDEN",
                message: "Only customers can view products",
            });
            return;
        }

        const searchQuery = req.query.search || "";
        const page = parseInt(req.query.page as string) || 1;
        const limit = 10;
        const offset = (page - 1) * limit;

        const searchPrice = parseFloat(searchQuery as string);
        const isPriceValid = !isNaN(searchPrice);

        const products = await Products.findAndCountAll({
            where: {
                [Op.or]: [
                    { name: { [Op.like]: `%${searchQuery}%` } },
                    { description: { [Op.like]: `%${searchQuery}%` } },
                    { category: { [Op.like]: `%${searchQuery}%` } },
                    { brand: { [Op.like]: `%${searchQuery}%` } },
                    ...(isPriceValid
                        ? [{ price: { [Op.between]: [searchPrice - 0.01, searchPrice + 0.01] } }]
                        : []),
                ],
            },
            limit,
            offset,
            include: [
                {
                    model: Users,
                    as: "userProducts",
                    attributes: ["firstName", "lastName"],
                },
                {
                    model: ProductRatings,
                    as: "productRating",
                    attributes: ["rating", "createdAt", "updatedAt"],
                },
            ],
        });

        const totalPages = Math.ceil(products.count / limit);

        if (products.count === 0) {
            res.status(404).json({
                message: "Product not found",
                products: [],
                currentPage: page,
                totalPages,
                totalProducts: 0,
            });
            return;
        }

        res.json({
            products: products.rows,
            currentPage: page,
            totalPages,
            totalProducts: products.count,
        });

        console.log("Products for customer:", products);
    } catch (error) {
        console.error("Error in getting products for customer:", error);
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            status: "INTERNAL_SERVER_ERROR",
            message: (error as Error).message,
        });
    }
};
