import { Request, Response } from "express";
import bcrypt from "bcrypt";
import { StatusCodes } from "../utils/statusCodes";
import { StatusMessages } from "../utils/statusMessages";
import { Users, Products, Admins } from "../models";
import { v4 as uuidv4 } from "uuid";
import { adminRegisterValidation, adminLoginValidation } from "../validations/admin.auth.validation";
import { createProductValidation } from "../validations/createProduct.validation";
import { ratingValidation } from '../validations/rating.validation';
import jwt from "jsonwebtoken";
import dotenv from "dotenv";
dotenv.config({ path: `./config/.env.${process.env.NODE_ENV}` });

interface RegisterBody {
    adminFirstName: string;
    adminLastName: string;
    adminEmail: string;
    adminPassword: string;
}
interface LoginBody {
    adminEmail: string;
    adminPassword: string;
}
interface CreateProductBody {
    productName: string;
    productDescription: string;
    productPrice: number;
    productCategory: string;
    productBrand: string;
    productImage: string;
}
export const adminRegister = async (req: Request<{}, {}, RegisterBody>, res: Response): Promise<void> => {
    try {
        const { error } = adminRegisterValidation.validate(req.body);
        if (error) {
            res.status(StatusCodes.BAD_REQUEST).json({ message: error.details[0].message });
            return;
        }

        const { adminFirstName, adminLastName, adminEmail, adminPassword } = req.body;

        const emailExist = await Admins.findOne({
            where: {
                adminEmail,
            },
        });

        if (emailExist) {
            res.status(StatusCodes.BAD_REQUEST).json({
                message: "Email already exists",
            });
            return;
        }

        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(adminPassword, salt);

        const admin = await Admins.create({
            id: uuidv4(),
            adminFirstName,
            adminLastName,
            adminEmail,
            adminPassword: hashedPassword,
        });

        res.status(StatusCodes.CREATED).json({
            message: "Admin created successfully",
        });

    } catch (error) {
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            status: StatusMessages.INTERNAL_SERVER_ERROR,
            message: (error as Error).message,
        });
    }
};

export const adminLogin = async (req: Request, res: Response): Promise<void> => {
    try {
        const { error } = adminLoginValidation.validate(req.body);
        if (error) {
            res.status(StatusCodes.BAD_REQUEST).json({
                status: StatusMessages.BAD_REQUEST,
                message: error.details[0].message,
            });
            return;
        }

        const { adminEmail, adminPassword } = req.body;
        console.log("Received login request:", { adminEmail });

        const user = await Admins.findOne({
            where: { adminEmail },
        });

        if (!user) {
            console.log("Admin not found for email:", adminEmail);
            res.status(StatusCodes.UNAUTHORIZED).json({
                status: "UNAUTHORIZED",
                message: "Invalid email or password",
            });
            return;
        }

        // Check if the account is locked
        if (user.passwordLock && user.lockedUntil) {
            if (new Date() < new Date(user.lockedUntil)) {
                const timeLeft = Math.ceil((new Date(user.lockedUntil).getTime() - Date.now()) / (1000 * 60));
                console.log(`Account locked. Try again in ${timeLeft} minutes.`);
                res.status(StatusCodes.UNAUTHORIZED).json({
                    status: "UNAUTHORIZED",
                    message: `Your account is locked. Please try again after ${timeLeft} minutes.`,
                });
                return;
            } else {
                console.log("Lock expired. Resetting failed login attempts.");
                await user.update({
                    failedLoginAttempts: 0,
                    passwordLock: false,
                    lockedUntil: null,
                });
            }
        }

        // Compare password
        console.log("Comparing password...");
        const isValidPassword = await bcrypt.compare(adminPassword, user.adminPassword);

        if (!isValidPassword) {
            console.log("Invalid password for user:", adminEmail);

            const failedLoginAttempts = user.failedLoginAttempts + 1;
            let passwordLock = false;
            let lockedUntil: Date | null = null;

            if (failedLoginAttempts >= 3) {
                passwordLock = true;
                lockedUntil = new Date(Date.now() + 5 * 60 * 1000); // Lock for 5 minutes
                console.log("Password locked after 3 failed attempts.");
            }

            await user.update({
                failedLoginAttempts,
                passwordLock,
                lockedUntil,
            });

            res.status(StatusCodes.UNAUTHORIZED).json({
                status: "UNAUTHORIZED",
                message: "Invalid email or password",
            });
            return;
        }

        console.log("Password correct. Proceeding with login.");

        // Reset failed login attempts
        await user.update({
            failedLoginAttempts: 0,
            passwordLock: false,
            lockedUntil: null,
        });

        const JWT_SECRET_KEY = process.env.JWT_SECRET_KEY;

        if (!JWT_SECRET_KEY) {
            console.log("JWT secret not defined.");
            res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
                status: "INTERNAL_SERVER_ERROR",
                message: "JWT secret is not defined",
            });
            return;
        }

        const token = jwt.sign(
            {
                id: user.id,
                adminEmail: user.adminEmail,
            },
            JWT_SECRET_KEY,
            { expiresIn: "10h" }
        );

        console.log("JWT token generated:", token);

        res.json({
            status: "OK",
            message: "Logged in successfully",
            token,
        });
    } catch (error) {
        console.error("Error in login process:", error);
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            status: "INTERNAL_SERVER_ERROR",
            message: (error as Error).message,
        });
    }
};



