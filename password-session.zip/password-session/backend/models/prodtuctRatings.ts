import { DataTypes ,Model } from "sequelize";
import sequelize from "../config/database";
import Products from "./products";

class ProductRatings extends Model{
    public id!: string;
    public userId!: string;
    public productId!: string;
    public rating!: number;
}

ProductRatings.init({
    id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false
    },
    userId: {
        type: DataTypes.UUID,
        allowNull: false,
        references: {
            model: "users",
            key: "id",
        },
        onDelete: "CASCADE",
    },
    productId: {
        type: DataTypes.UUID,
        allowNull: false,
        references: {
            model: "products",
            key: "id",
        },
        onDelete: "CASCADE",
    },
    rating: {
        type: DataTypes.INTEGER,
        allowNull: false
    }
},{
    sequelize,
    modelName: 'productRatings',
    timestamps: true,
    // paranoid:true,
});

export default ProductRatings;