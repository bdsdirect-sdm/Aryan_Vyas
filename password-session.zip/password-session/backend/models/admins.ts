import { DataTypes, Model, Optional } from 'sequelize';
import sequelize from '../config/database';

class Admins extends Model {
  public id!: string;
  public adminFirstName!: string;
  public adminLastName!: string;
  public adminEmail!: string;
  public adminPassword!: string;
  public failedLoginAttempts!: number;
  public passwordLock!: boolean;
  public lockedUntil!: Date | null;
}

Admins.init(
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    adminFirstName: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    adminLastName: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    adminEmail: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
    adminPassword: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    failedLoginAttempts: {
      type: DataTypes.INTEGER,
      defaultValue: 0,
  },
  passwordLock: {
      type: DataTypes.BOOLEAN,
      defaultValue: false,
  },
  lockedUntil: {
      type: DataTypes.DATE,
      defaultValue: null,
  },
  },
  {
    sequelize,
    modelName: 'admins',
  }
);
console.log("Table Name>>>>>>>",Admins.getTableName());
export default Admins;