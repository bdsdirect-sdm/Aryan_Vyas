import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database';

class Products extends Model{
    public id!: string;
    public name!: string;
    public description!: string;
    public price!: number;
    public stock!: number;
    public image!: string;
    public category!: string;
    public brand!: string;
    public rating!: number;
}
Products.init({
    id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false
    },
    description: {
        type: DataTypes.STRING,
        allowNull: false
    },
    price: {
        type: DataTypes.FLOAT,
        allowNull: false
    },
    stock: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    image: {
        type: DataTypes.STRING,
        allowNull: false
    },
    category: {
        type: DataTypes.STRING,
        allowNull: false
    },
    brand: {
        type: DataTypes.STRING,
        allowNull: false
    },
    rating: {
        type: DataTypes.FLOAT,
        allowNull: false
    }
    },{
        sequelize,
        modelName: 'products',
    });
export default Products;