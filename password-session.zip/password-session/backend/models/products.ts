import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database';

class Products extends Model{
    public id!: string;
    public sellerId!: string;
    public name!: string;
    public description!: string;
    public price!: number;
    public stock!: number;
    public productImage!: string;
    public category!: string;
    public brand!: string;
}
Products.init({
    id: {
        type: DataTypes.UUID,
        defaultValue: DataTypes.UUIDV4,
        primaryKey: true,
        allowNull: false
    },
    sellerId: {
        type: DataTypes.UUID,
        allowNull: false,
        references: {
            model: "users",
            key: "id",
        },
        onDelete: "CASCADE",
    },
    name: {
        type: DataTypes.STRING,
        allowNull: false
    },
    description: {
        type: DataTypes.STRING,
        allowNull: false
    },
    price: {
        type: DataTypes.FLOAT,
        allowNull: false
    },
    stock: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    productImage: {
        type: DataTypes.STRING,
        allowNull: true
    },
    category: {
        type: DataTypes.STRING,
        allowNull: false
    },
    brand: {
        type: DataTypes.STRING,
        allowNull: false
    },
    },{
        sequelize,
        modelName: 'products',
        // paranoid:true,
    });

console.log("Table Name>>>>>>>",Products.getTableName());
export default Products;