import sequelize from "../config/database";
import Admin from "./admin";
import User from "./user";
import Products from "./products";


Admin.hasMany(User, {foreignKey: 'adminId', as: 'users'});
User.belongsTo(Admin, {foreignKey: 'adminId', as: 'userAdmin'});

User.hasMany(Products, {foreignKey: 'userId', as: 'products'});
Products.belongsTo(User, {foreignKey: 'userId', as:"userProducts"});

export {  sequelize,User, Products, Admin };
