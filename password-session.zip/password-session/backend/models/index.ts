import sequelize from "../config/database";
import Admins from "./admins";
import Users from "./users";
import Products from "./products";
import ProductRatings from "./prodtuctRatings";

// Admins.hasMany(Users, {foreignKey: 'adminId', as: 'adminUsers'});
// Users.belongsTo(Admins, {foreignKey: 'adminId', as: 'userAdmin'});

Users.hasMany(Products, {foreignKey: 'sellerId', as: 'productsuser'});
Products.belongsTo(Users, {foreignKey: 'sellerId', as:"userProducts"});

Products.hasMany(ProductRatings, {foreignKey: 'productId', as: 'productRating'});
ProductRatings.belongsTo(Products, {foreignKey: 'productId', as: 'ratingProduct'});
Users.hasMany(ProductRatings, {foreignKey: 'userId', as: 'userRating'});
ProductRatings.belongsTo(Users, {foreignKey: 'userId', as: 'ratingUser'});

export {  sequelize,Users, Products, Admins , ProductRatings};
