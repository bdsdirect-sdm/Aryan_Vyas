import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database';

class User extends Model {
    public id!: string;
    public firstName!: string;
    public lastName!: string;
    public email!: string;
    public password!: string;
    public failedLoginAttempts!: number;
    public passwordLock!: boolean;
    public lockedUntil!: Date | null;
}

User.init(
    {
        id: {
            type: DataTypes.UUID,
            defaultValue: DataTypes.UUIDV4,
            primaryKey: true,
        },
        firstName: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        lastName: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        email: {
            type: DataTypes.STRING,
            unique: true,
            allowNull: false,
        },
        password: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        failedLoginAttempts: {
            type: DataTypes.INTEGER,
            defaultValue: 0,
        },
        passwordLock: {
            type: DataTypes.BOOLEAN,
            defaultValue: false,
        },
        lockedUntil: {
            type: DataTypes.DATE,
            defaultValue: null,
        },
    },
    {
        sequelize,
        modelName: 'User',
    }
);

export default User;
