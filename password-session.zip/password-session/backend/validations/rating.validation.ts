import Joi from 'joi';
export const ratingValidation = Joi.object({
    rating: Joi.number()
      .min(0)
      .max(5)
      .required()
      .messages({
        "number.base": "Rating must be a number",
        "number.min": "Rating cannot be less than 0",
        "number.max": "Rating cannot be more than 5",
        "any.required": "Rating is required",
      }),
    productId: Joi.string().uuid().required().messages({
      "any.required": "Product ID is required",
    }),
  });