import Joi from "joi";

export const createProductValidation = Joi.object({
  name: Joi.string().min(3).max(100).required().messages({
    "string.base": "Product name must be a string.",
    "string.min": "Product name must be at least 3 characters long.",
    "string.max": "Product name cannot be longer than 100 characters.",
    "any.required": "Product name is required."
  }),

  description: Joi.string().min(10).max(1000).required().messages({
    "string.base": "Description must be a string.",
    "string.min": "Description must be at least 10 characters long.",
    "string.max": "Description cannot be longer than 1000 characters.",
    "any.required": "Description is required."
  }),

  price: Joi.number().positive().required().messages({
    "number.base": "Price must be a number.",
    "number.positive": "Price must be a positive value.",
    "any.required": "Price is required."
  }),

  stock: Joi.number().integer().min(0).required().messages({
    "number.base": "Stock must be an integer.",
    "number.min": "Stock cannot be less than 0.",
    "any.required": "Stock is required."
  }),

  category: Joi.string().valid("Electronics", "Clothing", "Home", "Beauty", "Sports", "Toys").required().messages({
    "string.base": "Category must be a string.",
    "any.required": "Category is required.",
    "any.only": "Category must be one of the following: Electronics, Clothing, Home, Beauty, Sports, Toys."
  }),

  brand: Joi.string().min(2).max(50).required().messages({
    "string.base": "Brand must be a string.",
    "string.min": "Brand must be at least 2 characters long.",
    "string.max": "Brand cannot be longer than 50 characters.",
    "any.required": "Brand is required."
  }),

  productImage: Joi.string().uri().optional().messages({
    "string.base": "Product image must be a string.",
    "string.uri": "Product image must be a valid URL."
  }),

  discount: Joi.number().min(0).max(100).optional().messages({
    "number.base": "Discount must be a number.",
    "number.min": "Discount cannot be less than 0.",
    "number.max": "Discount cannot be more than 100."
  })
});
