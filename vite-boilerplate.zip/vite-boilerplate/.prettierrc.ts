module.exports = {
    semi: true,
    arrowParens: 'always',
    trailingComma: 'es5',
    singleQuote: true,
    printWidth: 80,
    tabWidth: 2,
};