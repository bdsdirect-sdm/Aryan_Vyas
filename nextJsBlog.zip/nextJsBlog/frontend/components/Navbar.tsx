"use client";

import Link from "next/link";
import Image from "next/image";
import { usePathname, useRouter } from "next/navigation";
import { useAuth } from "../context/AuthContext";
import { Menu, X } from "lucide-react";
import { useState } from "react";

const Navbar = () => {
  const { isLoggedIn, logout } = useAuth();
  const router = useRouter();
  const pathname = usePathname();
  const [menuOpen, setMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    router.push("/login");
  };

  const navLinks = [
    { name: "Home", path: "/home", auth: true },
    { name: "My Blogs", path: "/my-blogs", auth: true },
    { name: "Create Blog", path: "/create-blog", auth: true },
  ].filter((link) => !link.auth || isLoggedIn);

  return (
    <nav className="bg-gradient-to-r from-blue-600 to-blue-800 shadow-lg">
      <div className="container mx-auto px-6 py-4 flex items-center justify-between">
        {/* Logo with Background Color and "VyasVerse" */}
        <Link href={isLoggedIn ? "/home" : "/"} className="flex items-center space-x-2">
          <div className="bg-white p-1 rounded-full">
            <Image src="/favicon.png" alt="Logo" width={40} height={40} className="w-10 h-10 rounded-full" />
          </div>
          <span className="text-white font-bold text-2xl">VyasVerse</span>
        </Link>

        {/* Desktop Menu */}
        <div className="hidden md:flex space-x-6 items-center">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              href={link.path}
              className={`relative text-white text-lg transition duration-300 ease-in-out hover:text-gray-300
                  ${pathname === link.path ? "font-semibold underline decoration-2 decoration-white" : ""}`}
            >
              {link.name}
            </Link>
          ))}

          {!isLoggedIn && (
            <>
              <Link href="/login" className="text-white text-lg hover:text-gray-300">
                Login
              </Link>
              <Link href="/register" className="text-white text-lg hover:text-gray-300">
                Register
              </Link>
            </>
          )}

          {isLoggedIn && (
            <button
              onClick={handleLogout}
              className="bg-red-500 hover:bg-red-600 text-white px-4 py-2 rounded-lg shadow transition duration-300"
            >
              Logout
            </button>
          )}
        </div>

        {/* Mobile Menu Button */}
        <button className="md:hidden text-white focus:outline-none" onClick={() => setMenuOpen(!menuOpen)}>
          {menuOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Menu */}
      <div
        className={`md:hidden bg-blue-700 text-white px-6 space-y-4 transition-all duration-300 ease-in-out ${menuOpen ? "py-4 opacity-100" : "h-0 opacity-0 overflow-hidden"
          }`}
      >
        {navLinks.map((link) => (
          <Link
            key={link.path}
            href={link.path}
            className={`block text-lg transition duration-300 hover:text-gray-300 ${pathname === link.path ? "font-semibold underline decoration-2 decoration-white" : ""
              }`}
          >
            {link.name}
          </Link>
        ))}

        {!isLoggedIn && (
          <>
            <Link href="/login" className="block text-lg hover:text-gray-300">
              Login
            </Link>
            <Link href="/register" className="block text-lg hover:text-gray-300">
              Register
            </Link>
          </>
        )}

        {isLoggedIn && (
          <button
            onClick={handleLogout}
            className="bg-red-500 hover:bg-red-600 text-white text-lg py-2 px-4 rounded-lg shadow transition duration-300"
          >
            Logout
          </button>
        )}
      </div>
    </nav>
  );
};

export default Navbar;