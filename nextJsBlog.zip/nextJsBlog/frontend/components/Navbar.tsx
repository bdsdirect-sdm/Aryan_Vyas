"use client";

import Link from "next/link";
import { usePathname, useRouter } from "next/navigation";
import { useAuth } from "../context/AuthContext";
import { Menu, X, UserCircle } from "lucide-react";
import { useState, useEffect, useRef } from "react";
import axios from "axios";

const Navbar = () => {
  const { isLoggedIn, logout } = useAuth();
  const router = useRouter();
  const pathname = usePathname();
  const [menuOpen, setMenuOpen] = useState(false);
  const [profileMenuOpen, setProfileMenuOpen] = useState(false);
  const [userProfile, setUserProfile] = useState<{ firstName: string; lastName: string; email: string; profileImage?: string } | null>(null);
  const profileRef = useRef<HTMLDivElement>(null);

  // Fetch user profile if logged in
  useEffect(() => {
    if (isLoggedIn) {
      const token = localStorage.getItem("token");
      if (token) {
        axios
          .get("http://localhost:4001/api/v1/auth/getUserProfile", {
            headers: { Authorization: `Bearer ${token}` },
          })
          .then((response) => {
            const userData = (response.data as { data: { firstName: string; lastName: string; email: string; profileImage?: string } }).data;
            setUserProfile(userData);
          })
          .catch((error) => {
            console.error("Error fetching profile:", error);
          });
      }
    } else {
      setUserProfile(null);
      setProfileMenuOpen(false); // Close dropdown if logged out
    }
  }, [isLoggedIn]);

  // Update profile picture dynamically when the profile image changes
  useEffect(() => {
    if (isLoggedIn) {
      const token = localStorage.getItem("token");
      if (token) {
        // Optionally re-fetch the profile to check for updated profile picture after any change.
        axios
          .get("http://localhost:4001/api/v1/auth/getUserProfile", {
            headers: { Authorization: `Bearer ${token}` },
          })
          .then((response) => {
            const userData = (response.data as { data: { firstName: string; lastName: string; email: string; profileImage?: string } }).data;
            setUserProfile(userData);
          });
      }
    }
  }, [userProfile?.profileImage, isLoggedIn]); // Re-fetch profile if the profile image changes

  // Close profile dropdown when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (profileRef.current && !profileRef.current.contains(event.target as Node)) {
        setProfileMenuOpen(false);
      }
    };

    if (profileMenuOpen) {
      document.addEventListener("mousedown", handleClickOutside);
    }

    return () => {
      document.removeEventListener("mousedown", handleClickOutside);
    };
  }, [profileMenuOpen]);

  // Close dropdown when navigating to another page
  useEffect(() => {
    setProfileMenuOpen(false);
    setMenuOpen(false);
  }, [pathname]);

  const handleLogout = () => {
    const confirmLogout = window.confirm("Are you sure you want to log out?");
    if (confirmLogout) {
      setProfileMenuOpen(false);
      logout();
      router.push("/login");
    }
  };

  const navLinks = [
    { name: "Home", path: "/home", auth: true },
    { name: "My Blogs", path: "/my-blogs", auth: true },
    { name: "Create Blog", path: "/create-blog", auth: true },
  ].filter((link) => !link.auth || isLoggedIn);

  return (
    <nav className="bg-gradient-to-r from-blue-600 to-blue-800 shadow-lg">
      <div className="container mx-auto px-6 py-4 flex items-center justify-between">
        {/* Logo */}
        <Link href={isLoggedIn ? "/home" : "/"} className="flex items-center space-x-2">
          <span className="text-white font-bold text-2xl">VyasVerse</span>
        </Link>

        {/* Desktop Menu */}
        <div className="hidden md:flex space-x-6 items-center">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              href={link.path}
              className={`relative text-white text-lg transition duration-300 ease-in-out hover:text-gray-300
                  ${pathname === link.path ? "font-semibold underline decoration-2 decoration-white" : ""}`}
            >
              {link.name}
            </Link>
          ))}

          {!isLoggedIn ? (
            <>
              <Link href="/login" className="text-white text-lg hover:text-gray-300">
                Login
              </Link>
              <Link href="/register" className="text-white text-lg hover:text-gray-300">
                Register
              </Link>
            </>
          ) : (
            <div className="relative" ref={profileRef}>
              <button
                className="flex items-center space-x-2 text-white text-lg hover:text-gray-300 focus:outline-none"
                onClick={() => setProfileMenuOpen(!profileMenuOpen)}
              >
                 <span>{userProfile?.firstName} {userProfile?.lastName || "User"}</span>
                {userProfile?.profileImage ? (
                  <img
                    src={`http://localhost:4001${userProfile.profileImage}`}
                    alt="Profile"
                    className="w-10 h-10 rounded-full"
                  />
                ) : (
                  <UserCircle size={40} className="text-white" />
                )}
               
              </button>

              {profileMenuOpen && (
                <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-lg py-2">
                  <Link
                    href="/profile"
                    className="block px-4 py-2 text-gray-800 hover:bg-gray-100"
                    onClick={() => setProfileMenuOpen(false)}
                  >
                    View Profile
                  </Link>
                  <button
                    onClick={handleLogout}
                    className="block w-full text-left px-4 py-2 text-red-600 hover:bg-gray-100"
                  >
                    Logout
                  </button>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Mobile Menu Button */}
        <button className="md:hidden text-white focus:outline-none" onClick={() => setMenuOpen(!menuOpen)}>
          {menuOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {menuOpen && (
        <div className="md:hidden bg-blue-700 text-white px-6 py-4 space-y-4 transition-all duration-300 ease-in-out">
          {navLinks.map((link) => (
            <Link
              key={link.path}
              href={link.path}
              className={`block text-lg transition duration-300 hover:text-gray-300 ${pathname === link.path ? "font-semibold underline decoration-2 decoration-white" : ""}`}
              onClick={() => setMenuOpen(false)}
            >
              {link.name}
            </Link>
          ))}

          {!isLoggedIn ? (
            <>
              <Link href="/login" className="block text-lg hover:text-gray-300">
                Login
              </Link>
              <Link href="/register" className="block text-lg hover:text-gray-300">
                Register
              </Link>
            </>
          ) : (
            <div className="border-t border-gray-400 pt-4">
              <Link
                href="/profile"
                className="block text-lg hover:text-gray-300"
                onClick={() => setMenuOpen(false)}
              >
                View Profile
              </Link>
              <button
                onClick={handleLogout}
                className="block text-lg text-red-500 hover:text-red-400"
              >
                Logout
              </button>
            </div>
          )}
        </div>
      )}
    </nav>
  );
};

export default Navbar;
