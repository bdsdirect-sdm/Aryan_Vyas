import React from "react";

interface BlogCardProps {
  title: string;
  content: string;
  category: string;
}

const BlogCard: React.FC<BlogCardProps> = ({ title, content, category }) => {
  return (
    <div className="border p-4 rounded-lg bg-white shadow-md">
      <h2 className="text-lg font-semibold">{title}</h2>
      <p className="text-gray-600 text-sm">Category: {category}</p>
      <p className="text-gray-800 mt-2">{content.slice(0, 100)}...</p>
    </div>
  );
};

export default BlogCard;
