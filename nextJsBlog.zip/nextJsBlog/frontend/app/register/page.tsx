"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import axios from "axios";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";

const Register = () => {
  const router = useRouter();
  const [error, setError] = useState("");

  // ✅ Yup Validation Schema
  const registerValidationSchema = Yup.object({
    firstName: Yup.string()
      .min(2, "First Name must be at least 2 characters")
      .max(30, "First Name must be at most 30 characters")
      .required("First Name is required"),
    lastName: Yup.string()
      .min(2, "Last Name must be at least 2 characters")
      .max(30, "Last Name must be at most 30 characters")
      .required("Last Name is required"),
    email: Yup.string().email("Invalid email format").required("Email is required"),
    password: Yup.string()
      .min(8, "Password must be at least 8 characters long")
      .max(20, "Password must be at most 20 characters long")
      .required("Password is required")
      .matches(/[a-z]/, "Password must contain at least one lowercase letter")
      .matches(/[A-Z]/, "Password must contain at least one uppercase letter")
      .matches(/\d/, "Password must contain at least one number")
      .matches(
        /[`~!@#$%^&*()"?<>|:{}(),.]/,
        "Password must contain at least one special character"
      ),
  });

  const handleSubmit = async (values: { firstName: string; lastName: string; email: string; password: string }) => {
    setError("");
    try {
      await axios.post("http://localhost:4001/api/v1/auth/register", values);
      router.push("/login");
    } catch {
      setError("❌ Registration failed. Please try again.");
    }
  };

  return (
    <div className="flex min-h-screen items-center justify-center bg-gradient-to-r from-gray-100 to-gray-200">
      <div className="w-full max-w-md p-8 bg-white rounded-xl shadow-lg">
        <h1 className="text-2xl font-bold text-gray-800 text-center">Create an Account</h1>
        <p className="text-gray-500 text-center mb-6">Fill in the details below to register</p>

        {error && (
          <p className="text-red-600 bg-red-100 border border-red-400 p-3 rounded mb-4 text-center">
            {error}
          </p>
        )}

        <Formik
          initialValues={{ firstName: "", lastName: "", email: "", password: "" }}
          validationSchema={registerValidationSchema}
          onSubmit={handleSubmit}
        >
          {({ isSubmitting }) => (
            <Form className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700">
                  First Name <span className="text-red-500">*</span>
                </label>
                <Field
                  name="firstName"
                  type="text"
                  placeholder="Enter your first name"
                  className="mt-1 block w-full border rounded-md p-2 focus:ring-green-500 focus:border-green-500 outline-none transition-all duration-200"/>
                <ErrorMessage name="firstName">
                  {(msg) => <div className="text-red-500 text-sm mt-1">{msg}</div>}
                </ErrorMessage>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Last Name<span className="text-red-500">*</span></label>
                <Field name="lastName" type="text" placeholder="Enter your last name" className="mt-1 block w-full border rounded-md p-2" />
                <ErrorMessage name="lastName" component="div" className="text-red-500 text-sm mt-1" />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Email<span className="text-red-500">*</span></label>
                <Field name="email" type="email" placeholder="Enter your email" className="mt-1 block w-full border rounded-md p-2" />
                <ErrorMessage name="email" component="div" className="text-red-500 text-sm mt-1" />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700">Password<span className="text-red-500">*</span></label>
                <Field name="password" type="password" placeholder="Enter your password" className="mt-1 block w-full border rounded-md p-2" />
                <ErrorMessage name="password" component="div" className="text-red-500 text-sm mt-1" />
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full bg-blue-600 text-white py-2 rounded-lg shadow-md hover:scale-105 hover:bg-blue-700 focus:ring-2 focus:ring-blue-400"
              >
                {isSubmitting ? "Registering..." : "Register"}
              </button>
            </Form>
          )}
        </Formik>

        <p className="text-gray-600 text-sm text-center mt-4">
          Already have an account? <a href="/login" className="text-blue-600 hover:underline">Login here</a>
        </p>
      </div>
    </div>
  );
};

export default Register;