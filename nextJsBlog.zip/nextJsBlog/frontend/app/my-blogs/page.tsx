"use client";

import { useEffect, useState, useCallback } from "react";
import axios from "axios";
import Link from "next/link";
import Image from "next/image";

interface Blog {
  id: string;
  blogTitle: string;
  blogCategory: string;
  blogContent: string;
  blogImage?: string;
  createdAt: string;
}

interface BlogApiResponse {
  blogs: Blog[];
}

const MyBlogs = () => {
  const [blogs, setBlogs] = useState<Blog[]>([]);
  const [expandedBlog, setExpandedBlog] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const storedToken = localStorage.getItem("token");
      setToken(storedToken);
    }
  }, []);

  const fetchBlogs = useCallback(async () => {
    if (!token) return;

    try {
      const response = await axios.get<BlogApiResponse>(
        "http://localhost:4001/api/v1/auth/getBlogs",
        { headers: { Authorization: `Bearer ${token}` } }
      );
      console.log("View Blogs Of The User", response.data);
      setBlogs(response.data.blogs ?? []);
    } catch (err) {
      setError("Failed to fetch blogs.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [token]);

  useEffect(() => {
    fetchBlogs();
  }, [fetchBlogs]);

  const handleDelete = async (blogId: string) => {
    if (!token) {
      alert("You need to be logged in to delete a blog.");
      return;
    }

    const confirmDelete = window.confirm("Are you sure you want to delete this blog?");
    if (!confirmDelete) return;

    try {
      await axios.delete(`http://localhost:4001/api/v1/auth/deleteBlog/${blogId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });

      alert("Blog deleted successfully!");
      fetchBlogs();
    } catch (error) {
      console.error("Error deleting blog:", error);
      alert("Failed to delete the blog. Please try again.");
    }
  };

  if (!hydrated) return null;
  if (error) return <p className="text-center text-red-500 mt-10">{error}</p>;

  return (
    <div className="max-w-6xl mx-auto mt-10 px-6">
      <h1 className="text-3xl font-bold text-center text-gray-800 mb-8">📖 My Blogs</h1>

      {loading ? (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: Math.max(blogs.length || 3, 3) }).map((_, index) => (

            <div key={index} className="bg-white rounded-lg shadow-md p-4 animate-pulse">
              <div className="w-full h-52 bg-gray-300 rounded-md"></div>
              <div className="h-6 bg-gray-300 rounded w-3/4 mt-3"></div>
              <div className="h-4 bg-gray-300 rounded w-1/2 mt-2"></div>
              <div className="h-16 bg-gray-300 rounded w-full mt-3"></div>
              <div className="h-4 bg-gray-300 rounded w-1/3 mt-2"></div>
            </div>
          ))}
        </div>
      ) : blogs.length === 0 ? (
        <p className="text-center text-gray-500">
          No blogs found. <Link href="/create-blog" className="text-blue-500">Create one</Link>.
        </p>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {blogs.map((blog) => (
            <div
              key={blog.id}
              className="bg-white rounded-lg shadow-md p-4 transform transition duration-300 hover:shadow-xl hover:-translate-y-2"
            >
              {blog.blogImage && (
                <div className="w-full h-52 flex justify-center items-center overflow-hidden rounded-md">
                  <Image
                    src={`http://localhost:4001${blog.blogImage}`}
                    alt="Blog Image"
                    width={300}
                    height={200}
                    className="w-auto h-full object-contain"
                    unoptimized
                  />
                </div>
              )}

              <p className="text-xl font-semibold text-gray-800 mt-3">
                <strong>Title:</strong> {blog.blogTitle}
              </p>
              <p className="text-sm text-gray-500">
                <strong>Category:</strong> {blog.blogCategory}
              </p>
              <p className="text-gray-700 mt-2"><strong>Content:  </strong>{blog.blogContent}</p>
              <p className="text-gray-500 text-xs mt-2">
                <strong>Published On:</strong>{" "}
                {blog?.createdAt
                  ? `${new Date(blog.createdAt).toLocaleDateString()} at ${new Date(
                    blog.createdAt
                  ).toLocaleTimeString()}`
                  : "Date not available"}
              </p>

              {expandedBlog === blog.id ? (
                <>
                  <div className="flex justify-between mt-4 border-t pt-3">
                    <Link href={`/view-blog/${blog.id}`} className="text-blue-500 text-sm">View</Link>
                    <Link href={`/edit-blog/${blog.id}`} className="text-green-500 text-sm">Edit</Link>
                    <button onClick={() => handleDelete(blog.id)} className="text-red-500 text-sm">
                      Delete
                    </button>
                  </div>

                  <button
                    onClick={() => setExpandedBlog(null)}
                    className="mt-4 text-blue-500 hover:underline text-sm"
                  >
                    Show Less
                  </button>
                </>
              ) : (
                <button
                  onClick={() => setExpandedBlog(blog.id)}
                  className="mt-3 text-blue-500 hover:underline text-sm"
                >
                  More Options
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default MyBlogs;
