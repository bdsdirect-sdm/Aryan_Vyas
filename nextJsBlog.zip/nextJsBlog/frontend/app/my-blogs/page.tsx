"use client";

import { useEffect, useState } from "react";
import axios from "axios";
import Link from "next/link";
import Image from "next/image";
interface Blog {
  id: string;
  blogTitle: string;
  blogContent: string;
  blogCategory: string;
  blogImage?: string;
  createdAt: string;
}

interface BlogApiResponse {
  blogs: Blog[];
}

const MyBlogs = () => {
  const [blogs, setBlogs] = useState<Blog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [hydrated, setHydrated] = useState(false);

  useEffect(() => {
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (typeof window !== "undefined") {
      const storedToken = localStorage.getItem("token");
      setToken(storedToken);
    }
  }, []);

  const fetchBlogs = async () => {
    if (!token) return;

    try {
      const response = await axios.get<BlogApiResponse>(
        "http://localhost:4001/api/v1/auth/getBlogs",
        { headers: { Authorization: `Bearer ${token}` } }
      );
      console.log("View Blogs Of The User", response.data);
      setBlogs(response.data.blogs ?? []);
    } catch (err) {
      setError("Failed to fetch blogs.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBlogs();
  }, [token]);

  const handleDelete = async (blogId: string) => {
    if (!token) {
      alert("You need to be logged in to delete a blog.");
      return;
    }

    const confirmDelete = window.confirm("Are you sure you want to delete this blog?");
    if (!confirmDelete) return;

    try {
      await axios.delete(`http://localhost:4001/api/v1/auth/deleteBlog/${blogId}`, {
        headers: { Authorization: `Bearer ${token}` }
      });

      alert("Blog deleted successfully!");
      fetchBlogs();
    } catch (error) {
      console.error("Error deleting blog:", error);
      alert("Failed to delete the blog. Please try again.");
    }
  };

  if (!hydrated) return null;
  if (loading) return <p className="text-center mt-10">Loading...</p>;
  if (error) return <p className="text-center text-red-500 mt-10">{error}</p>;

  return (
    <div className="max-w-3xl mx-auto mt-10 p-6 bg-white rounded shadow">
      <h1 className="text-2xl font-bold mb-6">My Blogs</h1>

      {blogs.length === 0 ? (
        <p className="text-gray-500">
          No blogs found. <Link href="/create-blog" className="text-blue-500">Create one</Link>.
        </p>
      ) : (
        <div className="space-y-6">
          {blogs.map((blog) => (
            <div key={blog.id} className="p-4 border rounded shadow">
              {blog.blogImage && (
                <Image 
                  src={`http://localhost:4001${blog.blogImage}`} 
                  alt="Blog Image" 
                  width={640} 
                  height={160} 
                  className="h-20 object-cover rounded mb-2"
                  unoptimized
                />
              )}
              <p className="text-lg font-bold"><strong>Title:</strong>{blog.blogTitle}</p>
              <p className="text-sm text-gray-600"><strong>Blog Category:</strong>
                {blog.blogCategory}
              </p>
              <p className="text-gray-700 mt-2"><strong>Blog Content:</strong>{blog.blogContent.slice(0, 100)}...</p>
              <p className="text-sm text-gray-600"><strong>Blog Created At:</strong>{new Date(blog.createdAt).toLocaleDateString()} at {new Date(blog.createdAt).toLocaleTimeString()} </p>

              <div className="mt-4 flex space-x-4">
                <Link href={`/view-blog/${blog.id}`} className="text-blue-500">View</Link>
                <Link href={`/edit-blog/${blog.id}`} className="text-green-500">Edit</Link>
                <button onClick={() => handleDelete(blog.id)} className="text-red-500">Delete</button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default MyBlogs;
