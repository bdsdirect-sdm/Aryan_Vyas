"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import axios from "axios";
import Image from "next/image";

const categories = [
  "Technology",
  "Music",
  "Health & Wellness",
  "Food & Cooking",
  "Travel",
  "Lifestyle",
  "Finance & Business",
  "Personal Development",
  "Fashion & Beauty",
  "Sports & Fitness",
  "Entertainment", 
  "Parenting & Family", 
  "Education & Learning",
  "Gaming", 
  "Science & Innovation",
  "Photography & Art", 
  "DIY & Home Improvement", 
  "Automobiles & Vehicles",
  "Politics & Current Affairs", 
  "Spirituality & Mindfulness", 
  "Books & Literature",
];

const EditBlog = () => {
  const router = useRouter();
  const params = useParams();
  const id = params?.id;

  const [blogTitle, setBlogTitle] = useState("");
  const [blogContent, setBlogContent] = useState("");
  const [blogCategory, setBlogCategory] = useState(categories[0]);
  const [blogImage, setBlogImage] = useState<File | null>(null);
  const [existingImage, setExistingImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const token = localStorage.getItem("token");

    if (!id) {
      setError("Invalid Blog ID.");
      setLoading(false);
      return;
    }
    
    if (!token) {
      console.error("Access token is missing from localStorage");
      setError("You need to log in first.");
      setLoading(false);
      return;
    }

    const fetchBlog = async () => {
      try {
        const response = await axios.get(`http://localhost:4001/api/v1/auth/getBlogsById/${id}`, {
          headers: { Authorization: `Bearer ${token}` },
        });

        console.log("Fetched Blog Data:", response.data);

        const blogData = (response.data as { blog: { blogTitle: string; blogContent: string; blogCategory?: string; blogImage?: string | null } }).blog;
        setBlogTitle(blogData.blogTitle);
        setBlogContent(blogData.blogContent);
        setBlogCategory(blogData.blogCategory || categories[0]);
        setExistingImage(blogData.blogImage ?? null);
      } catch (err) {
        console.error("Error fetching blog:", err);
        setError("Failed to fetch the blog.");
      } finally {
        setLoading(false);
      }
    };

    fetchBlog();
  }, [id]);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setBlogImage(e.target.files[0]);
    }
  };

  const handleUpdate = async () => {
    const token = localStorage.getItem("token");
    if (!token) {
      alert("You need to be logged in to update the blog.");
      return;
    }

    const formData = new FormData();
    formData.append("blogTitle", blogTitle);
    formData.append("blogContent", blogContent);
    formData.append("blogCategory", blogCategory);
    if (blogImage) {
      formData.append("blogImage", blogImage);
    }

    try {
      await axios.put(`http://localhost:4001/api/v1/auth/updateBlogById/${id}`, formData, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "multipart/form-data",
        },
      });

      alert("Blog updated successfully!");
      router.push("/my-blogs");
    } catch (err) {
      console.error("Error updating blog:", err);
      setError("Failed to update the blog.");
    }
  };

  if (loading) return <p className="text-center mt-10">Loading...</p>;
  if (error) return <p className="text-center text-red-500 mt-10">{error}</p>;

  return (
    <div className="max-w-3xl mx-auto mt-10 p-6 bg-white rounded shadow">
      <h1 className="text-2xl font-bold">Edit Blog</h1>

      <label className="block text-sm font-medium mt-4">Title</label>
      <input type="text" className="w-full p-2 border rounded" value={blogTitle} onChange={(e) => setBlogTitle(e.target.value)} />

      <label className="block text-sm font-medium mt-4">Content</label>
      <textarea className="w-full p-2 border rounded" rows={5} value={blogContent} onChange={(e) => setBlogContent(e.target.value)} />

      <label className="block text-sm font-medium mt-4">Category</label>
      <select className="w-full p-2 border rounded" value={blogCategory} onChange={(e) => setBlogCategory(e.target.value)}>
        {categories.map((category) => (
          <option key={category} value={category}>{category}</option>
        ))}
      </select>

      {existingImage && (
  <div className="mt-4">
    <p className="text-sm">Current Image:</p>
    <Image 
      src={`http://localhost:4001${existingImage}`} 
      alt="Current Blog" 
      width={200} 
      height={200} 
      className="h-20 object-cover rounded"
      unoptimized
    />
  </div>
)}

      <label className="block text-sm font-medium mt-4">Upload New Image</label>
      <input type="file" onChange={handleFileChange} className="w-full p-2 border rounded" />

      <button onClick={handleUpdate} className="mt-4 bg-blue-500 text-white py-2 px-4 rounded">Update Blog</button>
    </div>
  );
};

export default EditBlog;
