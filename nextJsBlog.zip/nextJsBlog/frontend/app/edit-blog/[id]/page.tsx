"use client";

import { useEffect, useState } from "react";
import { useParams, useRouter } from "next/navigation";
import axios from "axios";
import Image from "next/image";
import { ArrowLeft } from "lucide-react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";

const categories = [
  "Technology", "Music", "Health & Wellness", "Food & Cooking", "Travel",
  "Lifestyle", "Finance & Business", "Personal Development", "Fashion & Beauty",
  "Sports & Fitness", "Entertainment", "Parenting & Family", "Education & Learning",
  "Gaming", "Science & Innovation", "Photography & Art", "DIY & Home Improvement",
  "Automobiles & Vehicles", "Politics & Current Affairs", "Spirituality & Mindfulness",
  "Books & Literature",
];

const BlogSchema = Yup.object().shape({
  blogTitle: Yup.string().trim().min(5, "Title must be at least 5 characters").required("Title is required"),
  blogContent: Yup.string().trim().min(20, "Content must be at least 20 characters").required("Content is required"),
  blogCategory: Yup.string().required("Category is required"),
  blogImage: Yup.mixed().notRequired(),
});

const EditBlog = () => {
  const router = useRouter();
  const params = useParams();
  const id = params?.id;

  const [existingImage, setExistingImage] = useState<string | null>(null);
  const [previewImage, setPreviewImage] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const [initialValues, setInitialValues] = useState({
    blogTitle: "",
    blogContent: "",
    blogCategory: categories[0],
    blogImage: null as File | null,
  });

  useEffect(() => {
    const token = localStorage.getItem("token");

    if (!id) {
      setError("Invalid Blog ID.");
      setLoading(false);
      return;
    }

    if (!token) {
      console.error("Access token is missing from localStorage");
      setError("You need to log in first.");
      setLoading(false);
      return;
    }

    const fetchBlog = async () => {
      try {
        const response = await axios.get(`http://localhost:4001/api/v1/auth/getBlogsById/${id}`, {
          headers: { Authorization: `Bearer ${token}` },
        });

        console.log("Fetched Blog Data:", response.data);

        const blogData = (response.data as { blog: { blogTitle: string; blogContent: string; blogCategory?: string; blogImage?: string | null } }).blog;
        setInitialValues({
          blogTitle: blogData.blogTitle,
          blogContent: blogData.blogContent,
          blogCategory: blogData.blogCategory || categories[0],
          blogImage: null,
        });

        setExistingImage(blogData.blogImage ?? null);
      } catch (err) {
        console.error("Error fetching blog:", err);
        setError("Failed to fetch the blog.");
      } finally {
        setLoading(false);
      }
    };

    fetchBlog();
  }, [id]);

  const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>, setFieldValue: (field: string, value: File | null, shouldValidate?: boolean) => void) => {
    if (event.target.files && event.target.files.length > 0) {
      const file = event.target.files[0];
      setFieldValue("blogImage", file);
      setPreviewImage(URL.createObjectURL(file));
    }
  };

  const handleSubmit = async (values: { blogTitle: string; blogContent: string; blogCategory: string; blogImage: File | null }) => {
    const token = localStorage.getItem("token");
    if (!token) {
      alert("You need to be logged in to update the blog.");
      return;
    }

    const formData = new FormData();
    formData.append("blogTitle", values.blogTitle);
    formData.append("blogContent", values.blogContent);
    formData.append("blogCategory", values.blogCategory);
    if (values.blogImage) {
      formData.append("blogImage", values.blogImage);
    }

    try {
      await axios.put(`http://localhost:4001/api/v1/auth/updateBlogById/${id}`, formData, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "multipart/form-data",
        },
      });

      alert("Blog updated successfully!");
      router.push("/my-blogs");
    } catch (err) {
      console.error("Error updating blog:", err);
      setError("Failed to update the blog.");
    }
  };

  if (loading) return <p className="text-center mt-10">Loading...</p>;
  if (error) return <p className="text-center text-red-500 mt-10">{error}</p>;

  return (
    <div className="max-w-lg mx-auto mt-10 p-6 bg-white rounded shadow">
      <button onClick={() => router.back()} className="flex items-center text-blue-600 hover:text-blue-800 mb-4">
        <ArrowLeft size={20} className="mr-2" />
        <span>Back</span>
      </button>

      <h1 className="text-2xl font-bold">Edit Blog</h1>

      <Formik initialValues={initialValues} validationSchema={BlogSchema} onSubmit={handleSubmit} enableReinitialize>
        {({ setFieldValue, isSubmitting }) => (
          <Form>
            <label className="block text-sm font-medium mt-4 mb-3">
              Title<span className="text-red-500">*</span>
            </label>
            <Field as="textarea" name="blogTitle" placeholder="Enter your blog title" className="w-full p-2 border rounded" />
            <ErrorMessage name="blogTitle" component="p" className="text-red-500 text-sm" />

            <label className="block text-sm font-medium mt-4 mb-3">
              Content<span className="text-red-500">*</span>
            </label>
            <Field as="textarea" name="blogContent" placeholder="Write your content here..." className="w-full p-2 border rounded" rows={5} />
            <ErrorMessage name="blogContent" component="p" className="text-red-500 text-sm" />

            <label className="block text-sm font-medium mt-4 mb-3">
              Category<span className="text-red-500">*</span>
            </label>
            <Field as="select" name="blogCategory" className="w-full p-2 border rounded">
              {categories.map((category) => (
                <option key={category} value={category}>
                  {category}
                </option>
              ))}
            </Field>
            <ErrorMessage name="blogCategory" component="p" className="text-red-500 text-sm" />

            {existingImage && !previewImage && (
              <div className="mt-4">
                <p className="text-sm">Current Image</p>
                <Image src={`http://localhost:4001${existingImage}`} alt="Current Blog" width={600} height={400} className="w-full h-auto max-h-64 rounded-lg object-contain" unoptimized />
              </div>
            )}

            {previewImage && (
              <div className="mt-4">
                <p className="text-sm">New Image Preview</p>
                <Image src={previewImage} alt="New Preview" width={600} height={400} className="w-full h-auto max-h-64 rounded-lg object-contain"
                  unoptimized />
              </div>
            )}

            <label className="block text-sm font-medium mt-4 mb-3">Upload New Image:</label>
            <input type="file" onChange={(e) => handleFileChange(e, setFieldValue)} className="w-full p-2 border rounded mb-3" />


            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-2 rounded-lg shadow-md transition-transform transform hover:scale-105 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-400 mb-3"
            >
              {isSubmitting ? "Updating Blog..." : "Update Blog"}
            </button>
          </Form>
        )}
      </Formik>
    </div>
  );
};

export default EditBlog;
