"use client";

import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import axios from "axios";
import Image from "next/image";

interface Blog {
  id: string;
  blogTitle: string;
  blogContent: string;
  blogCategory: string;
  blogImage?: string;
  createdAt: string;
  userBlogs: {
    firstName: string;
    lastName: string;
  };
}

const ViewBlog = () => {
  const params = useParams();
  const id = params?.id;
  const [blog, setBlog] = useState<Blog | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!id) return;

    const fetchBlog = async () => {
      try {
        const response = await axios.get<{ blog: Blog }>(
          `http://localhost:4001/api/v1/auth/getBlogsById/${id}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
            },
          }
        );

        setBlog(response.data.blog);
      } catch (err) {
        console.log("Failed to fetch the blog.", err);
        setError("Failed to fetch the blog.");
      } finally {
        setLoading(false);
      }
    };

    fetchBlog();
  }, [id]);

  if (loading)
    return <p className="text-center mt-10 text-gray-500">Loading...</p>;
  if (error)
    return <p className="text-center text-red-500 mt-10">{error}</p>;

  return (
    <div className="max-w-lg mx-auto mt-8 p-4 bg-white rounded-lg shadow-md">
      {blog?.blogImage && (
        <div className="flex justify-center">
          <Image
            src={`http://localhost:4001${blog.blogImage}`}
            alt="Blog Cover"
            width={250}
            height={200}
            className="rounded-md object-contain"
            unoptimized
          />
        </div>
      )}

      <h1 className="text-lg font-semibold text-gray-900 mt-4">
        {blog?.blogTitle}
      </h1>

      <p className="text-gray-600 text-sm mt-1">
        <strong>Category: </strong> {blog?.blogCategory}
      </p>

      <p className="text-gray-700 text-sm leading-relaxed mt-3">
      <strong>Content: </strong>{blog?.blogContent}
      </p>

      {blog && (
        <p className="text-gray-600 mt-4 text-xs">
          <strong>Published By: </strong> {blog.userBlogs.firstName}{" "}
          {blog.userBlogs.lastName}
        </p>
      )}

      <p className="text-gray-500 text-xs mt-2">
        <strong>Published On:</strong>{" "}
        {blog?.createdAt
          ? `${new Date(blog.createdAt).toLocaleDateString()} at ${new Date(
              blog.createdAt
            ).toLocaleTimeString()}`
          : "Date not available"}
      </p>
    </div>
  );
};

export default ViewBlog;
