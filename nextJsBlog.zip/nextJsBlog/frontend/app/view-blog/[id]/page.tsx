"use client";

import { useParams, useRouter } from "next/navigation";
import { useEffect, useState } from "react";
import axios from "axios";
import Image from "next/image";
import { ArrowLeft } from "lucide-react";

interface Blog {
  id: string;
  blogTitle: string;
  blogContent: string;
  blogCategory: string;
  blogImage?: string;
  createdAt: string;
  userBlogs: {
    firstName: string;
    lastName: string;
  };
}

const ViewBlog = () => {
  const params = useParams();
  const router = useRouter();
  const id = params?.id;
  const [blog, setBlog] = useState<Blog | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!id) return;

    const fetchBlog = async () => {
      try {
        const response = await axios.get<{ blog: Blog }>(
          `http://localhost:4001/api/v1/auth/getBlogsById/${id}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
            },
          }
        );
        setBlog(response.data.blog);
      } catch (err) {
        console.log("Failed to fetch the blog.", err);
        setError("Failed to fetch the blog.");
      } finally {
        setLoading(false);
      }
    };

    fetchBlog();
  }, [id]);

  if (loading)
    return (
      <div className="max-w-lg mx-auto mt-8 p-4 bg-white rounded-lg shadow-md animate-pulse">
        <div className="h-6 bg-gray-300 rounded w-3/4 mb-2"></div>
        <div className="h-4 bg-gray-300 rounded w-1/2 mb-4"></div>
        <div className="h-40 bg-gray-300 rounded mb-4"></div>
        <div className="h-4 bg-gray-300 rounded w-full mb-2"></div>
        <div className="h-4 bg-gray-300 rounded w-5/6 mb-2"></div>
        <div className="h-4 bg-gray-300 rounded w-4/6"></div>
      </div>
    );

  if (error)
    return <p className="text-center text-red-500 mt-10">{error}</p>;

  return (
    <div className="max-w-lg mx-auto mt-10 p-6 bg-white rounded shadow">
    <button 
      onClick={() => router.back()} 
      className="flex items-center text-blue-600 hover:text-blue-800 mb-4"
    >
      <ArrowLeft size={20} className="mr-2" />
      <span>Back</span>
    </button>

      {blog?.blogImage && (
        <div className="flex justify-center">
          <Image
            src={`http://localhost:4001${blog.blogImage}`}
            alt="Blog Cover"
            width={250}
            height={200}
            className="rounded-md object-cover shadow-md"
            unoptimized
          />
        </div>
      )}

      <h1 className="text-2xl font-bold text-gray-900 mt-4">
        {blog?.blogTitle}
      </h1>

      <p className="text-gray-600 text-sm mt-1">
        <strong>Category: </strong> {blog?.blogCategory}
      </p>

      <p className="text-gray-700 text-base leading-relaxed mt-3">
        <strong>Content:</strong> {blog?.blogContent}
      </p>

      {blog && (
        <p className="text-gray-600 mt-4 text-sm">
          <strong>Published By: </strong> {blog.userBlogs.firstName}{" "}
          {blog.userBlogs.lastName}
        </p>
      )}

      <p className="text-gray-500 text-xs mt-2">
        <strong>Published On:</strong>{" "}
        {blog?.createdAt
          ? `${new Date(blog.createdAt).toLocaleDateString()} at ${new Date(
              blog.createdAt
            ).toLocaleTimeString()}`
          : "Date not available"}
      </p>
    </div>
  );
};

export default ViewBlog;