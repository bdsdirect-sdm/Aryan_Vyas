"use client";

import { useParams } from "next/navigation";
import { useEffect, useState } from "react";
import axios from "axios";
import Image from "next/image";

interface Blog {
  id: string;
  blogTitle: string;
  blogContent: string;
  blogCategory: string;
  blogImage?: string;
  createdAt: string;
}

const ViewBlog = () => {
  const params = useParams();
  const id = params?.id;
  const [blog, setBlog] = useState<Blog | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const token = localStorage.getItem("token");
    console.log("Blog ID:", id);
    if (!id) return;

    const fetchBlog = async () => {
      try {
        console.log("Fetching blog...");
        const response = await axios.get<{ blog: Blog }>(
          `http://localhost:4001/api/v1/auth/getBlogsById/${id}`,
          {
            headers: {
              Authorization: `Bearer ${token}`,
              "Content-Type": "application/json",
            },
          }
        );

        console.log("Blog Data:", response.data);
        setBlog(response.data.blog);
      } catch (err) {
        console.error("API Error:", err);
        setError("Failed to fetch the blog.");
      } finally {
        setLoading(false);
      }
    };

    fetchBlog();
  }, [id]);

  if (loading) return <p className="text-center mt-10">Loading...</p>;
  if (error) return <p className="text-center text-red-500 mt-10">{error}</p>;

  return (
    <div className="max-w-2xl mx-auto mt-10 p-6 bg-white rounded-lg shadow-md">
      {blog?.blogImage && (
        <div className="flex justify-center">
          <Image
            src={`http://localhost:4001${blog.blogImage}`}
            alt="Blog Cover"
            width={200}
            height={200}
            className="rounded-lg shadow-md border"
            unoptimized
          />
        </div>
      )}
      
      <h1 className="text-2xl font-bold mt-4 text-gray-800">{blog?.blogTitle}</h1>
      <p className="text-gray-600 text-sm mt-1">
        <span className="font-semibold">{blog?.blogCategory}</span> •{" "}
        {blog?.createdAt ? new Date(blog.createdAt).toLocaleDateString() : "Unknown Date"}
      </p>

      <p className="mt-6 text-gray-700 leading-relaxed">{blog?.blogContent}</p>
    </div>
  );
};

export default ViewBlog;
