"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import axios from "axios";
import { ArrowLeft, UserCircle } from "lucide-react";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";

interface ProfileData {
  firstName: string;
  lastName: string;
  email: string;
  phoneNumber?: string | null;
  profileImage?: string | null | File;
  address?: string | null;
  city?: string | null;
  state?: string | null;
  country?: string | null;
  zipcode?: string | null;
}

const Profile = () => {
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [blogCount, setBlogCount] = useState<number>(0);
  const [loading, setLoading] = useState(true);
  const [profileImagePreview, setProfileImagePreview] = useState<string | null>(null);
  const [imageInputKey, setImageInputKey] = useState<number>(0);
  const router = useRouter();

  useEffect(() => {
    const token = localStorage.getItem("token");

    if (token) {
      const fetchProfile = async () => {
        try {
          const response = await axios.get<{ data: ProfileData & { blogCount: number } }>(
            "http://localhost:4001/api/v1/auth/getUserProfile",
            {
              headers: { Authorization: `Bearer ${token}` },
            }
          );

          const userData = response.data.data;
          setProfile(userData);
          setBlogCount(userData.blogCount || 0);

          if (userData.profileImage) {
            setProfileImagePreview(`http://localhost:4001${userData.profileImage}`);
          }
        } catch (error) {
          console.error("Error fetching profile:", error);
        } finally {
          setLoading(false);
        }
      };

      fetchProfile();
    }
  }, []);

  if (loading) {
    return (
      <div className="max-w-5xl mx-auto mt-10 bg-white shadow-lg rounded-lg p-8 border border-gray-200 animate-pulse">
        <button
          className="flex items-center text-blue-600 hover:text-blue-800 mb-4">
          <ArrowLeft size={20} className="mr-2" />
          <span className="w-24 h-4 bg-gray-300 rounded"></span>
        </button>
  
        <div className="text-3xl font-bold text-center text-gray-800 mb-6 w-1/4 h-8 bg-gray-300 rounded mx-auto"></div>
  
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {/* Left Sidebar - Profile Image & Blog Count */}
          <div className="flex flex-col items-center space-y-4">
            <div className="w-32 h-32 rounded-full shadow-lg bg-gray-300 animate-pulse"></div>
            <div className="w-48 h-6 bg-gray-300 rounded"></div>
          </div>
  
          {/* Middle Section - Basic Info */}
          <div className="space-y-4">
            <div className="h-6 bg-gray-300 rounded w-1/2 mb-2"></div>
            <div className="h-6 bg-gray-300 rounded w-3/4 mb-2"></div>
            <div className="h-6 bg-gray-300 rounded w-2/3 mb-2"></div>
            <div className="h-6 bg-gray-300 rounded w-4/5 mb-2"></div>
            <div className="h-6 bg-gray-300 rounded w-1/2 mb-2"></div>
          </div>
  
          {/* Right Section - Address Details */}
          <div className="space-y-4">
            <div className="h-12 bg-gray-300 rounded w-1/2 mb-2"></div>
            <div className="h-6 bg-gray-300 rounded w-3/4 mb-2"></div>
            <div className="h-6 bg-gray-300 rounded w-2/3 mb-2"></div>
            <div className="h-6 bg-gray-300 rounded w-4/5 mb-2"></div>
          </div>
  
          {/* Submit Button */}
          <div className="col-span-full text-right">
            <div className="w-32 h-10 bg-gray-300 rounded ml-auto"></div>
          </div>
        </div>
      </div>
    );
  }
  
  

  if (!profile) return <p className="text-center mt-10 text-red-500">Failed to load profile.</p>;

  const validationSchema = Yup.object().shape({
    firstName: Yup.string().required("First name is required"),
    lastName: Yup.string().required("Last name is required"),
    email: Yup.string().email("Please enter a valid email").required("Email is required"),
    phoneNumber: Yup.string()
      .matches(/^\d{10}$/, "Phone number must be exactly 10 digits")
      .required("Phone number is required"),
    address: Yup.string().required("Address is required"),
    city: Yup.string().required("City is required"),
    state: Yup.string().required("State is required"),
    country: Yup.string().required("Country is required"),
    zipcode: Yup.string().matches(/^\d{6}$/, "Zipcode must be exactly 6 digits").required("Zipcode is required"),
  });
  
  return (
    <div className="max-w-5xl mx-auto mt-10 bg-white shadow-lg rounded-lg p-8 border border-gray-200">
      <button
        onClick={() => router.push("/my-blogs")}
        className="flex items-center text-blue-600 hover:text-blue-800 mb-4"
      >
        <ArrowLeft size={20} className="mr-2" />
        <span>Back</span>
      </button>
      <h2 className="text-3xl font-bold text-center text-gray-800 mb-6">My Profile</h2>

      <Formik
        initialValues={{
          firstName: profile.firstName || "",
          lastName: profile.lastName || "",
          email: profile.email || "",
          phoneNumber: profile.phoneNumber || "",
          profileImage: profile.profileImage || null,
          address: profile.address || "",
          city: profile.city || "",
          state: profile.state || "",
          country: profile.country || "",
          zipcode: profile.zipcode || "",
        }}
        validationSchema={validationSchema}
        onSubmit={async (values, { setSubmitting }) => {
          const token = localStorage.getItem("token");
          if (!token) return;

          const formData = new FormData();
          Object.entries(values).forEach(([key, value]) => {
            if (value !== null && value !== undefined && key !== "profileImage") {
              formData.append(key, value as string);
            }
          });

          if (values.profileImage && typeof values.profileImage !== "string") {
            formData.append("profileImage", values.profileImage as File);
          }

          try {
            const response = await axios.post("http://localhost:4001/api/v1/auth/updateUserProfile", formData, {
              headers: {
                Authorization: `Bearer ${token}`,
                "Content-Type": "multipart/form-data",
              },
            });

            alert("Profile updated successfully!");

            const responseData = response.data as { data: ProfileData };
            if (responseData.data.profileImage) {
              setProfileImagePreview(`http://localhost:4001${responseData.data.profileImage}`);
            }
          } catch (error) {
            console.error("Error updating profile:", error);
            alert("Failed to update profile.");
          } finally {
            setSubmitting(false);
          }
        }}
        enableReinitialize
      >
        {({ setFieldValue }) => (
          <Form className="grid grid-cols-1 md:grid-cols-3 gap-6">
            {/* Left Sidebar - Profile Image & Blog Count */}
            <div className="flex flex-col items-center">
              <div
                className="w-32 h-32 rounded-full shadow-lg cursor-pointer flex justify-center items-center"
                onClick={() => {
                  document.getElementById("profileImageInput")?.click();
                }}
              >
                {profileImagePreview ? (
                  <img
                    src={profileImagePreview}
                    alt="Profile Preview"
                    className="w-32 h-32 rounded-full"
                  />
                ) : (
                  <UserCircle size={100} className="text-gray-400" />
                )}
              </div>

              {/* Profile Image Upload */}
              <input
                id="profileImageInput"
                type="file"
                accept="image/*"
                key={imageInputKey} // Reset key when changing profile image
                onChange={(event) => {
                  const file = event.currentTarget.files?.[0];
                  if (file) {
                    setProfileImagePreview(URL.createObjectURL(file));
                    setFieldValue("profileImage", file);
                    setImageInputKey(prev => prev + 1); // Reset input key
                  }
                }}
                className="hidden"
              />

              <p className="mt-3 font-semibold text-gray-700">
                Total Blogs Posted: <span className="text-blue-500">{blogCount}</span>
              </p>
            </div>

            {/* Middle Section - Basic Info */}
            <div className="space-y-4">
              <div className="flex flex-col">
                <label className="text-gray-700 font-medium capitalize">
                  First Name <span className="text-red-500">*</span>
                </label>
                <Field
                  name="firstName"
                  placeholder="Enter your first name"
                  className="border border-gray-300 rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
                />
                <ErrorMessage name="firstName" component="div" className="text-red-500 text-sm mt-1" />
              </div>

              <div className="flex flex-col">
                <label className="text-gray-700 font-medium capitalize">
                  Last Name <span className="text-red-500">*</span>
                </label>
                <Field
                  name="lastName"
                  placeholder="Enter your last name"
                  className="border border-gray-300 rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
                />
                <ErrorMessage name="lastName" component="div" className="text-red-500 text-sm mt-1" />
              </div>

              <div className="flex flex-col">
                <label className="text-gray-700 font-medium capitalize">
                  Phone Number <span className="text-red-500">*</span>
                </label>
                <Field
                  name="phoneNumber"
                  placeholder="Enter your phone number"
                  className="border border-gray-300 rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
                />
                <ErrorMessage name="phoneNumber" component="div" className="text-red-500 text-sm mt-1" />
              </div>

              <div className="flex flex-col">
                <label className="text-gray-700 font-medium capitalize">
                  Email
                </label>
                <Field
                  name="email"
                  disabled
                  placeholder="Enter your email"
                  className="border border-gray-300 rounded-md px-3 py-2 bg-gray-200 text-gray-500 cursor-not-allowed focus:ring-0 outline-none"
                />
                <ErrorMessage name="email" component="div" className="text-red-500 text-sm mt-1" />
              </div>
              <div className="flex flex-col">
                <label className="text-gray-700 font-medium capitalize">
                  Country <span className="text-red-500">*</span>
                </label>
                <Field
                  name="country"
                  placeholder="Enter your country"
                  className="border border-gray-300 rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
                />
                <ErrorMessage name="country" component="div" className="text-red-500 text-sm mt-1" />
              </div>
            </div>

            {/* Right Section - Address Details */}
            <div className="space-y-4">
              <div className="flex flex-col">
                <label className="text-gray-700 font-medium capitalize">
                  Address <span className="text-red-500">*</span>
                </label>
                <Field
                  name="address"
                  as="textarea"
                  rows={4}
                  placeholder="Enter your address"
                  className="border border-gray-300 rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
                  style={{ paddingTop: '18px' }}

                />
                <ErrorMessage name="address" component="div" className="text-red-500 text-sm mt-1" />
              </div>

              <div className="flex flex-col">
                <label className="text-gray-700 font-medium capitalize">
                  City <span className="text-red-500">*</span>
                </label>
                <Field
                  name="city"
                  placeholder="Enter your city"
                  className="border border-gray-300 rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
                />
                <ErrorMessage name="city" component="div" className="text-red-500 text-sm mt-1" />
              </div>

              <div className="flex flex-col">
                <label className="text-gray-700 font-medium capitalize">
                  State <span className="text-red-500">*</span>
                </label>
                <Field
                  name="state"
                  placeholder="Enter your state"
                  className="border border-gray-300 rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
                />
                <ErrorMessage name="state" component="div" className="text-red-500 text-sm mt-1" />
              </div>

              <div className="flex flex-col">
                <label className="text-gray-700 font-medium capitalize">
                  Zipcode <span className="text-red-500">*</span>
                </label>
                <Field
                  name="zipcode"
                  placeholder="Enter your zipcode"
                  className="border border-gray-300 rounded-md px-3 py-2 focus:ring-2 focus:ring-blue-500 outline-none"
                />
                <ErrorMessage name="zipcode" component="div" className="text-red-500 text-sm mt-1" />
              </div>
            </div>

            {/* Submit Button */}
            <div className="col-span-full text-right">
              <button
                type="submit"
                className="bg-blue-600 text-white px-6 py-2 rounded-lg shadow-md transition-transform transform hover:scale-105 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-400"
                disabled={loading}
              >
                {loading ? "Updating..." : "Update Profile"}
              </button>
            </div>

          </Form>
        )}
      </Formik>
    </div>

  );
};

export default Profile;
