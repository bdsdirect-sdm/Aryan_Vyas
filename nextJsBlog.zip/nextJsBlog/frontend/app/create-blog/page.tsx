"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import axios from "axios";
import FormInput from "../../components/FormInput";

const categories = [
  "Technology",
  "Music",
  "Health & Wellness",
  "Food & Cooking",
  "Travel",
  "Lifestyle",
  "Finance & Business",
  "Personal Development",
  "Fashion & Beauty",
  "Sports & Fitness",
  "Entertainment",
  "Parenting & Family",
  "Education & Learning",
  "Gaming",
  "Science & Innovation",
  "Photography & Art",
  "DIY & Home Improvement",
  "Automobiles & Vehicles",
  "Politics & Current Affairs",
  "Spirituality & Mindfulness",
  "Books & Literature",
];

const CreateBlog = () => {
  const router = useRouter();
  const [form, setForm] = useState({
    blogTitle: "",
    blogContent: "",
    blogCategory: categories[0], // Default to first category
  });
  const [blogImage, setBlogImage] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Handle input change
  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  // Handle file selection
  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      setBlogImage(e.target.files[0]);
    }
  };

  // Submit form
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);

    const token = localStorage.getItem("token");
    if (!token) {
      setError("You must be logged in to create a blog.");
      return;
    }

    // FormData for file upload
    const formData = new FormData();
    formData.append("blogTitle", form.blogTitle);
    formData.append("blogContent", form.blogContent);
    formData.append("blogCategory", form.blogCategory);
    if (blogImage) {
      formData.append("blogImage", blogImage);
    }

    try {
      await axios.post("http://localhost:4001/api/v1/auth/createBlog", formData, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "multipart/form-data",
        },
      });
      router.push("/my-blogs");
    } catch (err) {
      setError("Blog creation failed. Please try again.");
      console.error("Error:", err);
    }
  };

  return (
    <div className="max-w-lg mx-auto mt-10 p-6 bg-white rounded shadow">
      <h1 className="text-xl font-bold mb-4">Create Blog</h1>
      {error && <p className="text-red-500">{error}</p>}
      <form onSubmit={handleSubmit} className="space-y-4">
      <FormInput label="Title" name="blogTitle" type="text" value={form.blogTitle} onChange={handleChange} required={true} />
<FormInput label="Content" name="blogContent" type="text" value={form.blogContent} onChange={handleChange} required={false} />


        {/* Category Dropdown */}
        <label className="block text-sm font-medium">Category</label>
        <select
          name="blogCategory"
          value={form.blogCategory}
          onChange={handleChange}
          className="w-full p-2 border rounded"
        >
          {categories.map((category) => (
            <option key={category} value={category}>
              {category}
            </option>
          ))}
        </select>

        {/* File Upload */}
        <label className="block text-sm font-medium">Upload Image</label>
        <input type="file" onChange={handleFileChange} className="w-full p-2 border rounded" />

        <button type="submit" className="w-full bg-blue-500 text-white py-2 rounded">
          Submit
        </button>
      </form>
    </div>
  );
};

export default CreateBlog;
