"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import axios from "axios";
import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import { ArrowLeft } from "lucide-react";

const categories = [
  "Technology",
  "Music",
  "Health & Wellness",
  "Food & Cooking",
  "Travel",
  "Lifestyle",
  "Finance & Business",
  "Personal Development",
  "Fashion & Beauty",
  "Sports & Fitness",
  "Entertainment",
  "Parenting & Family",
  "Education & Learning",
  "Gaming",
  "Science & Innovation",
  "Photography & Art",
  "DIY & Home Improvement",
  "Automobiles & Vehicles",
  "Politics & Current Affairs",
  "Spirituality & Mindfulness",
  "Books & Literature",
];

// Yup validation schema
const blogSchema = Yup.object().shape({
  blogTitle: Yup.string()
    .min(2, "Blog title must be at least 2 characters")
    .max(100, "Blog title must be at most 100 characters")
    .required("Blog title is required"),
  blogContent: Yup.string()
    .min(10, "Content must be at least 10 characters long")
    .required("Content is required"),
  blogCategory: Yup.string()
    .oneOf(categories, "Invalid category selected")
    .required("Category is required"),
  blogImage: Yup.mixed().nullable(),
});

const CreateBlog = () => {
  const router = useRouter();
  const [error, setError] = useState<string | null>(null);

  // Submit form
  const handleSubmit = async (
    values: { blogTitle: string; blogContent: string; blogCategory: string; blogImage: File | null },
    { setSubmitting }: { setSubmitting: (isSubmitting: boolean) => void }
  ) => {
    setError(null);
    const token = localStorage.getItem("token");
    if (!token) {
      setError("You must be logged in to create a blog.");
      setSubmitting(false);
      return;
    }

    const formData = new FormData();
    formData.append("blogTitle", values.blogTitle);
    formData.append("blogContent", values.blogContent);
    formData.append("blogCategory", values.blogCategory);
    if (values.blogImage) {
      formData.append("blogImage", values.blogImage);
    }

    try {
      await axios.post("http://localhost:4001/api/v1/auth/createBlog", formData, {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "multipart/form-data",
        },
      });
      router.push("/my-blogs");
    } catch (err) {
      setError("Blog creation failed. Please try again.");
      console.error("Error:", err);
    }
    setSubmitting(false);
  };

  return (
    <div className="max-w-lg mx-auto mt-10 p-6 bg-white rounded shadow">
      {/* Back Button */}
      <button
        onClick={() => router.push("/my-blogs")}
        className="flex items-center text-blue-600 hover:text-blue-800 mb-4"
      >
        <ArrowLeft size={20} className="mr-2" />
        <span>Back</span>
      </button>

      <h1 className="text-xl font-bold mb-4">Create Blog</h1>
      {error && <p className="text-red-500">{error}</p>}

      {/* Formik Form */}
      <Formik
        initialValues={{
          blogTitle: "",
          blogContent: "",
          blogCategory: categories[0],
          blogImage: null,
        }}
        validationSchema={blogSchema}
        onSubmit={handleSubmit}
      >
        {({ setFieldValue, isSubmitting }) => (
          <Form className="space-y-4">
            {/* Title */}
            <div>
              <label className="block text-sm font-medium mb-3">
                Title<span className="text-red-500">*</span>
              </label>
              <Field
                name="blogTitle"
                type="text"
                placeholder="Enter your blog title"
                className="w-full p-2 border rounded"
              />
              <ErrorMessage name="blogTitle" component="p" className="text-red-500 text-sm" />
            </div>

            {/* Content */}
            <div>
              <label className="block text-sm font-medium mb-3">
                Content<span className="text-red-500">*</span>
              </label>
              <Field
                as="textarea"
                name="blogContent"
                placeholder="Write your content here..."
                className="w-full p-2 border rounded"
                rows={5}
              />
              <ErrorMessage name="blogContent" component="p" className="text-red-500 text-sm" />
            </div>

            {/* Category Dropdown */}
            <div>
              <label className="block text-sm font-medium mb-3">
                Category<span className="text-red-500">*</span>
              </label>
              <Field as="select" name="blogCategory" className="w-full p-2 border rounded">
                {categories.map((category) => (
                  <option key={category} value={category}>
                    {category}
                  </option>
                ))}
              </Field>
              <ErrorMessage name="blogCategory" component="p" className="text-red-500 text-sm" />
            </div>

            {/* File Upload */}
            <div>
              <label className="block text-sm font-medium mb-3">Upload Image</label>
              <input
                type="file"
                className="w-full p-2 border rounded"
                onChange={(event) => setFieldValue("blogImage", event.currentTarget.files?.[0])}
              />
              <ErrorMessage name="blogImage" component="p" className="text-red-500 text-sm" />
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              className="w-full bg-blue-600 text-white py-2 rounded-lg shadow-md transition-transform transform hover:scale-105 hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-400"
              disabled={isSubmitting}
            >
              {isSubmitting ? "Creating Blog..." : "Create Blog"}
            </button>
          </Form>
        )}
      </Formik>
    </div>
  );
};

export default CreateBlog;
