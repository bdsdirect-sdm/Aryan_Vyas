import { AuthProvider } from "../context/AuthContext";
import Navbar from "../components/Navbar";
import "./global.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "VyasVerse – Unleash Your Thoughts, Share Your Stories",
  description: "A dynamic blogging platform for sharing ideas, publishing articles, and engaging with a like-minded community.",
  icons: {
    icon: "/favicon.png",
  },
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/favicon.png" type="image/png" />
      </head>
      <body>
        <AuthProvider>
          <Navbar />
          {children}
        </AuthProvider>
      </body>
    </html>
  );
}
