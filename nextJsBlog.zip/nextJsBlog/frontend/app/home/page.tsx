"use client";

import { useEffect, useState } from "react";
import axios from "axios";
import Image from "next/image";
import { useRouter } from "next/navigation";

interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
}

interface Blog {
  id: string;
  bloggerId: string;
  blogTitle: string;
  blogContent: string;
  blogCategory: string;
  blogImage?: string;
  createdAt: string;
  updatedAt: string;
  userBlogs: User;
}

const HomePage = () => {
  const [blogs, setBlogs] = useState<Blog[]>([]);
  const [expandedBlog, setExpandedBlog] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  useEffect(() => {
    const fetchBlogs = async () => {
      try {
        const token = localStorage.getItem("token");
        if (!token) {
          setError("You need to log in first. Redirecting...");
          setTimeout(() => router.push("/login"), 5000);
          return;
        }

        const response = await axios.get<{ blogs: Blog[] }>(
          "http://localhost:4001/api/v1/auth/viewAllBlogs",
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );

        setBlogs(response.data.blogs);
      } catch (err) {
        console.log("⚠️ Failed to load blogs. Please try again.", err);
        setError("⚠️ Failed to load blogs. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    fetchBlogs();
  }, [router]);

  return (
    <div className="max-w-6xl mx-auto mt-10 px-6">
      <h1 className="text-3xl font-bold text-center text-gray-800 mb-8">
        📖 All Blogs
      </h1>

      {loading ? (
        // 🔥 Skeleton Loader - Dynamically Matches Blog Count (At Least 3)
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {Array.from({ length: Math.max(blogs.length || 3, 3) }).map(
            (_, index) => (
              <div
                key={index}
                className="bg-white rounded-lg shadow-md p-4 animate-pulse"
              >
                <div className="w-full h-52 bg-gray-300 rounded-md"></div>
                <div className="h-6 bg-gray-300 rounded w-3/4 mt-3"></div>
                <div className="h-4 bg-gray-300 rounded w-1/2 mt-2"></div>
                <div className="h-16 bg-gray-300 rounded w-full mt-3"></div>
                <div className="h-4 bg-gray-300 rounded w-1/3 mt-2"></div>
              </div>
            )
          )}
        </div>
      ) : error ? (
        <div className="flex justify-center items-center h-screen">
          <p className="text-lg text-red-500">{error}</p>
        </div>
      ) : blogs.length === 0 ? (
        <p className="text-center text-gray-500">No blogs available.</p>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {blogs.map((blog) => (
            <div
              key={blog.id}
              className="bg-white rounded-lg shadow-md p-4 transform transition duration-300 hover:shadow-xl hover:-translate-y-2"
            >
              {/* Blog Image - Always Visible */}
              {blog.blogImage && (
                <div className="w-full h-52 flex justify-center items-center overflow-hidden rounded-md">
                  <Image
                    src={`http://localhost:4001${blog.blogImage}`}
                    alt="Blog Image"
                    width={300}
                    height={200}
                    className="w-auto h-full object-contain"
                    unoptimized
                  />
                </div>
              )}

              {/* Blog Title & Category - Always Visible */}
              <p className="text-xl font-semibold text-gray-800 mt-3">
                <strong>Title: </strong>
                {blog.blogTitle}
              </p>
              <p className="text-sm text-gray-500">
                <strong>Category: </strong>
                {blog.blogCategory}
              </p>

              {/* Read More Section */}
              {expandedBlog === blog.id ? (
                <>
                  <p className="text-gray-600 mt-3">
                    <strong>Content:</strong>
                    {blog.blogContent}
                  </p>

                  {blog.userBlogs && (
                    <p className="mt-4 text-sm text-gray-700">
                      <strong>Published By: </strong>
                      {blog.userBlogs.firstName} {blog.userBlogs.lastName}
                    </p>
                  )}

                  <p className="text-xs text-gray-500 mt-1">
                    <strong>Published on: </strong>
                    {new Date(blog.createdAt).toLocaleDateString()} at{" "}
                    {new Date(blog.createdAt).toLocaleTimeString()}
                  </p>

                  <button
                    onClick={() => setExpandedBlog(null)}
                    className="mt-4 text-blue-500 hover:underline text-sm"
                  >
                    Show Less
                  </button>
                </>
              ) : (
                <button
                  onClick={() => setExpandedBlog(blog.id)}
                  className="mt-3 text-blue-500 hover:underline text-sm"
                >
                  Read More
                </button>
              )}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default HomePage;
