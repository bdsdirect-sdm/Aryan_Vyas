"use client";

import { useEffect, useState } from "react";
import axios from "axios";
import Image from "next/image";
import { useRouter } from "next/navigation";

interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
}

interface Blog {
  id: string;
  bloggerId: string;
  blogTitle: string;
  blogContent: string;
  blogCategory: string;
  blogImage?: string;
  createdAt: string;
  updatedAt: string;
  userBlogs: User;
}

const HomePage = () => {
  const [blogs, setBlogs] = useState<Blog[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();

  useEffect(() => {
    const fetchBlogs = async () => {
      try {
        const token = localStorage.getItem("token");
        if (!token) {
          console.error("Access token is missing");
          setError("You need to log in first to see your home page. Redirecting to login page...");

          setTimeout(() => {
            router.push("/login");
          }, 5000);

          return;
        }

        const response = await axios.get<{ blogs: Blog[] }>(
          "http://localhost:4001/api/v1/auth/viewAllBlogs",
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );

        console.log("Fetched Blogs:", response.data.blogs);
        setBlogs(response.data.blogs);
      } catch (err) {
        console.error("Error fetching blogs:", err);
        setError("⚠️ Failed to load blogs. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    fetchBlogs();
  }, [router]);

  if (loading)
    return (
      <div className="flex justify-center items-center h-screen">
        <p className="text-lg text-gray-600 animate-pulse">Loading blogs...</p>
      </div>
    );

  if (error)
    return (
      <div className="flex justify-center items-center h-screen">
        <p className="text-lg text-red-500">{error}</p>
      </div>
    );

  return (
    <div className="max-w-6xl mx-auto mt-10 px-6">
      <h1 className="text-3xl font-bold text-center text-gray-800 mb-8">📖 All Blogs</h1>

      {blogs.length === 0 ? (
        <p className="text-center text-gray-500">No blogs available.</p>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {blogs.map((blog) => (
            <div
              key={blog.id}
              className="bg-white rounded-lg shadow-md p-4 transform transition duration-300 hover:shadow-xl hover:-translate-y-2"
            >
              {/* Blog Image */}
              {blog.blogImage && (
                <Image
                  src={`http://localhost:4001${blog.blogImage}`}
                  alt="Blog Image"
                  width={300}
                  height={200}
                  className="h-48 object-cover rounded-lg"
                  unoptimized
                />
              )}

              <p className="text-xl font-semibold text-gray-800 mt-4"><strong>Blog Title: </strong>{blog.blogTitle}</p>
              <p className="text-sm text-gray-500"><strong>Blog Category: </strong>{blog.blogCategory}</p>

              <p className="text-gray-600 mt-2">
                <strong>Blog Content: </strong>
                {blog.blogContent.length > 100
                  ? `${blog.blogContent.substring(0, 100)}...`
                  : blog.blogContent}
              </p>

              {blog.userBlogs && (
                <p className="mt-4 text-sm text-gray-700">
                  <strong>Published By: </strong>{blog.userBlogs.firstName} {blog.userBlogs.lastName}
                </p>
              )}
              <p className="text-xs text-gray-500 mt-1">
              <strong>Published on: </strong>{new Date(blog.createdAt).toLocaleDateString()} at {new Date(blog.createdAt).toLocaleTimeString()} 
              </p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};

export default HomePage;
