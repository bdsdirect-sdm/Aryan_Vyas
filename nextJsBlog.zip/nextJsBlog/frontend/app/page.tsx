"use client";

import { useEffect, useState } from "react";
import BlogCard from "../components/BlogCard";
import axios from "axios";

const Home = () => {
  interface Blog {
    id: string;
    blogTitle: string;
    blogContent: string;
    blogCategory: string;
  }

  const [blogs, setBlogs] = useState<Blog[]>([]);

  const fetchBlogs = async () => {
    try {
      const response = await axios.get<{ blogs: Blog[] }>("http://localhost:4001/api/v1/auth/getBlogs");
      setBlogs(response.data.blogs);
    } catch (error) {
      console.error("Error fetching blogs:", error);
    }
  };

  useEffect(() => {
    fetchBlogs();
  }, []);

  return (
    <div className="container mx-auto px-4 py-8">
      <h1 className="text-3xl font-semibold text-center text-gray-800 mb-8">Latest Blogs</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {blogs.map((blog) => (
          <BlogCard 
            key={blog.id} 
            title={blog.blogTitle} 
            content={blog.blogContent} 
            category={blog.blogCategory} 
          />
        ))}
      </div>
    </div>
  );
};

export default Home;
