"use client";

import { useEffect, useState } from "react";
import axios from "axios";
import Image from "next/image";
import { useRouter } from "next/navigation";
import { useAuth } from "../context/AuthContext";

interface User {
  id: string;
  firstName: string;
  lastName: string;
  email: string;
}

interface Blog {
  id: string;
  bloggerId: string;
  blogTitle: string;
  blogContent: string;
  blogCategory: string;
  blogImage?: string;
  createdAt: string;
  updatedAt: string;
  userBlogs: User;
}

const LandingPage = () => {
  const [blogs, setBlogs] = useState<Blog[]>([]);
  const [expandedBlog, setExpandedBlog] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const router = useRouter();
  const { isLoggedIn } = useAuth();

  useEffect(() => {
    if (isLoggedIn) {
      router.replace("/home");
      return;
    }

    const fetchBlogs = async () => {
      try {
        const response = await axios.get<{ blogs: Blog[] }>(
          "http://localhost:4001/api/v1/auth/viewAllBlogs"
        );
        setBlogs(response.data.blogs);
      } catch (err) {
        console.error("Error fetching blogs:", err);
        setError("⚠️ Failed to load blogs. Please try again.");
      } finally {
        setLoading(false);
      }
    };

    fetchBlogs();
  }, [isLoggedIn, router]);

  if (loading)
    return (
      <div className="flex justify-center items-center h-screen">
        <p className="text-lg text-gray-600 animate-pulse">Loading blogs...</p>
      </div>
    );

  if (error)
    return (
      <div className="flex justify-center items-center h-screen">
        <p className="text-lg text-red-500">{error}</p>
      </div>
    );

  return (
    <div className="max-w-6xl mx-auto mt-10 px-6">
      <h1 className="text-3xl font-bold text-center text-gray-800 mb-8">📖 Explore Blogs</h1>

      {blogs.length === 0 ? (
        <p className="text-center text-gray-500">No blogs available.</p>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {blogs.map((blog) => (
            <div
              key={blog.id}
              className="bg-white rounded-lg shadow-md p-4 transform transition duration-300 hover:shadow-xl hover:-translate-y-2"
            >
              {/* Blog Image - Always Visible */}
              {blog.blogImage && (
                <div className="w-[300px] h-[200px] flex justify-center items-center overflow-hidden">
                  <Image
                    src={`http://localhost:4001${blog.blogImage}`}
                    alt="Blog Image"
                    width={300}
                    height={200}
                    className="w-auto h-full object-contain"
                    unoptimized
                  />
                </div>
              )}

              {/* Always Visible: Blog Title & Category */}
              <p className="text-xl font-semibold text-gray-800 mt-4"><strong>Title: </strong>{blog.blogTitle}</p>
              <p className="text-sm text-gray-500"><strong>Category: </strong>{blog.blogCategory}</p>

              {/* Expandable Content */}
              {expandedBlog === blog.id ? (
                <>
                  <p className="text-gray-600 mt-2"><strong>Content: </strong>{blog.blogContent}</p>
                  {blog.userBlogs && (
                    <p className="mt-4 text-sm text-gray-700">
                      <strong>Published By:</strong> {blog.userBlogs.firstName} {blog.userBlogs.lastName}
                    </p>
                  )}
                  <p className="text-xs text-gray-500 mt-1">
                    <strong>Published on:</strong> {new Date(blog.createdAt).toLocaleDateString()} at{" "}
                    {new Date(blog.createdAt).toLocaleTimeString()}
                  </p>

                  {/* Show Less Button */}
                  <button
                    className="mt-3 text-blue-500 hover:underline"
                    onClick={() => setExpandedBlog(null)}
                  >
                    Show Less
                  </button>
                </>
              ) : (
                <button
                  className="mt-3 text-blue-500 hover:underline"
                  onClick={() => setExpandedBlog(blog.id)}
                >
                  Read More
                </button>
              )}
            </div>
          ))}
        </div>
      )}

      {/* Call to Action for New Users */}
      <div className="text-center mt-12 p-6 bg-gray-100 rounded-lg shadow-md">
        <h2 className="text-xl font-semibold text-gray-700">✍️ Love Writing? Join Us!</h2>
        <p className="text-gray-600 mt-2">
          If you enjoy reading our blogs and want to contribute, start blogging today!
        </p>
        <div className="mt-4">
          <button
            className="bg-blue-600 text-white px-6 py-2 rounded-md hover:bg-blue-700 transition"
            onClick={() => router.push("/register")}
          >
            Register
          </button>
          <span className="mx-2 text-gray-500">or</span>
          <button
            className="bg-green-600 text-white px-6 py-2 rounded-md hover:bg-green-700 transition"
            onClick={() => router.push("/login")}
          >
            Login
          </button>
        </div>
      </div>
    </div>
  );
};

export default LandingPage;
