"use client";

import { createContext, useContext, useEffect, useState } from "react";

interface AuthContextType {
  isLoggedIn: boolean;
  login: (token: string) => void;
  logout: () => void;
  userProfile: { firstName: string; lastName: string; email: string; profileImage?: string } | null;
  updateUserProfile: (profileData: { firstName: string; lastName: string; email: string; profileImage?: string }) => void;
}

const AuthContext = createContext<AuthContextType | null>(null);

export const AuthProvider = ({ children }: { children: React.ReactNode }) => {
  const [isLoggedIn, setIsLoggedIn] = useState<boolean>(false);
  const [userProfile, setUserProfile] = useState<{ firstName: string; lastName: string; email: string; profileImage?: string } | null>(null);

  useEffect(() => {
    const token = localStorage.getItem("token");
    if (token) {
      setIsLoggedIn(true);
      // Optionally fetch user data here, for example, using an API request
    } else {
      setIsLoggedIn(false);
    }
  }, []);

  const login = (token: string) => {
    localStorage.setItem("token", token);
    setIsLoggedIn(true);
  };

  const logout = () => {
    localStorage.removeItem("token");
    setIsLoggedIn(false);
    setUserProfile(null); // Clear user profile on logout
  };

  const updateUserProfile = (profileData: { firstName: string; lastName: string; email: string; profileImage?: string }) => {
    setUserProfile(profileData); // Update profile
  };

  return (
    <AuthContext.Provider value={{ isLoggedIn, login, logout, userProfile, updateUserProfile }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error("useAuth must be used within an AuthProvider");
  }
  return context;
};
