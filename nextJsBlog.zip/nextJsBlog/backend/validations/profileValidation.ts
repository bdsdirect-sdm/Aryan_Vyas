import Joi from "joi";

export const updateProfileValidation = Joi.object({
  firstName: Joi.string().min(2).max(30).optional()
    .messages({ "string.min": "First Name must be at least 2 characters", "string.max": "First Name must be at most 30 characters" }),
  
  lastName: Joi.string().min(2).max(30).optional()
    .messages({ "string.min": "Last Name must be at least 2 characters", "string.max": "Last Name must be at most 30 characters" }),

  email: Joi.string().email().optional()
    .messages({ "string.email": "Please enter a valid email" }),

  phoneNumber: Joi.string().pattern(/^\d{10}$/).optional()
    .messages({ "string.pattern.base": "Phone number must be exactly 10 digits" }),

  profileImage: Joi.string().allow(null, '').optional()
    .messages({ "string.base": "Profile Image must be a valid URL or file path" }),

  address: Joi.string().max(255).optional()
    .messages({ "string.max": "Address must be at most 255 characters" }),

  city: Joi.string().max(50).optional()
    .messages({ "string.max": "City must be at most 50 characters" }),

  state: Joi.string().max(50).optional()
    .messages({ "string.max": "State must be at most 50 characters" }),

  country: Joi.string().max(50).optional()
    .messages({ "string.max": "Country must be at most 50 characters" }),

  zipcode: Joi.string().pattern(/^\d{6}$/).optional()
    .messages({ "string.pattern.base": "Zipcode must be exactly 6 digits" }),
});