import Joi from "joi";

export const blogValidation = Joi.object({
    blogTitle: Joi.string().min(2).max(100).required()
        .messages({
            "any.required": "Blog title is required",
            "string.min": "Blog title must be at least 2 characters",
            "string.max": "Blog title must be at most 100 characters",
        }),

    blogContent: Joi.string().min(10).required()
        .messages({
            "any.required": "Content is required",
            "string.min": "Content must be at least 10 characters long",
        }),

    blogImage: Joi.string().allow(null, '').optional()
        .messages({
            "string.base": "Blog image must be a string.",
        }),

        blogCategory: Joi.string()
        .valid(
          "Technology",
          "Music",
          "Health & Wellness",
          "Food & Cooking",
          "Travel",
          "Lifestyle",
          "Finance & Business",
          "Personal Development",
          "Fashion & Beauty",
          "Sports & Fitness",
          "Entertainment",
          "Parenting & Family",
          "Education & Learning",
          "Gaming",
          "Science & Innovation",
          "Photography & Art",
          "DIY & Home Improvement",
          "Automobiles & Vehicles",
          "Politics & Current Affairs",
          "Spirituality & Mindfulness",
          "Books & Literature"
        )
        .required()
        .messages({
          "string.base": "Category must be a string.",
          "any.required": "Category is required.",
          "any.only":
            "Category must be one of the predefined options: Technology, Health & Wellness, Food & Cooking, Travel, Lifestyle, Finance & Business, Personal Development, Fashion & Beauty, Sports & Fitness, Entertainment, Parenting & Family, Education & Learning, Gaming, Science & Innovation, Photography & Art, DIY & Home Improvement, Automobiles & Vehicles, Politics & Current Affairs, Spirituality & Mindfulness, Books & Literature.",
        }),
});
