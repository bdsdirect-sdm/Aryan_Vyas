import { ValidationError } from 'joi';

export const handleValidationMessages = (error: ValidationError) => {
  const messages = error.details.map(detail => detail.message);
  return {
    status: 'error',
    statusCode: 400,
    message: 'Validation failed',
    errors: messages,
  };
};