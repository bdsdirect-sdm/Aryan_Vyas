import { Model, DataTypes } from 'sequelize';
import sequelize from '../config/database';

class Users extends Model {
    public id!: string;
    public firstName!: string;
    public lastName!: string;
    public email!: string;
    public password!: string;
    public phoneNumber!: string | null;
    public profileImage!: string | null;
    public address!: string | null;
    public city!: string | null;
    public state!: string | null;
    public country!: string | null;
    public zipcode!: string | null;
    public failedLoginAttempts!: number;
    public passwordLock!: boolean;
    public lockedUntil!: Date | null;
}

Users.init(
    {
        id: {
            type: DataTypes.UUID,
            defaultValue: DataTypes.UUIDV4,
            primaryKey: true,
        },
        firstName: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        lastName: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        email: {
            type: DataTypes.STRING,
            unique: true,
            allowNull: false,
        },
        password: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        phoneNumber: {
            type: DataTypes.STRING,
            allowNull: true,
            validate: {
                is: /^\d{10}$/,
            },
        },
        profileImage: {
            type: DataTypes.STRING,
            allowNull: true, // Profile image is optional
        },
        address: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        city: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        state: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        country: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        zipcode: {
            type: DataTypes.STRING,
            allowNull: true,
            validate: {
                is: /^\d{6}$/,
            },
        },
        failedLoginAttempts: {
            type: DataTypes.INTEGER,
            defaultValue: 0,
        },
        passwordLock: {
            type: DataTypes.BOOLEAN,
            defaultValue: false,
        },
        lockedUntil: {
            type: DataTypes.DATE,
            defaultValue: null,
        },
    },
    {
        sequelize,
        modelName: 'users',
    }
);

console.log("Table Name>>>>>>>", Users.getTableName());

export default Users;
