import sequelize from "../config/database";
import Users from "./users";
import Blogs from "./blogs";

Users.hasMany(Blogs, {foreignKey: 'bloggerId', as: 'blogsUser'});
Blogs.belongsTo(Users, {foreignKey: 'bloggerId', as:'userBlogs'});

export {  sequelize,Users, Blogs};