import { Model, DataTypes } from "sequelize";
import sequelize from "../config/database";

class Blogs extends Model {
    public id!: string;
    public bloggerId!: string;
    public blogTitle!: string;
    public blogContent!: string;
    public blogImage!: string | null;
    public blogCategory!: string;
}

Blogs.init(
    {
        id: {
            type: DataTypes.UUID,
            defaultValue: DataTypes.UUIDV4,
            primaryKey: true,
            allowNull: false,
        },
        bloggerId: {
            type: DataTypes.UUID,
            allowNull: false,
            references: {
                model: "users",
                key: "id",
            },
            onDelete: "CASCADE",
        },
        blogTitle: {
            type: DataTypes.STRING,
            allowNull: false,
        },
        blogContent: {
            type: DataTypes.TEXT,
            allowNull: false,
        },
        blogImage: {
            type: DataTypes.STRING,
            allowNull: true,
        },
        blogCategory: {
            type: DataTypes.STRING,
            allowNull: false,
        },
    },
    {
        sequelize,
        modelName: "blogs",
    }
);

export default Blogs;
