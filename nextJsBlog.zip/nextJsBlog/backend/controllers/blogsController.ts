import {Request, Response} from 'express';
import {StatusCodes} from '../utils/statusCodes';
import {StatusMessages} from '../utils/statusMessages';
import {Users,Blogs} from '../models';
import {v4 as uuidv4} from 'uuid';
import {blogValidation} from '../validations/blog.validation';
import {handleValidationMessages} from '../validations/handleValidationMessages';
import { Op } from 'sequelize';
import path from 'path';

export const createBlog = async (req: Request, res: Response): Promise<void> => {
    try {
        const { error } = blogValidation.validate(req.body);
        if (error) {
            res.status(StatusCodes.BAD_REQUEST).json({
                status: "BAD_REQUEST",
                message: error.details[0].message,
            });
            return;
        }
        const user = req.user as Users;
        if (!user) {
            res.status(StatusCodes.UNAUTHORIZED).json({
                status: "UNAUTHORIZED",
                message: "User not found",
            });
            return;
        }

        const { blogTitle, blogContent, blogCategory } = req.body;
        const imgPath = req.file ? `/uploads/${path.basename(req.file.path)}` : null;

        const newBlog = await Blogs.create({
            bloggerId: user.id,
            blogTitle,
            blogContent,
            blogImage: imgPath,
            blogCategory,
        });

        res.status(StatusCodes.CREATED).json({
            status: "OK",
            message: "Blog created successfully",
            blog: newBlog,
        });
    } catch (error) {
        console.error("Error creating blog:", error);
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            status: "INTERNAL_SERVER_ERROR",
            message: (error as Error).message,
        });
    }
};

export const getBlogs = async (req: Request, res: Response): Promise<void> => {
    try {
        const user = req.user as Users;

        if (!user) {
            res.status(StatusCodes.UNAUTHORIZED).json({
                status: "UNAUTHORIZED",
                message: "User not found",
            });
            return;
        }

        const searchQuery = (req.query.search as string) || "";
        const page = parseInt(req.query.page as string) || 1;
        const limit = 10;
        const offset = (page - 1) * limit;

        const blogs = await Blogs.findAndCountAll({
            where: {
                bloggerId: user.id,
                [Op.or]: [
                    { blogTitle: { [Op.like]: `%${searchQuery}%` } },   
                    { blogContent: { [Op.like]: `%${searchQuery}%` } },
                    { blogCategory: { [Op.like]: `%${searchQuery}%` } },
                ],
            },
            include: [
                {
                    model: Users,
                    as: "userBlogs",
                    attributes: ["id", "firstName", "lastName", "email"],
                },
            ],
            limit,
            offset,
            order: [["createdAt", "DESC"]],
        });

        const totalPages = Math.ceil(blogs.count / limit);

        res.status(StatusCodes.OK).json({
            status: "SUCCESS",
            message: blogs.count === 0 ? "No blogs found for this user" : "Blogs fetched successfully",
            blogs: blogs.rows,
            currentPage: page,
            totalPages,
            totalBlogs: blogs.count,
        });

    } catch (error) {
        console.error("Error fetching blogs:", error);
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            status: "INTERNAL_SERVER_ERROR",
            message: (error as Error).message,
        });
    }
};

export const getBlogsById = async (req: Request, res: Response): Promise<void> => {
    try {
        const user = req.user as Users;
        if (!user) {
            res.status(StatusCodes.UNAUTHORIZED).json({
                status: "UNAUTHORIZED",
                message: "User not found",
            });
            return;
        }

        const { id } = req.params;
        const blog = await Blogs.findOne({
            where: {
                id,
                bloggerId: user.id,
            },
            include: [
                {
                    model: Users,
                    as: "userBlogs",
                    attributes: ["id", "firstName", "lastName", "email"],
                },
            ],
        });

        if (!blog) {
            res.status(StatusCodes.NOT_FOUND).json({
                status: "NOT_FOUND",
                message: "Blog not found",
            });
            return;
        }

        res.status(StatusCodes.OK).json({
            status: "SUCCESS",
            message: "Blog fetched successfully",
            blog,
        });
    } catch (error) {
        console.error("Error fetching blog:", error);
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            status: "INTERNAL_SERVER_ERROR",
            message: (error as Error).message,
        });
    }
};

export const updateBlog = async (req: Request, res: Response): Promise<void> => {
    try {
        const user = req.user as Users;
        if (!user) {
            res.status(StatusCodes.UNAUTHORIZED).json({
                status: "UNAUTHORIZED",
                message: "User not found",
            });
            return;
        }

        const { id } = req.params;
        const blog = await Blogs.findOne({
            where: {
                id,
                bloggerId: user.id,
            },
        });

        if (!blog) {
            res.status(StatusCodes.NOT_FOUND).json({
                status: "NOT_FOUND",
                message: "Blog not found or unauthorized",
            });
            return;
        }

        const { blogTitle, blogContent, blogCategory } = req.body;
        const imgPath = req.file ? `/uploads/${path.basename(req.file.path)}` : blog.blogImage;

        await blog.update({
            blogTitle: blogTitle || blog.blogTitle,
            blogContent: blogContent || blog.blogContent,
            blogCategory: blogCategory || blog.blogCategory,
            blogImage: imgPath,
        });

        res.status(StatusCodes.OK).json({
            status: "SUCCESS",
            message: "Blog updated successfully",
            blog,
        });
    } catch (error) {
        console.error("Error updating blog:", error);
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            status: "INTERNAL_SERVER_ERROR",
            message: (error as Error).message,
        });
    }
};

export const deleteBlog = async (req: Request, res: Response): Promise<void> => {
    try {
        const user = req.user as Users;
        if (!user) {
            res.status(StatusCodes.UNAUTHORIZED).json({
                status: "UNAUTHORIZED",
                message: "User not found",
            });
            return;
        }

        const { id } = req.params;
        const blog = await Blogs.findOne({
            where: {
                id,
                bloggerId: user.id,
            },
        });

        if (!blog) {
            res.status(StatusCodes.NOT_FOUND).json({
                status: "NOT_FOUND",
                message: "Blog not found or unauthorized",
            });
            return;
        }

        await blog.destroy();

        res.status(StatusCodes.OK).json({
            status: "SUCCESS",
            message: "Blog deleted successfully",
        });
    } catch (error) {
        console.error("Error deleting blog:", error);
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            status: "INTERNAL_SERVER_ERROR",
            message: (error as Error).message,
        });
    }
};

export const viewAllBlogs = async (req: Request, res: Response): Promise<void> => {
    try {
        const blogs = await Blogs.findAll({
            include: [
                {
                    model: Users,
                    as: "userBlogs",
                    attributes: ["id", "firstName", "lastName", "email"],
                },
            ],
            order: [["createdAt", "DESC"]],
        });

        res.status(StatusCodes.OK).json({
            status: "SUCCESS",
            message: "All blogs fetched successfully",
            blogs,
        });
    } catch (error) {
        console.error("Error fetching blogs:", error);
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            status: "INTERNAL_SERVER_ERROR",
            message: (error as Error).message,
        });
    }
};