import { Request, Response } from "express";
import bcrypt from "bcrypt";
import { StatusCodes } from "../utils/statusCodes";
import { StatusMessages } from "../utils/statusMessages";
import {Users}  from "../models";
import { v4 as uuidv4 } from "uuid";
import { registerValidation,loginValidation } from "../validations/auth.validation";
import { handleValidationMessages } from "../validations/handleValidationMessages";
import jwt from "jsonwebtoken";
import dotenv from "dotenv";
dotenv.config({ path: `./config/.env.${process.env.NODE_ENV}` });

interface RegisterBody {
    firstName: string;
    lastName: string;
    email: string;
    password: string;
}

export const register = async (req: Request, res: Response): Promise<void> => {
    try {
        const { error } = registerValidation.validate(req.body);
        if (error) {
            res.status(StatusCodes.BAD_REQUEST).json(handleValidationMessages(error));
            return;
        }

        const emailExist = await Users.findOne({
            where: { email: req.body.email },
        });

        if (emailExist) {
            res.status(StatusCodes.BAD_REQUEST).json({
                status: 'error',
                statusCode: StatusCodes.BAD_REQUEST,
                message: 'Email already exists',
            });
            return;
        }

        const salt = await bcrypt.genSalt(10);
        const hashedPassword = await bcrypt.hash(req.body.password, salt);

        const user = await Users.create({
            id: uuidv4(),
            firstName: req.body.firstName,
            lastName: req.body.lastName,
            email: req.body.email,
            password: hashedPassword,
            passwordLock: false,
            failedLoginAttempts: 0,
        });

        res.status(StatusCodes.CREATED).json({
            status: 'success',
            statusCode: StatusCodes.CREATED,
            message: 'User created successfully',
            data: {
                id: user.id,
                firstName: user.firstName,
                lastName: user.lastName,
                email: user.email,
            },
        });
    } catch (error) {
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            status: 'error',
            statusCode: StatusCodes.INTERNAL_SERVER_ERROR,
            message: (error as Error).message,
        });
    }
};

export const login = async (req: Request, res: Response): Promise<void> => {
    try {
        const { error } = loginValidation.validate(req.body);
        if (error) {
            res.status(StatusCodes.BAD_REQUEST).json(handleValidationMessages(error));
            return;
        }
        const { email, password } = req.body;
        console.log("Received login request:", { email });

        const user = await Users.findOne({
            where: { email },
        });

        if (!user) {
            console.log("User not found for email:", email);
            res.status(StatusCodes.UNAUTHORIZED).json({
                status: "UNAUTHORIZED",
                message: "Invalid email or password",
            });
            return;
        }

        if (user.passwordLock && user.lockedUntil) {
            if (new Date() < new Date(user.lockedUntil)) {
                const timeLeft = Math.ceil((new Date(user.lockedUntil).getTime() - Date.now()) / (1000 * 60));
                console.log(`Account locked. Try again in ${timeLeft} minutes.`);
                res.status(StatusCodes.UNAUTHORIZED).json({
                    status: "UNAUTHORIZED",
                    message: `Your account is locked. Please try again after ${timeLeft} minutes.`,
                });
                return;
            } else {

                console.log("Lock expired. Resetting failed login attempts.");
                await user.update({
                    failedLoginAttempts: 0,
                    passwordLock: false,
                    lockedUntil: null,
                });
            }
        }

        console.log("Comparing password...");
        const isValidPassword = await bcrypt.compare(password, user.password);

        if (!isValidPassword) {
            console.log("Invalid password for user:", email);

            const failedLoginAttempts = user.failedLoginAttempts + 1;
            let passwordLock = false;
            let lockedUntil: Date | null = null;

            if (failedLoginAttempts >= 3) {
                passwordLock = true;
                lockedUntil = new Date(Date.now() + 5 * 60 * 1000);
                console.log("Password locked after 3 failed attempts.");
            }

            await user.update({
                failedLoginAttempts,
                passwordLock,
                lockedUntil,
            });

            res.status(StatusCodes.UNAUTHORIZED).json({
                status: "UNAUTHORIZED",
                message: "Invalid email or password",
            });
            return;
        }

        console.log("Password correct. Resetting failed login attempts.");
        await user.update({
            failedLoginAttempts: 0,
            passwordLock: false,
            lockedUntil: null,
        });

        const JWT_SECRET_KEY = process.env.JWT_SECRET_KEY;

        if (!JWT_SECRET_KEY) {
            console.log("JWT secret not defined.");
            res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
                status: "INTERNAL_SERVER_ERROR",
                message: "JWT secret is not defined",
            });
            return;
        }

        const token = jwt.sign(
            {
                id: user.id,
                email: user.email,
            },
            JWT_SECRET_KEY,
            { expiresIn: "10h" }
        );
        console.log("JWT token generated:", token);

        res.json({
            status: "OK",
            message: "Logged in successfully",
            token,
        });
    } catch (error) {
        console.error("Error in login process:", error);
        res.status(StatusCodes.INTERNAL_SERVER_ERROR).json({
            status: "INTERNAL_SERVER_ERROR",
            message: (error as Error).message,
        });
    }
};
