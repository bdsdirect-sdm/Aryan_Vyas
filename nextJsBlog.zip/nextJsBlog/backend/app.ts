import express, { Request, Response } from "express";
import path from "path";
import cors from "cors";
import router from "./routes/userRoutes";
import dotenv from "dotenv";
dotenv.config({ path: `./config/.env.${process.env.NODE_ENV}` });

dotenv.config();

const app = express();

// Middleware
app.use(cors({ origin: "*" }));
app.use(express.json());

// Routes
app.use("/api/v1", router);
// Serve static files
app.use(
  "/uploads",
  express.static(path.join(__dirname, "uploads"), {
    setHeaders: (res) => {
      res.set("Cross-Origin-Resource-Policy", "cross-origin");
    },
  })
);

console.log(path.join(__dirname, "uploads"));

export default app;