import { Router} from "express";
import { login, register } from "../controllers/userController";
import { createBlog, deleteBlog, getBlogsById, getBlogs, updateBlog, viewAllBlogs } from "../controllers/blogsController";
import upload from "../middleware/multer";
import { verifyToken } from "../middleware/verifyToken";

const router = Router();

router.post("/auth/register", register);
router.post("/auth/login",login)
router.post("/auth/createBlog", verifyToken, upload.single("blogImage"), createBlog);
router.get("/auth/getBlogs", verifyToken, getBlogs);
router.get("/auth/getBlogsById/:id", verifyToken, getBlogsById);
router.put("/auth/updateBlogById/:id", verifyToken, upload.single("blogImage"), updateBlog);
router.delete("/auth/deleteBlog/:id", verifyToken, deleteBlog);
router.get("/auth/viewAllBlogs",viewAllBlogs);

export default router;