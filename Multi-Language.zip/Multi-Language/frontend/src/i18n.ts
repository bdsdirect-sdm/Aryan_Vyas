import i18n from 'i18next';
import { initReactI18next } from 'react-i18next';

i18n.use(initReactI18next).init({
  resources: {
    hi: {
      translation: {
        firstName: "पहला नाम",
        lastName: "अंतिम नाम",
        email: "ईमेल",
        submit: "जमा करें",
        required: "आवश्यक है",
        firstNamePlaceholder: "पहला नाम दर्ज करें",
        lastNamePlaceholder: "अंतिम नाम दर्ज करें",
        emailPlaceholder: "आपका ई-मेल दर्ज करें",
      }
    },
    en: {
      translation: {
        firstName: "First Name",
        lastName: "Last Name",
        email: "Email",
        submit: "Submit",
        required: "is required",
        firstNamePlaceholder: "Enter First Name",
        lastNamePlaceholder: "Enter Last Name",
        emailPlaceholder: "Enter Your E-mail",
      }
    },
    fr: {
      translation: {
        firstName: "Prénom",
        lastName: "Nom de famille",
        email: "Courriel",
        submit: "Soumettre",
        required: "est requis",
        firstNamePlaceholder: "Entrez le prénom",
        lastNamePlaceholder: "Entrez le nom de famille",
        emailPlaceholder: "Entrez votre e-mail",
      }
    },
    es: {
      translation: {
        firstName: "Nombre",
        lastName: "Apellido",
        email: "Correo electrónico",
        submit: "Enviar",
        required: "es requerido",
        firstNamePlaceholder: "Ingrese el nombre",
        lastNamePlaceholder: "Ingrese el apellido",
        emailPlaceholder: "Ingrese su correo electrónico",
      }
    },
    ar: {
      translation: {
        firstName: "الاسم الأول",
        lastName: "اسم العائلة",
        email: "البريد الإلكتروني",
        submit: "إرسال",
        required: "مطلوب",
        firstNamePlaceholder: "أدخل الاسم الأول",
        lastNamePlaceholder: "أدخل اسم العائلة",
        emailPlaceholder: "أدخل بريدك الإلكتروني",
      }
    },
    nl: {
      translation: {
        firstName: "Voornaam",
        lastName: "Achternaam",
        email: "E-mail",
        submit: "Verzenden",
        required: "is verplicht",
        firstNamePlaceholder: "Voer voornaam in",
        lastNamePlaceholder: "Voer achternaam in",
        emailPlaceholder: "Voer uw e-mail in",
      }
    },
  },
  lng: "en", 
  fallbackLng: "en",
  interpolation: { escapeValue: false },
});

export default i18n;