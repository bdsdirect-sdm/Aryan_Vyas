import React, { useEffect, useState } from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import MultiLangForm from './components/MultiLangForm';
import SubmittedPage from './components/SubmittedPage';
import './index.css';

const App: React.FC = () => {
  const [darkMode, setDarkMode] = useState(() => localStorage.getItem('darkMode') === 'true');

  useEffect(() => {
    if (darkMode) {
      document.body.classList.add('dark-mode');
    } else {
      document.body.classList.remove('dark-mode');
    }
  }, [darkMode]);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
    localStorage.setItem('darkMode', (!darkMode).toString());
  };

  return (
    <Router>
      <div>
        <button onClick={toggleDarkMode} style={{marginLeft: '75px'}}>
          {darkMode ? 'Switch to Light Mode' : 'Switch to Dark Mode'}
        </button>
        <Routes>
          <Route path="/" element={<MultiLangForm />} />
          <Route path="/submitted" element={<SubmittedPage />} />
        </Routes>
      </div>
    </Router>
  );
};

export default App;
