import React from 'react';
import { useFormik } from 'formik';
import * as Yup from 'yup';
import { useTranslation } from 'react-i18next';
import { useNavigate } from 'react-router-dom';
import '../css/MultiLangForm.css';

const MultiLangForm: React.FC = () => {
  const { t, i18n } = useTranslation();
  const navigate = useNavigate();

  const formik = useFormik({
    initialValues: { firstName: '', lastName: '', email: '' },
    validationSchema: Yup.object({
      firstName: Yup.string().required(t('firstName') + ' ' + t('required')),
      lastName: Yup.string().required(t('lastName') + ' ' + t('required')),
      email: Yup.string().email('Invalid email').required(t('email') + ' ' + t('required')),
    }),
    onSubmit: (values) => {
      localStorage.setItem('formData', JSON.stringify(values));
      navigate('/submitted');
    },
  });

  return (
    <div className="form-container">
      <select className="language-selector" onChange={(e) => i18n.changeLanguage(e.target.value)}>
        <option value="en">English</option>
        <option value="hi">हिन्दी</option>
        <option value="fr">Français</option>
        <option value="es">Español</option>
        <option value="ar">Arabic</option>
        <option value="nl">Deutsch</option>
      </select>

      <form onSubmit={formik.handleSubmit}>
        <div className="form-group">
          <label>{t('firstName')}</label>
          <input 
            type="text" 
            {...formik.getFieldProps('firstName')} 
            placeholder={t('firstNamePlaceholder')} 
          />
          {formik.touched.firstName && formik.errors.firstName && (
            <div className="error-message">{formik.errors.firstName}</div>
          )}
        </div>

        <div className="form-group">
          <label>{t('lastName')}</label>
          <input 
            type="text" 
            {...formik.getFieldProps('lastName')} 
            placeholder={t('lastNamePlaceholder')} 
          />
          {formik.touched.lastName && formik.errors.lastName && (
            <div className="error-message">{formik.errors.lastName}</div>
          )}
        </div>

        <div className="form-group">
          <label>{t('email')}</label>
          <input 
            type="email" 
            {...formik.getFieldProps('email')} 
            placeholder={t('emailPlaceholder')} 
          />
          {formik.touched.email && formik.errors.email && (
            <div className="error-message">{formik.errors.email}</div>
          )}
        </div>

        <button type="submit" className="submit-btn">{t('submit')}</button>
      </form>
    </div>
  );
};

export default MultiLangForm;
