import React from 'react';
import { useTranslation } from 'react-i18next';
import '../css/SubmittedPage.css';

const SubmittedPage: React.FC = () => {
  const { t, i18n } = useTranslation();
  const formData = JSON.parse(localStorage.getItem('formData') || '{}');

  return (
    <div className="submitted-container">
      <select className="language-selector" onChange={(e) => i18n.changeLanguage(e.target.value)}>
        <option value="en">English</option>
        <option value="hi">हिन्दी</option>
        <option value="fr">Français</option>
        <option value="es">Español</option>
        <option value="ar">Arabic</option>
        <option value="nl">Deutsch</option>
      </select>

      <div className="submitted-data">
        <h2>{t('firstName')}: {formData.firstName}</h2>
        <h2>{t('lastName')}: {formData.lastName}</h2>
        <h2>{t('email')}: {formData.email}</h2>
      </div>
    </div>
  );
};

export default SubmittedPage;
