import { useEffect, useState } from "react";
import axios from "axios";
import moment from "moment-timezone";
import { useNavigate } from "react-router-dom";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import "../css/Profile.css";

const Profile = () => {
  const [user, setUser] = useState<any>(null);
  const [patients, setPatients] = useState<any[]>([]);
  const [appointments, setAppointments] = useState<any[]>([]);
  const [selectedDate, setSelectedDate] = useState<{ [key: number]: Date | null }>({});
  const [currentTime, setCurrentTime] = useState<string>("");
  const [currentUTCTime, setCurrentUTCTime] = useState<string>("");
  const [refreshAppointments, setRefreshAppointments] = useState<boolean>(false);
  const navigate = useNavigate();

  useEffect(() => {
    const storedUser = localStorage.getItem("user");
    if (storedUser) {
      const parsedUser = JSON.parse(storedUser);
      setUser(parsedUser);

      if (parsedUser.type === 1) {
        fetchPatients(parsedUser.id);
        fetchDoctorAppointments(parsedUser.id);
      } else {
        fetchAppointments(parsedUser.id, parsedUser.timezone);
      }

      const interval = setInterval(() => {
        setCurrentTime(moment.tz(parsedUser.timezone).format("YYYY-MM-DD hh:mm A"));
        setCurrentUTCTime(moment.utc().format("YYYY-MM-DD hh:mm A"));
      }, 60000);
      setCurrentTime(moment.tz(parsedUser.timezone).format("YYYY-MM-DD hh:mm A"));
      setCurrentUTCTime(moment.utc().format("YYYY-MM-DD hh:mm A"));

      return () => clearInterval(interval);
    }
  }, [refreshAppointments]);

  const handleLogout = () => {
    navigate("/");
  };

  const fetchPatients = async (doctorId: number) => {
    const response = await axios.get(`http://localhost:4000/api/users/patients/${doctorId}`);
    console.log("Patients:", response.data);
    setPatients(response.data);
  };

  const fetchDoctorAppointments = async (doctorId: number) => {
    const response = await axios.get(`http://localhost:4000/api/appointments/doctor/${doctorId}`);
    console.log("Doctor's Appointments:", response.data);

    const convertedAppointments = response.data.map((appointment: any) => {
      const doctorLocalTime = moment.utc(appointment.appointmentDateTime).tz(appointment.doctor.timezone).format("YYYY-MM-DD hh:mm A");
      const patientLocalTime = moment.utc(appointment.appointmentDateTime).tz(appointment.patient.timezone).format("YYYY-MM-DD hh:mm A");

      return {
        ...appointment,
        doctorLocalTime,
        patientLocalTime,
      };
    });

    setAppointments(convertedAppointments);
  };

  const fetchAppointments = async (patientId: number, timezone: string) => {
    const response = await axios.get(`http://localhost:4000/api/appointments/${patientId}`);
    console.log("Appointments:", response.data);

    const convertedAppointments = response.data.map((appointment: any) => {
      const doctorLocalTime = moment.utc(appointment.appointmentDateTime).tz(appointment.doctor.timezone).format("YYYY-MM-DD hh:mm A");
      const patientLocalTime = moment.utc(appointment.appointmentDateTime).tz(timezone).format("YYYY-MM-DD hh:mm A");

      return {
        ...appointment,
        doctorLocalTime,
        patientLocalTime,
      };
    });

    setAppointments(convertedAppointments);
  };

  const scheduleAppointment = async (patientId: number) => {
    if (!selectedDate[patientId]) {
      alert("Please select a date and time.");
      return;
    }

    const utcDateTime = moment.tz(selectedDate[patientId], user.timezone).utc().format();

    await axios.post("http://localhost:4000/api/appointments/create", {
      doctorId: user.id,
      patientId,
      dateTime: utcDateTime,
      timezone: user.timezone,
    });

    alert("Appointment scheduled!");
    setRefreshAppointments(!refreshAppointments);
  };

  return (
    <div className="profile-page">
      <div className="profile-container">
        <button onClick={handleLogout} style={{ marginLeft: 650 }}>Logout</button>
        <h1 style={{ marginTop: -30 }}>Welcome, {user?.firstName} {user?.lastName}</h1>
        <p>Role: {user?.type === 1 ? "Doctor" : "Patient"}</p>

        <div className="current-time">
          <h3 className="current-time-line">Current ({user?.timezone}) Time: {currentTime}</h3>
          <h3 className="current-time-line">Current UTC Time: {currentUTCTime}</h3>
        </div>

        {user?.type === 1 ? (
          <div className="list-wrapper">

            <div className="list-container" style={{ height: '200px', overflow: 'auto' }}>
            <div style={{display:'flex', justifyContent:"space-between",fontSize:18}}>
            <h2 style={{fontSize:18,marginLeft:"10px"}}>Your Patients:</h2>
           <h3 style={{fontSize:18,color:"#333",marginRight:"6px"}}>Select Appointment Date and Time</h3>
            </div>
              {patients.length > 0 ? (
                patients.map((patient, index) => (
                  <div key={patient.id} className="patient-item">
                    <span style={{marginTop:-46}}>
                      {index + 1}. {patient.firstName} {patient.lastName} ({patient.email})
                    </span>
                    <div className="date-picker-container">
                      <DatePicker
                        selected={selectedDate[patient.id] || null}
                        onChange={(date) =>
                          setSelectedDate((prev) => ({ ...prev, [patient.id]: date }))
                        }
                        showTimeSelect
                        dateFormat="Pp"
                        timeIntervals={15}
                        timeCaption="Time"
                        minDate={new Date()}
                      />
                      <button
                        onClick={() => scheduleAppointment(patient.id)}
                        disabled={!selectedDate[patient.id]}
                        style={{
                          backgroundColor: !selectedDate[patient.id] ? "gray" : "#117e7f",
                          cursor: !selectedDate[patient.id] ? "not-allowed" : "pointer",
                          color: "white",
                          padding: "10px",
                          border: "none",
                          borderRadius: "5px",
                          marginTop: "10px"
                        }}
                      >
                        Schedule Appointment
                      </button>
                    </div>
                  </div>
                ))
              ) : (
                <p className="no-data">No patients yet.</p>
              )}
            </div>
            <div className="list-container" style={{ height: '200px', overflow: 'auto' }}>
              <h2>Your Appointments:</h2>
              {appointments.length > 0 ? (
                appointments.map((appointment, index) => (
                  <div key={appointment.id} className="appointment-item">
                    <span>
                      {index + 1}. Doctor: {appointment.doctor.firstName} {appointment.doctor.lastName} - {appointment.doctorLocalTime} (Your Time)
                      <br />
                      &nbsp; &nbsp; Patient Appointment Time: {appointment.patientLocalTime}
                    </span>
                  </div>
                ))
              ) : (
                <p className="no-data">No appointments yet.</p>
              )}
            </div>
          </div>
        ) : (
          <div className="list-wrapper">
            <div className="list-container" style={{ height: '200px', overflow: 'auto' }}>
              <h2>Your Appointments:</h2>
              {appointments.length > 0 ? (
                appointments.map((appointment, index) => (
                  <div key={appointment.id} className="appointment-item">
                    <span>
                      {index + 1}. Doctor: {appointment.doctor.firstName} {appointment.doctor.lastName} - {appointment.doctorLocalTime} (Your Time)
                      <br />
                      &nbsp; &nbsp; Patient Appointment Time: {appointment.patientLocalTime}
                    </span>
                  </div>
                ))
              ) : (
                <p className="no-data">No appointments yet.</p>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Profile;