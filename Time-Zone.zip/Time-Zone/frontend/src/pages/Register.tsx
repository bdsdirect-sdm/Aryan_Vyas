import { Formik, Form, Field, ErrorMessage } from "formik";
import * as Yup from "yup";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import "../css/Register.css";

const Register = () => {
  const initialValues = {
    firstName: "",
    lastName: "",
    email: "",
    password: "",
    type: "1",
    timezone: "Asia/Kolkata",
  };

  const validationSchema = Yup.object({
    firstName: Yup.string().min(2, "Minimum 2 characters!")
      .max(30, "Maximum 30 characters!")
      .required("First Name Is Required"),
    lastName: Yup.string().min(2, "Minimum 2 characters!")
      .max(30, "Maximum 30 characters!").required("Last Name Is Required"),
    email: Yup.string().email("Invalid E-mail").required("E-mail Is Required"),
    password: Yup.string()
      .min(6, "Password must be at least 6 characters long")
      .max(20, "Password must be at most 20 characters long")
      .required("Password is required")
      .matches(/[a-z]/, "Password must contain at least one lowercase letter")
      .matches(/[A-Z]/, "Password must contain at least one uppercase letter")
      .matches(/\d/, "Password must contain at least one number")
      .matches(
        /[`~!@#$%^&*()"?<>|:{}(),.]/,
        "Password must contain at least one special character"
      ),
  });

  const navigate = useNavigate();
  const handlelogin = () => {
    navigate("/")
  }
  const handleSubmit = async (values: typeof initialValues) => {
    try {
      await axios.post("http://localhost:4000/api/users/register", values);
      alert("Registered successfully");
      navigate("/");
    } catch {
      alert("Error registering user");
    }
  };

  return (
    <div className="register-page">
      <div className="register-container">
        <h2>Register</h2>
        <Formik initialValues={initialValues} validationSchema={validationSchema} onSubmit={handleSubmit}>
          <Form>
            <Field name="firstName" placeholder="Enter Your First Name" />
            <ErrorMessage name="firstName" component="div" className="error" />

            <Field name="lastName" placeholder="Enter Your Last Name" />
            <ErrorMessage name="lastName" component="div" className="error" />

            <Field name="email" type="email" placeholder="Enter Your Email" />
            <ErrorMessage name="email" component="div" className="error" />

            <Field name="password" type="password" placeholder="Enter Your Password" />
            <ErrorMessage name="password" component="div" className="error" />

            <Field as="select" name="type">
              <option value="1">Doctor</option>
              <option value="2">Patient</option>
            </Field>

            <Field as="select" name="timezone">
              <option value="Asia/Kolkata">India</option>
              <option value="America/Phoenix">Arizona, USA</option>
            </Field>

            <button className="button-register" type="submit">Register</button>
            <button className="button-register" onClick={handlelogin}>Login</button>
          </Form>
        </Formik>
      </div>
    </div>
  );
};

export default Register;
