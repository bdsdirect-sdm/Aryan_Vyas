import express from "express";
import jwt from "jsonwebtoken";
import User from "../models/User";
import dotenv from "dotenv";
dotenv.config();
const router = express.Router();

router.post("/register", async (req, res) => {
  try {
    const { firstName, lastName, email, password, type, timezone } = req.body;
    const newUser = await User.create({
      firstName,
      lastName,
      email,
      password: password,
      type,
      timezone,
    });

    res.status(201).json({ message: "User registered", user: newUser });
  } catch (error) {
    res.status(500).json({ error: "Error registering user" });
  }
});


router.post("/login", async (req, res) => {
  try {
    const { email, password } = req.body;
    const user = await User.findOne({ where: { email } });

    if (!user) {
      return res.status(401).json({ error: "Invalid credentials" });
    }
    const storedPassword = user.dataValues.password;
    if (password !== storedPassword) {
      return res.status(401).json({ error: "Invalid credentials" });
    }
    const jwtSecret = process.env.JWT_SECRET;
    if (!jwtSecret) {
      return res.status(500).json({ error: "JWT secret is not defined" });
    }
    const token = jwt.sign(
      { id: user.id, type: user.type, timezone: user.timezone },
      jwtSecret,
      { expiresIn: "1h" }
    );

    res.json({ message: "Login successful", token, user });
  } catch (error) {
    res.status(500).json({ error: "Error logging in" });
  }
});

router.get("/patients/:doctorId", async (req, res) => {
  try {
    const { doctorId } = req.params;
    const patients = await User.findAll({ where: { type: 2 } });
    res.json(patients);
  } catch (error) {
    res.status(500).json({ error: "Error fetching patients" });
  }
});

export default router;