import React, { useCallback, useEffect, useState } from 'react';
import { getTruckInsuranceQuotes, deleteTruckInsuranceQuote, restoreTruckInsuranceQuote, Quote } from "../../API/Admin/index";
import { ToastContainer, toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { MdDelete, MdRestore } from "react-icons/md";
import './adminQuotesTable.css';

const SkeletonRow: React.FC = () => {
    return (
        <tr className="skeleton-row">
            <td><div className="skeleton-cell"></div></td>
            <td><div className="skeleton-cell"></div></td>
            <td><div className="skeleton-cell skeleton-cell-tall"></div></td>
            <td><div className="skeleton-cell"></div></td>
            <td><div className="skeleton-cell"></div></td>
            <td><div className="skeleton-cell"></div></td>
            <td><div className="skeleton-cell skeleton-cell-tall"></div></td>
            <td><div className="skeleton-cell"></div></td>
            <td><div className="skeleton-cell"></div></td>
            <td><div className="skeleton-cell"></div></td>
            <td><div className="skeleton-cell"></div></td>
        </tr>
    );
};

const AdminQuotesTable: React.FC = () => {
    const [quotes, setQuotes] = useState<Quote[]>([]);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);
    const [currentPage, setCurrentPage] = useState<number>(1);
    const [totalPages, setTotalPages] = useState<number>(1);
    const [totalItems, setTotalItems] = useState<number>(0);
    const [sortField, setSortField] = useState<string>('createdAt');
    const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('desc');

    // const fetchQuotes = useCallback(async (page: number = 1) => {
    //     try {
    //         setLoading(true);
    //         const { quotes, pagination } = await getTruckInsuranceQuotes(page, sortField, sortOrder);
    //         setQuotes(quotes);
    //         setTotalPages(pagination.totalPages);
    //         setTotalItems(pagination.totalItems);
    //         setCurrentPage(pagination.currentPage);
    //         setLoading(false);
    //     } catch (err) {
    //         setError('Failed to fetch quotes data. Please try again later.');
    //         setLoading(false);
    //         console.error('Error fetching quotes:', err);
    //     }
    // }, [sortField, sortOrder]);


    const fetchQuotes = useCallback(async (page: number = 1) => {
        try {
            setLoading(true);
            // await new Promise(resolve => setTimeout(resolve, 2000));
            const { quotes, pagination } = await getTruckInsuranceQuotes(page, sortField, sortOrder);
            setQuotes(quotes);
            setTotalPages(pagination.totalPages);
            setTotalItems(pagination.totalItems);
            setCurrentPage(pagination.currentPage);
            setLoading(false);
        } catch (err) {
            setError('Failed to fetch quotes data. Please try again later.');
            setLoading(false);
            console.error('Error fetching quotes:', err);
        }
    }, [sortField, sortOrder]);


    // const fetchQuotes = useCallback(async (page: number = 1) => {
    //     try {
    //         setLoading(true);
    //         if (process.env.NODE_ENV === 'development') {
    //             await new Promise(resolve => setTimeout(resolve, 2000));
    //         }

    //         const { quotes, pagination } = await getTruckInsuranceQuotes(page, sortField, sortOrder);
    //         setQuotes(quotes);
    //         setTotalPages(pagination.totalPages);
    //         setTotalItems(pagination.totalItems);
    //         setCurrentPage(pagination.currentPage);
    //         setLoading(false);
    //     } catch (err) {
    //         setError('Failed to fetch quotes data. Please try again later.');
    //         setLoading(false);
    //         console.error('Error fetching quotes:', err);
    //     }
    // }, [sortField, sortOrder]);

    useEffect(() => {
        fetchQuotes(currentPage);
    }, [currentPage, fetchQuotes]);

    const handleSort = (field: string) => {
        if (field === sortField) {
            setSortOrder(prev => (prev === 'asc' ? 'desc' : 'asc'));
        } else {
            setSortField(field);
            setSortOrder('asc');
        }
    };

    const handleDelete = async (quoteId: string) => {
        const confirmDelete = window.confirm('Are you sure you want to delete this quote?');
        if (!confirmDelete) return;

        try {
            await deleteTruckInsuranceQuote(quoteId);
            toast.success('Quote deleted successfully', {
                position: "top-right",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
            });
            setTimeout(() => {
                fetchQuotes(currentPage);
            }, 3000);
        } catch (err) {
            console.error('Failed to delete quote:', err);
            toast.error('Failed to delete quote. Please try again.', {
                position: "top-right",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
            });
        }
    };

    const handleRestore = async (quoteId: string) => {
        const confirmRestore = window.confirm('Are you sure you want to restore this quote?');
        if (!confirmRestore) return;

        try {
            await restoreTruckInsuranceQuote(quoteId);
            toast.success('Quote restored successfully', {
                position: "top-right",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
            });
            setTimeout(() => {
                fetchQuotes(currentPage);
            }, 3000);
        } catch (err) {
            console.error('Failed to restore quote:', err);
            toast.error('Failed to restore quote. Please try again.', {
                position: "top-right",
                autoClose: 3000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
            });
        }
    };

    const formatDate = (dateString: string): string => {
        const options: Intl.DateTimeFormatOptions = {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
        };
        return new Date(dateString).toLocaleDateString('en-US', options);
    };

    const formatCurrency = (amount: number): string => {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD',
            minimumFractionDigits: 2,
        }).format(amount);
    };

    const renderSkeletonRows = () => {
        return Array(5).fill(0).map((_, index) => <SkeletonRow key={`skeleton-${index}`} />);
    };

    // const renderSkeletonRows = () => {
    //     if (currentPage < totalPages) {
    //         return Array(quotes.length || 5).fill(0).map((_, index) => (
    //             <SkeletonRow key={`skeleton-${index}`} />
    //         ));
    //     } else if (currentPage === totalPages) {
    //         const remainingItems = totalItems % (quotes.length || 5);
    //         const lastPageCount = remainingItems === 0 ? (quotes.length || 5) : remainingItems;
    //         return Array(lastPageCount).fill(0).map((_, index) => (
    //             <SkeletonRow key={`skeleton-${index}`} />
    //         ));
    //     } else {
    //         return Array(5).fill(0).map((_, index) => (
    //             <SkeletonRow key={`skeleton-${index}`} />
    //         ));
    //     }
    // };

    if (error) return <div className="error">{error}</div>;

    return (
        <>
            <ToastContainer
                position="bottom-center"
                autoClose={10000}
                hideProgressBar={false}
                closeOnClick
                pauseOnHover
                draggable
                aria-label="Notification container"
            />
            <div className="admin-quotes-container">

                <h1 style={{ fontWeight: "bold", color: "black" }}>Truck Insurance Quotes</h1>

                <div className="quote-summary">
                    {loading ? (
                        <div className="skeleton-text-short"></div>
                    ) : (
                        <p title="Total Quotes Generated" style={{ fontWeight: "bold", color: "black", cursor: "pointer" }}>Total Quotes: {totalItems}</p>
                    )}
                </div>

                <div className="table-container">
                    <table className="quotes-table">
                        <thead>
                            <tr>
                                <th onClick={() => handleSort('messageUser.firstName')} title="Customer's full name from Telegram" style={{ cursor: 'pointer' }}>
                                    Customer {sortField === 'messageUser.firstName' && (sortOrder === 'asc' ? '↑' : '↓')}
                                </th>
                                <th onClick={() => handleSort('messageUser.phoneNumber')} title="Registered mobile number" style={{ cursor: 'pointer' }}>
                                    Phone {sortField === 'messageUser.phoneNumber' && (sortOrder === 'asc' ? '↑' : '↓')}
                                </th>
                                <th title="Type, model, and year of truck">Truck Info</th>
                                <th onClick={() => handleSort('truckValue')} title="Declared value of the truck in USD" style={{ cursor: 'pointer' }}>
                                    Truck Value ($) {sortField === 'truckValue' && (sortOrder === 'asc' ? '↑' : '↓')}
                                </th>
                                <th onClick={() => handleSort('truckState')} title="Registered state of the truck" style={{ cursor: 'pointer' }}>
                                    State {sortField === 'truckState' && (sortOrder === 'asc' ? '↑' : '↓')}
                                </th>
                                <th onClick={() => handleSort('basePremium')} title="Base insurance quotation" style={{ cursor: 'pointer' }}>
                                    Base Quotation ($) {sortField === 'basePremium' && (sortOrder === 'asc' ? '↑' : '↓')}
                                </th>

                                <th title="Includes carrier fee, surplus line tax, and stamp fee">
                                    Fees & Taxes
                                </th>
                                <th onClick={() => handleSort('totalQuotation')} title="Total amount payable for the policy" style={{ cursor: 'pointer' }}>
                                    Total Quotation ($) {sortField === 'totalQuotation' && (sortOrder === 'asc' ? '↑' : '↓')}
                                </th>
                                <th onClick={() => handleSort('createdAt')} title="Date when quote was created" style={{ cursor: 'pointer' }}>
                                    Created Date {sortField === 'createdAt' && (sortOrder === 'asc' ? '↑' : '↓')}
                                </th>
                                <th onClick={() => handleSort('deletedAt')} title="Date of deletion (if any)" style={{ cursor: 'pointer' }}>
                                    Deleted At {sortField === 'deletedAt' && (sortOrder === 'asc' ? '↑' : '↓')}
                                </th>
                                <th title="Perform actions like delete">Actions</th>
                            </tr>
                        </thead>

                        <tbody style={{ cursor: "pointer" }}>
                            {loading ? (
                                renderSkeletonRows()
                            ) : quotes.length > 0 ? (
                                quotes.map((quote) => (
                                    <tr key={quote.id}>
                                        <td title={`Name: ${quote.messageUser?.firstName || ''} ${quote.messageUser?.lastName || ''}`}>
                                            {quote.messageUser ? (
                                                <>
                                                    <div className="customer-name">
                                                        {quote.messageUser.firstName} {quote.messageUser.lastName}
                                                    </div>
                                                    <div className="telegram-id">
                                                        <small title={`Telegram ID: ${quote.messageUser.telegramId}`}>
                                                            Telegram: {quote.messageUser.telegramId}
                                                        </small>
                                                    </div>
                                                </>
                                            ) : (
                                                <span className="missing-user">User not found</span>
                                            )}
                                        </td>

                                        <td title={`Phone: ${quote.messageUser?.phoneNumber || 'Not Provided'}`}>
                                            {quote.messageUser?.phoneNumber ?? "Not Provided"}
                                        </td>

                                        <td
                                            title={`Truck Details:\n Type: ${quote.truckType}\n Model: ${quote.truckModel}\n Year: ${quote.truckYear}`}
                                        >
                                            <div className="truck-details">
                                                <div><small>Type: {quote.truckType} </small></div>
                                                <div><small>Model: {quote.truckModel}</small></div>
                                                <div><small>Year: {quote.truckYear}</small></div>
                                            </div>
                                        </td>

                                        <td title={`Truck Value: $${quote.truckValue}`}>{formatCurrency(quote.truckValue)}</td>
                                        <td title={`Truck State: ${quote.truckState}`}>{quote.truckState}</td>
                                        <td title={`Base Quotation: ${quote.basePremium}`}>{formatCurrency(quote.basePremium)}</td>

                                        <td
                                            title={`Carrier Fee: ${formatCurrency(quote.carrierFee)}\nSurplus Line Tax: ${formatCurrency(quote.surplusLineTax)}\nStamp Fee: ${formatCurrency(quote.stampingFee)}`}
                                        >
                                            <div className="fees-breakdown">
                                                <div>Carrier Fee: {formatCurrency(quote.carrierFee)}</div>
                                                <div>Surplus Line Tax: {formatCurrency(quote.surplusLineTax)}</div>
                                                <div>Stamp Fee: {formatCurrency(quote.stampingFee)}</div>
                                            </div>
                                        </td>

                                        <td title={`Total Quotation: ${quote.totalQuotation}`} className="total-cell">
                                            {formatCurrency(quote.totalQuotation)}
                                        </td>

                                        <td title={`Created at: ${formatDate(quote.createdAt)}`}>
                                            {formatDate(quote.createdAt)}
                                        </td>

                                        <td>
                                            {quote.deletedAt ? (
                                                <span
                                                    className="badge badge-deleted"
                                                    title={`Deleted at: ${formatDate(quote.deletedAt)}`}
                                                    style={{ cursor: "pointer" }}
                                                >
                                                    ❌ {formatDate(quote.deletedAt)}
                                                </span>
                                            ) : (
                                                <span
                                                    className="badge badge-active"
                                                    title="This quote is active"
                                                    style={{ cursor: "pointer" }}
                                                >
                                                    ✅ Active
                                                </span>
                                            )}
                                        </td>

                                        <td>
                                            {quote.deletedAt ? (
                                                <MdRestore
                                                    className="restore-icon"
                                                    onClick={() => handleRestore(quote.id)}
                                                    style={{ cursor: "pointer", color: "green", fontSize: "1.3rem" }}
                                                    title="Restore this quote"
                                                />
                                            ) : (
                                                <MdDelete
                                                    className="delete-icon"
                                                    onClick={() => handleDelete(quote.id)}
                                                    style={{ cursor: "pointer", color: "red", fontSize: "1.3rem" }}
                                                    title="Delete this quote"
                                                />
                                            )}
                                        </td>

                                    </tr>
                                ))
                            ) : (
                                <tr>
                                    <td colSpan={12} className="no-results">No quotes found.</td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>

                <div className="pagination-controls">
                    {loading ? (
                        <div className="skeleton-pagination">
                            <div className="skeleton-button"></div>
                            <div className="skeleton-button"></div>
                            <div className="skeleton-button"></div>
                        </div>
                    ) : (
                        <>
                            <button
                                onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                                disabled={currentPage === 1}
                                title={
                                    totalPages === 1
                                        ? "Only one page available"
                                        : currentPage === 1
                                            ? "You're on the first page"
                                            : "Go to previous page"
                                }
                            >
                                « Prev
                            </button>

                            {[...Array(totalPages)].map((_, index) => {
                                const page = index + 1;
                                return (
                                    <button
                                        key={page}
                                        onClick={() => setCurrentPage(page)}
                                        className={currentPage === page ? 'active-page' : ''}
                                        title={
                                            totalPages === 1
                                                ? "Only one page available"
                                                : currentPage === page
                                                    ? "You're on this page"
                                                    : `Go to page ${page}`
                                        }
                                    >
                                        {page}
                                    </button>
                                );
                            })}

                            <button
                                onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                                disabled={currentPage === totalPages}
                                title={
                                    totalPages === 1
                                        ? "Only one page available"
                                        : currentPage === totalPages
                                            ? "You're on the last page"
                                            : "Go to next page"
                                }
                            >
                                Next »
                            </button>
                        </>
                    )}
                </div>
            </div>
        </>
    );
};

export default AdminQuotesTable;