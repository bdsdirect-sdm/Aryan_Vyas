import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { MdDelete, MdDeleteOutline } from "react-icons/md";
import './adminQuotesTable.css';

interface User {
    id: string;
    telegramId: string;
    firstName: string;
    lastName: string;
    phoneNumber: string;
}

interface Quote {
    id: string;
    userId: string;
    message: string;
    truckModel: string;
    truckType: string;
    truckYear: string;
    truckValue: number;
    truckState: string;
    basePremium: number;
    carrierFee: number;
    surplusLineTax: number;
    stampingFee: number;
    totalQuotation: number;
    createdAt: string;
    updatedAt: string;
    messageUser: User | null;
    deletedAt?: string;
}

interface Pagination {
    totalItems: number;
    totalPages: number;
    currentPage: number;
    itemsPerPage: number;
}

interface ApiResponse {
    success: boolean;
    data: Quote[];
    pagination: Pagination;
}

const AdminQuotesTable: React.FC = () => {
    const [quotes, setQuotes] = useState<Quote[]>([]);
    const [loading, setLoading] = useState<boolean>(true);
    const [error, setError] = useState<string | null>(null);
    const [currentPage, setCurrentPage] = useState<number>(1);
    const [totalPages, setTotalPages] = useState<number>(1);
    const [totalItems, setTotalItems] = useState<number>(0);
    const [deleteMessage, setDeleteMessage] = useState<string | null>(null);

    const fetchQuotes = async (page: number = 1) => {
        try {
            setLoading(true);
            const response = await axios.get<ApiResponse>(
                `http://localhost:4001/api/v1/auth/getAllUserQuotes?page=${page}`
            );
            const { data, pagination } = response.data;
            setQuotes(data);
            setTotalPages(pagination.totalPages);
            setTotalItems(pagination.totalItems);
            setCurrentPage(pagination.currentPage);
            setLoading(false);
        } catch (err) {
            setError('Failed to fetch quotes data. Please try again later.');
            setLoading(false);
            console.error('Error fetching quotes:', err);
        }
    };

    useEffect(() => {
        fetchQuotes(currentPage);
    }, [currentPage]);

    const handleDelete = async (quoteId: string) => {
        const confirmDelete = window.confirm('Are you sure you want to delete this quote?');
        if (!confirmDelete) return;

        try {
            await axios.delete(`http://localhost:4001/api/v1/auth/deleteQuote/${quoteId}`);
            setDeleteMessage('Quote deleted successfully');
            fetchQuotes(currentPage);
        } catch (err) {
            console.error('Failed to delete quote:', err);
            setDeleteMessage('Failed to delete quote. Please try again.');
        } finally {
            setTimeout(() => setDeleteMessage(null), 3000);
        }
    };

    const formatDate = (dateString: string): string => {
        const options: Intl.DateTimeFormatOptions = {
            year: 'numeric',
            month: 'short',
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit',
        };
        return new Date(dateString).toLocaleDateString('en-US', options);
    };

    const formatCurrency = (amount: number): string => {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD',
            minimumFractionDigits: 2,
        }).format(amount);
    };

    if (loading) return <div className="loading">Loading quotes data...</div>;
    if (error) return <div className="error">{error}</div>;

    return (
        <div className="admin-quotes-container">
            <h1 style={{ fontWeight: "bold", color: "black" }}>Truck Insurance Quotes</h1>

            {deleteMessage && <div className="delete-message">{deleteMessage}</div>}

            <div className="quote-summary">
                <p style={{ fontWeight: "bold", color: "black" }}>Total Quotes: {totalItems}</p>
            </div>

            <div className="table-container">
                <table className="quotes-table">
                    <thead>
                        <tr>
                            <th title="Customer’s full name from Telegram" style={{ cursor: 'pointer' }}>Customer Name</th>
                            <th title="Registered mobile number" style={{ cursor: 'pointer' }}>Phone Number</th>
                            <th title="Type, model, and year of truck" style={{ cursor: 'pointer' }}>Truck Details</th>
                            <th title="Declared value of the truck in USD" style={{ cursor: 'pointer' }}>Truck Value ($)</th>
                            <th title="Registered state of the truck" style={{ cursor: 'pointer' }}>Truck State</th>
                            <th title="Base insurance premium" style={{ cursor: 'pointer' }}>Base Quotation</th>
                            <th title="Includes carrier fee, tax, and stamp" style={{ cursor: 'pointer' }}>Additional Fees</th>
                            <th title="Total amount payable for the policy" style={{ cursor: 'pointer' }}>Total Quotation</th>
                            <th title="Date when quote was created" style={{ cursor: 'pointer' }}>Created On</th>
                            <th title="Date of deletion (if any)" style={{ cursor: 'pointer' }}>Deleted At</th>
                            <th title="Perform actions like delete" style={{ cursor: 'pointer' }}>Actions</th>
                        </tr>
                    </thead>

                    <tbody style={{cursor:"pointer"}}>
                        {quotes.length > 0 ? (
                            quotes.map((quote) => (
                                <tr key={quote.id}>
                                    <td title={`Name: ${quote.messageUser?.firstName || ''} ${quote.messageUser?.lastName || ''}`}>
                                        {quote.messageUser ? (
                                            <>
                                                <div className="customer-name">
                                                    {quote.messageUser.firstName} {quote.messageUser.lastName}
                                                </div>
                                                <div className="telegram-id">
                                                    <small title={`Telegram ID: ${quote.messageUser.telegramId}`}>
                                                        Telegram: {quote.messageUser.telegramId}
                                                    </small>
                                                </div>
                                            </>
                                        ) : (
                                            <span className="missing-user">User not found</span>
                                        )}
                                    </td>

                                    <td title={`Phone: ${quote.messageUser?.phoneNumber || 'Not Provided'}`}>
                                        {quote.messageUser?.phoneNumber ?? "Not Provided"}
                                    </td>

                                    <td title={`Truck Details: ${quote.truckType} ${quote.truckModel} (${quote.truckYear})`}>
                                        <div className="truck-details">
                                            <div>{quote.truckType} {quote.truckModel}</div>
                                            <div><small>Year: {quote.truckYear}</small></div>
                                        </div>
                                    </td>

                                    <td title={`Truck Value: $${quote.truckValue}`}>{formatCurrency(quote.truckValue)}</td>
                                    <td title={`Truck State: ${quote.truckState}`}>{quote.truckState}</td>
                                    <td title={`Base Quotation: ${quote.basePremium}`}>{formatCurrency(quote.basePremium)}</td>

                                    <td title={`Carrier Fee: ${quote.carrierFee}, Surplus Line Tax: ${quote.surplusLineTax}, Stamp Fee: ${quote.stampingFee}`}>
                                        <div className="fees-breakdown">
                                            <div>Carrier Fee: {formatCurrency(quote.carrierFee)}</div>
                                            <div>Surplus Line Tax: {formatCurrency(quote.surplusLineTax)}</div>
                                            <div>Stamp Fee: {formatCurrency(quote.stampingFee)}</div>
                                        </div>
                                    </td>

                                    <td title={`Total Quotation: ${quote.totalQuotation}`} className="total-cell">
                                        {formatCurrency(quote.totalQuotation)}
                                    </td>

                                    <td title={`Created at: ${formatDate(quote.createdAt)}`}>
                                        {formatDate(quote.createdAt)}
                                    </td>

                                    <td>
                                        {quote.deletedAt ? (
                                            <span
                                                className="badge badge-deleted"
                                                title={`Deleted at: ${formatDate(quote.deletedAt)}`}
                                                style={{ cursor: "pointer" }}
                                            >
                                                ❌ {formatDate(quote.deletedAt)}
                                            </span>
                                        ) : (
                                            <span
                                                className="badge badge-active"
                                                title="This quote is active"
                                                style={{ cursor: "pointer" }}
                                            >
                                                ✅ Active
                                            </span>
                                        )}
                                    </td>

                                    <td>
                                        {quote.deletedAt ? (
                                            <MdDeleteOutline
                                                style={{
                                                    color: "#ccc",
                                                    cursor: "not-allowed",
                                                    fontSize: "1.3rem",
                                                }}
                                                title="Already deleted"
                                            />
                                        ) : (
                                            <MdDelete
                                                className="delete-icon"
                                                onClick={() => handleDelete(quote.id)}
                                                style={{ cursor: "pointer", color: "red", fontSize: "1.3rem" }}
                                                title="Delete this quote"
                                            />
                                        )}
                                    </td>
                                </tr>
                            ))
                        ) : (
                            <tr>
                                <td colSpan={12} className="no-results">No quotes found.</td>
                            </tr>
                        )}
                    </tbody>
                </table>
            </div>

            <div className="pagination-controls">
                <button
                    onClick={() => setCurrentPage((prev) => Math.max(prev - 1, 1))}
                    disabled={currentPage === 1}
                >
                    Previous
                </button>

                {[...Array(totalPages)].map((_, index) => {
                    const page = index + 1;
                    return (
                        <button
                            key={page}
                            onClick={() => setCurrentPage(page)}
                            className={currentPage === page ? 'active-page' : ''}
                        >
                            {page}
                        </button>
                    );
                })}

                <button
                    onClick={() => setCurrentPage((prev) => Math.min(prev + 1, totalPages))}
                    disabled={currentPage === totalPages}
                >
                    Next
                </button>
            </div>
        </div>
    );
};

export default AdminQuotesTable;
