import AdminDashboard from '../src/pages/admin/adminDashboard'
import './App.css'

function App() {
  return (
    <div>
      <AdminDashboard />
    </div>
  )
}

export default App
