import axios from 'axios';
import envConfig from '../../enviroment';
import { Quote, Pagination, GetQuotesResponse } from '../../utils/types/global';

export const getTruckInsuranceQuotes = async (
  page: number,
  sortField: string,
  sortOrder: 'asc' | 'desc'
): Promise<{
  quotes: Quote[];
  pagination: Pagination;
}> => {
  const response = await axios.get<GetQuotesResponse>(`${envConfig.apiUrl}/auth/getAllUserQuotes`, {
    params: { page, sortField, sortOrder },
  });
  
  return {
    quotes: response.data.data,
    pagination: response.data.pagination
  };
};

export const deleteTruckInsuranceQuote = async (quoteId: string) => {
  return axios.delete(`${envConfig.apiUrl}/auth/deleteQuote/${quoteId}`);
};

export const restoreTruckInsuranceQuote = async (quoteId: string) => {
  return axios.patch(`${envConfig.apiUrl}/auth/quotes/restore/${quoteId}`);
};

export type { Quote, Pagination, GetQuotesResponse } from '../../utils/types/global';