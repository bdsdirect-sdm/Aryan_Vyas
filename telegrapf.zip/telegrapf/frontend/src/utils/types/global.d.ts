export interface MessageUser {
    id: string;
    telegramId: string;
    firstName: string;
    lastName: string;
    phoneNumber?: string;
    createdAt: string;
    updatedAt: string;
  }
  
  export interface Quote {
    id: string;
    messageUserId: string;
    truckType: string;
    truckModel: string;
    truckYear: number;
    truckValue: number;
    truckState: string;
    basePremium: number;
    carrierFee: number;
    surplusLineTax: number;
    stampingFee: number;
    totalQuotation: number;
    createdAt: string;
    updatedAt: string;
    deletedAt: string | null;
    messageUser?: MessageUser;
  }
  
  export interface Pagination {
    currentPage: number;
    totalPages: number;
    totalItems: number;
  }
  
  export interface GetQuotesResponse {
    data: Quote[];
    pagination: Pagination;
  }
  