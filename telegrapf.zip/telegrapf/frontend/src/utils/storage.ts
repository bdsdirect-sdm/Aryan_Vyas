import { User } from '../utils/types/global';
const storagePrefix = 'truck_insurance_quotes';
const storage = {
  getToken: () => {
    return JSON.parse(
      window.sessionStorage.getItem(`${storagePrefix}token`) as string,
    );
  },
  setToken: (token: string) => {
    window.sessionStorage.setItem(
      `${storagePrefix}token`,
      JSON.stringify(token),
    );
  },
  clearToken: () => {
    window.sessionStorage.removeItem(`${storagePrefix}token`);
    window.sessionStorage.removeItem(`${storagePrefix}token`);
  },
  getUser: () => {
    return JSON.parse(
      window.sessionStorage.getItem(`${storagePrefix}user`) as string,
    );
  },
  setUser: (user: User) => {
    window.sessionStorage.setItem(`${storagePrefix}user`, JSON.stringify(user));
  },
  clearUser: () => {
    window.sessionStorage.removeItem(`${storagePrefix}user`);
  },
};

export default storage;