import express from 'express';
import { deleteQuoteById, getAllQuotesWithUsers } from '../controller/userController';

const router = express.Router();

router.get('/auth/getAllUserQuotes', getAllQuotesWithUsers);
router.delete('/auth/deleteQuote/:quoteId', deleteQuoteById);

export default router;
