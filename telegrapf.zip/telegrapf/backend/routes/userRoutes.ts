import express from 'express';
import { deleteQuoteById, getAllQuotesWithUsers, getUserByTelegramId, restoreQuoteById } from '../controller/userController';

const router = express.Router();

router.get('/auth/getAllUserQuotes', getAllQuotesWithUsers);
router.delete('/auth/deleteQuote/:quoteId', deleteQuoteById);
router.patch('/auth/quotes/restore/:quoteId', restoreQuoteById);
router.get('/auth/getUserByTelegramId/:telegramId', getUserByTelegramId);

export default router;