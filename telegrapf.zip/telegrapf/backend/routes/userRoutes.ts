import express from 'express';
import { getAllQuotesWithUsers } from '../controller/userController';

const router = express.Router();

router.get('/auth/getAllUserQuotes', getAllQuotesWithUsers);

export default router;
