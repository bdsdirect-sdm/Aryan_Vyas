import { Request, Response } from 'express';
import { Quotes, Users } from '../models';

export const getAllQuotesWithUsers = async (req: Request, res: Response) => {
  try {
    const quotes = await Quotes.findAll({
      include: [
        {
          model: Users,
          as: 'messageUser',
          attributes: ['id', 'telegramId', 'firstName', 'lastName', 'phoneNumber'],
        },
      ],
      order: [['createdAt', 'DESC']],
    });

    res.status(200).json({ success: true, data: quotes });
  } catch (error) {
    console.error('Error fetching quotes:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch quotes', error });
  }
};
