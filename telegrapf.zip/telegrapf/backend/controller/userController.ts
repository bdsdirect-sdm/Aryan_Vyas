import { Request, Response } from 'express';
import { Quotes, Users } from '../models';

export const getAllQuotesWithUsers = async (req: Request, res: Response) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = 5;
    const offset = (page - 1) * limit;

    const sortField = (req.query.sortField as string) || 'createdAt';
    const sortOrder = (req.query.sortOrder as string)?.toUpperCase() === 'ASC' ? 'ASC' : 'DESC';

    const validSortFields = [
      'id', 'userId', 'message', 'truckModel', 'truckType', 'truckYear', 'truckValue', 
      'truckState', 'basePremium', 'carrierFee', 'surplusLineTax', 'stampingFee', 
      'totalQuotation', 'createdAt', 'updatedAt'
    ];

    const order: any[] = validSortFields.includes(sortField)
      ? [[sortField, sortOrder]]
      : [['createdAt', sortOrder]];

    const totalCount = await Quotes.count({
      include: [
        {
          model: Users,
          as: 'messageUser',
          required: true,
        },
      ],
      paranoid: false,
    });

    const totalPages = Math.ceil(totalCount / limit);

    const quotes = await Quotes.findAll({
      include: [
        {
          model: Users,
          as: 'messageUser',
          attributes: ['id', 'telegramId', 'firstName', 'lastName', 'phoneNumber'],
        },
      ],
      order: order,
      limit: limit,
      offset: offset,
      paranoid: false,
    });

    res.status(200).json({
      success: true,
      data: quotes,
      pagination: {
        totalItems: totalCount,
        totalPages: totalPages,
        currentPage: page,
        itemsPerPage: limit,
      },
    });
  } catch (error) {
    console.error('Error fetching quotes:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch quotes', error });
  }
};

export const deleteQuoteById = async (req: Request, res: Response): Promise<void> => {
  try {
    const { quoteId } = req.params;

    const quote = await Quotes.findByPk(quoteId);
    if (!quote) {
      res.status(404).json({ success: false, message: 'Quote not found' });
      return;
    }

    await quote.destroy();

    res.status(200).json({ success: true, message: 'Quote deleted successfully' });
  } catch (error) {
    console.error('Error deleting quote:', error);
    res.status(500).json({ success: false, message: 'Failed to delete quote', error });
  }
};

export const restoreQuoteById = async (req: Request, res: Response): Promise<void> => {
  try {
    const { quoteId } = req.params;

    const quote = await Quotes.findOne({
      where: { id: quoteId },
      paranoid: false,
    });

    if (!quote) {
      res.status(404).json({ success: false, message: 'Quote not found' });
      return;
    }

    if (!quote.deletedAt) {
      res.status(400).json({ success: false, message: 'Quote is not deleted' });
      return;
    }

    await quote.restore();

    res.status(200).json({ success: true, message: 'Quote restored successfully' });
  } catch (error) {
    console.error('Error restoring quote:', error);
    res.status(500).json({ success: false, message: 'Failed to restore quote', error });
  }
};

export const getUserByTelegramId = async (req: Request, res: Response): Promise<void> => {
  const { telegramId } = req.params;
  try {
    const user = await Users.findOne({
      where: { telegramId },
      paranoid: false,
      include: [
        {
          model: Quotes,
          as: 'userMessages',
          required: false,
          paranoid: false,
        },
      ],
    });

    if (user) {
      res.status(200).json({
        success: true,
        user: {
          ...user.toJSON(),
          userMessages: user.get('userMessages'),
        },
      });
    } else {
      res.status(404).json({ success: false, message: 'User not found' });
    }
  } catch (error) {
    console.error('Error fetching user:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch user', error });
  }
};
