import { Request, Response } from 'express';
import { Quotes, Users } from '../models';

export const getAllQuotesWithUsers = async (req: Request, res: Response) => {
  try {
    const page = parseInt(req.query.page as string) || 1;
    const limit = 5;
    const offset = (page - 1) * limit;
    const totalCount = await Quotes.count({
      include: [
        {
          model: Users,
          as: 'messageUser',
          required: true,
        },
      ],
      paranoid: false,
    });

    const totalPages = Math.ceil(totalCount / limit);
    const quotes = await Quotes.findAll({
      include: [
        {
          model: Users,
          as: 'messageUser',
          attributes: ['id', 'telegramId', 'firstName', 'lastName', 'phoneNumber'],
        },
      ],
      order: [['createdAt', 'DESC']],
      limit: limit,
      offset: offset,
      paranoid: false,
    });

    res.status(200).json({
      success: true,
      data: quotes,
      pagination: {
        totalItems: totalCount,
        totalPages: totalPages,
        currentPage: page,
        itemsPerPage: limit,
      },
    });
  } catch (error) {
    console.error('Error fetching quotes:', error);
    res.status(500).json({ success: false, message: 'Failed to fetch quotes', error });
  }
};

export const deleteQuoteById = async (req: Request, res: Response): Promise<void> => {
  try {
    const { quoteId } = req.params;

    const quote = await Quotes.findByPk(quoteId);
    if (!quote) {
      res.status(404).json({ success: false, message: 'Quote not found' });
      return;
    }

    await quote.destroy();

    res.status(200).json({ success: true, message: 'Quote deleted successfully' });
  } catch (error) {
    console.error('Error deleting quote:', error);
    res.status(500).json({ success: false, message: 'Failed to delete quote', error });
  }
};
