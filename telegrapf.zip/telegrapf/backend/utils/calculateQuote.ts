import quoteRates from './quoteRates';

interface QuoteResult {
  basePremium: number;
  deductibleAdjustedPremium: number;
  carrierFee: number;
  surplusLineTax: number;
  stampingFee: number;
  clearingHouseFee: number;
  stateSurcharge: number;
  totalQuotation: number;
  deductible: number;
}

const rateTiers = [
  { min: 1, max: 10000, rate: 10 },
  { min: 10001, max: 35000, rate: 5 },
  { min: 35001, max: 60000, rate: 4.75 },
  { min: 60001, max: 75000, rate: 4.25 },
  { min: 75001, max: 90000, rate: 4.25 },
  { min: 90001, max: 200000, rate: 3.83 }
];

const deductibleTiers = [
  { min: 1, max: 75000, deductible: 1000 },
  { min: 75001, max: 99999, deductible: 2500 },
  { min: 100000, max: 200000, deductible: 5000 }
];

const stateNameToAbbreviation: Record<string, string> = {
  'ALABAMA': 'AL', 'ALASKA': 'AK', 'ARIZONA': 'AZ', 'ARKANSAS': 'AR',
  'CALIFORNIA': 'CA', 'COLORADO': 'CO', 'CONNECTICUT': 'CT', 'DELAWARE': 'DE',
  'FLORIDA': 'FL', 'GEORGIA': 'GA', 'HAWAII': 'HI', 'IDAHO': 'ID',
  'ILLINOIS': 'IL', 'INDIANA': 'IN', 'IOWA': 'IA', 'KANSAS': 'KS',
  'KENTUCKY': 'KY', 'LOUISIANA': 'LA', 'MAINE': 'ME', 'MARYLAND': 'MD',
  'MASSACHUSETTS': 'MA', 'MICHIGAN': 'MI', 'MINNESOTA': 'MN', 'MISSISSIPPI': 'MS',
  'MISSOURI': 'MO', 'MONTANA': 'MT', 'NEBRASKA': 'NE', 'NEVADA': 'NV',
  'NEW HAMPSHIRE': 'NH', 'NEW JERSEY': 'NJ', 'NEW MEXICO': 'NM', 'NEW YORK': 'NY',
  'NORTH CAROLINA': 'NC', 'NORTH DAKOTA': 'ND', 'OHIO': 'OH', 'OKLAHOMA': 'OK',
  'OREGON': 'OR', 'PENNSYLVANIA': 'PA', 'RHODE ISLAND': 'RI', 'SOUTH CAROLINA': 'SC',
  'SOUTH DAKOTA': 'SD', 'TENNESSEE': 'TN', 'TEXAS': 'TX', 'UTAH': 'UT',
  'VERMONT': 'VT', 'VIRGINIA': 'VA', 'WASHINGTON': 'WA', 'WEST VIRGINIA': 'WV',
  'WISCONSIN': 'WI', 'WYOMING': 'WY', 'DISTRICT OF COLUMBIA': 'DC'
};

export function calculateQuote(truckValue: number, state: string, customDeductible?: number): QuoteResult {
  const stateInput = state.toUpperCase();
  let stateAbbreviation = stateInput;

  if (stateInput.length > 2) {
    stateAbbreviation = stateNameToAbbreviation[stateInput] || stateInput;
  }

  if (stateAbbreviation.length > 2) {
    throw new Error(`Unsupported state: ${stateInput}`);
  }

  const stateRate = quoteRates[stateAbbreviation];
  if (!stateRate) {
    throw new Error(`Unsupported state: ${stateAbbreviation}`);
  }

  const applicableTier = rateTiers.find(tier =>
    truckValue >= tier.min && truckValue <= tier.max
  );

  if (!applicableTier) {
    throw new Error(`Truck value $${truckValue} is outside our supported range`);
  }

  const deductible = customDeductible || deductibleTiers.find(tier =>
    truckValue >= tier.min && truckValue <= tier.max
  )?.deductible || 1000;

  const basePremium = (applicableTier.rate / 100) * truckValue;

  // Apply 0.90 factor only if truckValue > 75000 and deductible > 1000
  const deductibleFactor = truckValue > 75000 && deductible > 1000 ? 0.90 : 1.0;
  const deductibleAdjustedPremium = basePremium * deductibleFactor;

  const carrierFee = stateRate.carrierFee;
  const surplusLineTax = (stateRate.surplusLineTaxRate / 100) * deductibleAdjustedPremium;
  const stampingFee = stateRate.stampingFee || 0;
  const clearingHouseFee = stateRate.clearingHouseFee ?
    (stateRate.clearingHouseFee / 100) * deductibleAdjustedPremium : 0;

  const stateSurcharge = stateRate.stateSurcharge ?
    stateRate.stateSurcharge * deductibleAdjustedPremium : 0;

  const totalQuotation = deductibleAdjustedPremium + carrierFee + surplusLineTax +
    stampingFee + clearingHouseFee + stateSurcharge;

  return {
    basePremium,
    deductibleAdjustedPremium,
    carrierFee,
    surplusLineTax,
    stampingFee,
    clearingHouseFee,
    stateSurcharge,
    totalQuotation,
    deductible
  };
}
