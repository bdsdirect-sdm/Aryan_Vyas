interface StateQuoteRate {
  baseRate: number; 
  carrierFee: number; 
  surplusLineTaxRate: number;
  stampingFee: number | null;
  clearingHouseFee: number | null;
  stateSurcharge: number | null;
}

const quoteRates: Record<string, StateQuoteRate> = {
  AL: {
    baseRate: 5,
    carrierFee: 200,
    surplusLineTaxRate: 6,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  AK: {
    baseRate: 4.5,
    carrierFee: 200,
    surplusLineTaxRate: 3.70,
    stampingFee: null,
    clearingHouseFee: 1,
    stateSurcharge: null
  },
  AZ: {
    baseRate: 5.5,
    carrierFee: 200,
    surplusLineTaxRate: 6,
    stampingFee: null,
    clearingHouseFee: 0.20,
    stateSurcharge: null
  },
  AR: {
    baseRate: 5,
    carrierFee: 200,
    surplusLineTaxRate: 4,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  CA: {
    baseRate: 6,
    carrierFee: 200,
    surplusLineTaxRate: 3,
    stampingFee: null,
    clearingHouseFee: 0.25,
    stateSurcharge: null
  },
  CO: {
    baseRate: 4.5,
    carrierFee: 200,
    surplusLineTaxRate: 3,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  CT: {
    baseRate: 5,
    carrierFee: 200,
    surplusLineTaxRate: 4,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  DE: {
    baseRate: 4,
    carrierFee: 200,
    surplusLineTaxRate: 2,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  FL: {
    baseRate: 5.5,
    carrierFee: 200,
    surplusLineTaxRate: 5,
    stampingFee: null,
    clearingHouseFee: 0.10,
    stateSurcharge: null
  },
  GA: {
    baseRate: 5,
    carrierFee: 200,
    surplusLineTaxRate: 4,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  HI: {
    baseRate: 4.5,
    carrierFee: 200,
    surplusLineTaxRate: 4.68,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  ID: {
    baseRate: 4.5,
    carrierFee: 200,
    surplusLineTaxRate: 1.50,
    stampingFee: null,
    clearingHouseFee: 0.25,
    stateSurcharge: null
  },
  IL: {
    baseRate: 5,
    carrierFee: 200,
    surplusLineTaxRate: 3.50,
    stampingFee: null,
    clearingHouseFee: 0.10,
    stateSurcharge: 0.2
  },
  IN: {
    baseRate: 4.5,
    carrierFee: 200,
    surplusLineTaxRate: 2.50,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  IA: {
    baseRate: 4,
    carrierFee: 200,
    surplusLineTaxRate: 1,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  KS: {
    baseRate: 5.5,
    carrierFee: 200,
    surplusLineTaxRate: 6,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  KY: {
    baseRate: 5,
    carrierFee: 200,
    surplusLineTaxRate: 4.80,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  LA: {
    baseRate: 5.5,
    carrierFee: 200,
    surplusLineTaxRate: 5,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  ME: {
    baseRate: 4.5,
    carrierFee: 200,
    surplusLineTaxRate: 3,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  MD: {
    baseRate: 4.5,
    carrierFee: 200,
    surplusLineTaxRate: 3,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  MA: {
    baseRate: 5,
    carrierFee: 200,
    surplusLineTaxRate: 4,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  MI: {
    baseRate: 4.5,
    carrierFee: 200,
    surplusLineTaxRate: 2.50,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  MN: {
    baseRate: 4.5,
    carrierFee: 200,
    surplusLineTaxRate: 3,
    stampingFee: null,
    clearingHouseFee: 0.80,
    stateSurcharge: 0.5
  },
  MS: {
    baseRate: 6,
    carrierFee: 200,
    surplusLineTaxRate: 7,
    stampingFee: null,
    clearingHouseFee: 0.25,
    stateSurcharge: null
  },
  MO: {
    baseRate: 5.5,
    carrierFee: 200,
    surplusLineTaxRate: 5,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  MT: {
    baseRate: 4.5,
    carrierFee: 200,
    surplusLineTaxRate: 2.75,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  NE: {
    baseRate: 4.5,
    carrierFee: 200,
    surplusLineTaxRate: 3,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  NV: {
    baseRate: 5,
    carrierFee: 200,
    surplusLineTaxRate: 3.50,
    stampingFee: null,
    clearingHouseFee: 0.40,
    stateSurcharge: null
  },
  NH: {
    baseRate: 4.5,
    carrierFee: 200,
    surplusLineTaxRate: 3,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  NJ: {
    baseRate: 5.5,
    carrierFee: 200,
    surplusLineTaxRate: 5,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  NM: {
    baseRate: 4.5,
    carrierFee: 200,
    surplusLineTaxRate: 3.00,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  NY: {
    baseRate: 4.5,
    carrierFee: 200,
    surplusLineTaxRate: 3.60,
    stampingFee: 15,
    clearingHouseFee: 0.20,
    stateSurcharge: null
  },
  NC: {
    baseRate: 5.5,
    carrierFee: 200,
    surplusLineTaxRate: 5,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  ND: {
    baseRate: 4,
    carrierFee: 200,
    surplusLineTaxRate: 1.75,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  OH: {
    baseRate: 5.5,
    carrierFee: 200,
    surplusLineTaxRate: 5,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: 0.2
  },
  OK: {
    baseRate: 5.5,
    carrierFee: 200,
    surplusLineTaxRate: 6,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  OR: {
    baseRate: 4.5,
    carrierFee: 200,
    surplusLineTaxRate: 2.30,
    stampingFee: 15,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  PA: {
    baseRate: 4.5,
    carrierFee: 200,
    surplusLineTaxRate: 3,
    stampingFee: 25,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  RI: {
    baseRate: 5,
    carrierFee: 200,
    surplusLineTaxRate: 4,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  SC: {
    baseRate: 5.5,
    carrierFee: 200,
    surplusLineTaxRate: 6,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  SD: {
    baseRate: 4.5,
    carrierFee: 200,
    surplusLineTaxRate: 2.50,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  TN: {
    baseRate: 5.5,
    carrierFee: 200,
    surplusLineTaxRate: 5,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  TX: {
    baseRate: 5,
    carrierFee: 200,
    surplusLineTaxRate: 4.85,
    stampingFee: 10,
    clearingHouseFee: 0.06,
    stateSurcharge: null
  },
  UT: {
    baseRate: 5,
    carrierFee: 200,
    surplusLineTaxRate: 4.25,
    stampingFee: null,
    clearingHouseFee: 0.15,
    stateSurcharge: null
  },
  VT: {
    baseRate: 4.5,
    carrierFee: 200,
    surplusLineTaxRate: 3,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  VA: {
    baseRate: 4.5,
    carrierFee: 200,
    surplusLineTaxRate: 2.25,
    stampingFee: null,
    clearingHouseFee: 0.03,
    stateSurcharge: null
  },
  WA: {
    baseRate: 4,
    carrierFee: 200,
    surplusLineTaxRate: 2,
    stampingFee: null,
    clearingHouseFee: 0.10,
    stateSurcharge: null
  },
  WV: {
    baseRate: 5,
    carrierFee: 200,
    surplusLineTaxRate: 4.55,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  WI: {
    baseRate: 4.5,
    carrierFee: 200,
    surplusLineTaxRate: 3,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  WY: {
    baseRate: 4.5,
    carrierFee: 200,
    surplusLineTaxRate: 3,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  },
  DC: {
    baseRate: 5,
    carrierFee: 200,
    surplusLineTaxRate: 2,
    stampingFee: null,
    clearingHouseFee: null,
    stateSurcharge: null
  }
};

export default quoteRates;