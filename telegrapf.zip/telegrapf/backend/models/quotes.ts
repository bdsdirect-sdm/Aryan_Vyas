import { Model, DataTypes, Optional } from 'sequelize';
import sequelize from '../config/database';

interface MessageAttributes {
  id: string;
  userId: string;
  message: string;
  truckModel: string;
  truckType: string;
  truckYear: string;
  truckValue: number;
  truckState: string;
  basePremium: number;
  carrierFee: number;
  surplusLineTax: number;
  stampingFee: number;
  totalQuotation: number;
}

type MessageCreationAttributes = Optional<MessageAttributes, 'id'>;

class Quotes extends Model<MessageAttributes, MessageCreationAttributes>
  implements MessageAttributes {
  public id!: string;
  public userId!: string;
  public message!: string;
  public truckModel!: string;
  public truckType!: string;
  public truckYear!: string;
  public truckValue!: number;
  public truckState!: string;
  public basePremium!: number;
  public carrierFee!: number;
  public surplusLineTax!: number;
  public stampingFee!: number;
  public totalQuotation!: number;
  public readonly deletedAt!: Date | null;
}

Quotes.init(
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    userId: {
      type: DataTypes.UUID,
      allowNull: false,
    },
    message: {
      type: DataTypes.TEXT,
      allowNull: false,
    },
    truckModel: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    truckType: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    truckYear: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    truckValue: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    truckState: {
      type: DataTypes.STRING,
      allowNull: false,
    },
    basePremium: { 
      type: DataTypes.FLOAT, 
      allowNull: false 
    },
    carrierFee: { 
      type: DataTypes.FLOAT, 
      allowNull: false 
    },
    surplusLineTax: { 
      type: DataTypes.FLOAT, 
      allowNull: false 
    },
    stampingFee: { 
      type: DataTypes.FLOAT, 
      allowNull: false 
    },
    totalQuotation: { 
      type: DataTypes.FLOAT, 
      allowNull: false 
    },
  },
  {
    sequelize,
    modelName: 'quotes',
    timestamps: true,
    paranoid: true,
  }
);

export default Quotes;
