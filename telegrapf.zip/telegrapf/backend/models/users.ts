import { Model, DataTypes, Optional } from 'sequelize';
import sequelize from '../config/database';

interface UserAttributes {
  id: string;
  telegramId: string;
  firstName: string | null;
  lastName: string | null;
  phoneNumber: string | null;
}

type UserCreationAttributes = Optional<UserAttributes, 'id'>;

class Users extends Model<UserAttributes, UserCreationAttributes>
  implements UserAttributes {
  public id!: string;
  public telegramId!: string;
  public firstName!: string | null;
  public lastName!: string | null;
  public phoneNumber!: string | null;
}

Users.init(
  {
    id: {
      type: DataTypes.UUID,
      defaultValue: DataTypes.UUIDV4,
      primaryKey: true,
    },
    telegramId: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: true,
    },
    firstName: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    lastName: {
      type: DataTypes.STRING,
      allowNull: true,
    },
    phoneNumber: {
      type: DataTypes.STRING,
      allowNull: true,
      validate: {
        is: {
          args: [/^[0-9]{10,15}$/],
          msg: 'Phone number must be between 10 and 15 digits',
        },
      },
    },
  },
  {
    sequelize,
    modelName: 'users',
    timestamps: true,
    paranoid: true,
  }
);

export default Users;
