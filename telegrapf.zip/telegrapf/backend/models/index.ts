import sequelize from "../config/database";
import Users from "./users";
import Quotes from "./quotes";

Users.hasMany(Quotes, { foreignKey: 'userId', as: 'userMessages' });
Quotes.belongsTo(Users, { foreignKey: 'userId', as: 'messageUser' });

export { sequelize, Users, Quotes };
