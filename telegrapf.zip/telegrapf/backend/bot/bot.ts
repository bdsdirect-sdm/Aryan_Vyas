import { Telegraf } from 'telegraf';
import dotenv from 'dotenv';
import { handleMessage } from './handlers';

dotenv.config();

const token = process.env.BOT_TOKEN!;
const bot = new Telegraf(token);

const userState: Record<number, string> = {};

export function initBot() {
  bot.on('message', (ctx) => handleMessage(bot, ctx, userState));
  bot.launch();
}
