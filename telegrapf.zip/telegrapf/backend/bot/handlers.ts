import { Telegraf, Context } from 'telegraf';
import { validateTruckDetails } from './validation';
import { Users, Quotes } from '../models';
import { calculateQuote } from '../utils/calculateQuote';

const truckCompanies = ['VOLVO', 'TATA'];
const truckModels = {
  VOLVO: ['VNL760', 'VNR300'],
  TATA: ['3380', '3381'],
};

const truckYears = Array.from({ length: new Date().getFullYear() - 2014 }, (_, i) =>
  (2015 + i).toString()
);

export async function handleMessage(
  bot: Telegraf<Context>,
  ctx: Context,
  userState: Record<number | string, string>
) {
  const chatId = ctx.chat?.id;
  const messageText =
    'text' in (ctx.message || {}) ? (ctx.message as { text: string }).text : '';
  const contact = (ctx.message as any)?.contact;
  const fromUser = ctx.from;

  if (!chatId || !fromUser) return;

  console.log('📩 Full message object:', ctx.message);
  console.log(`💬 Message from ${fromUser.first_name}: "${messageText}"`);
  console.log(`📍 Current state for ${chatId}: ${userState[chatId]}`);

  const [user, created] = await Users.findOrCreate({
    where: { telegramId: String(fromUser.id) },
    defaults: {
      telegramId: String(fromUser.id),
      firstName: fromUser.first_name || null,
      lastName: fromUser.last_name || null,
      phoneNumber: contact?.phone_number || null,
    },
  });

  if (!created && contact?.phone_number && !user.phoneNumber) {
    await user.update({ phoneNumber: contact.phone_number });
  }

  if (messageText === '/start') {
    userState[chatId] = 'START';
    return await ctx.reply(`👋 Welcome to the Insurance Quote Bot!\n\nChoose an option:`, {
      reply_markup: {
        keyboard: [
          [{ text: '📄 Company Details' }],
          [{ text: '💰 Check Insurance Quote' }],
        ],
        resize_keyboard: true,
        one_time_keyboard: true,
      },
    });
  }

  if (messageText === '/close') {
    delete userState[chatId];
    return await ctx.reply('👋 Chat session closed. Type /start to begin again.', {
      reply_markup: { remove_keyboard: true },
    });
  }

  if (messageText === '/clear') {
    userState[chatId] = 'START';
    return await ctx.reply('🧹 Chat cleared. What would you like to do next?', {
      reply_markup: {
        keyboard: [
          [{ text: '📄 Company Details' }],
          [{ text: '💰 Check Insurance Quote' }],
        ],
        resize_keyboard: true,
        one_time_keyboard: true,
      },
    });
  }

  const currentState = userState[chatId];

  if (messageText === '📄 Company Details') {
    userState[chatId] = 'COMPANY_DETAILS';
    return await ctx.reply('Coming Soon....', {
      reply_markup: { remove_keyboard: true },
    });
  }

  if (messageText === '💰 Check Insurance Quote') {
    userState[chatId] = 'WAITING_FOR_PHONE';
    return await ctx.reply('If you want, you can share your mobile number (optional):', {
      reply_markup: {
        keyboard: [
          [{ text: '📱 Share Phone Number', request_contact: true }],
          [{ text: '➡️ Skip' }],
        ],
        resize_keyboard: true,
        one_time_keyboard: true,
      },
    });
  }

  if (currentState === 'WAITING_FOR_PHONE') {
    let phoneReceived = false;

    if (contact?.phone_number) {
      await ctx.reply(`✅ Phone number received: ${contact.phone_number}`);
      phoneReceived = true;
    } else if (messageText === '➡️ Skip') {
      await ctx.reply('✅ Skipped phone number');
      phoneReceived = true;
    } else if (/^\+?[0-9]{10,15}$/.test(messageText)) {
      await ctx.reply(`✅ Mobile number received: ${messageText}`);
      phoneReceived = true;
      if (!user.phoneNumber) {
        await user.update({ phoneNumber: messageText });
      }
      
    } else {
      return await ctx.reply('❌ Please share your phone number or tap "Skip".');
    }

    if (phoneReceived) {
      userState[chatId] = 'WAITING_FOR_TRUCK_COMPANY';
      return await ctx.reply('🚛 Select your Truck Company:', {
        reply_markup: {
          keyboard: truckCompanies.map((c) => [{ text: c }]),
          resize_keyboard: true,
          one_time_keyboard: true,
        },
      });
    }
  }

  if (currentState === 'WAITING_FOR_TRUCK_COMPANY') {
    if (truckCompanies.includes(messageText)) {
      userState[chatId] = 'WAITING_FOR_TRUCK_MODEL';
      userState[`${chatId}_truckCompany`] = messageText;
      return await ctx.reply(`🔧 Select model for ${messageText}:`, {
        reply_markup: {
          keyboard:
            truckModels[messageText as keyof typeof truckModels]?.map((model) => [
              { text: model },
            ]) || [],
          resize_keyboard: true,
          one_time_keyboard: true,
        },
      });
    } else {
      return await ctx.reply('❌ Please select a valid truck company.');
    }
  }

  if (currentState === 'WAITING_FOR_TRUCK_MODEL') {
    const selectedCompany = userState[`${chatId}_truckCompany`];
    if (
      truckModels[selectedCompany as keyof typeof truckModels]?.includes(messageText)
    ) {
      userState[chatId] = 'WAITING_FOR_TRUCK_YEAR';
      userState[`${chatId}_truckModel`] = messageText;
      return await ctx.reply('📅 Select the Year of Purchase:', {
        reply_markup: {
          keyboard: truckYears.map((year) => [{ text: year }]),
          resize_keyboard: true,
          one_time_keyboard: true,
        },
      });
    } else {
      return await ctx.reply('❌ Please select a valid truck model.');
    }
  }

  if (currentState === 'WAITING_FOR_TRUCK_YEAR') {
    if (truckYears.includes(messageText)) {
      userState[chatId] = 'WAITING_FOR_TRUCK_STATE';
      userState[`${chatId}_truckYear`] = messageText;
      return await ctx.reply(
        '🌎 Please type the US state you’re based in (e.g., TX, CA, NY):',
        {
          reply_markup: { remove_keyboard: true },
        }
      );
    } else {
      return await ctx.reply('❌ Please select a valid year.');
    }
  }

  if (currentState === 'WAITING_FOR_TRUCK_STATE') {
    const truckCompany = userState[`${chatId}_truckCompany`];
    const truckModel = userState[`${chatId}_truckModel`];
    const truckYear = userState[`${chatId}_truckYear`];

    const validation = validateTruckDetails(`${truckCompany},${truckModel},${messageText}`);

    if (!validation.valid) {
      return await ctx.reply(`❌ ${validation.message}`);
    }

    userState[chatId] = 'WAITING_FOR_TRUCK_VALUE';
    userState[`${chatId}_truckState`] = validation.stateFull ?? messageText;

    return await ctx.reply('💵 Please enter your Truck Value in USD (minimum $10,000):', {
      reply_markup: { remove_keyboard: true },
    });
  }

  if (currentState === 'WAITING_FOR_TRUCK_VALUE') {
    const enteredValue = parseFloat(messageText.replace(/[^0-9.]/g, ''));

    if (isNaN(enteredValue) || enteredValue < 10000) {
      return await ctx.reply(
        '❌ Invalid truck value. Please enter a number not less than $10,000.'
      );
    }

    const truckCompany = userState[`${chatId}_truckCompany`];
    const truckModel = userState[`${chatId}_truckModel`];
    const truckYear = userState[`${chatId}_truckYear`];
    const state = userState[`${chatId}_truckState`];

    const quoteBreakdown = calculateQuote(enteredValue, state);

    await Quotes.create({
      userId: user.id,
      message: `Truck Details Collected`,
      truckType: truckCompany,
      truckModel: truckModel,
      truckYear: truckYear,
      truckState: state,
      truckValue: enteredValue,
      basePremium: quoteBreakdown.basePremium,
      carrierFee: quoteBreakdown.carrierFee,
      surplusLineTax: quoteBreakdown.surplusLineTax,
      stampingFee: quoteBreakdown.stampingFee,
      totalQuotation: quoteBreakdown.totalQuotation,
    });

    userState[chatId] = 'DONE';

    await ctx.reply(
      `✅ **Truck Details Received**:\n` +
        `Company: ${truckCompany}\n` +
        `Model: ${truckModel}\n` +
        `Year: ${truckYear}\n` +
        `State: ${state}\n` +
        `Truck Value: $${enteredValue.toLocaleString()}\n\n` +
        `📝 **Quotation Breakdown**:\n` +
        `Base Premium: $${quoteBreakdown.basePremium.toFixed(2)}\n` +
        `Carrier Fee: $${quoteBreakdown.carrierFee.toFixed(2)}\n` +
        `Surplus Line Tax: $${quoteBreakdown.surplusLineTax.toFixed(2)}\n` +
        `Stamping Fee: $${quoteBreakdown.stampingFee.toFixed(2)}\n` +
        `Total Quotation: $${quoteBreakdown.totalQuotation.toFixed(2)}`
    );
  }
}
