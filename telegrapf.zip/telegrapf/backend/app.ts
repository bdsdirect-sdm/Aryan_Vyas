import express, { Request, Response } from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import userRoutes from './routes/userRoutes';
import path from 'path';
dotenv.config({ path: `./config/.env.${process.env.NODE_ENV}` });
dotenv.config();

const app = express();

// Middleware
app.use(cors({ origin: '*' }));
app.use(express.json());

// Routes
app.use('/api/v1', userRoutes);

// Static Files
app.use(
  '/uploads',
  express.static(path.join(__dirname, 'uploads'), {
    setHeaders: (res) => {
      res.setHeader('Cross-Origin-Resource-Policy', 'cross-origin');
    },
  })
);

// Root Endpoint
app.get('/', (_req: Request, res: Response): void => {
  res.send('🚀 API is running...');
});

export default app;