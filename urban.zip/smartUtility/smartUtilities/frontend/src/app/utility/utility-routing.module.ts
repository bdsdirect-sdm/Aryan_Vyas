import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { utilityComponent } from './utility.component';
import { loginComponent } from './login/login.component';
export const routes: Routes = [
  {
    path: 'utility', component: utilityComponent,
    children: [
      {
        path: 'login',
        component: loginComponent
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class UtilityRoutingModule { }
