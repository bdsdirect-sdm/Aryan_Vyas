import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { UtilityRoutingModule } from './utility-routing.module';
import { utilityComponent } from './utility.component';
import { loginComponent } from './login/login.component';
import {CommonService} from './services/common.service';
import { masterModulesModule} from './masterModules/masterModules.module';
import { masterModulesRoutingModule } from './masterModules/masterModules-routing.module';
import { AppSharedModule } from '../shared/app-shared.module';


@NgModule({ 
  declarations: [
    utilityComponent,
    loginComponent,      
  ],
  imports: [
    AppSharedModule,
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    UtilityRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    masterModulesModule,
    masterModulesRoutingModule
  ],
  providers: [CommonService],
  bootstrap: [utilityComponent]
})
export class utilityModule { }
