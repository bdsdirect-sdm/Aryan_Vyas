import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { subAdminsService } from '../../services/subAdmins.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from '../../../services/common.service';

@Component({
  selector: 'subAdmins-edit-tutorial',
  templateUrl: './subAdmins-edit.component.html',
  styleUrls: ['./subAdmins-edit.component.css']
})
export class subAdminEditComponent implements OnInit {
  modulesList: any = [];
  subadmin: any;
  moduleIds: any = [];

  constructor(private subAdminService: subAdminsService, private spinner: NgxSpinnerService,
    private toastr: ToastrService, private router: Router,
    private commonService: CommonService, private activatedRoute: ActivatedRoute) {
    this.subadmin = {};
  }

  ngOnInit() {
    this.getDetails();
    this.getAllModules();
    this.commonService.notifyOther({ option: 'breadcrumbs', value: 'Manage Sub Admins' });
  }

  getDetails() {
    this.spinner.show();
    this.subAdminService.getsubAdminDetail(this.activatedRoute.snapshot.params.id).subscribe(result => {
      this.subadmin = result.data.user[0];
      result.data.permissions.forEach(element => {
        this.moduleIds.push(element.module_id);
      });
      console.log('-------xxxxxx', this.moduleIds)
      this.spinner.hide();
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });

  }

  getAllModules() {
    this.spinner.show();
    this.subAdminService.getSubModules().subscribe(result => {
      this.modulesList = result;
      this.spinner.hide();
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });

  }

  checklistChanged(id) {
    console.log('-------this.moduleIds-----', this.moduleIds)
    if(this.moduleIds.includes(id)) {
      this.moduleIds.splice(this.moduleIds.indexOf(id), 1);
    } else {
      this.moduleIds.push(id);
    }
  }

  isChecked(id) {
    if(this.moduleIds.includes(id)) {
      return true;
    }
  }

  update() {
    this.spinner.show();
    this.subadmin['first_name'] = this.commonService.titleCase(this.subadmin.first_name);
    this.subadmin['last_name'] = this.commonService.titleCase(this.subadmin.last_name);
    this.subadmin['module_id'] = this.moduleIds;
    delete this.subadmin.password;
    this.subAdminService.updateSubAdmin(this.subadmin).subscribe(response => {
      this.spinner.hide();
      this.toastr.success('Sub Admin edited successfully', 'Success');
      this.router.navigate(['/utility/manageSubAdmins']);
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
  }

}
