
import { Injectable, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import 'rxjs/add/operator/map';
import { CookieService } from 'ngx-cookie';

@Injectable({
  providedIn: 'root'
})
export class incidentsService {
  constructor(private http: HttpClient, public router: Router,
    private _cookieservice: CookieService) {

  }

  getHeaders() {
    let headerOption = environment.headerOption;
    if (this._cookieservice.get('token')) {
      const loggedInUtility = JSON.parse(this._cookieservice.get('token'));
      headerOption['Authorization'] = loggedInUtility.access_token;
    }
    const headers = new HttpHeaders(headerOption);
    const options = { headers };
    return options
  }

  getAll() {
    return this.http.get(environment.apiEndPoint + 'api/utility/incidentList', this.getHeaders()).map(res =>
      res as any);

  }

  markResolved(post) {
    return this.http.post(environment.apiEndPoint + 'api/utility/incidentMarkResolved', post, this.getHeaders()).map(res =>
      res as any);
  }

  incidentDetail(id) {

    return this.http.get(environment.apiEndPoint + 'incident/incidentDetail/' + id, this.getHeaders()).map(res => res as any);

  }

  deleteIncident(id) {
    const data: any = {
      id: id
    }

    return this.http.post(environment.apiEndPoint + 'api/utility/deleteIncident', data, this.getHeaders()).map(res => res as any);
  }

  search(keyword) {
    const data: any = {
      keyword: keyword
    };

    return this.http.post(environment.apiEndPoint + 'api/utility/searchIncident', data, this.getHeaders()).map(res => res as any);

  }


  /*********RATING*******/

  getAllRating(obj) {

    console.log("=-=----=raman---");

    return this.http.get(environment.apiEndPoint + 'api/utility/ratingList', this.getHeaders()).map(res =>
      res as any);

  }


  deleteRating(id) {
    const data: any = {
      id: id
    }

    return this.http.post(environment.apiEndPoint + 'api/utility/deleteRating', data, this.getHeaders()).map(res => res as any);
  }

  searchRating(keyword) {
    const data: any = {
      keyword: keyword
    };

    return this.http.post(environment.apiEndPoint + 'api/utility/searchRating', data, this.getHeaders()).map(res => res as any);

  }

  /*****************/
}
