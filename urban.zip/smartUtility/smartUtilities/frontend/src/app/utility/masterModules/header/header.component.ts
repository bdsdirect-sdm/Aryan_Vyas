import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { CookieService } from 'ngx-cookie';
import { UtilityService } from '../../services/utility.service';
import { CommonService } from '../../services/common.service';
import * as _ from 'underscore';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { environment } from '../../../../environments/environment';

@Component({
  selector: 'app-utility-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  title = 'frontend';
  showDropdown: any;
  loggedInUser: any;
  notificationsList: any;
  notiCount: any;
  pageNumber: any;
  environment: any = {};
  constructor(private router: Router, private _cookieservice: CookieService,
    private spinner: NgxSpinnerService,
    private toastr: ToastrService,
    private utilityService: UtilityService, private commonService: CommonService) {
    this.showDropdown = false;
    this.notificationsList = [];
    this.pageNumber = 1;
    this.loggedInUser = JSON.parse(this._cookieservice.get('token'));
    this.environment = environment;
  }

  ngOnInit() {
    this.getNotifications();
  }

  getNotifications() {
   
    this.utilityService.getNotification().subscribe(result => {
      console.log("----result.data---",result.data)
      if (result.data.length > 100) {
        this.notiCount = '100+';
      } else {
        this.notiCount = result.data.length;
      }

      let mainArray = [];
      _.each(result.data, (obj: any) => {
        let temp;
        temp = obj;
        temp['timeAgo'] = this.timeSince(obj.created_at);
        mainArray.push(temp);
      });
      this.notificationsList = this.paginate(mainArray, 5, this.pageNumber);

    }, err => {
      this.commonService.handleError(err);
    });
  }

  paginate(array, page_size, page_number) {
    return array.slice((page_number - 1) * page_size, page_number * page_size);
  }

  /*________________________________________________________________________

   * @Method :        nextPage
   * Modified On:     -
   * @Purpose:        Load next 5 notifications
   * Input:
   * Output:          Call getNotifications() function
   _________________________________________________________________________
  */
  nextPage() {
    this.pageNumber = this.pageNumber + 1;
    this.getNotifications();
  }

  manageNotification(not, status) {
    //this.spinner.show();
    let json = {
      status: status,
      id: btoa(not.id)
    }

    this.utilityService.notifyStatus(json).subscribe(result => {
     // this.spinner.hide();
     
      if(status == 1) {
        //this.toastr.success('Notification Readed Successfully', 'Success');
      } else {
        this.toastr.success('Notification Removed Successfully', 'Success');
      }
      this.getNotifications();
      

    }, err => {
      this.commonService.handleError(err);
    });
  }

  /*________________________________________________________________________

   * @Method :        timeSince
   * Modified On:     -
   * @Purpose:        Convert time format
   * Input:
   * Output:          Time in ago format
   _________________________________________________________________________
  */
  timeSince(time) {
    switch (typeof time) {
      case 'number':
        break;
      case 'string':
        time = +new Date(time);
        break;
      case 'object':
        if (time.constructor === Date) { time = time.getTime(); }
        break;
      default:
        time = +new Date();
    }
    const time_formats = [
      [60, 'seconds', 1], // 60
      [120, '1 minute ago', '1 minute from now'], // 60*2
      [3600, 'minutes', 60], // 60*60, 60
      [7200, '1 hour ago', '1 hour from now'], // 60*60*2
      [86400, 'hours', 3600], // 60*60*24, 60*60
      [172800, 'Yesterday', 'Tomorrow'], // 60*60*24*2
      [604800, 'days', 86400], // 60*60*24*7, 60*60*24
      [1209600, 'Last week', 'Next week'], // 60*60*24*7*4*2
      [2419200, 'weeks', 604800], // 60*60*24*7*4, 60*60*24*7
      [4838400, 'Last month', 'Next month'], // 60*60*24*7*4*2
      // [29030400, messagesConstants.months, 2419200], // 60*60*24*7*4*12, 60*60*24*7*4
      [58060800, 'Last year', 'Next year'], // 60*60*24*7*4*12*2
      [2903040000, 'years', 29030400], // 60*60*24*7*4*12*100, 60*60*24*7*4*12
      [5806080000, 'Last century', 'Next century'], // 60*60*24*7*4*12*100*2
      [58060800000, 'centuries', 2903040000] // 60*60*24*7*4*12*100*20, 60*60*24*7*4*12*100
    ];
    let seconds = (+new Date() - time) / 1000,
      token = 'ago',
      list_choice = 1;

    if (seconds == 0) {
      return 'Just now';
    }
    if (seconds < 0) {
      seconds = Math.abs(seconds);
      token = 'from now';
      list_choice = 2;
    }
    let i = 0,
      format;
    while (format = time_formats[i++]) {
      if (seconds < format[0]) {
        if (typeof format[2] == 'string') {
          return format[list_choice];
        }
        else {
          return Math.floor(seconds / format[2]) + ' ' + format[1] + ' ' + token;
        }
      }
    }
    return time;
  }

  logout() {
    this._cookieservice.removeAll();
    this.router.navigate(['/utility/login']);
  }
}
