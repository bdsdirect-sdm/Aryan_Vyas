import { Component, OnInit, TemplateRef } from '@angular/core';
import { CommonService } from '../../services/common.service';
import { serviceProvidersService } from '../../masterModules/services/serviceProviders.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import * as _ from 'underscore';
import { ToastrService } from 'ngx-toastr';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { CustomEventTitleFormatter } from './custom-event-title-formatter.provider';
import { serviceRequestService } from '../services/serviceRequests.service';
import {
  startOfDay,
  endOfDay,
  subDays,
  addDays,
  endOfMonth,
  isSameDay,
  isSameMonth,
  addHours,
} from 'date-fns';
import {
  CalendarEvent,
  CalendarEventAction,
  CalendarEventTimesChangedEvent,
  CalendarView,
  CalendarEventTitleFormatter,
} from 'angular-calendar';
import { Subject } from 'rxjs';
const colors: any = {
  red: {
    primary: '#ad2121',
    secondary: '#FAE3E3',
  },
  blue: {
    primary: '#1e90ff',
    secondary: '#D1E8FF',
  },
  yellow: {
    primary: '#e3bc08',
    secondary: '#FDF1BA',
  },
};

@Component({
  selector: 'calender-root',
  templateUrl: './calender.component.html',
  providers: [
    {
      provide: CalendarEventTitleFormatter,
      useClass: CustomEventTitleFormatter,
    },
  ],
  styleUrls: ['./calender.component.css']
})
export class CalenderComponent implements OnInit {
  view: CalendarView = CalendarView.Month;
  modalRef: BsModalRef;

  CalendarView = CalendarView;

  viewDate: Date = new Date();
  actions: CalendarEventAction[] = [
    {
      label: '<i class="fas fa-fw fa-pencil-alt"></i>',
      a11yLabel: 'Edit',
      onClick: ({ event }: { event: CalendarEvent }): void => {

      },
    },
    {
      label: '<i class="fas fa-fw fa-trash-alt"></i>',
      a11yLabel: 'Delete',
      onClick: ({ event }: { event: CalendarEvent }): void => {

      },
    },
  ];

  refresh: Subject<any> = new Subject();

  events: any;

  activeDayIsOpen: boolean = false;
  title = 'frontend';
  service_provider: any;
  utilityServiceProviders: any;
  service_request: any;
  request_status: any;
  providerId: any;
  providerName: string;
  startDate = new Date();
  endDate = new Date();
  viewEvent: any;
  requestType: any;
  serviceStatus: any;
  EVENT_LIMIT: any = 10;

  constructor(private commonService: CommonService, private serviceProvidersService: serviceProvidersService,
    private spinner: NgxSpinnerService, private router: Router, private serviceRequestService: serviceRequestService,
    private modalService: BsModalService, private toastr: ToastrService, private activatedRoute: ActivatedRoute) {
    this.service_provider = '';
    this.service_request = 'job';
    this.requestType = 'Service Requests';
    this.request_status = '';
    this.activatedRoute.params.subscribe(paramid => {
      this.providerId = paramid.id;
    });
    this.startDate = new Date(moment().startOf('month').toString());
    this.endDate = new Date(moment().endOf('month').toString());

  }

  ngOnInit() {
    this.commonService.notifyOther({ option: 'breadcrumbs', value: 'Manage Calender' });
    this.getList();
    this.getProvidersWeeklyData();
    this.getAllServiceStatus();
  }

  getAllServiceStatus() {
    this.serviceRequestService.listServiceStatus().subscribe(result => {
      this.serviceStatus = result.data;
    }, err => {
      this.commonService.handleError(err);
    });
  }

  getList() {
    this.spinner.show();
    let inputJson = {};
    inputJson['page'] = 1;
    inputJson['limit'] = 10;
    inputJson['sort'] = { 'title': 'asc' };
    this.serviceProvidersService.getAll(inputJson).subscribe(result => {
      this.utilityServiceProviders = result;
      this.serviceProvidersService.getDetails(this.providerId).subscribe(response => {
        this.providerName = response[0].first_name + ' ' + response[0].last_name;
        this.service_provider = response[0].id;
      }, err => {
        this.spinner.hide();
        this.commonService.handleError(err);
      });
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });

  }

  getProvidersWeeklyData() {
    let json = {
      start_date: moment(this.startDate).format('YYYY-MM-DD'),
      end_date: moment(this.endDate).format('YYYY-MM-DD'),
      service_provider_id: this.providerId,
      service_request_type: this.service_request
    }

    if (this.request_status != '') {
      json['service_request_status'] = this.request_status
    }
    this.serviceProvidersService.getProvidersData(json).subscribe(result => {
      console.log('-------------result', result)
      if (result.data.length == 0) {
        this.setWeeklySchedule(result.data);
        this.toastr.info('No Weekly data in the selected date range', 'Info')
      } else {
        this.setWeeklySchedule(result.data);
      }

    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
  }

  changeServiceProvider() {
    this.spinner.show();
    this.router.navigate(['/utility/manageCalender', btoa(this.service_provider)]);
    this.startDate = new Date(moment().startOf('month').toString());
    this.endDate = new Date(moment().endOf('month').toString());
    this.providerId = btoa(this.service_provider);
    this.getList();
    this.getProvidersWeeklyData();
  }

  setWeeklySchedule(data) {
    this.events = [];
    if (this.service_request == 'job') {
      _.each(data, (obj: any) => {
        obj['time'] = this.tConvert(obj.time);
        obj['key'] = 'service';
        this.events.push({
          start: startOfDay(new Date(obj.date)),
          title: obj.title,
          id: obj.request_number,
          color: colors.blue,
          data: obj,
          actions: this.actions,
          allDay: true
        });
      });
    } else if (this.service_request == 'incident') {
      _.each(data, (obj: any) => {
        obj['time'] = this.tConvert(obj.time);
        obj['key'] = 'incident';
        this.events.push({
          start: startOfDay(new Date(obj.utilityServiceIncidents_created_at)),
          title: obj.incident_description,
          id: obj.incident_number,
          color: colors.red,
          data: obj,
          actions: this.actions,
          allDay: true
        });
      });
    } else {
      _.each(data, (obj: any) => {
        obj['time'] = moment(obj.payment_date).format('h:mm A');
        obj['key'] = 'payment';
        this.events.push({
          start: startOfDay(new Date(obj.payment_date)),
          title: obj.description,
          id: obj.request_number,
          color: colors.yellow,
          data: obj,
          actions: this.actions,
          allDay: true
        });
      });
    }
    this.spinner.hide();
  }

  handleEvent(action: string, event, template: TemplateRef<any>): void {
    this.modalRef = this.modalService.show(template);
    console.log('------------event.data----', event.data)
    if (this.service_request == 'job') { 
      this.viewEvent = {
        id: event.data.request_number,
        first_name: event.data.customer_first_name,
        last_name: event.data.customer_last_name,
        status: event.data.service_request_status,
        title: event.data.utilityServiceTypes_title,
        date: event.data.date,
        time: event.data.time,
        customer_notes: event.data.customer_note,
        provider_notes: event.data.provider_note,
        hourly_rate: event.data.hourly_rate,
        flat_rate: event.data.flat_rate,
        taskStatus: event.data.taskStatus,
        cost: event.data.cost

      }
    } else if (this.service_request == 'incident') {
      this.viewEvent = {
        id: event.data.incident_number,
        first_name: event.data.customer_first_name,
        last_name: event.data.customer_last_name,
        status: event.data.incident_status,
        title: event.data.incident_description,
        date: event.data.utilityServiceIncidents_created_at,
        time: event.data.time,
        priority: event.data.priority,
        incident_type: event.data.incident_type,
        incident_status: event.data.incident_status,
        request_number: event.data.request_number
      }
    } else {
      this.viewEvent = {
        id: event.data.request_number,
        customer_name: event.data.customer_first_name + ' ' + event.data.customer_last_name,
        status: event.data.taskStatus,
        service_name: event.data.utilityServiceTypes_title,
        transaction_id: event.data.transaction_id,
        title: event.data.description,
        date: moment(event.data.payment_date).format('DD-MM-YYYY'),
        time: moment(event.data.payment_date).format('hh:mm A'),
        cost: event.data.cost,
        payment_status: event.data.status
      }
    }
  }

  dayClicked({ date, events }: { date: Date; events: CalendarEvent[] }): void {
    if (isSameMonth(date, this.viewDate)) {
      if (
        (isSameDay(this.viewDate, date) && this.activeDayIsOpen === true) ||
        events.length === 0
      ) {
        this.activeDayIsOpen = false;
      } else {
        this.activeDayIsOpen = true;
      }
      this.viewDate = date;
    }
  }

  eventTimesChanged({
    event,
    newStart,
    newEnd,
  }: CalendarEventTimesChangedEvent): void {
    this.events = this.events.map((iEvent) => {
      console.log('eventr time changed')
      if (iEvent === event) {
        return {
          ...event,
          start: newStart,
          end: newEnd,
        };
      }
      return iEvent;
    });
    // this.handleEvent('Dropped or resized', event);
  }

  closeModal() {
    this.modalRef.hide();
  }

  changeRequest() {
    this.spinner.show();
    if (this.service_request == 'job') {
      this.requestType = 'Service Requests';
    } else if (this.service_request == 'incident') {
      this.requestType = 'Incidents';
    } else {
      this.requestType = 'Payments';
    }
    this.activeDayIsOpen = false;
    this.getProvidersWeeklyData();
  }

  tConvert(time) {
    time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time];

    if (time.length > 1) {
      time = time.slice(1);
      time[5] = +time[0] < 12 ? ' AM' : ' PM';
      time[0] = +time[0] % 12 || 12;
    }
    delete time[3]
    return time.join('');
  }

  viewRequests() {
    this.router.navigate(['/utility/manageServiceRequests', 'provider', this.providerId]);
  }

  closeOpenMonthViewDay(event) {
    this.spinner.show();
    this.startDate = new Date(moment(event).startOf('month').toString());
    this.endDate = new Date(moment(event).endOf('month').toString());
    this.getProvidersWeeklyData();
    this.activeDayIsOpen = false;
  }

  setView(view: CalendarView) {
    this.view = view;
  }

}
