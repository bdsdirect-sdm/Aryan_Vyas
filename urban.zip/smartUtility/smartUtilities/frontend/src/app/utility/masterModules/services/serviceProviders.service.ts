
import { Injectable, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import 'rxjs/add/operator/map';
import { CookieService } from 'ngx-cookie';

@Injectable({
  providedIn: 'root'
})
export class serviceProvidersService {
  constructor(private http: HttpClient, public router: Router, private _cookieservice: CookieService) {
  }

  getHeaders() {
    let headerOption = environment.headerOption;
    if (this._cookieservice.get('token')) {
      const loggedInUtility = JSON.parse(this._cookieservice.get('token'));
      headerOption['Authorization'] = loggedInUtility.access_token;
    }
    const headers = new HttpHeaders(headerOption);
    const options = { headers };
    return options
  }

  getAll(obj) {

    return this.http.get(environment.apiEndPoint + 'api/utility/getserviceProviders', this.getHeaders()).map(res =>
      res as any);

  }

  getDetails(objId) {

    return this.http.get(environment.apiEndPoint + 'api/utility/getserviceProviderDetails?id=' + objId, this.getHeaders()).map(res => res as any);

  }

  getProviderDetails(objId) {

    return this.http.get(environment.apiEndPoint + 'api/utility/getProviderDetails?id=' + objId, this.getHeaders()).map(res => res as any);

  }



  create(data) {

    return this.http.post(environment.apiEndPoint + 'api/utility/addserviceProvider', data, this.getHeaders()).map(res => res as any);

  }

  getProvidersData(data) {

    return this.http.post(environment.apiEndPoint + 'api/utilityServiceProvider/calendarInDates', data, this.getHeaders()).map(res => res as any);

  }

  update(data) {

    return this.http.post(environment.apiEndPoint + 'api/utility/updateserviceProvider', data, this.getHeaders()).map(res => res as any);
  }


  multiUpdate(data) {

    return this.http.post(environment.apiEndPoint + 'api/utility/multiUpdateserviceProviders', data, this.getHeaders()).map(res => res as any);
  }

  deleteSericeType(id) {
    const data: any = {
      id: id
    }

    return this.http.post(environment.apiEndPoint + 'api/utility/deleteServiceProvider', data, this.getHeaders()).map(res => res as any);
  }

  deleteAll() {
    return this.http.delete(environment.apiEndPoint + 'api');
  }

  findByTitle(keyword) {
    const data: any = {
      keyword: keyword
    };

    return this.http.post(environment.apiEndPoint + 'api/utility/findserviceProviders', data, this.getHeaders()).map(res => res as any);

  }

  uploadFile(data) {
    const headers = new HttpHeaders(environment.multipartHeaderOption);
    const options = { headers };
    console.log("-=-==--=-headers=-=-", headers);
    return this.http.post(environment.apiEndPoint + 'shared/uploadFile', data, options).map(res => res as any);
  }

}
