
import { Injectable, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import 'rxjs/add/operator/map';
import { CookieService } from 'ngx-cookie';

@Injectable({
  providedIn: 'root'
})
export class serviceTypesService {
  constructor(private http: HttpClient, public router: Router,
    private _cookieservice: CookieService) {

  }

  getHeaders() {
    let headerOption = environment.headerOption;
    if (this._cookieservice.get('token')) {
      const loggedInUtility = JSON.parse(this._cookieservice.get('token'));
      headerOption['Authorization'] = loggedInUtility.access_token;
    }
    const headers = new HttpHeaders(headerOption);
    const options = { headers };
    return options
  }

  getAll(obj) {
    if (obj.is_active) {
      return this.http.get(environment.apiEndPoint + 'api/utility/getserviceType?is_active=1', this.getHeaders()).map(res =>
        res as any);
    } else {
      return this.http.get(environment.apiEndPoint + 'api/utility/getserviceType', this.getHeaders()).map(res =>
        res as any);
    }
  }

  getserviceTypeDetails(objId) {

    return this.http.get(environment.apiEndPoint + 'api/utility/getserviceTypeDetails?id=' + objId, this.getHeaders()).map(res => res as any);

  }



  create(data) {

    return this.http.post(environment.apiEndPoint + 'api/utility/addserviceType', data, this.getHeaders());

  }

  update(data) {


    return this.http.post(environment.apiEndPoint + 'api/utility/updateserviceType', data, this.getHeaders()).map(res => res as any);
  }


  multiUpdate(data) {

    return this.http.post(environment.apiEndPoint + 'api/utility/multiUpdate', data, this.getHeaders()).map(res => res as any);
  }

  deleteSericeType(id) {
    const data: any = {
      id: id
    }

    return this.http.post(environment.apiEndPoint + 'api/utility/deleteServiceType', data, this.getHeaders()).map(res => res as any);
  }

  deleteAll() {
    return this.http.delete(environment.apiEndPoint + 'api');
  }

  findByTitle(keyword) {
    const data: any = {
      keyword: keyword
    };

    return this.http.post(environment.apiEndPoint + 'api/utility/findserviceType', data, this.getHeaders()).map(res => res as any);

  }

}
