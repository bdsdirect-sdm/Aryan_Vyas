import { Component, OnInit,TemplateRef } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { serviceRequestService } from '../../services/serviceRequests.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import * as _ from 'underscore';
import * as moment from 'moment';
import { CookieService } from 'ngx-cookie';
import { CommonService } from '../../../services/common.service';

@Component({
  selector: 'serviceRequests-view-tutorial',
  templateUrl: './serviceRequests-view.component.html',
  styleUrls: ['./serviceRequests-view.component.css']
})
export class serviceRequestsViewComponent implements OnInit {
  modalRef: BsModalRef;
  serviceRequest: any;
  providerList: any;
  meridian: any = true;
  minuteStep = 15;
  timeValue: any;
  endtimeValue:any;
  bsValue: any;
  dateValue: string;
  minDate: Date;
  diff = 0;
  incidentDetail: any;
  serviceHistory: any;
  defaultCurrency: any;
  notes: string;
  constructor(private serviceRequestService: serviceRequestService, private spinner: NgxSpinnerService,private modalService: BsModalService,private toastr: ToastrService, private router: Router,private _cookieservice: CookieService,private commonService: CommonService, private activatedRoute: ActivatedRoute) {
    this.serviceRequest = {};
    this.serviceRequest.service_provider_id = '';
    this.minDate = new Date();
  }

  ngOnInit() {
    this.getDetails();
    this.getServiceRequestHistory();
    this.commonService.notifyOther({ option: 'breadcrumbs', value: 'Manage Service Requests' });
  }

  async getDetails() {
    this.spinner.show();
    let superAdminSettings: any = await this.commonService.getSuperAdminDetails();
    this.defaultCurrency = superAdminSettings.default_currency;
    this.serviceRequestService.getServiceRequestDetail(this.activatedRoute.snapshot.params.id).subscribe(result => {
      this.serviceRequestService.getIncidentList(this.activatedRoute.snapshot.params.id).subscribe(response => {
        this.serviceRequest = result.data;
        this.timeValue = moment(this.serviceRequest.time, ["HH:mm"]).format("h:mm A");
        this.endtimeValue = moment(this.serviceRequest.etime, ["HH:mm"]).format("h:mm A");
        this.dateValue = moment(this.serviceRequest.date).format("DD-MM-YYYY");
        this.incidentDetail = response.data;

        this.spinner.hide();
      }, err => {
        this.spinner.hide();
        this.commonService.handleError(err);
      });      
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
  }

  getServiceRequestHistory() {
    this.spinner.show();
    this.serviceRequestService.serviceRequestHistory(this.activatedRoute.snapshot.params.id).subscribe(result => {
      console.log('sssssssssssssssssssssss', result)
      this.serviceHistory = result.data;
      this.spinner.hide();
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
  }

  declineRequest(){
    this.spinner.show();
    let data ={
      id:  this.activatedRoute.snapshot.params.id,
      notes:this.notes
    }
    this.serviceRequestService.updateRequestStatus(data).subscribe(result => {
      console.log('sssssssssssssssssssssss', result);
      this.getDetails();
      this.getServiceRequestHistory();
      this.closeModal();
      this.spinner.hide();
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
  }

  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }

  closeModal() {
    this.modalRef.hide();
  }

}
