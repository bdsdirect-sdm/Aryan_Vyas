import { Component, OnInit, TemplateRef } from '@angular/core';
import { subAdminsService } from '../../services/subAdmins.service';
import { CommonService } from '../../../services/common.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'subAdmins-list',
  templateUrl: './subAdmins-list.component.html',
  styleUrls: ['./subAdmins-list.component.css']
})
export class subAdminListComponent implements OnInit {
  modalRef: BsModalRef;
  subAdminList: any;
  currentServiceType = null;
  currentIndex = -1;
  title = '';
  dataIds: any = [];
  action: any;
  itemValue: any;
  selectedAll: any;
  checked = false;

  showDropdown: any;
  recordsPerPage: unknown;
  hit=0;

  constructor(private subAdminService: subAdminsService, private spinner: NgxSpinnerService,
    private modalService: BsModalService, private toastr: ToastrService, private commonService: CommonService) {
    this.showDropdown = false;
    this.selectedAll = false;
  }

  ngOnInit() {
    this.getList();
    this.commonService.notifyOther({ option: 'breadcrumbs', value: 'Manage Sub Admins' });
  }

  async getList() {
    this.spinner.show();
    let superAdminSettings: any = await this.commonService.getSuperAdminDetails();
    this.recordsPerPage = superAdminSettings.records_per_page;
    this.subAdminService.getAllSubAdmins('').subscribe(result => {
      this.subAdminList = result;
      this.subAdminList.forEach((tmpObj, k) => {
        this.subAdminList[k].id = btoa(this.subAdminList[k].id);
      });
      this.hit=1;
      this.spinner.hide();
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
    this.title = "";
  }
  unselectAll() {
    this.checked = false;
  }

  selectall(event) {
    if (event.target.checked) {
      const selectedIds = [];
      this.subAdminList.forEach(val => { selectedIds.push(val.id) });
      this.dataIds = selectedIds;
    } else {
      this.dataIds = [];
    }
  }

  multiUpdate() {
    if (this.dataIds.length > 0) {
      this.spinner.show();
      let data = {
        action: this.action,
        dataId: this.dataIds
      };
      this.subAdminService.multiUpdate(data).subscribe(response => {
        this.getList();
        this.modalRef.hide();
        this.spinner.hide();
        this.showDropdown = false;
        this.toastr.success('Selected records have been ' + this.action + 'ed successfully', 'Success');
      }, err => {
        this.spinner.hide();
        this.commonService.handleError(err);
      });
    } else {
      this.toastr.info('Please select an record first', 'Info');
      this.modalRef.hide();
    }
  }

  searchTitle() {
    this.spinner.show();
    this.subAdminService.getAllSubAdmins(this.title).subscribe(result => {
      this.subAdminList = result;
      this.spinner.hide();
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
  }

  openModal(template: TemplateRef<any>, data, action) {
    this.modalRef = this.modalService.show(template);
    this.itemValue = data;
    this.action = action;
  }

  closeModal() {
    this.modalRef.hide();
  }

  openModalConfirm(template: TemplateRef<any>, action) {
    this.modalRef = this.modalService.show(template);
    this.action = action;
  }

  countCurrentPageRows() {
    let oRows = document.getElementById('tableBody').getElementsByTagName('tr');
    let iRowCount = oRows.length;
    return iRowCount;

  }

  changeStatusDelete() {
    let data = {
      action: this.action,
      dataId: [this.itemValue.id]
    };
    this.subAdminService.multiUpdate(data).subscribe(response => {
      this.getList();
      this.modalRef.hide();
      this.spinner.hide();
      this.showDropdown = false;
      this.toastr.success('Record ' + this.action + 'ed successfully', 'Success');
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
  }

}
