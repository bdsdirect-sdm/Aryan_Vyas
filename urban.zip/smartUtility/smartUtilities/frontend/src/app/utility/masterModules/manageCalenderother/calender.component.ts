import { Component, OnInit } from '@angular/core';
import { CommonService } from '../../services/common.service';
import { serviceProvidersService } from '../../masterModules/services/serviceProviders.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ActivatedRoute, Router } from '@angular/router';
import * as moment from 'moment';
import * as _ from 'underscore';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'calender-other-root',
  templateUrl: './calender.component.html',
  styleUrls: ['./calender.component.css']
})
export class CalenderOtherComponent implements OnInit {
  title = 'frontend';
  service_provider: any;
  utilityServiceProviders: any;
  service_request: any;
  request_status: any;
  time_duration: any;
  weekdays = [
    "Mon",
    "Tue",
    "Wed",
    "Thur",
    "Fri",
    "Sat",
    "Sun"
  ];
  weekdays2 = [
    "Monday",
    "Tuesday",
    "Wednesday",
    "Thursday",
    "Friday",
    "Saturday",
    "Sunday"
  ];
  weeklyData: any = {};
  providerId: any;
  colorClasses: string[];
  providerName: string;
  calenderDateRange: Date[];
  startDate = new Date();
  endDate = new Date();
  week: any = {};

  constructor(private commonService: CommonService, private serviceProvidersService: serviceProvidersService,
    private spinner: NgxSpinnerService, private router: Router, private toastr: ToastrService, private activatedRoute: ActivatedRoute) {
    this.service_provider = '';
    this.service_request = 'job';
    this.request_status = '';
    this.time_duration = '';
    this.activatedRoute.params.subscribe(paramid => {
      this.providerId = paramid.id;
    });
    this.startDate = new Date(moment().startOf('week').add(1, 'days').toString());
    this.endDate = new Date(moment().startOf('week').add(7, 'days').toString());
    this.calenderDateRange = [this.startDate, this.endDate];
    this.weeklyData = {
      Monday: [],
      Tuesday: [],
      Wednesday: [],
      Thursday: [],
      Friday: [],
      Saturday: [],
      Sunday: []
    };
    this.colorClasses = [
      "blue-row",
      "red-row",
      "turquoise-row",
      "emerald-row",
      "purple-row",
      "orange-row",
      "sea-green-row",
      "carrot-row",
      "blue-dark-row",
      "yellow-row"
    ];
  }

  ngOnInit() {
    this.commonService.notifyOther({ option: 'breadcrumbs', value: 'Manage Calender' });
    this.getList();
    this.getProvidersWeeklyData();
  }

  getList() {
    this.spinner.show();
    let inputJson = {};
    inputJson['page'] = 1;
    inputJson['limit'] = 10;
    inputJson['sort'] = { 'title': 'asc' };
    this.serviceProvidersService.getAll(inputJson).subscribe(result => {
      this.utilityServiceProviders = result;
      this.serviceProvidersService.getDetails(this.providerId).subscribe(response => {
        this.providerName = response[0].first_name + ' ' + response[0].last_name;
        this.service_provider = response[0].id;
      }, err => {
        this.spinner.hide();
        this.commonService.handleError(err);
      });
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });

  }

  getProvidersWeeklyData() {
    let json = {
      start_date: moment(this.startDate).format('YYYY-MM-DD'),
      end_date: moment(this.endDate).format('YYYY-MM-DD'),
      service_provider_id: this.providerId,
      service_request_type: this.service_request
    }
    console.log('-------------------json', json)
    this.serviceProvidersService.getProvidersData(json).subscribe(result => {
      console.log('-------------result', result)
      if (result.data.length == 0) {
        this.setWeeklySchedule(result.data);
        this.toastr.info('No Weekly data in the selected date range', 'Info')
      } else {
        this.setWeeklySchedule(result.data);
      }

    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
  }

  changeServiceProvider() {
    this.spinner.show();
    this.router.navigate(['/utility/manageCalender', btoa(this.service_provider)]);
    this.startDate = new Date(moment().startOf('week').add(1, 'days').toString());
    this.endDate = new Date(moment().startOf('week').add(7, 'days').toString());
    this.providerId = btoa(this.service_provider);
    this.getList();
    this.getProvidersWeeklyData();
  }

  setWeeklySchedule(data) {
    this.weeklyData = {
      Monday: [],
      Tuesday: [],
      Wednesday: [],
      Thursday: [],
      Friday: [],
      Saturday: [],
      Sunday: []
    };

    _.each(data, (obj: any) => {
      obj['time'] = this.tConvert(obj.time);
      this.weeklyData[obj.day_name].push(obj);
    });

    this.spinner.hide();
  }

  changeRequestType() {
    this.spinner.show();
    this.getProvidersWeeklyData();
  }

  tConvert(time) {
    time = time.toString().match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time];

    if (time.length > 1) {
      time = time.slice(1);
      time[5] = +time[0] < 12 ? ' AM' : ' PM';
      time[0] = +time[0] % 12 || 12;
    }
    delete time[3]
    return time.join('');
  }

  checkcolor(type, cc) {
    let new_color = this.colorClasses[parseInt(cc) % 10];
    if (type != 'Requested') {
      new_color = new_color + ' ' + 'set_color';
    }
    return new_color;
  }

  searchOnDate(date) {
    this.spinner.show();
    this.startDate = date[0];
    this.endDate = date[1];
    this.getProvidersWeeklyData();
  }

  viewRequests() {
    this.router.navigate(['/utility/manageServiceRequests', 'provider', this.providerId]);
  }


  getServiceProviders() {
    
  }
}
