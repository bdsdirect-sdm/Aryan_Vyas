
import { Injectable, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import 'rxjs/add/operator/map';
import { CookieService } from 'ngx-cookie';

@Injectable({
  providedIn: 'root'
})
export class customerService {

  constructor(private http: HttpClient, public router: Router,
    private _cookieservice: CookieService) {

  }

  getHeaders() {
    let headerOption = environment.headerOption;
    if (this._cookieservice.get('token')) {
      const loggedInUtility = JSON.parse(this._cookieservice.get('token'));
      headerOption['Authorization'] = loggedInUtility.access_token;
    }
    const headers = new HttpHeaders(headerOption);
    const options = { headers };
    return options
  }


  getCustomerDetail(id) {

    return this.http.get(environment.apiEndPoint + 'customer/edit/' + id, this.getHeaders()).map(res =>
      res as any);
  }

  getAllCustomers(search) {

    return this.http.get(environment.apiEndPoint + 'customer/list?keyword=' + search, this.getHeaders()).map(res =>
      res as any);
  }

  createCustomer(data) {

    return this.http.post(environment.apiEndPoint + 'customer/add', data, this.getHeaders()).map(res => res as any);
  }

  updateCustomer(data) {

    return this.http.post(environment.apiEndPoint + 'customer/update/' + data.id, data, this.getHeaders()).map(res => res as any);
  }


  multiUpdate(data) {

    return this.http.post(environment.apiEndPoint + 'customer/activeInactiveDelete', data, this.getHeaders()).map(res => res as any);
  }


}
