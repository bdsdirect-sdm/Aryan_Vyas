import { Component, OnInit, TemplateRef } from '@angular/core';
import { serviceProvidersService } from '../../../../utility/masterModules/services/serviceProviders.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { CommonService } from '../../../services/common.service';

@Component({
  selector: 'serviceProviders-list',
  templateUrl: './serviceProviders-list.component.html',
  styleUrls: ['./serviceProviders-list.component.css']
})
export class serviceProvidersListComponent implements OnInit {
  modalRef: BsModalRef;
  utilityServiceProviders: any;
  currentServiceProvider = null;
  currentIndex = -1;
  title = '';
  action = null;
  dataIds: any = [];
  itemValue: any;
  showDropdown: any;
  selectedAll: boolean;
  experience: any = [];
  checked = false;
  recordsPerPage: unknown;
  constructor(private serviceProvidersService: serviceProvidersService, private spinner: NgxSpinnerService, private modalService: BsModalService,
    private toastr: ToastrService, private router: Router, private commonService: CommonService
  ) {
    this.showDropdown = false;
    this.selectedAll = false;
    for (let i = 0; i <= 50; i++) {
      this.experience.push(i);
    }
  }

  ngOnInit() {
    this.getList();
    this.commonService.notifyOther({ option: 'breadcrumbs', value: 'Manage Service Providers' });
  }

  async getList() {
    this.spinner.show();
    let inputJson = {};
    inputJson['page'] = 1;
    inputJson['limit'] = 10;
    inputJson['sort'] = { 'title': 'asc' };
    let superAdminSettings: any = await this.commonService.getSuperAdminDetails();
    this.recordsPerPage = superAdminSettings.records_per_page;
    this.serviceProvidersService.getAll(inputJson).subscribe(result => {
      console.log("--list data--", result)
      this.utilityServiceProviders = result;
 
      this.utilityServiceProviders.forEach((tmpObj, k) => {
        this.utilityServiceProviders[k].id = btoa(this.utilityServiceProviders[k].id);
      });
      this.spinner.hide();
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
    this.title = '';
  }



  deleteRow() {
    this.spinner.show();
    this.modalRef.hide();
    this.serviceProvidersService.deleteSericeType(this.itemValue.id).subscribe(result => {
      this.getList();
      this.toastr.success('Service Type has been deleted successfully', 'Success');
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
  }


  refreshList() {
    this.getList();
    this.currentServiceProvider = null;
    this.currentIndex = -1;
  }

  unselectAll() {
    this.checked = false;
  }
  selectall(event) {
    if (event.target.checked) {
      const selectedIds = [];
      this.utilityServiceProviders.forEach(val => { selectedIds.push(val.id) });
      this.dataIds = selectedIds;
    } else {
      this.dataIds = [];
    }
  }


  changeStatus(itemID, action) {
    let data = {
      action: action,
      dataId: [itemID]
    };
    console.log("-=-==-data-=-", data);
    this.serviceProvidersService.multiUpdate(data)
      .subscribe(
        response => {
          console.log("after save", response);
          this.toastr.success('Selected records have been ' + action + 'd successfully', 'Success');
          this.getList();

        },
        err => {
          this.spinner.hide();
          this.commonService.handleError(err);
        });
  }

  multiUpdate() {
    if (this.dataIds.length > 0) {
      let data = {
        action: this.action,
        dataId: this.dataIds
      };

      this.serviceProvidersService.multiUpdate(data)
        .subscribe(
          response => {
            console.log("after save", response);
            this.toastr.success('Selected records have been ' + this.action + 'ed successfully', 'Success');
            this.getList();

          },
          err => {
            this.spinner.hide();
            this.commonService.handleError(err);
          });
    }
    this.modalRef.hide();
  }

  searchTitle() {
    let keyword = this.title;
    this.serviceProvidersService.findByTitle(keyword)
      .subscribe(
        data => {
          this.utilityServiceProviders = data;
          console.log(data);
        },
        err => {
          this.spinner.hide();
          this.commonService.handleError(err);
        });
  }

  openModal(template: TemplateRef<any>, data) {
    this.modalRef = this.modalService.show(template);
    this.itemValue = data;
  }

  openModalConfirm(template: TemplateRef<any>, data) {
    if (this.dataIds.length == 0) {
      this.toastr.error('Please select atleast one item', 'Error');
      return false;
    }
    this.modalRef = this.modalService.show(template);
    this.action = data;
    this.showDropdown = false;
  }

  closeModal() {
    this.modalRef.hide();
  }

  closeMultiModal() {
    this.modalRef.hide();
  }

  countCurrentPageRows() {
    let oRows = document.getElementById('tableBody').getElementsByTagName('tr');
    let iRowCount = oRows.length;
    return iRowCount;

  }

  viewRequests(id) {
    this.commonService.notifyOther({ option: 'sidebar-active', value: 'manageServiceRequests' });
    this.router.navigate(['/utility/manageServiceRequests', 'provider', id]);
  }

  manageCalender(id) {
    this.router.navigate(['/utility/manageCalender', id]);
  }

}
