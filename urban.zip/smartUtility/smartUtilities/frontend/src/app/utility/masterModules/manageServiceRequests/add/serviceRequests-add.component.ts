import { Component, OnInit } from "@angular/core";
import { ActivatedRoute, Params, Router } from "@angular/router";
import { serviceRequestService } from "../../services/serviceRequests.service";
import { customerService } from "../../services/customers.service";
import { NgxSpinnerService } from "ngx-spinner";
import { ToastrService } from "ngx-toastr";
import * as moment from "moment";
import { CommonService } from "../../../services/common.service";
import { CookieService } from "ngx-cookie";

@Component({
  selector: "serviceRequests-add-tutorial",
  templateUrl: "./serviceRequests-add.component.html",
  styleUrls: ["./serviceRequests-add.component.css"],
})
export class serviceRequestsAddComponent implements OnInit {
  serviceRequest: any;
  serviceList: any;
  providerList: any;
  customerID: any;
  meridian: any = true;
  customerName: any;
  minuteStep = 30;
  minDate: Date;
  timeValue: { hour: number; minute: number; second: number };
  endTimeValue: { hour: number; minute: number; second: number };
  allCategories: any;
  subCategories: any;
  options: any;

  finalCost: number = 0;
  hours: number = 0;
  optionCost = 0;
  optionType = "";

  constructor(
    private serviceRequestService: serviceRequestService,
    private spinner: NgxSpinnerService,
    private _cookieservice: CookieService,
    private toastr: ToastrService,
    private commonService: CommonService,
    private customerService: customerService,
    private router: Router,
    private activatedRoute: ActivatedRoute
  ) {
    this.serviceRequest = {};
    this.customerName = {};
    this.serviceRequest.date = new Date();
    this.serviceRequest.time = {
      hour: new Date().getHours() + 1,
      minute: new Date().getMinutes(),
      second: new Date().getSeconds(),
    };
    this.serviceRequest.etime = {
      hour: new Date().getHours() + 1,
      minute: new Date().getMinutes(),
      second: new Date().getSeconds(),
    };
    this.serviceRequest.service_type_id = "";
    this.serviceRequest.service_provider_id = "";
    this.minDate = new Date();
    this.activatedRoute.params.subscribe((paramid) => {
      this.customerID = paramid.id;
    });

    console.log("--this.timeValuesssss--", this.timeValue);
  }

  async ngOnInit() {
    this.getServices();
    this.commonService.notifyOther({
      option: "breadcrumbs",
      value: "Manage Service Requests",
    });
    let categories: any = await this.commonService.getCategories();
    this.allCategories = categories;
  }

  async getSubCategories() {
    this.spinner.show();
    console.log("---vaalaa", this.serviceRequest.utility_id);
    this.subCategories = await this.commonService.getSubCategories(
      this.serviceRequest.utility_id
    );
    console.log("---subCategories----", this.subCategories);
    this.spinner.hide();
  }

  getOptions() {
    this.spinner.show();
    console.log("---vaalaa", this.serviceRequest.utility_id);
    let json = {
      utility_id: this.serviceRequest.utility_id,
      subUtility_id: this.serviceRequest.subUtility_id,
    };

    this.commonService.getOptions(json).subscribe(
      (response) => {
        console.log("---getOptions----", response);
        this.options = response.data;
        if (this.options.length > 0) {
          this.serviceRequest.service_type_id = this.options[0].service_type_id;
        }
        this.spinner.hide();
      },
      (err) => {
        this.spinner.hide();
        this.commonService.handleError(err);
      }
    );
  }

  calculateCost(eventVal: any, eventField) {
    this.finalCost = 0;
    if (eventField == "startTime") {
      this.serviceRequest.time = eventVal;
    }

    if (eventField == "endTime") {
      this.serviceRequest.etime = eventVal;
    }

    for (let i = 0; i < this.options.length; i++) {
      if (
        this.options[i].id == this.serviceRequest.utility_service_sub_type_id
      ) {
        this.optionCost = this.options[i].flat_rate;
        this.optionType = this.options[i].hourly_rate;
      }
    }

    if (this.optionType != "Hourly") {
      this.finalCost = this.optionCost;
    }

    if (this.serviceRequest.utility_service_sub_type_id == "") {
      this.toastr.error("Please select service option", "Error");
      return false;
    }

    console.log(
      "==this.serviceRequest",
      this.serviceRequest.time,
      this.serviceRequest.etime
    );
    if (!this.serviceRequest.time) {
      this.toastr.error("Please select start time", "Error");
      return false;
    }

    if (!this.serviceRequest.etime) {
      this.toastr.error("Please select end time", "Error");
      return false;
    }

    var sTime = this.serviceRequest.time;
    var eTime = this.serviceRequest.etime;
    if (
      sTime != undefined &&
      eTime != undefined &&
      sTime != null &&
      eTime != null
    ) {
      let startTime = moment(
        moment(this.serviceRequest.date).format("YYYY-MM-DD") +
          " " +
          moment(sTime, "hh:mm A").format("HH:mm:ss")
      );

      let endTime = moment(
        moment(this.serviceRequest.date).format("YYYY-MM-DD") +
          " " +
          moment(eTime, "hh:mm A").format("HH:mm:ss")
      );

      var duration = moment.duration(endTime.diff(startTime));
      this.hours = duration.hours();
      var minutes = duration.minutes();
      if (minutes == 30) {
        this.hours = this.hours + 0.5;
      }
      if (this.hours <= 0) {
        this.toastr.error(
          "Please select valid service Start and End time",
          "Error"
        );
        //this.finalSubmitbtn=false;
      } else {
        if (this.optionType == "Hourly") {
          this.finalCost = this.optionCost * this.hours;
        }
      }
    }
    if (isNaN(this.finalCost)) {
      this.finalCost = 0;
    }

    this.getServiceProviders();
  }

  getServices() {
    this.spinner.show();
    this.serviceRequestService.getServices("").subscribe(
      (response) => {
        this.customerService.getCustomerDetail(this.customerID).subscribe(
          (result) => {
            this.customerName = result.data;
            this.serviceList = response.data;
            console.log("-----------nnn-----", this.serviceList);
            this.spinner.hide();
          },
          (err) => {
            this.spinner.hide();
            this.commonService.handleError(err);
          }
        );
      },
      (err) => {
        this.spinner.hide();
        this.commonService.handleError(err);
      }
    );
  }

  getServiceProviders() {
    console.log("==-=this.serviceRequest-==-", this.serviceRequest.time);
    console.log("==-=this.serviceRequest-==-", this.serviceRequest.etime);
    console.log("==-=this.serviceRequest-==-", this.serviceRequest.date);

    if (
      this.serviceRequest.date &&
      this.serviceRequest.time &&
      this.serviceRequest.etime
    ) {
      let dt = moment(this.serviceRequest.date, "YYYY-MM-DD HH:mm:ss");
      let json = {
        day_index: dt.format("dddd"),
        service_id: this.serviceRequest.service_type_id,
        AvailableFrom:
          moment(this.serviceRequest.time, "hh:mm A").format("HH") +
          ":" +
          moment(this.serviceRequest.time, "hh:mm A").format("mm") +
          ":" +
          moment(this.serviceRequest.time, "hh:mm A").format("ss"),
        AvailableTo:
          moment(this.serviceRequest.etime, "hh:mm A").format("HH") +
          ":" +
          moment(this.serviceRequest.etime, "hh:mm A").format("mm") +
          ":" +
          moment(this.serviceRequest.etime, "hh:mm A").format("ss"),
        reqDate: moment(this.serviceRequest.date, "YYYY-MM-DD"),
      };
      console.log("-----------------------", json);
      this.serviceRequestService.getServiceProviders(json).subscribe(
        (response) => {
          this.providerList = response.data;
          this.serviceRequest.service_provider_id = "";
        },
        (err) => {
          this.spinner.hide();
          this.commonService.handleError(err);
        }
      );
    } else {
      this.toastr.info(
        "Please select service, date and full time to get the list of available service providers",
        "Info"
      );
    }
  }

  save() {
    if (
      this.isToday(this.serviceRequest.date) &&
      this.serviceRequest["time"].hour <= new Date().getHours() &&
      this.serviceRequest["time"].minute <= new Date().getMinutes()
    ) {
      this.toastr.warning("Date and Time Should be of Future only", "Warning");
    } else {
      this.spinner.show();
      let json = {
        date: moment(this.serviceRequest.date).format("YYYY-MM-DD"),
        time: moment(this.serviceRequest["time"], "hh:ii A").format("HH:mm:ss"),
        etime: moment(this.serviceRequest["etime"], "hh:ii A").format(
          "HH:mm:ss"
        ),

        service_type_id: this.serviceRequest.service_type_id,
        utility_id: this.serviceRequest.utility_id,
        subUtility_id: this.serviceRequest.subUtility_id,
        utility_service_sub_type_id: this.serviceRequest
          .utility_service_sub_type_id,
        customer_id: atob(this.customerID),
        service_provider_id: this.serviceRequest.service_provider_id,
        cost: this.finalCost,
        provider_note: this.serviceRequest.provider_note,
        customer_note: this.serviceRequest.customer_note,
        customer_full_name:
          this.customerName.first_name + " " + this.customerName.last_name,
        customer_email: this.customerName.email,
        admin_email: JSON.parse(this._cookieservice.get("token")).email,
        admin_full_name:
          JSON.parse(this._cookieservice.get("token")).first_name +
          " " +
          JSON.parse(this._cookieservice.get("token")).last_name,
      };

      this.serviceRequestService.createServiceRequest(json).subscribe(
        (response) => {
          this.spinner.hide();
          this.toastr.success("Service Request added successfully", "Success");
          this.router.navigate(["/utility/manageServiceRequests"]);
        },
        (err) => {
          this.spinner.hide();
          this.commonService.handleError(err);
        }
      );
    }
  }

  isToday(someDate) {
    const checkDate = new Date(someDate);
    const today = new Date();
    return (
      checkDate.getDate() == today.getDate() &&
      checkDate.getMonth() == today.getMonth() &&
      checkDate.getFullYear() == today.getFullYear()
    );
  }
}
