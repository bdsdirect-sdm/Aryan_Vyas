import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from '../../../utility/services/common.service';
import { SuperAdminUtilityProviderService } from '../../../services/superAdmin/admin-utilityProvider.service';
import { CookieService } from 'ngx-cookie';
import { environment } from '../../../../environments/environment';
import { Address } from 'ngx-google-places-autocomplete/objects/address';
import { GooglePlaceDirective } from 'ngx-google-places-autocomplete';
import { SuperAdminUtilityService } from '../../../services/superAdmin/admin-utility.service';
import * as moment from 'moment';

@Component({
  selector: 'profile-edit',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class profileComponent implements OnInit {
  @ViewChild("placesRef") placesRef: GooglePlaceDirective;
  modulesList: any = [];
  utilityProvider: any;
  moduleIds: any = [];
  imageUrl: string;
  profileImage: any;
  profileImageName: string | ArrayBuffer;
  utlityList: any;
  maxDate: Date;
  providerTypeList: { id: string; name: string; }[];
  idProofFrontName: any;
  idProofBackName: any;
  multipleFiles: any = [];
  allCategories: any;
  dataIds: any =[];
  loggedInUser: any;
  constructor(private adminService: SuperAdminUtilityProviderService, private spinner: NgxSpinnerService,
    private toastr: ToastrService, private router: Router, private superadminService: SuperAdminUtilityService,
    private commonService: CommonService, private activatedRoute: ActivatedRoute, private _cookieservice: CookieService) {
    this.utilityProvider = {};
    this.maxDate = new Date();
    this.imageUrl = environment.apiEndPoint + 'uploads/';
    this.providerTypeList = [{
      id: 'Company',
      name: 'Company'
    }, {
      id: 'Freelancer',
      name: 'Freelancer'
    }];

    this.loggedInUser = JSON.parse(this._cookieservice.get('token'));
    //console.log("----this.loggedInUser----",this.loggedInUser);
    this.loggedInUser.id=btoa(this.loggedInUser.id);
  }

  async ngOnInit() {
    this.getDetails();
    this.getAllModules();
    this.getUtilitiesList();
    this.commonService.notifyOther({ option: 'breadcrumbs', value: 'My Profile' });
  }

  getUtilitiesList() {
     this.superadminService.getProviderCategories(this.loggedInUser.id).subscribe(result => {
      this.utlityList = result.data;
      this.allCategories=  result.utilities

      this.dataIds = [];
          if (this.utlityList && this.utlityList.length > 0) {
            this.utlityList.forEach(obj => {
              this.allCategories.forEach(obj2 => {
                if (obj.id == obj2.id) {
                  this.dataIds.push(obj2.id);
                }
              });
            });
          }

    }, err => {
      this.spinner.hide();
      this.commonService.handleSuperAdminError(err);
    });
  }

  getAllModules() {
    this.adminService.getAllModules().subscribe(result => {
      this.modulesList = result;
      result.forEach(element => {
        this.moduleIds.push(element.id)
      });
    }, err => {
      this.spinner.hide();
      this.commonService.handleSuperAdminError(err);
    });

  }

  getDetails() {
    this.spinner.show();
    this.adminService.getDetails(this.loggedInUser.id).subscribe(result => {
      this.utilityProvider = result.data.user[0];
      this.profileImageName = this.imageUrl + result.data.user[0].logo
      this.spinner.hide();
    }, err => {
      this.spinner.hide();
      this.commonService.handleSuperAdminError(err);
    });

  }

  handleAddressChange(place: Address) {
    this.spinner.show();
    const location_obj = {};
    location_obj['lat'] = (place.geometry && place.geometry.location && place.geometry.location.lat()) ? place.geometry.location.lat() : '';
    location_obj['lng'] = (place.geometry && place.geometry.location && place.geometry.location.lng()) ? place.geometry.location.lng() : '';
    for (const i in place.address_components) {
      const item = place.address_components[i];
      location_obj['formatted_address'] = place.formatted_address;
      location_obj['full_address'] = place.name + ', ' + place.formatted_address;
      if ((item.types.indexOf('locality') > -1) || (item.types.indexOf('sublocality_level_1') > -1) || (item.types.indexOf('administrative_area_level_2') > -1)) {
        location_obj['city'] = item.long_name;
      } else if (item.types.indexOf('administrative_area_level_1') > -1) {
        location_obj['state'] = item.long_name;
      } else if (item.types.indexOf('street_number') > -1) {
        location_obj['street_number'] = item.short_name;
      } else if (item.types.indexOf('route') > -1) {
        location_obj['route'] = item.long_name;
      } else if (item.types.indexOf('country') > -1) {
        location_obj['country'] = item.long_name;
      } else if (item.types.indexOf('postal_code') > -1) {
        location_obj['postal_code'] = item.short_name;
      }

    }
    this.utilityProvider['address'] = location_obj['formatted_address'];

    this.utilityProvider['city']=location_obj['city'];
    this.utilityProvider['state']=location_obj['state'];
    this.utilityProvider['country']=location_obj['country'];
    this.utilityProvider['zip']=location_obj['postal_code'];


    this.spinner.hide();
  }

  onUpload(event) {
    const allowedImageMimeTypes = [
      "image/jpeg",
      "image/png",
      "image/gif",
      "image/bmp",
      "image/jpg"
    ];
    if (event && event.target && event.target.files && event.target.files.length > 0) {
      if (allowedImageMimeTypes.indexOf(event.target.files[0].type) == -1) {
        this.toastr.error("Please upload an image with one of the following extensions : '.jpeg','.jpg','.gif','.png','.png','.bmp'", 'Error');
        return false;
      } else if (event.target.files[0].size > 5242880) {
        this.toastr.error("Too large image, Please upload profile image of size 5mb or less.", 'Error');
        return false;
      } else {
        event.target.files[0]['imageTypeName'] = 'logo';
        this.multipleFiles.push(event.target.files[0]);
        var mimeType = event.target.files[0].type;
        if (mimeType.match(/image\/*/) == null) {
          this.toastr.error('Please upload image only', 'Error');
          return;
        }
        var reader = new FileReader();
        reader.readAsDataURL(event.target.files[0]);
        reader.onload = (_event) => {
          this.profileImageName = reader.result;
        }
      }
    }
  }

  onIdUpload(event: any, title) {
    const allowedImageMimeTypes = [
      "image/jpeg",
      "image/png",
      "image/gif",
      "image/bmp",
      "image/jpg"
    ];
    if (event && event.target && event.target.files && event.target.files.length > 0) {
      if (allowedImageMimeTypes.indexOf(event.target.files[0].type) == -1) {
        this.toastr.error("Please upload an image with one of the following extensions : '.jpeg','.jpg','.gif','.png','.png','.bmp'", 'Error');
        return false;
      } else if (event.target.files[0].size > 5242880) {
        this.toastr.error("Too large image, Please upload profile image of size 5mb or less.", 'Error');
        return false;
      } else {
        if (title == 'front') {
          event.target.files[0]['imageTypeName'] = 'idfront';
          this.multipleFiles.push(event.target.files[0]);
          var mimeType = event.target.files[0].type;
          if (mimeType.match(/image\/*/) == null) {
            this.toastr.error('Please upload image only', 'Error');
            return;
          }
          var reader = new FileReader();
          reader.readAsDataURL(event.target.files[0]);
          reader.onload = (_event) => {
            this.idProofFrontName = reader.result;
          }
        }
        if (title == 'back') {
          event.target.files[0]['imageTypeName'] = 'idback';
          this.multipleFiles.push(event.target.files[0]);
          var mimeType = event.target.files[0].type;
          if (mimeType.match(/image\/*/) == null) {
            this.toastr.error('Please upload image only', 'Error');
            return;
          }
          var reader = new FileReader();
          reader.readAsDataURL(event.target.files[0]);
          reader.onload = (_event) => {
            this.idProofBackName = reader.result;
          }
        }
      }
    }
  }


  update() {
    const formdata = new FormData();
    this.spinner.show();
    delete this.utilityProvider.password;
    this.utilityProvider['module_id'] = this.moduleIds;
    this.utilityProvider['category_ids'] = this.dataIds;
    this.utilityProvider['first_name'] = this.commonService.titleCase(this.utilityProvider.first_name);
		this.utilityProvider['last_name'] = this.commonService.titleCase(this.utilityProvider.last_name);
    this.utilityProvider['dob'] = moment(this.utilityProvider.dob).format('YYYY-MM-DD');
    const files: Array<File> = this.multipleFiles;
    for (let i = 0; i < files.length; i++) {
      formdata.append("files[]", files[i], files[i]['imageTypeName']);
    }
    formdata.append('data', JSON.stringify(this.utilityProvider));

    this.adminService.update(formdata).subscribe(response => {
      this.spinner.hide();
      this.toastr.success('Utility providers edited successfully', 'Success');
    }, err => {
      this.spinner.hide();
      this.commonService.handleSuperAdminError(err);
    });
  }

}
