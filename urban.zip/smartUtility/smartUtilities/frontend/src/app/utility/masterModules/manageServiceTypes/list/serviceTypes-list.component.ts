import { Component, OnInit, TemplateRef } from '@angular/core';
import { serviceTypesService } from '../../../../utility/masterModules/services/serviceTypes.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import * as CryptoJS from 'crypto-js';
import { CommonService } from '../../../services/common.service';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { environment } from '../../../../../environments/environment';
@Component({
  selector: 'serviceTypes-list',
  templateUrl: './serviceTypes-list.component.html',
  styleUrls: ['./serviceTypes-list.component.css']
})
export class serviceTypesListComponent implements OnInit {
  modalRef: BsModalRef;
  utilityServiceTypes: any;
  currentServiceType = null;
  currentIndex = -1;
  title = '';
  action = null;
  dataIds: any = [];
  itemValue: any;
  showDropdown: any;
  selectedAll: boolean;
  checked: boolean=false;
  currency:string;
  environment:any=environment;
  recordsPerPage: unknown;
  defaultCurrency: any;
  constructor(private serviceTypesService: serviceTypesService, private spinner: NgxSpinnerService, private modalService: BsModalService,
    private toastr: ToastrService, private router: Router, private commonService: CommonService
  ) {
    this.showDropdown = false;
    this.selectedAll = false;
    this.currency=this.environment.currency;
  }

  ngOnInit() {
    this.getList();
    this.commonService.notifyOther({ option: 'breadcrumbs', value: 'Manage Service Types' });
  }

  async getList() {
    this.spinner.show();
    let inputJson = {};
    inputJson['page'] = 1;
    inputJson['limit'] = 10;
    inputJson['sort'] = { 'title': 'asc' };
    let superAdminSettings: any = await this.commonService.getSuperAdminDetails();
    this.recordsPerPage = superAdminSettings.records_per_page;
    this.defaultCurrency = superAdminSettings.default_currency;
    this.serviceTypesService.getAll(inputJson).subscribe(result => {
      console.log("--list data--", result)
      this.utilityServiceTypes = result;
      this.utilityServiceTypes.forEach((tmpObj, k) => {      
        this.utilityServiceTypes[k].id=btoa(this.utilityServiceTypes[k].id);
      });
      this.spinner.hide();
    }, err => {
      console.log("error from api");
    });
    this.title='';
  }

  deleteRow() {
    this.spinner.show();
    this.modalRef.hide();
    this.serviceTypesService.deleteSericeType(this.itemValue.id).subscribe(result => {
      this.getList();
      this.toastr.success('Service Type has been deleted successfully', 'Success');
    }, err => {
      console.log("error from api");
      this.toastr.error('Something went wrong', 'Error');
    });
  }


  refreshList() {
    this.getList();
    this.currentServiceType = null;
    this.currentIndex = -1;
  }

  unselectAll(){
    this.checked=false;
  }

  selectall(event) {
    if (event.target.checked) {
      const selectedIds = [];
      this.utilityServiceTypes.forEach(val => { selectedIds.push(val.id) });
      this.dataIds = selectedIds;
    } else {
      this.dataIds = [];
    }
  }

  changeStatus(itemID, action) {
    let data = {
      action: action,
      dataId: [itemID]
    };
    this.serviceTypesService.multiUpdate(data)
      .subscribe(
        response => {
          console.log("after save", response);
          this.toastr.success('Selected records have been ' + action + 'd successfully', 'Success');
          this.getList();

        },
        error => {
          this.toastr.error('Something went wrong', 'Error');
          console.log(error);
        });
  }

  multiUpdate() {
    if (this.dataIds.length > 0) {
      let data = {
        action: this.action,
        dataId: this.dataIds
      };

      this.serviceTypesService.multiUpdate(data)
        .subscribe(
          response => {
            console.log("after save", response);
            this.toastr.success('Selected records have been ' + this.action + 'ed successfully', 'Success');
            this.getList();

          },
          err => {
            this.spinner.hide();
            this.commonService.handleError(err);
          });
    }
    this.modalRef.hide();
  }

  searchTitle() {
    let keyword = this.title;
    this.serviceTypesService.findByTitle(keyword)
      .subscribe(
        data => {
          this.utilityServiceTypes = data;
          this.utilityServiceTypes.forEach((tmpObj, k) => {      
            this.utilityServiceTypes[k].id=btoa(this.utilityServiceTypes[k].id);
          });
          console.log(data);
        },
        err => {
          this.spinner.hide();
          this.commonService.handleError(err);
        });
  }

  openModal(template: TemplateRef<any>, data) {
    this.modalRef = this.modalService.show(template);
    this.itemValue = data;
  }

  openModalConfirm(template: TemplateRef<any>, data) {

    if (this.dataIds.length == 0) {
      this.toastr.error('Please select atleast one item', 'Error');
      return false;
    }
    this.modalRef = this.modalService.show(template);
    this.action = data;
    this.showDropdown = false;
  }

  closeModal() {
    this.modalRef.hide();
  }

  closeMultiModal() {
    this.modalRef.hide();
  }
  
  countCurrentPageRows() {
    let oRows = document.getElementById('tableBody').getElementsByTagName('tr');
    let iRowCount = oRows.length;
    return iRowCount;

  }
}
