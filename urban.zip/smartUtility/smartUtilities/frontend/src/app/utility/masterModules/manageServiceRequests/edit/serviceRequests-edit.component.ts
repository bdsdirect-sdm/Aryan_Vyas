import { Component, OnInit, TemplateRef } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { serviceRequestService } from '../../services/serviceRequests.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import * as _ from 'underscore';
import * as moment from 'moment';
import { CookieService } from 'ngx-cookie';
import { CommonService } from '../../../services/common.service';

@Component({
  selector: 'serviceRequests-edit-tutorial',
  templateUrl: './serviceRequests-edit.component.html',
  styleUrls: ['./serviceRequests-edit.component.css']
})
export class serviceRequestsEditComponent implements OnInit {
  serviceRequest: any;
  modalRef: BsModalRef;
  providerList: any;
  meridian: any = true;
  minuteStep = 30;
  timeValue: { hour: number; minute: number; second: number; };
  endTimeValue: { hour: number; minute: number; second: number; };
  bsValue: any;
  dateValue: string;
  minDate: Date;
  diff = 0;
  currentDatePassed: boolean;
  serviceProviderAligned: boolean;
  notes: string;
  finalCost:number=0;
	hours:number=0;
  optionCost=0; optionType='';
  verified=0;
  constructor(private serviceRequestService: serviceRequestService,private modalService: BsModalService, private spinner: NgxSpinnerService,
    private toastr: ToastrService, private router: Router,
    private _cookieservice: CookieService,
    private commonService: CommonService, private activatedRoute: ActivatedRoute) {
    this.serviceRequest = {};
    this.serviceRequest.service_provider_id = '';
    this.minDate = new Date();
    this.currentDatePassed = false;
    this.serviceProviderAligned = false;
  }

  ngOnInit() {
    this.getDetails();
    this.commonService.notifyOther({ option: 'breadcrumbs', value: 'Manage Service Requests' });
  }

  getDetails() {
    this.spinner.show();
    this.serviceRequestService.getServiceRequestDetail(this.activatedRoute.snapshot.params.id).subscribe(result => {
      this.serviceRequest = result.data;
      console.log("this.serviceRequest=",this.serviceRequest);
      this.finalCost=this.serviceRequest.cost;	
      let getStartTime = this.serviceRequest.time.split(':');
      this.timeValue = { hour: parseInt(getStartTime[0]), minute: parseInt(getStartTime[1]), second: 0 };

      let getEndTime = this.serviceRequest.etime.split(':');
      this.endTimeValue = { hour: parseInt(getEndTime[0]), minute: parseInt(getEndTime[1]), second: 0 };

      this.dateValue = moment(this.serviceRequest.date).format("DD-MM-YYYY HH:mm:ss");
      this.serviceRequest.date = moment(this.serviceRequest.date).format("YYYY-MM-DD");
      this.serviceRequest.time = moment(this.serviceRequest.time, ["HH:mm"]).format('h:mm A');
      this.serviceRequest.etime = moment(this.serviceRequest.etime, ["HH:mm"]).format('h:mm A');
      let currentdate = moment().utc();

      this.diff = currentdate.diff(moment(this.serviceRequest.date).utc(), 'days');
      if (this.diff > 0) {
        this.currentDatePassed = true;
        this.toastr.warning('Service Requested datetime has been passed.', 'Warning')
        this.getServiceProviders();
      } else {
        console.log('this.serviceRequest.service_provider_id', this.serviceRequest.service_provider_id == 0)
        if (this.serviceRequest.service_provider_id == 0) {
          this.serviceRequest.service_provider_id = '';
          this.getServiceProviders();
        } else {
          this.serviceProviderAligned = true;
        }
      }

      var sTime=this.serviceRequest.time;
		  var eTime=this.serviceRequest.etime;

      let startTime=moment(moment(this.serviceRequest.date).format("YYYY-MM-DD")+" "+moment(sTime,"hh:mm A").format("HH:mm:ss"));

				let endTime=moment(moment(this.serviceRequest.date).format("YYYY-MM-DD")+" "+moment(eTime,"hh:mm A").format("HH:mm:ss"));

				console.log("====startTime==",startTime);
				console.log("====endTime==",endTime);
				
				var duration = moment.duration(endTime.diff(startTime));
				this.hours = duration.hours();
				var minutes = duration.minutes();
				console.log("==duration----",duration,this.hours);
				if(minutes==30){
					this.hours = this.hours+0.5;
				}


      console.log('--------------------serviceRequest', this.serviceRequest)
      this.spinner.hide();
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
  }

  getServiceproviderList(eventVal,eventField){
   
    if(eventField=='startTime'){
      this.timeValue.hour=parseInt(moment(eventVal,"hh:mm A").format("HH"));
      this.timeValue.minute=parseInt(moment(eventVal,"hh:mm A").format("mm"));
      this.timeValue.second=parseInt(moment(eventVal,"hh:mm A").format("ss"));
		}

		if(eventField=='endTime'){
      this.endTimeValue.hour=parseInt(moment(eventVal,"hh:mm A").format("HH"));
      this.endTimeValue.minute=parseInt(moment(eventVal,"hh:mm A").format("mm"));
      this.endTimeValue.second=parseInt(moment(eventVal,"hh:mm A").format("ss"));
    }
    
    if(this.timeValue.hour > this.endTimeValue.hour){
      this.toastr.error('Please select valid time range', 'Error');
      return false;
    }

    if(this.timeValue.hour == this.endTimeValue.hour && this.timeValue.minute > this.endTimeValue.minute){
      this.toastr.error('Please select valid time range', 'Error');
      return false;
    }

    if(this.timeValue.hour == this.endTimeValue.hour && this.timeValue.minute == this.endTimeValue.minute){
      this.toastr.error('Please select valid time range', 'Error');
      return false;
    }


    this.calculateCost(eventVal,eventField)



    this.getServiceProviders();

  }

  calculateCost(eventVal:any,eventField){
		if(eventField=='startTime'){
			this.serviceRequest.time=eventVal;
		}

		if(eventField=='endTime'){
			this.serviceRequest.etime=eventVal;
		}

		
    this.optionCost=this.serviceRequest.optionCost;
    this.optionType=this.serviceRequest.hourly_rate;
		

		if(this.optionType!='Hourly'){
			this.finalCost=this.optionCost;

		}

		if(this.serviceRequest.utility_service_sub_type_id==""){
			this.toastr.error('Please select service option', 'Error');
			return false;
		}
				

		console.log("this.serviceRequest.time=",this.serviceRequest.time);
		console.log("this.serviceRequest.etime=",this.serviceRequest.etime);
		var sTime=this.serviceRequest.time;
		var eTime=this.serviceRequest.etime;
		if(sTime!=undefined && eTime!=undefined && 
			sTime!=null && eTime!=null){

				let startTime=moment(moment(this.serviceRequest.date).format("YYYY-MM-DD")+" "+moment(sTime,"hh:mm A").format("HH:mm:ss"));

				let endTime=moment(moment(this.serviceRequest.date).format("YYYY-MM-DD")+" "+moment(eTime,"hh:mm A").format("HH:mm:ss"));

				console.log("====startTime==",startTime);
				console.log("====endTime==",endTime);
				
				var duration = moment.duration(endTime.diff(startTime));
				this.hours = duration.hours();
				var minutes = duration.minutes();
				console.log("==duration----",duration,this.hours);
				if(minutes==30){
					this.hours = this.hours+0.5;
				}
				if(this.hours<=0){
					this.toastr.error('Please select valid service Start and End time', 'Error');
					//this.finalSubmitbtn=false;

				}else{
					
					if(this.optionType=='Hourly'){
						this.finalCost=this.optionCost*this.hours;
					}
				
					
				}
				
			}
	}
 
  getServiceProviders() {
    let dt;
    dt = moment(this.serviceRequest.date, "YYYY-MM-DD HH:mm:ss");

    let json = {
      reqDate:this.serviceRequest.date,
      day_index: dt.format('dddd'),
      service_id: this.serviceRequest.service_type_id,
      AvailableFrom: this.timeValue.hour + ':' + this.timeValue.minute + ':' + this.timeValue.second,
      AvailableTo: this.endTimeValue.hour + ':' + this.endTimeValue.minute + ':' + this.endTimeValue.second,
      
    }
    console.log('json', json)
    this.serviceRequestService.getServiceProviders(json).subscribe(response => {
      console.log('getServiceProviders', response.data)
      this.providerList = response.data;
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });

  }

  update() {
   
    this.spinner.show();
    let json = {
      date: this.serviceRequest.date,
      id: this.serviceRequest.id,
      time: this.timeValue.hour + ':' + this.timeValue.minute + ':' + this.timeValue.second,
      etime: this.endTimeValue.hour + ':' + this.endTimeValue.minute + ':' + this.endTimeValue.second,
      customer_id: this.serviceRequest.customer_id,
      service_provider_id: this.serviceRequest.service_provider_id,
      provider_notes: this.serviceRequest.provider_notes,
      cost:this.finalCost
    }
    
    if(this.finalCost!=this.serviceRequest.cost){

    }
    this.serviceRequestService.updateServiceRequest(json).subscribe(response => {
      this.modalRef.hide();
      this.toastr.success('Service Request updated successfully', 'Success');
      this.router.navigate(['/utility/manageServiceRequests']);
      this.spinner.hide();
    }, err => {
      this.modalRef.hide();
      this.spinner.hide();
      this.commonService.handleError(err);
    });
  }

  declineRequest(){
    this.spinner.show();
    let data ={
      id:  this.activatedRoute.snapshot.params.id,
      notes:this.notes
    }
    this.serviceRequestService.updateRequestStatus(data).subscribe(result => {
      console.log('sssssssssssssssssssssss', result);
      this.modalRef.hide();
      this.toastr.success('Service Request declined successfully', 'Success');
      this.router.navigate(['/utility/manageServiceRequests']);

      this.spinner.hide();
    }, err => {
      this.modalRef.hide();
      this.spinner.hide();
      this.commonService.handleError(err);
    });
  }

  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }

  closeModal() {
    this.modalRef.hide();
  }

}
