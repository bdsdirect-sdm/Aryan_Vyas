import { Component, OnInit, TemplateRef } from '@angular/core';
import { serviceProvidersService } from '../../../../utility/masterModules/services/serviceProviders.service';
import { serviceTypesService } from '../../../../utility/masterModules/services/serviceTypes.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { HttpClient, HttpEventType } from '@angular/common/http';
import { environment } from '../../../../../environments/environment';
import { CommonService } from '../../../services/common.service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
@Component({
  selector: 'serviceProviders-edit-tutorial',
  templateUrl: './serviceProviders-edit.component.html',
  styleUrls: ['./serviceProviders-edit.component.css']
})
export class serviceProvidersEditComponent implements OnInit {
  utilityServiceProviders: any = {};

  modalRef: BsModalRef;
  utilityServiceTypes: any;
  responseServices: any = [];
  responseAvailability: any = [];
  mobNumberPattern = "^((\\+[0-999])|0)?[0-9]{10}$";
  dataIds: any = [];
  daysIds: any = [];
  baseUrl = "";
  checked = false;
  filePhotoStatus = false;
  fileProofStatus = false;
  experience: any = [];
  imageTypes: any = {

    "allowedMimeTypes": [
      "image/jpeg",
      "image/png",
      "image/gif",
      "image/bmp",
      "image/jpg"
    ],
  }
  days: any = {

    "availability": [
      {
        "day": "Monday",
        "day_short": "Mon",
        "day_index": 1,
        "timeFrom": { hour: "", minute: "" },
        "timeTo": { hour: "", minute: "" }
      },
      {
        "day": "Tuesday",
        "day_short": "Tue",
        "day_index": 2,
        "timeFrom": { hour: "", minute: "" },
        "timeTo": { hour: "", minute: "" }
      },
      {
        "day": "Wednesday",
        "day_short": "Wed",
        "day_index": 3,
        "timeFrom": { hour: "", minute: "" },
        "timeTo": { hour: "", minute: "" }
      },
      {
        "day": "Thursday",
        "day_short": "Thur",
        "day_index": 4,
        "timeFrom": { hour: "", minute: "" },
        "timeTo": { hour: "", minute: "" }
      },
      {
        "day": "Friday",
        "day_short": "Fri",
        "day_index": 5,
        "timeFrom": { hour: "", minute: "" },
        "timeTo": { hour: "", minute: "" }
      },
      {
        "day": "Saturday",
        "day_short": "Sat",
        "day_index": 6,
        "timeFrom": { hour: "", minute: "" },
        "timeTo": { hour: "", minute: "" }
      },
      {
        "day": "Sunday",
        "day_short": "Sun",
        "day_index": 7,
        "timeFrom": { hour: "", minute: "" },
        "timeTo": { hour: "", minute: "" }
      },
    ]
  }

  fileData: File = null;
  previewPhotoUrl: any = null;
  previewProofUrl: any = null;
  fileUploadProgress: string = null;
  uploadedFilePath: string = null;
  popImg; string = "";
  submitted = true;
  constructor(private modalService: BsModalService, private serviceTypesService: serviceTypesService, private route: ActivatedRoute,
    private commonService: CommonService, private toastr: ToastrService, private router: Router, private serviceProvidersService: serviceProvidersService, private spinner: NgxSpinnerService) {

    for (let i = 0; i <= 30; i++) {
      this.experience.push(i)
    }
    this.baseUrl = environment.apiEndPoint;
  }




  ngOnInit() {
    this.getServices();
    this.commonService.notifyOther({ option: 'breadcrumbs', value: 'Manage Service Providers' });

  }
  profilePhotoModal(template: TemplateRef<any>, photoField) {
    this.modalRef = this.modalService.show(template);
    if (photoField == 'photo') {
      this.popImg = this.baseUrl + '/uploads/' + this.utilityServiceProviders.photo;
    } else if (photoField == 'identityproof') {
      this.popImg = this.baseUrl + '/uploads/' + this.utilityServiceProviders.identityproof;
    } else {
      this.popImg = ""
    }
  }


  onlyUnique(value, index, self) {
    return self.indexOf(value) === index;
  }
  selectall() {

    if (this.days.availability.length == this.daysIds.length) {
      this.daysIds = [];
      this.days.availability.forEach(val => { val.timeFrom = "", val.timeTo = "" });
    } else {
      this.daysIds = [];
      this.days.availability.forEach(val => { this.daysIds.push(val.day) });
    }
  }

  getDetails() {

    this.serviceProvidersService.getDetails(this.route.snapshot.params.id)
      .subscribe(
        response => {

          this.utilityServiceProviders = response.result[0];
          
          if (response.result.length > 0) {
            for (let i = 0; i < response.result.length; i++) {
              this.responseServices.push(response.result[i].service_id);
            }
            this.responseServices = this.responseServices.filter(this.onlyUnique);
          }
          this.responseAvailability=response.avail;
         
          this.previewPhotoUrl = this.baseUrl + '/uploads/' + this.utilityServiceProviders.photo;

          this.previewProofUrl = this.baseUrl + '/uploads/' + this.utilityServiceProviders.identityproof;

          this.dataIds = [];
          if (this.responseServices && this.responseServices.length > 0) {
            this.responseServices.forEach(obj => {
              this.utilityServiceTypes.forEach(obj2 => {
                if (obj == obj2.id) {
                  this.dataIds.push(obj2.id);
                }
              });
            });
          }

          this.daysIds = [];
         

          if (this.responseAvailability && this.responseAvailability.length > 0) {
            this.responseAvailability.forEach(obj => {
              var counter = 0;
              this.days.availability.forEach(obj2 => {
                if (obj.day == obj2.day) {
                  this.daysIds.push(obj2.day);
                  if (obj.timeFrom) {
                    let fullTimeFrom = obj.timeFrom.split(":");
                    this.days.availability[counter].timeFrom = { hour: parseInt(fullTimeFrom[0]), minute: parseInt(fullTimeFrom[1]) };
                  }
                  if (obj.timeTo) {
                    let fullTimeTo = obj.timeTo.split(":");
                    this.days.availability[counter].timeTo = { hour: parseInt(fullTimeTo[0]), minute: parseInt(fullTimeTo[1]) };
                  }
                }
                counter++;
              });
            });
          }

          //console.log("=======this.days.availability=========", this.days.availability)
          this.spinner.hide();
        },
        err => {
          this.spinner.hide();
          this.commonService.handleError(err);

        });
  }

  getServices() {
    this.spinner.show();
    let inputJson = {};
    inputJson['page'] = 1;
    inputJson['limit'] = 100;
    inputJson['sort'] = { 'title': 'asc' };
    inputJson['is_active'] = 1;
    this.serviceTypesService.getAll(inputJson).subscribe(result => {

      this.utilityServiceTypes = result;
      this.getDetails();
      this.spinner.hide();
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
  }

  onUpload(file: any, fieldName) {
    this.fileData = file.target.files[0];
    var mimeType = this.fileData.type;
    if (mimeType.match(/image\/*/) == null) {
      this.toastr.error('Please upload image only', 'Error');
      return;
    }
    var reader = new FileReader();
    reader.readAsDataURL(this.fileData);
    reader.onload = (_event) => {
      if (fieldName == 'photo') {
        this.previewPhotoUrl = reader.result;
      } else {
        this.previewProofUrl = reader.result;
      }
      const formData = new FormData();
      formData.append('file', this.fileData);
      console.log("-=-=formData=-=-", formData);
      this.serviceProvidersService.uploadFile(formData).subscribe(events => {
        if (events.success) {
          console.log("---------------inside", events);
          if (fieldName == 'photo') {
            this.utilityServiceProviders.photo = events.data.filename;
            this.filePhotoStatus = true;
            this.submitted = true;
          } else {
            this.utilityServiceProviders.identityproof = events.data.filename;
            this.fileProofStatus = true;
            this.submitted = true;
          }
        }

      })

    }
  }


  previewAndUpload(event, fieldName) {
    (this.filePhotoStatus == true) ? true : false;
    (this.fileProofStatus == true) ? true : false;
    const allowedImageMimeTypes = this.imageTypes.allowedMimeTypes;
    if (event && event.target && event.target.files && event.target.files.length > 0) {
      if (allowedImageMimeTypes.indexOf(event.target.files[0].type) == -1) {
        this.toastr.error('Wrong file type', 'Error');
        this.submitted = false
        return false;
      } else if (event.target.files[0].size > 5242880) {
        this.toastr.error('Image size should not exceed 5MB', 'Error');
        this.submitted = false
        return false;
      } else {
        this.onUpload(event, fieldName)
      }
    }
  }
  unselectAll() {
    this.checked = false;

  }


  update() {
    if (this.filePhotoStatus == false && this.submitted == false) {
      this.toastr.error('Please upload correct profile photo', 'Error');
      return false;
    }
    if (this.fileProofStatus == false && this.submitted == false) {
      this.toastr.error('Please upload  correct ID proof photo', 'Error');
      return false;
    }
    this.spinner.hide();
    var userAvail = [];

    
    for (let i = 0; i < this.days.availability.length; i++) {

      for (let j = 0; j < this.daysIds.length; j++) {

        if (this.daysIds[j] == this.days.availability[i].day) {

          if (this.days.availability[i].timeFrom != null && this.days.availability[i].timeTo == null) {

            this.toastr.error('Please enter end time for ' + this.daysIds[j], 'Error');
            return false;

          } else if (this.days.availability[i].timeFrom == null && this.days.availability[i].timeTo != null) {

            this.toastr.error('Please enter start time for ' + this.daysIds[j], 'Error');
            return false;

          } else {

            if (this.days.availability[i].timeFrom.hour != "" && this.days.availability[i].timeFrom.hour >= 0 && this.days.availability[i].timeTo.hour == "") {
              this.toastr.error('Please enter end time for ' + this.daysIds[j], 'Error');
              return false;

            }

            if (this.days.availability[i].timeTo.hour != "" && this.days.availability[i].timeTo.hour >= 0 && this.days.availability[i].timeFrom.hour == "") {
              this.toastr.error('Please enter start time for ' + this.daysIds[j], 'Error');
              return false;
            }

            console.log("index is ==", userAvail.findIndex(x => x.day === this.daysIds[j]))
            if (userAvail.findIndex(x => x.day === this.daysIds[j]) < 0) {


              if (this.days.availability[i].timeFrom.hour == 'undefined') {
                userAvail.push({
                  day: this.daysIds[j],
                  timeFrom: ":",
                  timeTo: ":"
                });

              } else {

                if (this.days.availability[i].timeTo.minute > 0 && this.days.availability[i].timeFrom.minute > 0) {

                  let stime = this.days.availability[i].timeFrom.hour + "." + this.days.availability[i].timeFrom.minute;

                  let etime = this.days.availability[i].timeTo.hour + "." + this.days.availability[i].timeTo.minute;


                  if (parseFloat(etime) <= parseFloat(stime)) {
                    this.toastr.error('Time range is not valid for ' + this.daysIds[j], 'Error');
                    return false;

                  }
                }

                userAvail.push({
                  day: this.daysIds[j],
                  timeFrom: this.days.availability[i].timeFrom.hour + ":" + this.days.availability[i].timeFrom.minute,
                  timeTo: this.days.availability[i].timeTo.hour + ":" + this.days.availability[i].timeTo.minute
                });
              }
            }
          }
        }
      }
    }

    this.utilityServiceProviders['first_name'] = this.commonService.titleCase(this.utilityServiceProviders.first_name);
    this.utilityServiceProviders['last_name'] = this.commonService.titleCase(this.utilityServiceProviders.last_name);

    var data = {
      formdata: this.utilityServiceProviders,
      serviceTypes: this.dataIds,
      availability: userAvail
    }

    this.serviceProvidersService.update(data)
      .subscribe(
        response => {
          this.toastr.success('Service Type has been update successfully', 'Success');
          this.router.navigate(['/utility/manageServiceProviders']);
          this.spinner.hide();
        },
        err => {
          this.spinner.hide();
          this.commonService.handleError(err);
        });
  }



}
