
import { Injectable, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { environment } from '../../../../environments/environment';
import 'rxjs/add/operator/map';
import { CookieService } from 'ngx-cookie';

@Injectable({
  providedIn: 'root'
})
export class serviceRequestService {
  constructor(private http: HttpClient, public router: Router, private _cookieservice: CookieService, ) {

  }

  getHeaders() {
    let headerOption = environment.headerOption;
    if (this._cookieservice.get('token')) {
      const loggedInUtility = JSON.parse(this._cookieservice.get('token'));
      headerOption['Authorization'] = loggedInUtility.access_token;
    }
    const headers = new HttpHeaders(headerOption);
    const options = { headers };
    return options
  }

  getServiceRequestDetail(id) {

    return this.http.get(environment.apiEndPoint + 'utilityServiceRequest/edit/' + id, this.getHeaders()).map(res =>
      res as any);
  }

  serviceRequestHistory(id) {

    return this.http.get(environment.apiEndPoint + 'utilityServiceRequest/getServiceRequestHistory/' + id, this.getHeaders()).map(res =>
      res as any);
  }

  getAllServiceRequests(data) {

    return this.http.post(environment.apiEndPoint + 'utilityServiceRequest/list', data, this.getHeaders()).map(res =>
      res as any);
  }

   getAllServiceGroup(data) {

    return this.http.post(environment.apiEndPoint + 'utilityServiceRequest/getAllServiceGroup', data, this.getHeaders()).map(res =>
      res as any);
  }

  markJobDone(data) {

    return this.http.post(environment.apiEndPoint + 'utilityServiceRequest/markJobDone', data, this.getHeaders()).map(res =>
      res as any);
  }

  updateRequestStatus(data) {

    return this.http.post(environment.apiEndPoint + 'utilityServiceRequest/updateRequestStatus', data, this.getHeaders()).map(res =>
      res as any);
  }

  getIncidentList(id) {

    return this.http.get(environment.apiEndPoint + 'incident/incidentDetail/' + id, this.getHeaders()).map(res =>
      res as any);
  }

  listServiceStatus() {

    return this.http.get(environment.apiEndPoint + 'utilityServiceRequest/listServiceStatus' , this.getHeaders()).map(res =>
      res as any);
  }

  getServices(search) {

    return this.http.get(environment.apiEndPoint + 'utilityServiceRequest/getUtilityServiceTypes?keyword=' + search, this.getHeaders()).map(res =>
      res as any);
  }

  getServiceProviders(body) {

    return this.http.post(environment.apiEndPoint + 'utilityServiceRequest/getserviceProviders', body, this.getHeaders()).map(res =>
      res as any);
  }

  createServiceRequest(data) {

    return this.http.post(environment.apiEndPoint + 'utilityServiceRequest/add', data, this.getHeaders()).map(res => res as any);
  }

  updateServiceRequest(data) {

    return this.http.post(environment.apiEndPoint + 'utilityServiceRequest/update/' + data.id, data, this.getHeaders()).map(res => res as any);
  }


  multiUpdate(data) {

    return this.http.post(environment.apiEndPoint + 'utilityServiceRequest/activeInactiveDelete', data, this.getHeaders()).map(res => res as any);
  }

}
