import { Component, OnInit, TemplateRef } from '@angular/core';
import { FormGroup, Validators, NgForm } from "@angular/forms";
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { CookieService } from 'ngx-cookie';
import { SuperAdminService } from '../../services/superAdmin/admin.service';
import { CommonService } from '../../utility/services/common.service';

@Component({
  selector: 'superAdmin-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class superAdminloginComponent implements OnInit {
  admin: any;
  constructor(private activatedRoute: ActivatedRoute, private router: Router, private toastr: ToastrService,
    private spinner: NgxSpinnerService, private adminService: SuperAdminService,
    private _cookieservice: CookieService, private commonService: CommonService) {
    this.admin = {};
  }

  ngOnInit() {
    this._cookieservice.removeAll();
  }

  login(loginForm: NgForm) {
    this.adminService.adminLogin(this.admin).subscribe(result => {
      this.toastr.success('Welcome to the Super Admin Panel', 'Success');
      this.router.navigate(['/admin/dashboard']);
      this._cookieservice.put('admin-data', JSON.stringify(result.data[0]));
    }, err => {
      loginForm.resetForm();
      this.commonService.handleSuperAdminError(err);
    });

  }

}
