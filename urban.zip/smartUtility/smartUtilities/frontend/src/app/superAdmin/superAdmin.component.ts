import { Component, TemplateRef } from '@angular/core';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { CustomerService } from '../services/customers/customer.service';
import { CookieService } from 'ngx-cookie';
import { CommonService } from '../utility/services/common.service';

@Component({
  selector: 'superadmin-root',
  templateUrl: './superAdmin.component.html',
  styleUrls: ['./superAdmin.component.css']
})
export class superAdminComponent {
  title = 'frontend';
  modalRef: BsModalRef;
  active_link_name: any;

  constructor(private modalService: BsModalService, private commonService: CommonService,
    private router: Router, private toastr: ToastrService,
    private customerService: CustomerService, private _cookieservice: CookieService) {
    this.commonService.notifyObservable$.subscribe((res) => {
      if (res.hasOwnProperty('option') && res.option === 'breadcrumbs' && res.value !== undefined) {
        this.active_link_name = res.value;
      }
    });
  }



}
