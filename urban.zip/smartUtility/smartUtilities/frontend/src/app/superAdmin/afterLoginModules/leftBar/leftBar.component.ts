import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CookieService } from 'ngx-cookie';
import { ToastrService } from 'ngx-toastr';

@Component({
  selector: 'app-admin-sidebar',
  templateUrl: './leftBar.component.html',
  styleUrls: ['./leftBar.component.css']
})
export class AdminleftBarComponent implements OnInit {
  title = 'frontend';
  loggedInUser: any;
  sidebarList: any;
  currentRoter: any;

  constructor(private router: Router, private activatedRoute: ActivatedRoute,
    private _cookieservice: CookieService, private toastr: ToastrService) {
    // this.loggedInUser = JSON.parse(this._cookieservice.get('token'));
    // this.currentRoter = activatedRoute.snapshot.firstChild.url[0].path;
  }

  ngOnInit() {
   
  }


}
