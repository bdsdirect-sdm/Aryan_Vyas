

import { Component, OnInit } from "@angular/core";

import { ActivatedRoute, Params, Router } from "@angular/router";
import { CommonService } from "../../../utility/services/common.service";
import { UserIdleService } from "angular-user-idle";
import { CookieService } from "ngx-cookie";

@Component({
  selector: "dashboard-superadmin",
  templateUrl: "./dashboard.component.html",
  styleUrls: ["./dashboard.component.css"],
})
export class dashboardComponent implements OnInit {
  title = "frontend";
  constructor(
    private commonService: CommonService,
    private userIdle: UserIdleService,
    private router: Router,
    private _cookieservice: CookieService
  ) { }

  ngOnInit() {
    this.commonService.notifyOther({ option: "breadcrumbs", value: null });
    this.userIdle.startWatching();
    console.log("----");

    // Start watching when user idle is starting.
    this.userIdle.onTimerStart().subscribe((count) => console.log(count));

    // Start watch when time is up.
    this.userIdle.onTimeout().subscribe(() => this.logout());
  }

  logout() {
    this._cookieservice.removeAll();
    this.router.navigate(["/admin/login"]);
  }
}
