import { Component, OnInit, TemplateRef } from "@angular/core";
import { NgxSpinnerService } from "ngx-spinner";
import { BsModalService, BsModalRef } from "ngx-bootstrap/modal";
import { ToastrService } from "ngx-toastr";
import { ActivatedRoute, Params, Router } from "@angular/router";
import { CommonService } from "../../../../utility/services/common.service";
import { SuperAdminSubscriptionService } from "../../../../services/superAdmin/admin-subscription.service";

@Component({
  selector: "subscription-list",
  templateUrl: "./subscription-list.component.html",
  styleUrls: ["./subscription-list.component.css"],
})
export class subscriptionListComponent implements OnInit {
  modalRef: BsModalRef;
  subscriptionList: any;
  currentServiceProvider = null;
  currentIndex = -1;
  title = "";
  action = null;
  dataIds: any = [];
  itemValue: any;
  showDropdown: any;
  selectedAll: boolean;
  experience: any = [];
  checked = false;
  recordsPerPage: unknown;
  constructor(
    private adminService: SuperAdminSubscriptionService,
    private spinner: NgxSpinnerService,
    private modalService: BsModalService,
    private toastr: ToastrService,
    private router: Router,
    private commonService: CommonService
  ) {
    this.showDropdown = false;
    this.selectedAll = false;
    for (let i = 0; i <= 50; i++) {
      this.experience.push(i);
    }
  }

  ngOnInit() {
    this.getList();
    this.commonService.notifyOther({
      option: "breadcrumbs",
      value: "Manage Subscriptions",
    });
  }

  async getList() {
    this.spinner.show();
    let superAdminSettings: any = await this.commonService.getSuperAdminDetails();
    this.recordsPerPage = superAdminSettings.records_per_page;
    this.adminService.getAll("").subscribe(
      (result) => {
        this.subscriptionList = result.data;
        this.dataIds = [];
        this.subscriptionList.forEach((tmpObj, k) => {
          this.subscriptionList[k].id = btoa(this.subscriptionList[k].id);
        });
        this.spinner.hide();
      },
      (err) => {
        this.spinner.hide();
        this.commonService.handleSuperAdminError(err);
      }
    );
  }

  multiUpdate() {
    if (this.dataIds.length > 0) {
      this.spinner.show();
      let data = {
        action: this.action,
        dataId: this.dataIds,
      };
      this.adminService.multiUpdate(data).subscribe(
        (response) => {
          this.getList();
          this.modalRef.hide();
          this.spinner.hide();
          this.showDropdown = false;
          this.toastr.success(
            "Selected records have been " + this.action + "ed successfully",
            "Success"
          );
        },
        (err) => {
          this.spinner.hide();
          this.commonService.handleError(err);
        }
      );
    } else {
      this.toastr.info("Please select an record first", "Info");
      this.modalRef.hide();
    }
  }

  searchTitle() {
    this.spinner.show();
    this.adminService.getAll(this.title).subscribe(
      (result) => {
        this.subscriptionList = result["data"];
        this.subscriptionList.forEach((tmpObj, k) => {
          this.subscriptionList[k].id = btoa(this.subscriptionList[k].id);
        });
        this.spinner.hide();
      },
      (err) => {
        this.spinner.hide();
        this.commonService.handleError(err);
      }
    );
  }

  openModal(template: TemplateRef<any>, data, action) {
    this.itemValue = data;
    if (this.dataIds.length === 0 && data === "") {
      alert("Kindly select at least one row for this action");
      return;
    }

    this.modalRef = this.modalService.show(template);
    this.action = action;
  }

  closeModal() {
    this.modalRef.hide();
  }

  changeStatusDelete() {
    this.spinner.show();
    let data = {
      action: this.action,
      dataId: [this.itemValue.id],
    };
    this.adminService.multiUpdate(data).subscribe(
      (response) => {
        this.getList();
        this.modalRef.hide();
        this.spinner.hide();
        this.showDropdown = false;
        this.toastr.success(
          "Record " + this.action + "ed successfully",
          "Success"
        );
      },
      (err) => {
        this.spinner.hide();
        this.commonService.handleSuperAdminError(err);
      }
    );
  }

  selectall(event) {
    if (event.target.checked) {
      const selectedIds = [];
      this.subscriptionList.forEach((val) => {
        selectedIds.push(val.id);
      });
      this.dataIds = selectedIds;
      const filterIds = [];
      setTimeout(() => {
        this.dataIds.forEach((val) => {
          const checkBoxElement = document.getElementById("chkin" + val) as any;
          if (checkBoxElement !== null) {
            if (checkBoxElement.checked === true) {
              console.log(checkBoxElement.checked);
              filterIds.push(val);
            }
          }
        });
        this.dataIds = filterIds;
      }, 500);
    } else {
      this.dataIds = [];
    }
  }

  searchOnEnter(keyCode) {
    if (keyCode === 13) {
      this.searchTitle();
    }
  }

  unselectAll() {
    console.log(this.dataIds);

    this.checked = false;
  }

  pageChange(event) {
    console.log(event);
  }
}
