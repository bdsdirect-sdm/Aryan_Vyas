import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { SuperAdminUtilityService } from '../../../../services/superAdmin/admin-utility.service';
import { CommonService } from '../../../../utility/services/common.service';

@Component({
  selector: 'utility-add-tutorial',
  templateUrl: './utility-add.component.html',
  styleUrls: ['./utility-add.component.css']
})
export class utilityAddComponent implements OnInit {
  utility: any;
  mainCategories: any = [];
  subCategories: any =[];
  subCategoriestitle:string="";
  constructor(private adminService: SuperAdminUtilityService, private spinner: NgxSpinnerService,
    private toastr: ToastrService, private router: Router, private commonService: CommonService) {
    this.utility = {};
  }

  async ngOnInit() {
    this.commonService.notifyOther({ option: 'breadcrumbs', value: 'Manage Categories' });

  }

  addSubCategory(){
    if (this.subCategories.indexOf(this.subCategoriestitle) >= 0) {
      this.toastr.error(this.subCategoriestitle + ' already exists in sub category list', 'Error');
      return false;
    }

    if (this.utility.title==this.subCategoriestitle) {
      this.toastr.error('Sub category  name can not be same as main category name', 'Error');
      return false;
    }
    this.subCategories.push(
      this.subCategoriestitle
    );
    this.subCategoriestitle = "";
  }

  removeSubCat(subServiceVal){

    this.subCategories = this.subCategories.filter(e => e !== subServiceVal);
  }

  save() {
    if(/^\d+$/.test(this.utility.title)===true){
      this.toastr.error('Title must have alphabets', 'Error');
      return false;
    }
    if(/^\d+$/.test(this.utility.description)===true){
      this.toastr.error('Description must have alphabets', 'Error');
      return false;
    }
    
    this.spinner.show();
    this.utility['title'] = this.commonService.titleCase(this.utility.title);
    this.utility['subCategories'] =this.subCategories;
    this.adminService.create(this.utility).subscribe(response => {
      this.spinner.hide();
      this.toastr.success('Utility added successfully', 'Success');
      this.router.navigate(['/admin/utility']);
    }, err => {
      this.spinner.hide();
      this.commonService.handleSuperAdminError(err);
    });
  }

}
