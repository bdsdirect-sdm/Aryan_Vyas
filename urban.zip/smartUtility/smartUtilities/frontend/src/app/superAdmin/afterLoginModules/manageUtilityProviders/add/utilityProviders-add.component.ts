import { Component, OnInit, ViewChild } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { SuperAdminUtilityProviderService } from '../../../../services/superAdmin/admin-utilityProvider.service';
import { CommonService } from '../../../../utility/services/common.service';
import { GooglePlaceDirective } from 'ngx-google-places-autocomplete';
import { Address } from 'ngx-google-places-autocomplete/objects/address';
import * as moment from 'moment';
import { SuperAdminUtilityService } from '../../../../services/superAdmin/admin-utility.service';

@Component({
  selector: 'utilityProviders-add-tutorial',
  templateUrl: './utilityProviders-add.component.html',
  styleUrls: ['./utilityProviders-add.component.css']
})
export class utilityProvidersAddComponent implements OnInit {
  @ViewChild("placesRef") placesRef: GooglePlaceDirective;
  utilityProvider: any;
  providerTypeList: any;
  profileImageName: any;
  moduleIds: any = [];
  multipleFiles: any = [];
  modulesList: any;
  maxDate: Date;
  utlityList: any;
  idProofFrontName: any;
  idProofBackName: any;
  allCategories: any;
  dataIds: any =[];
  constructor(private adminService: SuperAdminUtilityProviderService, private spinner: NgxSpinnerService,
    private toastr: ToastrService, private router: Router, private superadminService: SuperAdminUtilityService,
    private commonService: CommonService) {
    this.utilityProvider = {};
    this.utilityProvider.provider_type = '';
    this.maxDate = new Date();
    this.providerTypeList = [{
      id: 'Company',
      name: 'Company'
    }, {
      id: 'Freelancer',
      name: 'Freelancer'
    }]
  }

  ngOnInit() {
    this.commonService.notifyOther({ option: 'breadcrumbs', value: 'Manage Utility Providers' });
    this.getAllModules();
    this.getUtilitiesList();
  }

  getUtilitiesList() {
    this.superadminService.getProviderCategories(0).subscribe(result => {
     this.allCategories=  result.data;   

   }, err => {
     this.spinner.hide();
     this.commonService.handleSuperAdminError(err);
   });
 }
  getAllModules() {
    this.spinner.show();
    this.adminService.getAllModules().subscribe(result => {
      this.modulesList = result;
      result.forEach(element => {
        this.moduleIds.push(element.id)
      });
      this.spinner.hide();
    }, err => {
      this.spinner.hide();
      this.commonService.handleSuperAdminError(err);
    });

  }

  handleAddressChange(place: Address) {
    this.spinner.show();
    const location_obj = {};
    location_obj['lat'] = (place.geometry && place.geometry.location && place.geometry.location.lat()) ? place.geometry.location.lat() : '';
    location_obj['lng'] = (place.geometry && place.geometry.location && place.geometry.location.lng()) ? place.geometry.location.lng() : '';
    console.log("----place.address_components---",place.address_components);
    for (const i in place.address_components) {
      const item = place.address_components[i];
      location_obj['formatted_address'] = place.formatted_address;
      location_obj['full_address'] = place.name + ', ' + place.formatted_address;
      if ((item.types.indexOf('locality') > -1) || (item.types.indexOf('sublocality_level_1') > -1) || (item.types.indexOf('administrative_area_level_2') > -1)) {
        location_obj['city'] = item.long_name;
      } else if (item.types.indexOf('administrative_area_level_1') > -1) {
        location_obj['state'] = item.long_name;
      } else if (item.types.indexOf('street_number') > -1) {
        location_obj['street_number'] = item.short_name;
      } else if (item.types.indexOf('route') > -1) {
        location_obj['route'] = item.long_name;
      } else if (item.types.indexOf('country') > -1) {
        location_obj['country'] = item.long_name;
      } else if (item.types.indexOf('postal_code') > -1) {
        location_obj['postal_code'] = item.short_name;
      }

    }
    this.utilityProvider['address'] = location_obj['formatted_address'];
    this.utilityProvider['city'] = location_obj['city'];
    this.utilityProvider['state'] = location_obj['state'];
    this.utilityProvider['country'] = location_obj['country'];
    this.utilityProvider['zip'] = location_obj['postal_code'];
    this.spinner.hide();
  }


  save() {
    const formdata = new FormData();
    this.spinner.show();
    this.utilityProvider['module_id'] = this.moduleIds;
    this.utilityProvider['category_id'] = this.dataIds;
    this.utilityProvider['first_name'] = this.commonService.titleCase(this.utilityProvider.first_name);
		this.utilityProvider['last_name'] = this.commonService.titleCase(this.utilityProvider.last_name);
		this.utilityProvider['dob'] = moment(this.utilityProvider.dob).format('YYYY-MM-DD');
    const files: Array<File> = this.multipleFiles;
    for (let i = 0; i < files.length; i++) {
      formdata.append("files[]", files[i], files[i]['imageTypeName']);
    }
    formdata.append('data', JSON.stringify(this.utilityProvider));
    this.adminService.create(formdata).subscribe(response => {
      this.spinner.hide();
      this.toastr.success('Utility Provider added successfully', 'Success');
      this.router.navigate(['/admin/utilitiyProvider']);
    }, err => {
      this.spinner.hide();
      this.commonService.handleSuperAdminError(err);
    });
  }

  onUpload(event) {
    const allowedImageMimeTypes = [
      "image/jpeg",
      "image/png",
      "image/gif",
      "image/bmp",
      "image/jpg"
    ];
    if (event && event.target && event.target.files && event.target.files.length > 0) {
      if (allowedImageMimeTypes.indexOf(event.target.files[0].type) == -1) {
        this.toastr.error("Please upload an image with one of the following extensions : '.jpeg','.jpg','.gif','.png','.png','.bmp'", 'Error');
        return false;
      } else if (event.target.files[0].size > 5242880) {
        this.toastr.error("Too large image, Please upload profile image of size 5mb or less.", 'Error');
        return false;
      } else {
        event.target.files[0]['imageTypeName'] = 'logo';
        this.multipleFiles.push(event.target.files[0]);
        var mimeType = event.target.files[0].type;
        if (mimeType.match(/image\/*/) == null) {
          this.toastr.error('Please upload image only', 'Error');
          return;
        }
        var reader = new FileReader();
        reader.readAsDataURL(event.target.files[0]);
        reader.onload = (_event) => {
          this.profileImageName = reader.result;
        }
      }
    }
  }

  onIdUpload(event: any, title) {
    const allowedImageMimeTypes = [
      "image/jpeg",
      "image/png",
      "image/gif",
      "image/bmp",
      "image/jpg"
    ];
    if (event && event.target && event.target.files && event.target.files.length > 0) {
      if (allowedImageMimeTypes.indexOf(event.target.files[0].type) == -1) {
        this.toastr.error("Please upload an image with one of the following extensions : '.jpeg','.jpg','.gif','.png','.png','.bmp'", 'Error');
        return false;
      } else if (event.target.files[0].size > 5242880) {
        this.toastr.error("Too large image, Please upload profile image of size 5mb or less.", 'Error');
        return false;
      } else {
        if (title == 'front') {
          event.target.files[0]['imageTypeName'] = 'idfront';
          this.multipleFiles.push(event.target.files[0]);
          var mimeType = event.target.files[0].type;
          if (mimeType.match(/image\/*/) == null) {
            this.toastr.error('Please upload image only', 'Error');
            return;
          }
          var reader = new FileReader();
          reader.readAsDataURL(event.target.files[0]);
          reader.onload = (_event) => {
            this.idProofFrontName = reader.result;
          }
        }
        if (title == 'back') {
          event.target.files[0]['imageTypeName'] = 'idback';
          this.multipleFiles.push(event.target.files[0]);
          var mimeType = event.target.files[0].type;
          if (mimeType.match(/image\/*/) == null) {
            this.toastr.error('Please upload image only', 'Error');
            return;
          }
          var reader = new FileReader();
          reader.readAsDataURL(event.target.files[0]);
          reader.onload = (_event) => {
            this.idProofBackName = reader.result;
          }
        }
      }
    }
  }

}
