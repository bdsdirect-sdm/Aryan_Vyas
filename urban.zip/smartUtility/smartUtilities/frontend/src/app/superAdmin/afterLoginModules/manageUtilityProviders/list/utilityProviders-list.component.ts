import { Component, OnInit, TemplateRef } from '@angular/core';
import { NgxSpinnerService } from 'ngx-spinner';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import { ToastrService } from 'ngx-toastr';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { CommonService } from '../../../../utility/services/common.service';
import { SuperAdminUtilityProviderService } from '../../../../services/superAdmin/admin-utilityProvider.service';

@Component({
  selector: 'UtilityProviders-list',
  templateUrl: './utilityProviders-list.component.html',
  styleUrls: ['./utilityProviders-list.component.css']
})
export class utilityProvidersListComponent implements OnInit {
  modalRef: BsModalRef;
  utilityProviders: any;
  currentServiceProvider = null;
  currentIndex = -1;
  title = '';
  action = null;
  dataIds: any = [];
  itemValue: any;
  showDropdown: any;
  selectedAll: boolean;
  experience: any = [];
  checked = false;
  recordsPerPage: unknown;
  constructor(private adminService: SuperAdminUtilityProviderService, private spinner: NgxSpinnerService, private modalService: BsModalService,
    private toastr: ToastrService, private router: Router, private commonService: CommonService
  ) {
    this.showDropdown = false;
    this.selectedAll = false;
    for (let i = 0; i <= 50; i++) {
      this.experience.push(i);
    }
  }

  ngOnInit() {
    this.getList();
    this.commonService.notifyOther({ option: 'breadcrumbs', value: 'Manage Utility Providers' });
  }

  async getList() {
    this.spinner.show();
    let superAdminSettings: any = await this.commonService.getSuperAdminDetails();
    this.recordsPerPage = superAdminSettings.records_per_page;
    this.adminService.getAll('').subscribe(result => {
      console.log("--list data--", result)
      this.utilityProviders = result.data;

      this.utilityProviders.forEach((tmpObj, k) => {
        this.utilityProviders[k].id = btoa(this.utilityProviders[k].id);
      });
      this.spinner.hide();
    }, err => {
      this.spinner.hide();
      this.commonService.handleSuperAdminError(err);
    });
  }


  multiUpdate() {
    if (this.dataIds.length > 0) {
      this.spinner.show();
      let data = {
        action: this.action,
        dataId: this.dataIds
      };
      this.adminService.multiUpdate(data).subscribe(response => {
        this.getList();
        this.modalRef.hide();
        this.spinner.hide();
        this.showDropdown = false;
        this.toastr.success('Selected records have been ' + this.action + 'ed successfully', 'Success');
      }, err => {
        this.spinner.hide();
        this.commonService.handleError(err);
      });
    } else {
      this.toastr.info('Please select an record first', 'Info');
      this.modalRef.hide();
    }
  }

  searchTitle() {
    this.spinner.show();
    this.adminService.getAll(this.title).subscribe(result => {
      this.utilityProviders = result['data'];
      this.utilityProviders.forEach((tmpObj, k) => {
        this.utilityProviders[k].id = btoa(this.utilityProviders[k].id);
      });
      this.spinner.hide();
    }, err => {
      this.spinner.hide();
      this.commonService.handleError(err);
    });
  }

  searchOnEnter(keyCode) {

    if (keyCode === 13) {
      this.searchTitle();
    }

  }

  openModal(template: TemplateRef<any>, data, action) {
    this.itemValue = data;

    if (this.dataIds.length === 0 && data === '') {
      alert('Kindly select at least one row for this action');
      return;
    }

    this.modalRef = this.modalService.show(template);
    this.action = action;
  }

  closeModal() {
    this.modalRef.hide();
  }

  changeStatusDelete() {
    this.spinner.show();
    let data = {
      action: this.action,
      dataId: [this.itemValue.id]
    };
    this.adminService.multiUpdate(data).subscribe(response => {
      this.getList();
      this.modalRef.hide();
      this.spinner.hide();
      this.showDropdown = false;
      this.toastr.success('Record ' + this.action + 'ed successfully', 'Success');
    }, err => {
      this.spinner.hide();
      this.commonService.handleSuperAdminError(err);
    });
  }

  selectall(event) {
    if (event.target.checked) {
      const selectedIds = [];
      this.utilityProviders.forEach(val => { selectedIds.push(val.id) });
      this.dataIds = selectedIds;

      
      const filterIds = [];
      setTimeout(() => {
        this.dataIds.forEach(val => {
          const checkBoxElement = document.getElementById('chkin' + val) as any;
          if (checkBoxElement !== null) {
            if (checkBoxElement.checked === true) {
              console.log(checkBoxElement.checked)
              filterIds.push(val);
            }
          }
        });
        this.dataIds = filterIds;
      }, 500);


    } else {
      this.dataIds = [];
    }
  }

  unselectAll() {
    this.checked = false;
  }



}
