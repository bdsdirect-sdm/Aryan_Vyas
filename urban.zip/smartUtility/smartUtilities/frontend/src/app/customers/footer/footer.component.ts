import { Component, OnInit, TemplateRef } from '@angular/core';
import { environment } from '../../../environments/environment';
import { CustomerService } from '../../services/customers/customer.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from '../../utility/services/common.service';
import { Router } from '@angular/router';
import { CookieService } from 'ngx-cookie';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';

@Component({
	selector: 'customer-footer',
	templateUrl: './footer.component.html',
	styleUrls: [
		'./footer.component.scss'
	]
})
export class CustomerFooterComponent implements OnInit {


	constructor(private customerService: CustomerService, private spinner: NgxSpinnerService,
		private commonService: CommonService, private router: Router, private modalService: BsModalService,
		private toastr: ToastrService, private _cookieservice: CookieService,
	) {
		
	}

	ngOnInit() {
		
	}


}
