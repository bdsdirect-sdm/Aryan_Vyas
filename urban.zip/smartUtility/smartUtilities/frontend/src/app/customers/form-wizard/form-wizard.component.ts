import {
  Component,
  OnInit,
  TemplateRef,
  ViewChild,
  OnDestroy,
} from "@angular/core";
import * as moment from "moment";
import { environment } from "../../../environments/environment";
import { CustomerService } from "../../services/customers/customer.service";
import { NgxSpinnerService } from "ngx-spinner";
import { ToastrService } from "ngx-toastr";
import { CommonService } from "../../utility/services/common.service";
import { Router, ActivatedRoute } from "@angular/router";
import { CookieService } from "ngx-cookie";
import { BsModalService, BsModalRef } from "ngx-bootstrap/modal";
import { Address } from "ngx-google-places-autocomplete/objects/address";
import { GooglePlaceDirective } from "ngx-google-places-autocomplete";
import * as _ from "underscore";
import { serviceProvidersService } from "../../utility/masterModules/services/serviceProviders.service";

@Component({
  selector: "app-form-wizard",
  templateUrl: "./form-wizard.component.html",
  styleUrls: ["./form-wizard.component.scss", "../scss/app.scss"],
})
export class FormWizardComponent implements OnInit {
  @ViewChild("placesRef") placesRef: GooglePlaceDirective;
  modalRef: BsModalRef;
  searchedType: any;
  zipcode: any;
  searchedKeyword: string;
  utilityProviders: any = [];
  serviceRequest: any;
  minuteStep = 30;
  rating: any;
  minDate: Date;
  selectedProvider: any;
  customer: any;
  customerLogin: any;
  service_type_id: any;
  loggedInUser: any;
  subServiceTypeList: any;
  sub_type_title: any;
  environment: any = {};
  finalSubmitbtn = false;
  providerDetail: any;
  providerData: any = {};
  currentStep = 1;
  defaultCurrency: any;
  totalRecords = 0;
  thisProviderProfile: any;
  finalCost: number = 0;
  hours: number = 0;
  optionCost = 0;
  optionType = "";
  constructor(
    private modalService: BsModalService,
    private customerService: CustomerService,
    private spinner: NgxSpinnerService,
    private commonService: CommonService,
    private router: Router,
    private toastr: ToastrService,
    private activatedRoute: ActivatedRoute,
    private _cookieservice: CookieService,
    private serviceProvidersService: serviceProvidersService
  ) {
    this.environment = environment;
    this.minDate = new Date();
    this.customer = {};
    this.customerLogin = {};
    this.serviceRequest = {};
    this.serviceRequest.utility_service_sub_type_id = "";
    this.serviceRequest.date = new Date();
    this.serviceRequest.time = {
      hour: new Date().getHours() + 1,
      minute: 0,
      second: new Date().getSeconds(),
    };
    this.activatedRoute.params.subscribe((paramid) => {
      this.searchedType = paramid.searched;
      this.zipcode = paramid.zipcode;
    });
    if (this._cookieservice.get("searched-service-type")) {
      this.searchedKeyword = JSON.parse(
        this._cookieservice.get("searched-service-type")
      ).searchedKeyword;
      //this.service_type_id = JSON.parse(this._cookieservice.get('searched-service-type')).selectedServiceType;
    }
    if (this._cookieservice.get("customer-data")) {
      this.loggedInUser = JSON.parse(this._cookieservice.get("customer-data"));

      console.log("==this.loggedInUser ==", this.loggedInUser);
    }
  }

  ngOnInit() {
    this.spinner.show();
    this.getProvidersList();
  }

  calculateCost(eventVal: any, eventField) {
    if (eventField == "startTime") {
      this.serviceRequest.time = eventVal;
    }

    if (eventField == "endTime") {
      this.serviceRequest.etime = eventVal;
    }

    this.finalCost = 0;

    for (let i = 0; i < this.subServiceTypeList.length; i++) {
      if (
        this.subServiceTypeList[i].id ==
        this.serviceRequest.utility_service_sub_type_id
      ) {
        this.optionCost = this.subServiceTypeList[i].flat_rate;
        this.optionType = this.subServiceTypeList[i].hourly_rate;
      }
    }

    if (this.optionType != "Hourly") {
      this.finalCost = this.optionCost;
    }

    if (this.serviceRequest.utility_service_sub_type_id == "") {
      this.toastr.error("Please select service option", "Error");
      return false;
    }

    console.log("this.serviceRequest.time=", this.serviceRequest.time);
    console.log("this.serviceRequest.etime=", this.serviceRequest.etime);
    var sTime = this.serviceRequest.time;
    var eTime = this.serviceRequest.etime;
    if (
      sTime != undefined &&
      eTime != undefined &&
      sTime != null &&
      eTime != null
    ) {
      let startTime = moment(
        moment(this.serviceRequest.date).format("YYYY-MM-DD") +
          " " +
          moment(sTime, "hh:mm A").format("HH:mm:ss")
      );

      let endTime = moment(
        moment(this.serviceRequest.date).format("YYYY-MM-DD") +
          " " +
          moment(eTime, "hh:mm A").format("HH:mm:ss")
      );

      console.log("====startTime==", startTime);
      console.log("====endTime==", endTime);

      var duration = moment.duration(endTime.diff(startTime));
      this.hours = duration.hours();
      var minutes = duration.minutes();
      console.log("==duration----", duration, this.hours);
      if (minutes == 30) {
        this.hours = this.hours + 0.5;
      }
      if (this.hours <= 0) {
        this.toastr.error(
          "Please select valid service Start and End time",
          "Error"
        );
        this.finalSubmitbtn = false;
      } else {
        if (this.optionType == "Hourly") {
          this.finalCost = this.optionCost * this.hours;
        }
      }
    }
  }

  async getProvidersList() {
    let json = {
      keyword: this.searchedKeyword,
      service_title: this.searchedType,
      zipcode: this.zipcode,
    };

    let superAdminSettings: any = await this.commonService.getSuperAdminDetails();
    this.defaultCurrency = superAdminSettings.default_currency;

    this.customerService.listUtilityProviders(json).subscribe(
      (response) => {
        var obj = [];
        var temp = {};
        console.log("-----response.data---", response.data);
        this.totalRecords = response.data.length;

        _.each(response.data, (obj) => {
          obj["providerId"] = btoa(obj["providerId"]);
        });

        this.utilityProviders = _.groupBy(response.data, "utility_provider_id");

        console.log("-----utilityProviders---", this.utilityProviders);

        this.spinner.hide();
      },
      (err) => {
        this.spinner.hide();
        this.commonService.handleCustomerError(err);
      }
    );
  }

  selectProvider(item) {
    this.selectedProvider = item;
    this.service_type_id = item.id;
    this.customerService.listServiceSubTypes(item.id).subscribe(
      (response) => {
        console.log("---response.data", response.data);

        this.subServiceTypeList = response.data;
      },
      (err) => {
        this.spinner.hide();
        this.commonService.handleCustomerError(err);
      }
    );
    this.currentStep = 2;
  }

  login() {
    this.spinner.show();
    this._cookieservice.remove("customer-data");
    this.customerService.customerLogin(this.customerLogin).subscribe(
      (result) => {
        this.loggedInUser = result.data[0];
        this.commonService.notifyOther({
          option: "customer-header",
          value: JSON.stringify(result.data[0]),
        });
        this._cookieservice.put(
          "customer-data",
          JSON.stringify(result.data[0])
        );
        this.spinner.hide();
      },
      (err) => {
        this.spinner.hide();
        this.customerLogin = {};
        this.commonService.handleCustomerError(err);
        this.spinner.hide();
      }
    );
  }

  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }

  openProfileModal(template: TemplateRef<any>, provider) {
    console.log("===provider===raman  ", provider);
    this.spinner.show();
    this.thisProviderProfile = provider;
    this.serviceProvidersService
      .getProviderDetails(btoa(provider.utility_provider_id))
      .subscribe(
        (response) => {
          this.thisProviderProfile.details = _.uniq(response);
          console.log("---response---", response);
          this.spinner.hide();
        },
        (err) => {
          this.spinner.hide();
          this.commonService.handleError(err);
        }
      );
    this.modalRef = this.modalService.show(template);
  }
  openRegisterModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(
      template,
      Object.assign({}, { class: "gray modal-lg" })
    );
  }

  viewProviderDetail(template: TemplateRef<any>, prov) {
    console.log("---------prov--", prov);
    this.providerDetail = prov;
    this.modalRef = this.modalService.show(template);
  }

  closeModal() {
    this.modalRef.hide();
  }

  finalStepEnter(serviceRequest) {
    this.serviceRequest = serviceRequest;
    this.serviceRequest.address = this.loggedInUser.address;
    this.sub_type_title = _.find(this.subServiceTypeList, (o: any) => {
      o.id = parseInt(o.id);
      this.serviceRequest.utility_service_sub_type_id = parseInt(
        this.serviceRequest.utility_service_sub_type_id
      );
      return o.id === this.serviceRequest.utility_service_sub_type_id;
    });
  }

  finalSubmit() {
    this.spinner.show();
    this.finalSubmitbtn = true;
    let dt = moment(this.serviceRequest.date, "YYYY-MM-DD HH:mm:ss");

    //return false;
    let json = {
      date: dt.format("YYYY-MM-DD"),
      time: this.serviceRequest["time"],
      etime: this.serviceRequest["etime"],
      service_type_id: this.service_type_id,
      cost: this.finalCost,
      utility_provider_id: this.selectedProvider.utility_provider_id,
      customer_note: this.serviceRequest.note,
      utility_service_sub_type_id: this.serviceRequest
        .utility_service_sub_type_id,
      admin_email: this.selectedProvider.email,
      utility_id: this.selectedProvider.utility_id,
      subUtility_id: this.selectedProvider.subUtility_id,
      customer_full_name:
        JSON.parse(this._cookieservice.get("customer-data")).first_name +
        " " +
        JSON.parse(this._cookieservice.get("customer-data")).last_name,
      customer_email: JSON.parse(this._cookieservice.get("customer-data"))
        .email,
      admin_full_name:
        this.selectedProvider.first_name +
        " " +
        this.selectedProvider.last_name,
    };
    this.customerService.addServiceRequest(json).subscribe(
      (response) => {
        this.spinner.hide();
        this.modalRef.hide();
        this.toastr.success("Service Request added successfully.", "Success");
        this.finalSubmitbtn = false;
        this.router.navigate(["/service-request"]);
      },
      (err) => {
        this.finalSubmitbtn = false;
        this.spinner.hide();
        this.modalRef.hide();
        if (
          err &&
          err.status &&
          err.status == 403 &&
          err.statusText &&
          err.statusText == "Forbidden"
        ) {
          this._cookieservice.removeAll();
          this.loggedInUser = null;
          this.commonService.notifyOther({
            option: "customer-header",
            value: null,
          });
          this.toastr.error("Please Login again to proceed futher", "Error");
        } else if (err && err.error && err.error.msg) {
          this.toastr.error(err.error.msg, "Error");
        } else if (err && err.msg) {
          this.toastr.error(err.msg, "Error");
        } else {
          this.toastr.error("Something Went wrong. Please try again", "Error");
        }
      }
    );
  }

  openProfile(prov) {
    this.router.navigate(["/provider/view/" + prov]);
  }

  tConvert(timeObject) {
    if (timeObject.hour.toString().length < 2) {
      timeObject.hour = "0" + timeObject.hour;
    }
    if (timeObject.minute.toString().length < 2) {
      timeObject.minute = "0" + timeObject.minute;
    }
    if (timeObject.second.toString().length < 2) {
      timeObject.second = "0" + timeObject.second;
    }

    let time: any =
      timeObject.hour + ":" + timeObject.minute + ":" + timeObject.second;
    time = time
      .toString()
      .match(/^([01]\d|2[0-3])(:)([0-5]\d)(:[0-5]\d)?$/) || [time];

    if (time.length > 1) {
      time = time.slice(1);
      time[5] = +time[0] < 12 ? " AM" : " PM";
      time[0] = +time[0] % 12 || 12;
    }
    delete time[3];

    return time.join(""); // return adjusted time or original string
  }

  register() {
    this.spinner.show();
    this.customer["first_name"] = this.commonService.titleCase(
      this.customer.first_name
    );
    this.customer["last_name"] = this.commonService.titleCase(
      this.customer.last_name
    );
    this.customerService.createCustomer(this.customer).subscribe(
      (response) => {
        this.modalRef.hide();
        this.toastr.success("Customer Registered successfully", "Success");
        this.customerLogin["email"] = this.customer.email;
        this.customerLogin["password"] = this.customer.password;
        this.login();
      },
      (err) => {
        this.modalRef.hide();
        this.commonService.handleCustomerError(err);
        this.spinner.hide();
      }
    );
  }

  handleAddressChange(place: Address) {
    this.spinner.show();
    const location_obj = {};
    location_obj["lat"] =
      place.geometry && place.geometry.location && place.geometry.location.lat()
        ? place.geometry.location.lat()
        : "";
    location_obj["lng"] =
      place.geometry && place.geometry.location && place.geometry.location.lng()
        ? place.geometry.location.lng()
        : "";
    for (const i in place.address_components) {
      const item = place.address_components[i];
      location_obj["formatted_address"] = place.formatted_address;
      location_obj["full_address"] =
        place.name + ", " + place.formatted_address;
      if (
        item.types.indexOf("locality") > -1 ||
        item.types.indexOf("sublocality_level_1") > -1 ||
        item.types.indexOf("administrative_area_level_2") > -1
      ) {
        location_obj["city"] = item.long_name;
      } else if (item.types.indexOf("administrative_area_level_1") > -1) {
        location_obj["state"] = item.long_name;
      } else if (item.types.indexOf("street_number") > -1) {
        location_obj["street_number"] = item.short_name;
      } else if (item.types.indexOf("route") > -1) {
        location_obj["route"] = item.long_name;
      } else if (item.types.indexOf("country") > -1) {
        location_obj["country"] = item.long_name;
      } else if (item.types.indexOf("postal_code") > -1) {
        location_obj["postal_code"] = item.short_name;
      }
    }
    this.customer["city"] = location_obj["city"];
    this.customer["state"] = location_obj["state"];
    this.customer["country"] = location_obj["country"];
    this.customer["zip"] = location_obj["postal_code"];
    this.customer["address"] = location_obj["formatted_address"];
    this.spinner.hide();
  }
}
