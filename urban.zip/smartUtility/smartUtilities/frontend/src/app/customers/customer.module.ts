import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { CustomerRoutingModule } from './customer-routing.module';
import { AppSharedModule } from '../shared/app-shared.module';

import {NgxMaterialTimepickerModule} from 'ngx-material-timepicker';
import { customerComponent } from './customer.component';
import { HomeComponent } from './home/home.component';
import { providerProfileComponent } from './afterLoginModules/providerProfile/providerProfile.component';
import { customerserviceRequestsListComponent } from './afterLoginModules/serviceRequests/list/serviceRequests-list.component';
import { customerServiceRequestsViewComponent } from './afterLoginModules/serviceRequests/view/serviceRequests-view.component';
import { FormWizardComponent } from './form-wizard/form-wizard.component';
import { ArchwizardModule } from 'ng2-archwizard';
import { CustomerHeaderComponent } from './header/header.component';
import { CustomerFooterComponent } from './footer/footer.component';
import { BannerComponent } from './banner/banner.component';
import { FeatureSectionComponent } from './feature-section/feature-section.component';
import { CategoriesComponent } from './categories/categories.component';

@NgModule({ 
  declarations: [ 
    customerComponent,
    providerProfileComponent,
    customerserviceRequestsListComponent,
    customerServiceRequestsViewComponent,
    FormWizardComponent,
    HomeComponent,
    CustomerHeaderComponent,
    CustomerFooterComponent,
    BannerComponent,
    FeatureSectionComponent,
    CategoriesComponent
  ],
  imports: [
    AppSharedModule,
    BrowserModule,
    BrowserAnimationsModule,
    HttpClientModule,
    CustomerRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    NgxMaterialTimepickerModule,
    CommonModule,
    ArchwizardModule
  ],
  providers: [],
  bootstrap: []
})
export class customerModule { }
