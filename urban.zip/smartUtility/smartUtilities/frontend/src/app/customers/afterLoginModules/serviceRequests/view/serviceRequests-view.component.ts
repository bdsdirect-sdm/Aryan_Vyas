import { Component, OnInit, TemplateRef, ViewChild } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import * as moment from 'moment';
import { FormGroup, FormBuilder, Validators } from "@angular/forms";

import { environment } from '../../../../../environments/environment';
import { CookieService } from 'ngx-cookie';
import { CommonService } from '../../../../utility/services/common.service';
import * as _ from 'underscore';
import { CustomerService } from '../../../../services/customers/customer.service';
import { IncidentService } from '../../../../services/customers/incident.service';
import { PaymentService } from '../../../../services/customers/payment.service';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';

import { StripeService, Elements, Element as StripeElement, ElementsOptions } from "ngx-stripe";

@Component({
  selector: 'cust-serviceRequests-view-tutorial',
  templateUrl: './serviceRequests-view.component.html',
  styleUrls: [
    './serviceRequests-view.component.scss',
    '../../../scss/app.scss'
  ]
})
export class customerServiceRequestsViewComponent implements OnInit {
  serviceRequest: any;
  providerList: any;
  meridian: any = true;
  timeValue: { hour: number; minute: number; second: number; };
  requestId: any;
  incident: any = {};
  incidentDetail: any = {};
  loggedInUser: any;
  rating: any = {};
  currentRate: number = 0;
  ServiceRating: number = 0;
  modalRef: BsModalRef | null;
  modalRef2: BsModalRef;
  apiEndPoint = environment.apiEndPoint;
  currentStatus = 1;
  showPaynow = false;
  payment: any = {};
  cancelComments = "";
  elements: Elements;
  card: StripeElement;
  assignedProvider: any ={}
  // optional parameters
  elementsOptions: ElementsOptions = {
    locale: 'en'
  };

  recordsPerPage: unknown;
  date_format: any;
  time_format: any;
  providerId="";
  stripeTest: FormGroup;

  constructor(private customerService: CustomerService, private spinner: NgxSpinnerService, private toastr: ToastrService, private commonService: CommonService, private router: Router, private activatedRoute: ActivatedRoute, private modalService: BsModalService, private _cookieservice: CookieService, private incidentService: IncidentService, private paymentService: PaymentService, private fb: FormBuilder,
    private stripeService: StripeService) {
    this.serviceRequest = {};
    this.serviceRequest.service_provider_id = '';
    this.requestId = this.activatedRoute.snapshot.params.id;
    this.rating.service_request_id = this.requestId;
  }

  ngOnInit() {
    this.stripeTest = this.fb.group({
      name: ['', [Validators.required]],
      email: ['', [Validators.required]],
      phone: ['', [Validators.required]]
    });
    this.stripeService.elements(this.elementsOptions)
      .subscribe(elements => {
        this.elements = elements;
        // Only mount the element the first time
        if (!this.card) {
          this.card = this.elements.create('card', {
            style: {
              base: {
                iconColor: '#666EE8',
                color: '#31325F',
                lineHeight: '40px',
                fontWeight: 300,
                fontFamily: '"Helvetica Neue", Helvetica, sans-serif',
                fontSize: '18px',
                '::placeholder': {
                  color: '#CFD7E0'
                }
              }
            }
          });
          this.card.mount('#card-element');
        }
      });

    this.getDetails();
    this.getIncidentDetails();


  }

  payNow() {

    this.payment.requestId = this.requestId;

    const name = this.stripeTest.get('name').value;
    const email = this.stripeTest.get('email').value;
    const phone = this.stripeTest.get('phone').value;

    this.stripeService.createToken(this.card, { name })
      .subscribe(result => {
        if (result.token) {
          // Use the token to create a charge or a customer
          // https://stripe.com/docs/charges
          console.log("---result.token--", result.token);

          this.spinner.show();
          this.payment.name = name;
          this.payment.email = email;
          this.payment.phone = phone;
          this.payment.token = result.token;
          this.payment.service_provider_id=this.assignedProvider.id;
          this.payment.utilityProvider=this.serviceRequest.utility_provider_id;
          this.payment.utilityID=this.serviceRequest.utility_id;
          this.paymentService.payNow(this.payment).subscribe(response => {
            console.log("---response--", response);
            if (response.success) {
              if(this.modalRef) this.modalRef.hide();
              this.spinner.hide();
              this.currentStatus=5;
              this.toastr.success('Thank you for the payment!', 'Success');
            }
          }, err => {
            this.spinner.hide();
            this.commonService.handleCustomerError(err);
          });
        } else if (result.error) {
          this.toastr.error(result.error.message, 'Error');
          this.spinner.hide();
        }
      });


  }
  saveFeedback() {
    if (this.rating.rating == 0) {
      this.toastr.warning('Please select atleast one star', 'Warning');
      return false;
    }
    this.spinner.show();
    this.rating.utility_provider_id=this.serviceRequest.utility_provider_id;
    this.incidentService.saveFeedback(this.rating).subscribe(result => {

      if (result.success) {
        this.toastr.success('Thank you for the feedback!', 'Success');
        this.modalRef.hide();
        this.getDetails();
        this.spinner.hide();
        this.rating = {};
      }

    }, err => {
      this.spinner.hide();
      this.commonService.handleCustomerError(err);
    });

  }

  getIncidentDetails() {
    this.spinner.show();
    this.incidentService.incidentDetail(this.requestId).subscribe(result => {
      console.log("----incidentDetail=-==-", result);
      if (result.success) {
        this.incidentDetail = result.data;
        _.each(this.incidentDetail, obj => {
          obj['created_at'] = moment(obj['created_at']).format('YYYY-MM-DD hh:mm A');

        });
      }

    }, err => {
      this.spinner.hide();
      this.commonService.handleCustomerError(err);
    });

    this.incident = this.serviceRequest;


  }

  async getDetails() {
    this.spinner.show();
    let superAdminSettings: any = await this.commonService.getSuperAdminDetails();
    this.date_format = superAdminSettings.default_date_format;
    this.time_format = superAdminSettings.time_format;
    this.customerService.serviceRequestDetails(this.requestId).subscribe(result => {

      this.serviceRequest = result.data.details[0];
      console.log("----this.serviceRequest=-=-=", this.serviceRequest);
      this.providerId=btoa(this.serviceRequest.utility_provider_id);
      this.assignedProvider=result.data.assignedProvider[0];
      console.log("----this.assignedProvider=-=-=", this.assignedProvider);

      this.currentStatus = this.serviceRequest.current_status;
      this.serviceRequest.date = moment(this.serviceRequest.date).format(this.date_format);
      if (this.time_format == '12hours') {
        this.serviceRequest.time = moment(this.serviceRequest.time, ["HH:mm"]).format("h:mm A");
        this.serviceRequest.etime = moment(this.serviceRequest.etime, ["HH:mm"]).format("h:mm A");
      } else {
        this.serviceRequest.time = moment(this.serviceRequest.time, ["HH:mm"]).format("HH:mm");
        this.serviceRequest.etime= moment(this.serviceRequest.etime, ["HH:mm"]).format("HH:mm");
      }

      let servicedate = this.serviceRequest.date + "(" + this.serviceRequest.time + " to " + this.serviceRequest.etime+")";
      console.log("==--servicedate-=-this.currentStatus=", servicedate, this.currentStatus);
      this.serviceRequest.date = servicedate;
      this.spinner.hide();
    }, err => {
      this.spinner.hide();
      this.commonService.handleCustomerError(err);
    });

    this.incident = this.serviceRequest;


  }


  openIncidentModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template);
  }

  closeModal() {
    this.modalRef.hide();
  }


  cancelServiceRequest() {
    let providerId=0;
    if(this.assignedProvider){
      providerId=this.assignedProvider.id;
    }
    this.customerService.cancelServiceRequest({
      requestId: this.requestId, 
      cancelComments: this.cancelComments,
      providerId:providerId
    }).subscribe(result => {
      this.toastr.success('Service Request has been cancelled now!', 'Success');
      this.getDetails();
      this.modalRef.hide();
      this.spinner.hide();
    }, err => {
      this.commonService.handleCustomerError(err);
      this.spinner.hide();
    });

  }

  openModal(template: TemplateRef<any>) {
    this.modalRef = this.modalService.show(template, { class: 'feedback-modal-wrapper  common-modal-wrapper' });
  }
  openModal2(template: TemplateRef<any>) {
    this.modalRef2 = this.modalService.show(template, { class: 'feedback-modal-wrapper  common-modal-wrapper' });
  }
  closeFirstModal() {
    if (!this.modalRef) {
      return;
    }
 
    this.modalRef.hide();
    this.modalRef = null;
  }


  save() {

    if (this._cookieservice.get('customer-data')) {
      this.loggedInUser = JSON.parse(this._cookieservice.get('customer-data'));
    } else {
      this.toastr.warning('Please login to post an incident', 'Warning');
      this.router.navigate(['/home']);
    }
    this.spinner.show();
    let data = {
      incident: this.incident,
      serviceRequest: this.serviceRequest,
      requestId: this.requestId

    };
    this.incidentService.saveIncident(data).subscribe(result => {
      this.getIncidentDetails();
      this.toastr.success('Incident has been raised successfully', 'Success');
      this.modalRef.hide();
      this.spinner.hide();
    }, err => {
      this.commonService.handleCustomerError(err);
      this.spinner.hide();
    });
  }

}
