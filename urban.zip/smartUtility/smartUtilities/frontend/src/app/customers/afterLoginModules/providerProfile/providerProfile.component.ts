import { Component, OnInit, TemplateRef, ViewChild, OnDestroy } from '@angular/core';
import * as moment from 'moment';
import { environment } from '../../../../environments/environment';
import { CustomerService } from '../../../services/customers/customer.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from '../../../utility/services/common.service';
import { Router, ActivatedRoute } from '@angular/router';
import { CookieService } from 'ngx-cookie';
import { BsModalService, BsModalRef } from 'ngx-bootstrap/modal';
import * as _ from 'underscore';
import { serviceProvidersService } from '../../../utility/masterModules/services/serviceProviders.service';

@Component({
  selector: 'providerProfile-root',
  templateUrl: './providerProfile.component.html',
  styleUrls: ['./providerProfile.component.css']
})
export class providerProfileComponent implements OnInit {
  environment: any;
  providerId:any;
  myservices:any;
  recentServices: any;
  loggedInUser:any;
  data:any;
  constructor(private modalService: BsModalService, private customerService: CustomerService, private spinner: NgxSpinnerService,
		private commonService: CommonService, private router: Router,
		private toastr: ToastrService, private activatedRoute: ActivatedRoute,private serviceProvidersService: serviceProvidersService,
		private _cookieservice: CookieService
	) {
    this.environment = environment;
    this.activatedRoute.params.subscribe(paramid => {
      this.providerId = paramid.id;
      
      if (this._cookieservice.get('customer-data')) {
        this.loggedInUser = JSON.parse(this._cookieservice.get('customer-data'));
      }
      console.log("===loggedInUser==",this.loggedInUser);
		});
  }

  ngOnInit() {
    
    
    
    console.log("=====",this.loggedInUser);
    if(this.loggedInUser){
      this.getProvidersDetails();
    }

  }

  getProvidersDetails(){
    this.spinner.show();
    let id=this.providerId;
    this.serviceProvidersService.getProviderDetails(id).subscribe(response => {
      this.data=response.data[0];
      
      if(this.data.myservices){
        this.myservices = _.groupBy(this.data.myservices, 'mainCategory');
      }

      if(this.data.recentServices){
        this.recentServices = this.data.recentServices
        ;
      }
      console.log("==this.myservices==",this.myservices);
      console.log("==this.recentServices==",this.recentServices);
			this.spinner.hide();			
		}, err => {
			this.spinner.hide();
			this.commonService.handleCustomerError(err);
		});
  }
}
