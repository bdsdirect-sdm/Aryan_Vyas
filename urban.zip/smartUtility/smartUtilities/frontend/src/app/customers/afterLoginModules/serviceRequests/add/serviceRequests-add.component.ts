import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { serviceRequestService } from '../../../../utility/masterModules/services/serviceRequests.service';
import { NgxSpinnerService } from 'ngx-spinner';
import { ToastrService } from 'ngx-toastr';
import * as moment from 'moment';
import * as CryptoJS from 'crypto-js';
import { environment } from '../../../../../environments/environment';
import { CommonService } from '../../../../utility/services/common.service';
import { CustomerService } from '../../../../services/customers/customer.service';

@Component({
  selector: 'cust-serviceRequests-add-tutorial',
  templateUrl: './serviceRequests-add.component.html',
  styleUrls: ['./serviceRequests-add.component.css']
})
export class customerServiceRequestsAddComponent implements OnInit {
  serviceRequest: any;
  serviceList: any;
  providerList: any;
  customerID: any;
  minuteStep = 15;
  minDate: Date;
  dataIds: any = [];
  selectedProvider: any;
  providersList: any;
  utilityProviders: any;



  constructor(private serviceRequestService: serviceRequestService, private spinner: NgxSpinnerService, private commonService: CommonService,
    private toastr: ToastrService, private router: Router, private customerService: CustomerService
    , private activatedRoute: ActivatedRoute) {
    this.serviceRequest = {};
    this.serviceRequest.serviceList = '';
    this.providersList = [];
    this.minDate = new Date();
    this.serviceRequest.date = new Date();
    this.serviceRequest.service_id = '';
    this.serviceRequest.service_provider_id = '';
    this.activatedRoute.params.subscribe(paramid => {
      const conversionDecryptOutput = CryptoJS.AES.decrypt(paramid.id.trim(), environment.cryptoPassword.trim()).toString(CryptoJS.enc.Utf8);
      this.customerID = conversionDecryptOutput;
    });
  }

  ngOnInit() {
  }


  save() {
    this.spinner.show();
    let dt = moment(this.serviceRequest.date, "YYYY-MM-DD HH:mm:ss");
    let json = {
      date: moment(this.serviceRequest.date).format("YYYY-MM-DD"),
      time: this.serviceRequest['time'].hour + ':' + this.serviceRequest['time'].minute + ':' + this.serviceRequest['time'].second,
      service_type_id: this.dataIds[0].id,
      utility_provider_id: this.dataIds[0].utility_provider_id,
      customer_note: this.serviceRequest.note
    }

    this.customerService.addServiceRequest(json).subscribe(response => {
      this.spinner.hide();
      this.toastr.success('Service Request added successfully', 'Success');
      this.router.navigate(['/service-request']);
    }, err => {
      this.spinner.hide();
      this.commonService.handleCustomerError(err);
    });
  }


  selectProvider(item) {
    this.dataIds = [];
    this.selectedProvider = item.id;
    this.dataIds.push(item);
  }

  checkboxChecked(event, item) {
    this.dataIds = [];
    if (event.target.checked) {
      this.dataIds.push(item);
      this.selectedProvider = item.id;
    } else {
      this.selectedProvider = null
    }

  }

  onTagFocused(event) {
    if (event.length > 2) {
      this.spinner.show();
      let json = {
        keyword: event
      }

      this.customerService.getProvidersList(json).subscribe(response => {
        this.providersList = response.data;
        console.log('this.providersList', this.providersList)
        // if(this.providersList.length>0){

        //    this.providersList.forEach((tmpObj, k) => {      
        //       let searchkeyword=this.providersList[k].seach_keyword;
        //       searchkeyword=searchkeyword.split(",");
        //       this.providersList[k].seach_keyword=searchkeyword;
        //     });
        //    console.log("====this.providersList====",this.providersList);
        // }
        this.spinner.hide();
      }, err => {
        this.spinner.hide();
        this.commonService.handleCustomerError(err);
      });
    } else {
      this.providersList = [];
      this.utilityProviders = [];
    }
  }

  setvalue(item) {
    this.serviceRequest.serviceList = item.utilityServiceTypes_title;
    this.utilityProviders = this.providersList;
    this.providersList = [];
  }


}
