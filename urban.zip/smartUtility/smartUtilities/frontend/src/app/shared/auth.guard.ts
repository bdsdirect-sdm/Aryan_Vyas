import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from '../utility/services/common.service';
import { CookieService } from 'ngx-cookie';

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {
  constructor(private httpClient: HttpClient, private router: Router, private _cookieservice: CookieService,
    private toastr: ToastrService, private commonService: CommonService) { }
  async canActivate(route: ActivatedRouteSnapshot) {
    let loggedInUser = this._cookieservice.get('token');
    if (loggedInUser && loggedInUser != '') {
      let currentUser = JSON.parse(loggedInUser);
      if (currentUser.type == 'subadmin') {
        if (route.routeConfig.path == 'dashboard') {
          return true;
        } else {
          let subAdmin: any;
          subAdmin = await this.commonService.getSubAdminModule(btoa(currentUser.id));
          let routerPath = route.url[0].path;
          if (subAdmin.includes(routerPath)) {
            return true;
          } else {
            this.router.navigate(['/utility/dashboard']);
            this.toastr.error('You are not authorized to view this page', 'Permission Access');
          }
        }
      } else {
        return true;
      }
    } else {
      this.router.navigate(['/utility/login']);
      this.toastr.error('Please Login to Proceed further', 'Authentication');
    }

  }


}





