import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from '../utility/services/common.service';
import { CookieService } from 'ngx-cookie';

@Injectable({
    providedIn: 'root'
})
export class AdminAuthGuard implements CanActivate {
    constructor(private httpClient: HttpClient, private router: Router,
        private toastr: ToastrService, private commonService: CommonService,
        private _cookieservice: CookieService) { }
    canActivate(route: ActivatedRouteSnapshot) {
        let loggedInAdmin = this._cookieservice.get('admin-data');
        if (loggedInAdmin && loggedInAdmin != '') {
            return true;
        } else {
            this.router.navigate(['/admin']);
            this.toastr.error('Please Login to Proceed further', 'Authentication');
        }

    }


}





