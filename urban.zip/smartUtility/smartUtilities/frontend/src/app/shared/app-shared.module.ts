import { NgModule } from "@angular/core";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";
import { CommonModule } from "@angular/common";
import { DataTableModule } from "ng-angular8-datatable";
import { ChecklistModule } from "angular-checklist";
import { NgxSpinnerModule } from "ngx-spinner";
import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { ToastrModule } from "ngx-toastr";
import { NgxMaterialTimepickerModule } from "ngx-material-timepicker";
import { ModalModule } from "ngx-bootstrap/modal";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { NgxMaskModule } from "ngx-mask";
import { TooltipModule } from "ngx-bootstrap/tooltip";
import { BsDatepickerModule } from "ngx-bootstrap/datepicker";
import { GooglePlaceModule } from "ngx-google-places-autocomplete";
import { CookieModule } from "ngx-cookie";
import { TagInputModule } from "ngx-chips";
import { RatingModule } from "ng-starrating";
import { NgxStripeModule } from "ngx-stripe";
import { BsDropdownModule } from "ngx-bootstrap/dropdown";
import { AlertModule } from "ngx-bootstrap/alert";
import { UserIdleModule } from "angular-user-idle";

@NgModule({
  declarations: [],
  imports: [
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    BrowserAnimationsModule,
    AlertModule.forRoot(),
    ToastrModule.forRoot({
      preventDuplicates: true,
    }),
    ModalModule.forRoot(),
    NgxMaskModule.forRoot(),
    TooltipModule.forRoot(),
    BsDatepickerModule.forRoot(),
    NgxMaterialTimepickerModule,
    GooglePlaceModule,
    CookieModule.forRoot(),
    TagInputModule,
    RatingModule,
    NgxStripeModule.forRoot("pk_test_ENM5VBinG3GxV6qvebzk0Q8n00O0iSCi4Z"),
    BsDropdownModule.forRoot(),
    UserIdleModule.forRoot({ idle: 900, timeout: 800, ping: 500 }),
  ],
  exports: [
    DataTableModule,
    ChecklistModule,
    NgxSpinnerModule,
    NgbModule,
    NgxMaskModule,
    TooltipModule,
    ModalModule,
    FormsModule,
    BsDatepickerModule,
    GooglePlaceModule,
    CookieModule,
    TagInputModule,
    BsDropdownModule,
    RatingModule,
    AlertModule,
  ],
  providers: [],
  bootstrap: [],
})
export class AppSharedModule {}
