import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, Router } from '@angular/router';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { ToastrService } from 'ngx-toastr';
import { CommonService } from '../utility/services/common.service';
import { CookieService } from 'ngx-cookie';

@Injectable({
  providedIn: 'root'
})
export class CustomerAuthGuard implements CanActivate {
  constructor(private httpClient: HttpClient, private router: Router,
    private toastr: ToastrService, private commonService: CommonService,
    private _cookieservice: CookieService) { }
  canActivate(route: ActivatedRouteSnapshot) {
    let loggedInCustomer = this._cookieservice.get('customer-data');
    if (loggedInCustomer && loggedInCustomer != '') {
      return true;
    } else {
      this.router.navigate(['/home']);
      this.toastr.error('Please Login to Proceed further', 'Authentication');
    }

  }


}





