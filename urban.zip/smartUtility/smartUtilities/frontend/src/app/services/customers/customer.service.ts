import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Subject } from 'rxjs/Subject';
import { environment } from '../../../environments/environment';
import { map } from 'rxjs/operators';
import { CookieService } from 'ngx-cookie';

@Injectable({
    providedIn: 'root'
})
export class CustomerService {

    private notify = new Subject<any>();
    /**
     * Observable string streams
     */
    notifyObservable$ = this.notify.asObservable();

    constructor(private http: HttpClient, private _cookieservice: CookieService) {
    }
    public notifyOther(data: any) {
        this.notify.next(data);
    }

    getHeaders() {
        let headerOption = environment.headerOption;
        if (this._cookieservice.get('customer-data')) {
            const loggedInUtility = JSON.parse(this._cookieservice.get('customer-data'));
            headerOption['Authorization'] = loggedInUtility.access_token;
        }
        const headers = new HttpHeaders(headerOption);
        const options = { headers };
        return options
    }

    getMultipartHeaders() {
        let headerOption = environment.multipartHeaderOption;
       
        const headers = new HttpHeaders(headerOption);
        const options = { headers };
        return options
    }

    customerLogin(data) {
        const headers = new HttpHeaders(environment.headerOption);
        const options = { headers };

        return this.http.post(environment.apiEndPoint + 'shared/customerlogin', data, options).map(res => res as any);
    }

    getProvidersList(data) {
        const headers = new HttpHeaders(environment.headerOption);
        const options = { headers };

        return this.http.post(environment.apiEndPoint + 'customer/getutilityProvidersDropDown', data, options).map(res => res as any);
    }

    serviceRequestDetails(id) {
        
        return this.http.get(environment.apiEndPoint + 'customer/getRequestDetails/'+id, this.getHeaders()).map(res => res as any);
    }

    addServiceRequest(data) {

        return this.http.post(environment.apiEndPoint + 'customer/requestService', data, this.getHeaders()).map(res => res as any);
    }

    listServiceRequest() {
        
        return this.http.get(environment.apiEndPoint + 'customer/getrequestService', this.getHeaders()).map(res => res as any);
    }

    listUtilityProviders(data) {
        const headers = new HttpHeaders(environment.headerOption);
        const options = { headers };

        return this.http.post(environment.apiEndPoint + 'customer/getutilityProviders', data, options).map(res => res as any);
    }

    listServiceSubTypes(id) {
        const headers = new HttpHeaders(environment.headerOption);
        const options = { headers };

        return this.http.get(environment.apiEndPoint + 'customer/getUtilityServiceSubTypes/'+ id, options).map(res => res as any);
    }

    createCustomer(data) {
        const headers = new HttpHeaders(environment.headerOption);
        const options = { headers };

        return this.http.post(environment.apiEndPoint + 'shared/customer_signup', data, options).map(res => res as any);
    }

 
    cancelServiceRequest(data){        
        return this.http.post(environment.apiEndPoint + 'customer/cancelServiceRequest/', data,this.getHeaders()).map(res => res as any);
    }

    getNotification() {
        return this.http.get(environment.apiEndPoint + 'notification/Utilitylist', this.getHeaders()).map(res => res as any);
    }

    notifyStatus(data) {
        return this.http.post(environment.apiEndPoint + 'shared/notificationStatus', data, this.getHeaders()).map(res => res as any);
        
    }

    

    createProvider(data){        
        return this.http.post(environment.apiEndPoint + 'superAdmin/utilityProviderSave', data,this.getMultipartHeaders()).map(res => res as any);
    }


}