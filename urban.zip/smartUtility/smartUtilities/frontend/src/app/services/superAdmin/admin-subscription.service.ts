import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Subject } from 'rxjs/Subject';
import { environment } from '../../../environments/environment';
import { map } from 'rxjs/operators';
import { CookieService } from 'ngx-cookie';

@Injectable({
    providedIn: 'root'
})
export class SuperAdminSubscriptionService {

    private notify = new Subject<any>();
    /**
     * Observable string streams
     */
    notifyObservable$ = this.notify.asObservable();

    constructor(private http: HttpClient, private _cookieservice: CookieService) {
    }
    public notifyOther(data: any) {
        this.notify.next(data);
    }

    getHeaders() {
        let headerOption = environment.headerOption;
        if (this._cookieservice.get('admin-data')) {
            const loggedInUtility = JSON.parse(this._cookieservice.get('admin-data'));
            headerOption['Authorization'] = loggedInUtility.access_token;
        }
        const headers = new HttpHeaders(headerOption);
        const options = { headers };
        return options
    }


    getAll(data) {
        return this.http.get(environment.apiEndPoint + 'superadmin/subscriptions/list?keyword=' + data, this.getHeaders()).map(res => res as any);
    }

    multiUpdate(data) {
        return this.http.post(environment.apiEndPoint + 'superAdmin/subscriptions/multi_activeInactive', data, this.getHeaders()).map(res => res as any);
    }

    getDetails(id) {
        return this.http.get(environment.apiEndPoint + 'superAdmin/subscriptions/edit/' + id, this.getHeaders()).map(res => res as any);
    }

    update(data) {
        return this.http.post(environment.apiEndPoint + 'superAdmin/subscriptions/update', data, this.getHeaders()).map(res => res as any);
    }

    create(data) {
        return this.http.post(environment.apiEndPoint + 'superadmin/subscriptions/save', data, this.getHeaders()).map(res => res as any);
    }



}