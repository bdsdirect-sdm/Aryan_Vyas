import { Injectable, Inject } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Subject } from 'rxjs/Subject';
import { environment } from '../../../environments/environment';
import { map } from 'rxjs/operators';
import { CookieService } from 'ngx-cookie';

@Injectable({
    providedIn: 'root'
})
export class SuperAdminService {

    private notify = new Subject<any>();
    /**
     * Observable string streams
     */
    notifyObservable$ = this.notify.asObservable();

    constructor(private http: HttpClient, private _cookieservice: CookieService) {
    }
    public notifyOther(data: any) {
        this.notify.next(data);
    }

    getHeaders() {
        let headerOption = environment.headerOption;
        if (this._cookieservice.get('admin-data')) {
            const loggedInUtility = JSON.parse(this._cookieservice.get('admin-data'));
            headerOption['Authorization'] = loggedInUtility.access_token;
        }
        const headers = new HttpHeaders(headerOption);
        const options = { headers };
        return options
    }

    getMultipartHeaders() {
        let headerOption = environment.multipartHeaderOption;
        if (this._cookieservice.get('admin-data')) {
            const loggedInUtility = JSON.parse(this._cookieservice.get('admin-data'));
            headerOption['Authorization'] = loggedInUtility.access_token;
        }
        console.log('------------------ssssss1111', headerOption)
        const headers = new HttpHeaders(headerOption);
        const options = { headers };
        return options
    }

    adminLogin(data) {
        const headers = new HttpHeaders(environment.headerOption);
        const options = { headers };

        return this.http.post(environment.apiEndPoint + 'shared/superAdminLogin', data, options).map(res => res as any);
    }

    getDetails() {
        return this.http.get(environment.apiEndPoint + 'superAdmin/settings/edit', this.getHeaders()).map(res => res as any);
    }

    update(data) {
        return this.http.post(environment.apiEndPoint + 'superAdmin/settings/update', data, this.getMultipartHeaders()).map(res => res as any);
    }


}