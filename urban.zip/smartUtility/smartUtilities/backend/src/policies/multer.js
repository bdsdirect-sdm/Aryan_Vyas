/*********************************************************************
 *this file contains middleware that pareses incoming forms with multer
**********************************************************************/

var path = require('path');
var crypto = require('crypto');
var multer = require('multer');

var storage = multer.diskStorage({
	destination: function (req, file, cb) {
		cb(null, __dirname + '../../../public/uploads')
	},
	filename: function (req, file, cb) {
		crypto.pseudoRandomBytes(16, function (err, raw) {
			if (err) return cb(err)
			cb(null, raw.toString('hex') + path.extname(file.originalname))
		})
	}
});



var storageM = multer.diskStorage({

	destination: function (req, file, cb) {
		console.log('******************** here in multer', file)
		cb(null, __dirname + '../../../public/uploads')
	},
	filename: function (req, file, cb) {
		console.log('******************** here in multer 222222222222222222', file)
		crypto.pseudoRandomBytes(16, function (err, raw) {
			if (err) return cb(err)
			cb(null, raw.toString('hex') + path.extname(file.originalname))
		})
	}
});

exports.cpUpload = multer({
	storage: storage
}).single('file');

exports.cpUploadArray = multer({
	storage: storageM
}).array('files[]');
