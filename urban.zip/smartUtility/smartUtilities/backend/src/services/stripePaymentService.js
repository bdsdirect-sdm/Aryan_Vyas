//public key to get token
var stripe = require('stripe')('pk_test_AoguywdTTrldJal07tpsVu6z');

exports.pay = async function (req, res) {
  // return new Promise((resolve, rej)=>{

  var card = req.body.card
  let user_details = new Promise((resolve, rej) => {
    req.getConnection((err, connection) => {
      const query = connection.query('select * from utilityProviders where id = 1', [], (err, result) => {
        if (err) {
          res.json(err);
          res.status(500).json({ status: 'error', error: err });
          return false
        }
        resolve(result[0])
      })
    })
  })
  let user_detail = await user_details
  //console.log('user_detail=============>',user_detail.id)

  stripe.tokens.create(
    {
      card
      // card: {
      //   number: '4242424242424242',
      //   exp_month: 5,
      //   exp_year: 2021,
      //   cvc: '314',
      // },
    },
    function (err, token) {
      // asynchronously called
      if (err) {
        console.log('err--------->', err);
      }
      console.log('toekn id_____===>', token.id)
      //define secrit key here
      var stripe = require('stripe')('sk_test_tuKzwulUeP7bNyiqUOvPjfNY');

      stripe.charges.create(
        {
          amount: 1200,
          currency: 'usd',
          source: 'tok_amex',
          description: 'dynamice card added',
        },
        function (err, charge) {
          if (err) {
            console.log('err=========>', err)
          }
          console.log('charge------------>', charge)
          // asynchronously called
        }
      );
    }
  );

  //   })
};
exports.createStripeCustomer = async function (req, res) {
  //nodevar stripe = require('stripe')('sk_test_swguQjhPgXoeIfGjYP0C4L7f00OtliGZ3h'); 
  const stripe = require('stripe')('sk_test_swguQjhPgXoeIfGjYP0C4L7f00OtliGZ3h');
/*
  const stripe = require('stripe')('sk_test_swguQjhPgXoeIfGjYP0C4L7f00OtliGZ3h');
  const payout = await stripe.payouts.create({
  amount: 5000,
  currency: 'usd',
});
*/
  /*
  stripe.accounts.createExternalAccount(
    'acct_1GeyjmIYBqFX2Rr4',
    {
      external_account: 'btok_1GfKUSIYBqFX2Rr4FCI4tc4m',
    },
    function(err, bankAccount) {
        if(err){
          console.log("if erri------->",err);      
        }
        console.log("transer-------------->",bankAccount);
    }
  );
  */
 const paymentIntent = await stripe.paymentIntents.create({
  payment_method_types: ['card'],
  amount: 100 * 100,
  currency: 'inr',
  application_fee_amount: 123,
  transfer_data: {
    destination: 'acct_1GfKG0EXSp8rZnTQ',
  },
}).then(function(paymentIntent) {
  // asynchronously called
  console.log('paymentIntent==========>',paymentIntent)
});

  // stripe.transfers.create(
  //   {
  //     amount: 400,
  //     currency: 'inr',
  //     destination: 'acct_1GfKG0EXSp8rZnTQ',
  //     transfer_group: 'ORDER_95',
  //   },
  //   function(err, transfer) {
  //       if(err){
  //         console.log("if erri------->",err);      
  //       }
  //       console.log("transer-------------->",transfer);
           
  //   }
  // );
  
  /*
  //account create with this api
  stripe.accounts.create(
    {
      type: 'custom',
      country: 'US',
      email: 'jenny.account@example.com',
      requested_capabilities: [
        'card_payments',
        'transfers',
      ],
    },
    function(err, account) {
    if(err){
      console.log("=-======err====?",err);
      
    }
    console.log('account----------------->',account);
    
    }
  );
  */
  /*
  //create source id
  stripe.sources.create({
    type: 'ach_credit_transfer',
    currency: 'usd',
    owner: {
      email: 'jenny.rosen@example.com'
    }
  }, function(err, source) {
         if(err){
              console.log("=======>",err);
            }
            console.log("source=================?",source)
    
  });
//create source for customer
  stripe.customers.createSource(
    'cus_HDl0dWdEAa2tME',
    {source: 'src_1GfK8FIYBqFX2Rr43PTyyT2C'},
    function(err, bankAccount) {
      if(err){
              console.log("=======>",err);
            }
            console.log("cutomer=================?",bankAccount)
    }
  );
*/
  // stripe.sources.create({
  //   type: 'ach_credit_transfer',
  //   currency: 'usd',
  //   owner: {
  //     email: 'customer@example.com'
  //   }
  // }, function(err, source) {
  //         if(err){
  //       console.log("=======>",err);
  //     }
  //     console.log("cutomer=================?",source)
  // });

  // stripe.customers.create({
  //   email: 'customer@example.com',
  // })
  //   .then(customer => console.log(customer.id))
  //   .catch(error => console.error(error));

  // stripe.customers.createSource(
  //   'cus_HDUO2W9B5ZgsOl',
  //   {source: 'tok_1Gf47UGaRr3FgetoHw1OtH8m'},
  //   function(err, bankAccount) {
  //     if(err){
  //       console.log("=======>",err);
  //     }
  //     console.log("cutomer=================?",bankAccount)
  //   }
  // );
};