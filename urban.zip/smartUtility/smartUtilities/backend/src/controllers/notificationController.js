const managetServiceRequest = require('../services/manageAdminService')
const controller = {};
 
/*
 * @api url : /notifications/list
 * @description: list subscriptions with search keyword
 *  @type : GET
 * @author: Sanjeev
 */
controller.list = async (req, res) => {
    console.log("-------------->",req.headers.decoded)
    req.getConnection((err, conn) => {

        let query = `SELECT notifications.*,notification.notification_title,notification.notification_description,notification.notification_type FROM notifications 
                    LEFT JOIN notification on notifications.notification_id = notification.id 
                    WHERE notifications.to = ? AND notifications.to_type = 'customer' and (status!='2' or status<2) ORDER BY notifications.id DESC`;
           console.log("listttt",query)         
        conn.query(query, [req.headers.decoded.user_id], (err, notification) => {
            if (err) {
                res.status(400).send({ err: err })
                return false
            }
            res.status(200).send({ "success": true, data: notification })
        });
    });
};

/*
 * @api url : /notifications/Utilitylist
 * @description: 
 *  @type : GET
 * @author: Sanjeev
 */
controller.Utilitylist = async (req, res) => {
    console.log("-------------->",req.headers.decoded)
    try {
        var provider_id_with_admin_id = await managetServiceRequest.get_provider_of_admin(req)
    } catch (error) { 
        console.log(error)
       res.status(400).send(error)
       return false
    }
    req.getConnection((err, conn) => {

        let query = `SELECT notifications.*,notification.notification_title,notification.notification_description,notification.notification_type FROM notifications 
                    LEFT JOIN notification on notifications.notification_id = notification.id 
                    WHERE notifications.to = ? AND notifications.to_type = 'provider' and (status!='2' or status<2) ORDER BY notifications.id DESC`
        conn.query(query, [provider_id_with_admin_id], (err, notification) => {
            if (err) {
                res.status(400).send({ err: err })
                return false
            }
            res.status(200).send({ "success": true, data: notification })
        });
    });
};
module.exports = controller;
