/*
 * @file: paymentrController.js
 * @description: It Contain functions for customer payments
 * @author: Raman
 */
const controller = {};
var md5 = require('md5');
const formidable = require('formidable');
const emailService = require('../services/emailService');
const manageAdminService = require('../services/manageAdminService')

var moment = require('moment');
const stripe = require('../services/stripe')

controller.payNow = async (req, res) => {

	console.log("-=--=--=-=-", JSON.stringify(req.body));
	var requestId = Buffer.from(req.body.requestId, 'base64').toString();
	// stripe.paymentByNewCustomer(req, response => { 
	// 	console.log("-=--=--response=-=-",JSON.stringify(response));

	// 	if(response){

	req.getConnection((err, conn) => {
		conn.query("select * from utilityServiceRequest where id=?", [requestId], (err, serviceData) => {
			console.log(err)
			if (err) {
				res.json(err);
				res.status(500).json({ status: 'error', error: err });
			}
			var customerId = serviceData[0].customer_id;
			conn.query("select * from customers where id=?", [customerId], (err, customerData) => {
				console.log(err)
				if (err) {
					res.json(err);
					res.status(500).json({ status: 'error', error: err });
				}

				conn.query("select * from utilityProviders where id=?", [req.body.utilityProvider], (err, utilityProviders) => {
					console.log(err)
					if (err) {
						res.json(err);
						res.status(500).json({ status: 'error', error: err });
					}
					if (customerData[0].stripe_id != null) {
						paymentByExistingStripeCustomer(req, res, customerData[0].stripe_id, customerId, customerData, serviceData, utilityProviders, result => {
							console.log("========error",result.error);
							if (result.error) {
								res.status(300).json({ status: 'error', msg: result.error.error.raw.message });
							} else {
								res.status(200).send(result)

							}
						})
					} else {
						paymentByNewStripeCustomer(req, res, customerId, customerData, serviceData, utilityProviders, result => {
							if (result.error) {
								res.status(300).json({ status: 'error', msg: result.error.error.raw.message });
							} else {
								res.status(200).send(result)

							}
						})



					}
				});
			});

		});
	});
}

/*
 * @api url : /customer/list?keyword=
 * @description: It Contain functions list the customers and searh with keyword
 *  @type : GET
 * @author: Sanjeev
 */
controller.list = async (req, res) => {
	try {
		var service_provider_id = await manageAdminService.get_provider_of_admin(req)
	} catch (error) {
		res.status(400).send(error)
		return false
	}
	req.getConnection((err, conn) => {
		var provider_id = ''
		if (req.body.provider_id) {
			var new_id = Buffer.from(req.body.provider_id, 'base64').toString();
			provider_id = `AND USP.id = ${new_id}`
		}
		var search = ''
		if (req.body.keyword) {
			
			search = `AND (USR.request_number LIKE '%${req.body.keyword}%' or USP.first_name LIKE '%${req.body.keyword}%' or CST.first_name LIKE '%${req.body.keyword}%' or PT.transaction_id LIKE '%${req.body.keyword}%')`
		}
		conn.query(`SELECT USR.request_number, PT.id, PT.amount, PT.payment_date, PT.transaction_id, PT.status, concat(USP.first_name," ",USP.last_name) as provider_name, concat(CST.first_name," ",CST.last_name) as customer_name, PT.service_request_id as service_request_id  FROM payments as PT LEFT JOIN utilityServiceRequest as USR on USR.id = PT.service_request_id LEFT JOIN utilityProgressServices as UPS on UPS.service_request_id = PT.service_request_id LEFT JOIN customers as CST on CST.id = PT.payment_by LEFT JOIN utilityServiceProviders as USP on USP.id =  UPS.service_provider_id where USR.utility_provider_id=? ${search} AND USR.current_status = UPS.service_request_status ${provider_id} group by USR.id ORDER BY PT.id DESC;`, [service_provider_id], (err, payments) => {
			console.log("errrorrrr=",err);
			if (err) {
				res.status(400).send({ err: err });
				return false;
			}
			res.status(200).send({ "success": true, data: payments })
		});
	});
};

var paymentByExistingStripeCustomer = (req, res, stripe_id, customerId, customerData, serviceData, utilityProviders, callback) => {

	stripe.paymentByExistingCustomer(req, res, stripe_id, customerId, customerData, serviceData, utilityProviders, response => {

		if (!response.error) {


			var requestId = Buffer.from(req.body.requestId, 'base64').toString();

			req.getConnection((err, conn) => {
				conn.query("update utilityServiceRequest set stripe_charge_id=?,current_status=? where id=?", [response.id, '5', requestId], (err, updateserviceData) => {
					if (err) {
						callback({ status: 'error', error: err });
					}

					var currentdate = moment().format("YYYY-MM-DD HH:mm:ss");
					conn.query("insert into  utilityProgressServices(service_request_id,service_provider_id,provider_notes,service_request_status,notes,created_at,modified_at) values(?,?,?,?,?,?,?)", [requestId, req.body.service_provider_id,'', 5, 'Payment made by customer', currentdate, currentdate], (err, insertData) => {

						if (err) {
							callback({ status: 'error', error: err });
						}

						var paymentData = {};
						paymentData.payment_method = 'Stripe';
						paymentData.amount = serviceData[0].cost;
						paymentData.payment_for = 'Service';
						paymentData.payment_by = customerId;
						paymentData.customer_type = 'Customer';
						paymentData.payment_date = currentdate;
						paymentData.charge_id = response.id;
						paymentData.transaction_id = response.balance_transaction;
						paymentData.service_request_id = requestId;
						paymentData.status = 'Success';
						paymentData.payment_response = 200;
						paymentData.statusCode = response.status;
						paymentData.utility_provider_id = req.body.utilityProvider;
						paymentData.service_provider_id = req.body.service_provider_id;
						paymentData.utlity_id = req.body.utilityID;

						conn.query("INSERT INTO payments set ?", [paymentData], (err, paymentResponse) => {



							callback({ "success": true, data: paymentResponse });
						})
					})
				})
			})
		} else {
			callback({ status: 'error', error: response });

		}
	});
};
exports.paymentByExistingStripeCustomer = paymentByExistingStripeCustomer;


var paymentByNewStripeCustomer = (req, res, customerId, customerData, serviceData, utilityProviders, callback) => {


	stripe.paymentByNewCustomer(req, customerData, serviceData, utilityProviders, response => {
		console.log("=-=-=-response--=--=-=-rrkkkkk", response);

		if (!response.error) {

			var requestId = Buffer.from(req.body.requestId, 'base64').toString();

			req.getConnection((err, conn) => {
				conn.query("update utilityServiceRequest set stripe_charge_id=?,current_status=? where id=?", [response.charge_id, '5', requestId], (err, updateserviceData) => {
					console.log(err)
					if (err) {
						callback({ status: 'error', error: err });
					}

					conn.query("update customers set stripe_id=? where id=?", [response.cust_id, customerId], (err, serviceData) => {
						console.log(err)
						if (err) {
							callback({ status: 'error', error: err });
						}

						var currentdate = moment().format("YYYY-MM-DD HH:mm:ss");
						conn.query("insert into  utilityProgressServices(service_request_id,service_provider_id,provider_notes,service_request_status,notes,created_at,modified_at) values(?,?,?,?,?,?,?)", [requestId, req.body.service_provider_id,'', 5, 'Payment made by customer', currentdate, currentdate], (err, insertData) => {

							if (err) {
								callback({ status: 'error', error: err });
							}

							var paymentData = {};
							paymentData.payment_method = 'Stripe';
							paymentData.amount = serviceData[0].cost;
							paymentData.payment_for = 'Service';
							paymentData.payment_by = customerId;
							paymentData.customer_type = 'Customer';
							paymentData.payment_date = currentdate;
							paymentData.charge_id = response.id;
							paymentData.transaction_id = response.balance_transaction;
							paymentData.service_request_id = requestId;
							paymentData.status = 'Success';
							paymentData.payment_response = 200;
							paymentData.statusCode = response.status;
							paymentData.utility_provider_id = req.body.utilityProvider;
							paymentData.service_provider_id = req.body.service_provider_id;
							paymentData.utlity_id = req.body.utilityID;


							conn.query("INSERT INTO payments set ?", [paymentData], (err, paymentResponse) => {



								callback({ "success": true, data: paymentResponse });
							})
						})

					})
				})
			})
		} else {
			callback({ status: 'error', error: response });

		}

	});

};
exports.paymentByNewStripeCustomer = paymentByNewStripeCustomer;

module.exports = controller;
