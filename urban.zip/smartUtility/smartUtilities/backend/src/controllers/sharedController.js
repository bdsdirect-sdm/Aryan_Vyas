const controller = {};
var md5 = require('md5');
var jwt = require('../services/jwt');
var UUID = require('uuid-js');
const managetServiceRequest = require('../services/manageAdminService')
const emailService = require('../services/emailService')
controller.login = (req, res) => {
    const data = req.body;
    req.getConnection((err, connection) => {

        const query = connection.query("select * from utilityProviders where email = ? and password = ? and is_active='true' and is_deleted='false' LIMIT 1", [data.email, md5(data.password)], (err, Newadmin) => {
            if (err) {
                res.status(400).send({ "error": err })
            }
            if (Newadmin.length == 0) {
                res.status(400).send({ "success": false, msg: 'Incorrect email or password.' });
                return false
            }

            let uuidToken = UUID.create().toString()
            var token = jwt.createToken(data.email, uuidToken, Newadmin[0].id, 'utilityProviders');

            req.getConnection((err, connection) => {
                const query = connection.query('update utilityProviders set access_token=? where id=? ', [token, Newadmin[0].id], (err, result) => {
                    if (err) {
                        res.json(err);
                        res.status(500).json({ status: 'error', error: err });
                    }
                    Newadmin[0].access_token = token;
                    res.status(200).send({ "success": true, data: Newadmin })
                })
            })
        })
    })
};



controller.superadminlogin = (req, res) => {
    const data = req.body;
    req.getConnection((err, connection) => {

        const query = connection.query('select * from settings where email = ? and password = ? LIMIT 1', [data.email, md5(data.password)], (err, Newadmin) => {
            if (err) {
                res.status(400).send({ "error": err })
            }
            if (Newadmin.length == 0) {
                res.status(400).send({ "success": false, msg: 'Incorrect email or password.' });
                return false
            }

            let uuidToken = UUID.create().toString()
            var token = jwt.createToken(data.email, uuidToken, Newadmin[0].id, 'settings');

            req.getConnection((err, connection) => {
                const query = connection.query('update settings set access_token=? where id=? ', [token, Newadmin[0].id], (err, result) => {
                    if (err) {
                        res.json(err);
                        res.status(500).json({ status: 'error', error: err });
                    }
                    Newadmin[0].access_token = token;
                    res.status(200).send({ "success": true, data: Newadmin })
                })
            })
        })
    })
};

controller.utilityAdminslogin = (req, res) => {
    const data = req.body;
    req.getConnection((err, connection) => {
        if (err) {
            res.status(400).send({ "error": err })
            return false
        }
        const query = connection.query("select * from utilitySubAdmins where email = ? and password = ? and is_deleted='false'", [data.email, md5(data.password)], (err, Newadmin) => {
            if (err) {
                res.status(400).send({ "error": err })
                return false
            }
            if (Newadmin.length == 0) {
                res.status(400).send({ "success": false, msg: 'Incorrect email or password.' });
                return false
            }

            if (Newadmin[0].is_active == 'false') {
                res.status(400).send({ "success": false, msg: 'Your account is not activated.' });
                return false
            }


            let uuidToken = UUID.create().toString()
            var token = jwt.createToken(data.email, uuidToken, Newadmin[0].id, 'utilitySubAdmins');

            req.getConnection((err, connection) => {
                const query = connection.query('update utilitySubAdmins set access_token=? where id=? ', [token, Newadmin[0].id], (err, result) => {
                    if (err) {
                        res.json(err);
                        res.status(500).json({ status: 'error', error: err });
                        return false
                    }
                    Newadmin[0].access_token = token;
                    res.status(200).send({ "success": true, data: Newadmin })
                })
            })

        })
    })
};

controller.customerlogin = (req, res) => {
    const data = req.body;
    req.getConnection((err, connection) => {
        if (err) {
            res.status(400).send({ "error": err })
        }

        connection.query('select * from customers where email = ?', [data.email], (err, customerData) => {
            if (err) {
                res.status(400).send({ "error": err })
            } else {
                console.log('***************************8----', customerData)
                if (customerData.length == 0) {
                    res.status(400).send({ "success": false, msg: "User doesn't exists" });
                    return false
                } else {
                    const query = connection.query('select * from customers where email = ? and password = ?', [data.email, md5(data.password)], (err, Newadmin) => {
                        if (err) {
                            res.status(400).send({ "error": err })
                        }
                        if (Newadmin.length == 0) {
                            res.status(400).send({ "success": false, msg: 'Incorrect email or password.' });
                            return false
                        }
                        let uuidToken = UUID.create().toString()
                        var token = jwt.createToken(data.email, uuidToken, Newadmin[0].id, 'customers');


                        req.getConnection((err, connection) => {
                            const query = connection.query('update customers set access_token=? where id=? ', [token, Newadmin[0].id], (err, result) => {
                                if (err) {
                                    res.json(err);
                                    res.status(500).json({ status: 'error', error: err });
                                    return false
                                }
                                Newadmin[0].access_token = token;
                                res.status(200).send({ "success": true, data: Newadmin })
                            })
                        })

                    })
                }

            }
        });
    })
};

controller.upload = (req, res) => {
    const file = req.file;
    console.log("sssssssssssssssssssssssssssss", file)

    if (!file) {
        const error = new Error('Please upload a file')
        error.httpStatusCode = 400
        return next(error)
    }
    res.status(200).send({ "success": true, data: req.body })
};



controller.uploadFile = (req, res) => {
    const file = req.file;
    if (!file) {
        const error = new Error('Please upload a file')
        error.httpStatusCode = 400
        return next(error)
    }
    res.status(200).send({ "success": true, data: file })
};

/*
 * @author: Sanjeev
 * @api url : /shared/customer_signup
 * @description: This function is used to save the customers
 *  @type : POST
 * @Prameters : first_name, last_name, email, mobile, password,address,city,state,country,zip*/
// controller.customer_signup = (req, res) => {
//     const data = req.body;
//     let paswordForEmail = data.password;
//     data['is_deleted'] = "false"
//     data['is_active'] = "true"
//     data['password'] = md5(data.password)
//     data['created_at'] = new Date
//     data['created_by'] = 0
//     data['utitlity_provider_id'] = 0
//     data['profile_pic'] = " "
//     data['access_token'] = " "
//     // data['modified_at'] = " "
//     console.log(req.body);
//     req.getConnection((err, connection) => {
//         connection.query('select * from customers where email = ?', [data.email], (err, Newadmin) => {
//             if (err) {
//                 res.status(400).send({ "error": err })
//             }
//             //checking is email already exists....
//             if (Newadmin.length == 0) {
//                 req.getConnection((err, connection) => {
//                     if (err) {
//                         res.status(400).send({ "error": err })
//                         return false
//                     }
//                     connection.query('INSERT INTO customers set ?', data, (err, Newadmin) => {
//                         if (err) {
//                             res.status(400).send({ "error": err })
//                             return false
//                         }
//                         connection.query('select * from customers where id = ?', [Newadmin.insertId], (err, new_user) => {
//                             if (err) {
//                                 res.status(400).send({ "error": err })
//                                 return false
//                             }
//                             emailService.sendEmail(req, res, 1, data.email, paswordForEmail, req.body.first_name + ' ' + req.body.last_name, null, finalRes => {
//                                 res.status(200).send({ "success": true, data: new_user[0] });
//                             });


//                         })
//                     })
//                 })
//             } else {
//                 res.status(400).send({ "error": "email already exists." })
//             }
//         })
//     })
// };


controller.customer_signup = (req, res) => {
    const data = req.body;
    let paswordForEmail = data.password;
    data['is_deleted'] = "false"
    data['is_active'] = "true"
    data['password'] = md5(data.password)
    data['created_at'] = new Date
    data['created_by'] = 0
    // data['utitlity_provider_id'] = 0
    // data['profile_pic'] = " "
    // data['access_token'] = " "
    // data['modified_at'] = " "
    console.log(req.body);
    req.getConnection((err, connection) => {
        connection.query('select * from customers where email = ?', [data.email], (err, Newadmin) => {
            if (err) {
                res.status(400).send({ "error": err })
            }
            //checking is email already exists....
            if (Newadmin.length == 0) {
                req.getConnection((err, connection) => {
                    if (err) {
                        res.status(400).send({ "error": err })
                        return false
                    }
                    connection.query('INSERT INTO customers set ?', data, (err, Newadmin) => {
                        if (err) {
                            res.status(400).send({ "error": err })
                            return false
                        }
                        connection.query('select * from customers where id = ?', [Newadmin.insertId], (err, new_user) => {
                            if (err) {
                                res.status(400).send({ "error": err })
                                return false
                            }
                            emailService.sendEmail(req, res, 1, data.email, paswordForEmail, req.body.first_name + ' ' + req.body.last_name, null, finalRes => {
                                res.status(200).send({ "success": true, data: new_user[0] });
                            });


                        })
                    })
                })
            } else {
                res.status(400).send({ "error": "email already exists." })
            }
        })
    })
};



controller.notificationStatus = (req, res) => {
    req.body.id = Buffer.from(req.body.id, 'base64').toString();
    req.getConnection((err, connection) => {
        connection.query('update notifications set status=? where id =?', [req.body.status, req.body.id], (err, result) => {
            console.log("-----update notifications set status=" + req.body.status + " where id =" + req.body.id);
            if (err) {
                res.json(err);
                res.status(500).json({ status: 'error', error: err });
            }
            res.status(200).send(result)
        });
    });
};
module.exports = controller;
