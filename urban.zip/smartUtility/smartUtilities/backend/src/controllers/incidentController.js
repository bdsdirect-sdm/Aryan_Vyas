/*
 * @file: customerController.js
 * @description: It Contain functions for incident CRUD operations
 * @author: Raman
 */
const controller = {};
var md5 = require('md5');
var moment = require('moment');
const managetServiceRequest = require('../services/manageAdminService')
const formidable = require('formidable');
const notification = require('../services/notifications')

controller.saveIncident = (req, res) => {

    const data = req.body;
    console.log("=-=--=data--=-=", data);
    var requestId = Buffer.from(data.requestId, 'base64').toString();


    var currentDateTime = moment().format("YYYY-MM-DD HH:mm:ss")
    console.log(req.body);
    req.getConnection((err, connection) => {
        connection.query('insert into  utilityServiceIncidents (incident_number,service_request_id,customer_id,service_provider_id,utility_provider_id,incident_description,incident_status,incident_type,priority,is_deleted,created_at,modified_at) values(?,?,?,?,?,?,?,?,?,?,?,?)', [1231313, requestId, data.serviceRequest.customer_id, data.serviceRequest.service_provider_id, data.serviceRequest.utility_provider_id, data.incident.incident_description, 'Open', data.incident.incident_type, data.incident.priority, 'false', currentDateTime, currentDateTime], (err, incident) => {

            if (err) {
                res.status(300).json({ status: 'error', msg: err });
                return false
            }

            /*********************notification start ************************************/
            /**@notifiction prameters template : req,notification_id,to_id,to_type,from,from_type */
            /**for @provider */
            notification.save_notification(req, 5, data.serviceRequest.utility_provider_id, 'provider', req.headers.decoded.user_id, 'customer')
            /*********************notification end **********************************/



            res.status(200).send({ "success": true, data: incident })

        })
    })
};



controller.saveFeedback = (req, res) => {

    const data = req.body;
    console.log("=-=--=saveFeedback--=-=", data);
    data.service_request_id = Buffer.from(data.service_request_id, 'base64').toString();
    var currentDateTime = moment().format("YYYY-MM-DD HH:mm:ss");
    req.getConnection((err, connection) => {

        connection.query(`select * from utilityServiceProviderRating where service_request_id=?`, [data.service_request_id], (err, ratingData) => {

            if (ratingData.length > 0) {
                res.status(304).json({ status: 'error', msg: "Feedback has been already provided for this service." });
                return false
            }

            connection.query('insert into  utilityServiceProviderRating (service_request_id,rating,comments,utility_provider_id,created_at,modified_at) values(?,?,?,?,?,?)', [data.service_request_id, data.rating, data.comments,data.utility_provider_id, currentDateTime, currentDateTime], (err, feedback) => {

                if (err) {
                    res.status(300).json({ status: 'error', msg: err });
                    return false
                }
                connection.query(`select * from utilityServiceRequest where id=?`, [data.service_request_id], (err, reqquest_data) => {
                    /*********************notification start ************************************/
                    /**@notifiction prameters template : req,notification_id,to_id,to_type,from,from_type */
                    /**for @provider */
                    console.log("reqquest_data====>", reqquest_data)
                    notification.save_notification(req, 4, reqquest_data[0].utility_provider_id, 'provider', req.headers.decoded.user_id, 'customer')
                    /*********************notification end **********************************/
                    res.status(200).send({ "success": true, data: feedback })
                })
            })
        });
    })
};

controller.incidentList = async (req, res) => {

    try {
        var provider_id_with_admin_id = await managetServiceRequest.get_provider_of_admin(req)
    } catch (error) {
        console.log(error)
        res.status(400).send(error)
        return false
    }
    let utility_id = 1;
    let utility_provider_id = provider_id_with_admin_id;

    req.getConnection((err, connection) => {
        connection.query(`select 
          USI.id, USI.incident_number, USI.incident_description,USI.created_at,  USI.incident_type, USI.priority,USI.service_request_id,USI.incident_status, USI.resolution_description, c.first_name,c.last_name,USP.first_name as provider_first_name,USP.last_name as provider_last_name,USR.request_number  from  utilityServiceIncidents as USI LEFT JOIN utilityServiceRequest as USR on USR.id=USI.service_request_id LEFT JOIN customers as c on c.id=USI.customer_id and c.id=USR.customer_id LEFT JOIN utilityServiceProviders as USP on USP.id=USI.service_provider_id
            where USI.utility_provider_id=?  and USI.is_deleted='false' order by USI.id DESC `, [utility_provider_id], (err, incidentList) => {

            console.log("incidentList=====", err, JSON.stringify(incidentList));
            if (err) {
                res.status(300).json({ status: 'error', msg: err });
                return false
            }
            res.status(200).send({ "success": true, data: incidentList })

        })
    })
};

controller.incidentDetail = (req, res) => {
    console.log("start", req.params.id);
    var id = Buffer.from(req.params.id, 'base64').toString();
    console.log("after======incidentDetail===========", id);
    req.getConnection((err, connection) => {
        connection.query('select * from  utilityServiceIncidents where service_request_id=?', [id], (err, incidentDetails) => {

            console.log("select * from  utilityServiceIncidents where service_request_id=" + id, err, JSON.stringify(incidentDetails));
            if (err) {
                res.status(300).json({ status: 'error', msg: 'Please try again' });
                return false
            }
            res.status(200).send({ "success": true, data: incidentDetails })

        })
    })
};



controller.deleteIncident = (req, res) => {
    console.log("deleteIncident-----", req.body);
    req.body.id = Buffer.from(req.body.id, 'base64').toString();
    req.getConnection((err, connection) => {
        connection.query('update utilityServiceIncidents set is_deleted=? where id =?', ['true', req.body.id], (err, result) => {
            if (err) {
                res.json(err);
                res.status(500).json({ status: 'error', error: err });
            }
            res.status(200).send(result)
        });
    });
};


controller.searchIncident = async (req, res) => {
    console.log("searchIncident-----", req.body);
    try {
        var provider_id_with_admin_id = await managetServiceRequest.get_provider_of_admin(req)
    } catch (error) {
        console.log(error)
        res.status(400).send(error)
        return false
    }
    let utility_id = 1;
    let utility_provider_id = provider_id_with_admin_id;
    req.getConnection((err, conn) => {

        conn.query(`select 
          USI.id, USI.incident_number, USI.incident_description,USI.created_at,  USI.incident_type, USI.priority,USI.service_request_id,c.first_name,c.last_name,USP.first_name as provider_first_name,USP.last_name as provider_last_name,USR.request_number  from  utilityServiceIncidents as USI LEFT JOIN utilityServiceRequest as USR on USR.id=USI.service_request_id LEFT JOIN customers as c on c.id=USI.customer_id and c.id=USR.customer_id LEFT JOIN utilityServiceProviders as USP on USP.id=USI.service_provider_id
            where (c.first_name LIKE ? or c.last_name LIKE ? or USI.incident_number LIKE ? or USR.request_number LIKE ?) and  USR.utility_provider_id=? and USI.is_deleted='false order by USI.id DESC'` , ['%' + req.body.keyword + '%', '%' + req.body.keyword + '%', '%' + req.body.keyword + '%', '%' + req.body.keyword + '%', utility_provider_id], (err, result) => {
            console.log("after======searchIncident===========", err, JSON.stringify(result));
            if (err) {
                res.json(err);
                res.status(500).json({ status: 'error', error: err });
            }
            res.status(200).send(result)
        });
    });
};

controller.ratingList = async (req, res) => {
    console.log("ramannnnnnnn========ratingList");
    try {
        var provider_id_with_admin_id = await managetServiceRequest.get_provider_of_admin(req)
    } catch (error) {
        console.log(error)
        res.status(400).send(error)
        return false
    }
    let utility_id = 1;
    let utility_provider_id = provider_id_with_admin_id;
    console.log("raman=====");
    req.getConnection((err, connection) => {
        connection.query('select  USI.id, USI.rating, USI.comments,USI.created_at,USI.service_request_id,c.first_name,c.last_name,USR.request_number from  utilityServiceProviderRating as USI LEFT JOIN utilityServiceRequest as USR on USR.id=USI.service_request_id LEFT JOIN customers as c on c.id=USR.customer_id where USR.utility_provider_id=? order by USI.id DESC', [utility_provider_id], (err, ratingList) => {

            console.log("ratingList=====", err, JSON.stringify(ratingList));
            if (err) {
                res.status(300).json({ status: 'error', msg: err });
                return false
            }
            res.status(200).send({ "success": true, data: ratingList })

        })
    })
};


controller.searchRating = async (req, res) => {
    console.log("searchIncident-----", req.body);
    try {
        var provider_id_with_admin_id = await managetServiceRequest.get_provider_of_admin(req)
    } catch (error) {
        console.log(error)
        res.status(400).send(error)
        return false
    }
    let utility_id = 1;
    let utility_provider_id = provider_id_with_admin_id;
    req.getConnection((err, conn) => {

        conn.query(`select  USI.id, USI.rating, USI.comments,USI.created_at,USI.service_request_id,c.first_name,c.last_name,USR.request_number from  utilityServiceProviderRating as USI LEFT JOIN utilityServiceRequest as USR on USR.id=USI.service_request_id LEFT JOIN customers as c on c.id=USR.customer_id where (c.first_name LIKE ? or c.last_name LIKE ? or USR.request_number LIKE ? ) and  USR.utility_provider_id=? order by USI.id DESC`, ['%' + req.body.keyword + '%', '%' + req.body.keyword + '%', '%' + req.body.keyword + '%', utility_provider_id], (err, result) => {
            console.log("after======searchIncident===========", err, JSON.stringify(result));
            if (err) {
                res.json(err);
                res.status(500).json({ status: 'error', error: err });
            }
            res.status(200).send(result)
        });
    });
};
controller.incidentStatus = (req, res) => {
    console.log("deleteIncident-----", req.body);
    req.body.id = Buffer.from(req.body.id, 'base64').toString();
    req.getConnection((err, connection) => {
        connection.query('update utilityServiceIncidents set incident_status=? where id =?', [req.body.incident_status, req.body.id], (err, result) => {
            if (err) {
                res.json(err);
                res.status(500).json({ status: 'error', error: err });
            }
            res.status(200).send(result)
        });
    });
};

controller.incidentMarkResolved = (req, res) => {
    console.log("deleteIncident-----",req.body);
    var currentDateTime=moment().format("YYYY-MM-DD HH:mm:ss")
    req.body.id=Buffer.from(req.body.id, 'base64').toString();

    req.getConnection((err, connection) => {
        connection.query('update utilityServiceIncidents set incident_status=?,resolution_description=?,resolution_datetime=? where id =?', [req.body.incident_status, req.body.resolution_description, currentDateTime, req.body.id], (err, result) => {
            if (err) {
                res.status(400).send({ err : err })
                return false;
            } else {
                res.status(200).send(result)
            }
            
        });
    });
};

module.exports = controller;
