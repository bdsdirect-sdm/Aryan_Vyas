/*
 * @file: customerController.js
 * @description: It Contain functions for customer CRUD operations
 * @author: Sanjeev
 */
const controller = {};
var md5 = require("md5");
const formidable = require("formidable");
const manageAdminService = require("../services/manageAdminService");
const emailService = require("../services/emailService");
const notification = require("../services/notifications");
var moment = require("moment");
/*
 * @api url : /customer/list?keyword=
 * @description: It Contain functions list the customers and searh with keyword
 *  @type : GET
 * @author: Sanjeev
 */
controller.list = async (req, res) => {
  try {
    var service_provider_id = await manageAdminService.get_provider_of_admin(
      req
    );
  } catch (error) {
    console.log(error);
    res.status(400).send(error);
    return false;
  }
  console.log("service_provider_id==================>", service_provider_id);
  req.getConnection((err, conn) => {
    conn.query(
      'SELECT * FROM customers where (first_name LIKE ? or last_name LIKE ? or  email LIKE ?  or concat(first_name," ",last_name) LIKE ?) and is_deleted=? and customers.utitlity_provider_id = ?  ORDER BY id DESC;',
      [
        "%" + req.query.keyword + "%",
        "%" + req.query.keyword + "%",
        "%" + req.query.keyword + "%",
        "%" + req.query.keyword + "%",
        "false",
        service_provider_id,
      ],
      (err, customer) => {
        if (err) {
          res.status(400).send({ err: err });
        }
        res.status(200).send({ success: true, data: customer });
      }
    );
  });
};
/*
 * @author: Sanjeev
 * @api url : /customer/add
 * @description: This function is used to save the customers
 *  @type : POST
 * @Prameters : first_name, last_name, email, mobile, password,address,city,state,country,zip*/

controller.save = async (req, res) => {
  const file = req.file;
  const data = req.body;
  try {
    var service_provider_id = await manageAdminService.get_provider_of_admin(
      req
    );
  } catch (error) {
    console.log(error);
    res.status(400).send(error);
    return false;
  }
  var paswordForEmail = req.body.password;
  data["utitlity_provider_id"] = service_provider_id;
  const login_user_id = req.headers.decoded.user_id;

  data["is_deleted"] = "false";
  data["is_active"] = "true";
  data["password"] = md5(data.password);
  data["created_at"] = new Date();
  data["modified_at"] = new Date();
  data["created_by"] = login_user_id;

  console.log(req.body);
  req.getConnection((err, connection) => {
    connection.query(
      "select * from customers where email = ?",
      [data.email],
      (err, Newadmin) => {
        if (err) {
          res.status(400).send({ error: err });
        }
        //checking is email already exists....
        if (Newadmin.length == 0) {
          req.getConnection((err, connection) => {
            if (err) {
              res.status(400).send({ error: err });
            }
            connection.query(
              "INSERT INTO customers set ?",
              data,
              (err, Newadmin) => {
                console.log(err);
                if (err) {
                  res.status(400).send({ error: err });
                }
                //sending email in customer save....
                emailService.sendEmail(
                  req,
                  res,
                  1,
                  data.email,
                  paswordForEmail,
                  req.body.first_name + " " + req.body.last_name,
                  null,
                  (finalRes) => {
                    res.status(200).send({ success: true, data: Newadmin });
                  }
                );
              }
            );
          });
        } else {
          res.status(400).send({ error: "email already exists." });
        }
      }
    );
  });
};
/*
 * @author: Sanjeev
 * @api url : /customer/edit/:id
 * @description: This function is used to get single customer information
 *  @type : GET
 * @Prameters : */
controller.edit = (req, res) => {
  var id = req.params.id;
  console.log("-=-=-=-=.safsdfsdfd-=--=", id);
  id = Buffer.from(id, "base64").toString();
  console.log("-=-=-=-=.ssssafsdfsdfd-=--=", id);
  req.getConnection((err, conn) => {
    if (err) {
      res.status(400).send({ error: err });
    }
    conn.query("SELECT * FROM customers WHERE id = ?", [id], (err, rows) => {
      if (err) {
        res.status(400).send({ error: err });
      }
      res.status(200).send({ success: true, data: rows[0] });
    });
  });
};
/*
 * @author: Sanjeev
 * @api url : /customer/update/1
 * @description: This function is used to update the customer with id
 * @Prameters : first_name, last_name, email, mobile, password,address,city,state,country,zip
 *  @type : POST
 */
controller.update = (req, res) => {
  const { id } = req.params;
  data = req.body;
  data["password"] = md5(data.password);
  const newCustomer = req.body;
  req.getConnection((err, conn) => {
    conn.query(
      "UPDATE customers set ? where id = ?",
      [newCustomer, id],
      (err, rows) => {
        if (err) {
          res.status(400).send({ error: err });
        }
        res.status(200).send({ success: true, data: rows });
      }
    );
  });
};
/*
 * @author: Sanjeev
 * @api url : /customer/multi_activeInactive
 * @description: This function is used to delete ,active and deavtivate customer
 * @Prameters : dataId in array e.g [1,2] and action = delete or activate or deactivate
 * @type : POST
 */
controller.multi_activeInactive = (req, res) => {
  console.log("multiUpdate sanjeev-----", req.body.action);
  if (req.body.action == "delete") {
    req.getConnection((err, connection) => {
      connection.query(
        "update customers set is_deleted=? where id IN(?)",
        ["true", req.body.dataId],
        (err, result) => {
          if (err) {
            res.json(err);
            res.status(500).json({ status: "error", error: err });
          }
          res.status(200).send(result);
        }
      );
    });
  } else if (req.body.action == "activate") {
    console.log("deactive---------->", req.body.dataId);
    req.getConnection((err, connection) => {
      if (err) {
        res.status(400).send({ err: err });
        return;
      }
      connection.query(
        "update customers set is_active=? where id IN(?)",
        ["true", req.body.dataId],
        (err, result) => {
          if (err) {
            res.json(err);
            res.status(500).json({ status: "error", error: err });
          }
          res.status(200).send(result);
        }
      );
    });
  } else if (req.body.action == "deactivate") {
    console.log("deactive---------->", req.body.dataId);
    req.getConnection((err, connection) => {
      connection.query(
        "update customers set is_active=? where id IN(?)",
        ["false", req.body.dataId],
        (err, result) => {
          if (err) {
            res.json(err);
            res.status(500).json({ status: "error", error: err });
          }
          res.status(200).send(result);
        }
      );
    });
  }
};
/*
 * @api url : /utilityServiceRequest/list?keyword=
 * @description: It Contain functions list the utilityServiceRequest and searh with keyword
 *  @type : GET
 * @author: Sanjeev
 */
controller.getCustomerRequests = (req, res) => {
  req.getConnection((err, conn) => {
    if (err) {
      res.status(400).send({ err: err });
      return;
    }
    var quer;
    var para;
    const login_user_id = req.headers.decoded.user_id;
    console.log("current user --->", login_user_id);
    quer = `SELECT * FROM utilityServiceRequest 
       where customer_id = ? `;
    para = [login_user_id];
    conn.query(quer, para, (err, customer) => {
      if (err) {
        console.log("===================================>>", err);
        //res.status(400).send({ err : err })
      } else {
        //  console.log('====================outdside===============>>',err)
        res.status(200).send({ success: true, data: customer });
      }
    });
  });
};

/*
 * @author: Sanjeev
 * @api url : /customer/requestService
 * @description: This function is used to save the utilityServiceRequest
 *  @type : POST
 * @Prameters : service_id , date , time ,service_provider_id ,note */
controller.requestService = async (req, res) => {
  console.log("req.headers.decoded.--->", req.headers.decoded);
  const file = req.file;
  var data = req.body;
  let admin_full_name = data.admin_full_name;
  let customer_full_name = data.customer_full_name;
  let customer_email = data.customer_email;
  console.log("==data===", data);
  data.time = moment(data.time, "hh:mm A").format("HH:mm:ss");
  data.etime = moment(data.etime, "hh:mm A").format("HH:mm:ss");
  let admin_email = data.admin_email;
  delete data.admin_full_name;
  delete data.customer_full_name;
  delete data.customer_email;
  delete data.admin_email;
  const login_user_id = req.headers.decoded.user_id;
  data["is_deleted"] = "false";
  data["is_active"] = "true";
  data["created_at"] = new Date();
  data["modified_at"] = new Date();
  data["customer_id"] = login_user_id;
  data["created_by"] = login_user_id;
  data["created_by_user_type"] = "Customer";
  req.getConnection((err, connection) => {
    if (err) {
      res.status(400).send({ error: err });
      return false;
    }
    connection.query(
      'select request_number from utilityServiceRequest where request_number != ""  ORDER BY  request_number DESC limit 1',
      data,
      async (err, r_number) => {
        console.log(err);
        if (err) {
          res.status(400).send({ error: err });
          return false;
        }

        if (r_number.length > 0) {
          var reqNumber = Number(r_number[0].request_number);
          data["request_number"] = Number(reqNumber) + 1;
        } else {
          try {
            const req_number = await manageAdminService.getSettings(req);
            data["request_number"] = req_number.service_request_auto_increment;
          } catch (error) {
            res.status(400).send({ error: err });
            return false;
          }
        }
        connection.query(
          "INSERT INTO utilityServiceRequest set ?",
          data,
          (err, status) => {
            console.log(err);
            if (err) {
              res.status(400).send({ error: err });
              return false;
            }

            console.log(
              " data.utility_provider_id==================>",
              data.utility_provider_id
            );
            notification.save_notification(
              req,
              1,
              data.utility_provider_id,
              "provider",
              login_user_id,
              "customer"
            );

            const utilityProgressServicesData = {
              service_request_id: status.insertId,
              notes: req.body.customer_note,
              created_at: new Date(),
              service_request_status: 1,
              modified_at: new Date(),
              service_provider_id: 0,
              provider_notes: "",
            };
            connection.query(
              "INSERT INTO utilityProgressServices set ?",
              utilityProgressServicesData,
              (err, statuspro) => {
                console.log(err);
                if (err) {
                  res.status(400).send({ error: err });
                  return false;
                }
                let serviceRequestData = {
                  num: data.request_number,
                  date: req.body.date,
                  time: req.body.time,
                  admin_full_name: admin_full_name,
                  customer_full_name: customer_full_name,
                };
                emailService.sendEmail(
                  req,
                  res,
                  2,
                  admin_email,
                  null,
                  null,
                  serviceRequestData,
                  (finalRes) => {
                    let serviceRequestData1 = {
                      num: data.request_number,
                      date: req.body.date,
                      time: req.body.time,
                      admin_full_name: customer_full_name,
                      customer_full_name:
                        "you by " + "<b>" + admin_full_name + "</b>",
                    };
                    emailService.sendEmail(
                      req,
                      res,
                      2,
                      customer_email,
                      null,
                      null,
                      serviceRequestData1,
                      (finalRes1) => {
                        res.status(200).send({ success: true, data: status });
                      }
                    );
                  }
                );
              }
            );
          }
        );
      }
    );
  });
};
/*
 * @api url : /cus/getrequestService
 * @description:
 *
 *  @type : POST
 * @author: Sanjeev
 */
controller.getrequestService = (req, res) => {
  req.getConnection((err, conn) => {
    var quer;
    const login_user_id = req.headers.decoded.user_id;
    quer = `SELECT DISTINCT  *,utilityServiceRequest.id as id,utilityProgressServices.service_request_status, utilities.title as utilityServiceTypes_title,
        subUtilities.title as subUtilityServiceTypes_title,
            utilityStatus.status as taskStatus,utilityStatus.slugCustomer as slugCustomer,
            utilityServiceSubTypes.sub_category_title,utilityServiceSubTypes.hourly_rate as jobType,utilityServiceSubTypes.flat_rate as jobPrice
         FROM utilityServiceRequest 
         
         INNER JOIN utilities on utilities.id = utilityServiceRequest.utility_id 
         
        
         INNER JOIN subUtilities on subUtilities.id = utilityServiceRequest.subUtility_id

       INNER JOIN utilityProviders on utilityProviders.id = utilityServiceRequest.utility_provider_id 
       INNER JOIN utilityServiceTypes on utilityServiceTypes.id = utilityServiceRequest.service_type_id         
       LEFT JOIN utilityProgressServices on utilityProgressServices.service_request_id = utilityServiceRequest.id
       LEFT JOIN utilityStatus on (utilityStatus.id = utilityServiceRequest.current_status)
       LEFT JOIN utilityServiceSubTypes on (utilityServiceSubTypes.id = utilityServiceRequest.utility_service_sub_type_id) 

       where customer_id = ? and subUtilities.utility_id=utilities.id and utilityServiceTypes.utility_id=utilities.id and utilityServiceSubTypes.service_type_id=utilityServiceRequest.service_type_id and utilityServiceSubTypes.service_type_id=utilityServiceTypes.id 
       AND utilityServiceRequest.current_status= utilityProgressServices.service_request_status group by utilityServiceRequest.id order by utilityServiceRequest.id DESC`;
    console.log("===login_user_id=====", login_user_id);
    conn.query(quer, [login_user_id], (err, customer) => {
      console.log("===", err, JSON.stringify(customer));
      if (err) {
        res.status(400).send({ err: err });
        return;
      } else {
        res.status(200).send({ success: true, data: customer });
      }
    });
  });
};

/*
 * @api url : /customer/getutilityProviders
 * @description:
 *  @type : POST
 * @author: Sanjeev
 */
controller.getutilityProviders = (req, res) => {
  req.getConnection((err, conn) => {
    if (err) {
      res.status(400).send({ err: err });
      return;
    }
    var quer;
    var para;
    console.log("----req.body----", req.body);
    // group by utilityServiceTypes.utility_provider_id
    //const login_user_id = req.headers.decoded.user_id
    quer = `SELECT *,utilityServiceTypes.id as id,utilities.title as utilityServiceTypes_title,subUtilities.title as subServiceTypes_title,"" as subTypes,utilityServiceTypes.utility_provider_id as providerId, 0 as rating FROM utilityServiceTypes LEFT JOIN utilities on utilities.id = utilityServiceTypes.utility_id LEFT JOIN subUtilities on utilities.id = subUtilities.utility_id LEFT JOIN utilityProviders on utilityProviders.id = utilityServiceTypes.utility_provider_id where utilities.title = ?  AND (utilityServiceTypes.is_deleted = 'false' AND utilityServiceTypes.is_active = 'true') AND (utilities.is_deleted = 'false' AND utilities.is_active = 'true') AND (utilityProviders.is_deleted = 'false' AND utilityProviders.is_active = 'true') and subUtilities.id=utilityServiceTypes.subUtility_id and (utilityProviders.zip=? or utilityProviders.city like ?) group by utilityServiceTypes.utility_provider_id, utilityServiceTypes.subUtility_id order by rating DESC`;
    para = [
      req.body.service_title,
      req.body.zipcode,
      "%" + req.body.zipcode + "%",
    ];
    conn.query(quer, para, (err, customer) => {
      console.log("err", err);
      if (err) {
        res.status(400).send({ err: err });
        return;
      }

      if (customer.length == 0) {
        console.log("ssssselesseeeeeeeeeeeeeeeee");
        quer = `SELECT *,utilityServiceTypes.id as id,utilities.title as utilityServiceTypes_title,subUtilities.title as subServiceTypes_title,"" as subTypes,utilityServiceTypes.utility_provider_id as providerId, 0 as rating   FROM utilityServiceTypes LEFT JOIN utilities on utilities.id = utilityServiceTypes.utility_id LEFT JOIN utilityProviders on utilityProviders.id = utilityServiceTypes.utility_provider_id LEFT JOIN subUtilities on subUtilities.utility_id=utilities.id where ( subUtilities.title= ? ) and utilityServiceTypes.subUtility_id=subUtilities.id AND (utilityServiceTypes.is_deleted = 'false' AND utilityServiceTypes.is_active = 'true') AND (utilities.is_deleted = 'false' AND utilities.is_active = 'true') AND (subUtilities.is_deleted = 'false' AND subUtilities.is_active = 'true') and (utilityProviders.is_deleted = 'false' AND utilityProviders.is_active = 'true')  and subUtilities.id=utilityServiceTypes.subUtility_id   group by utilityServiceTypes.utility_provider_id, utilityServiceTypes.subUtility_id order by rating DESC`;

        para = [req.body.service_title];
        conn.query(quer, para, (err, customer) => {
          console.log("----sss", err);
          if (err) {
            res.status(400).send({ err: err });
            return;
          }
          res.status(200).send({ success: true, data: customer });
        });
      } else {
        if (customer && customer.length > 0) {
          getSubcategoriesConditionaly(0, customer, conn, (finalRes2) => {
            if (finalRes2 && finalRes2.success) {
              console.log("====daata", JSON.stringify(finalRes2.data));
              res.status(200).send({ success: true, data: finalRes2.data });
            } else {
              res.status(400).send({ success: false, error: finalRes2.error });
            }
          });
        } else {
          res.status(200).send({ success: true, data: customer });
        }
      }
    });
  });
};

function getSubcategoriesConditionaly(i, data, conn, callback) {
  if (i < data.length) {
    conn.query(
      "select * from utilityServiceSubTypes where service_type_id = ?",
      [data[i].id],
      (err, rows) => {
        data[i]["subTypes"] = rows;

        conn.query(
          "select sum(rating) as rating,count(*) as totalServices from utilityServiceProviderRating where utility_provider_id = ?",
          [data[i].providerId],
          (err, rating) => {
            console.log(
              "-----err",
              i,
              err,
              data[i].providerId,
              rating[0].rating,
              rating[0].totalServices
            );
            if (rating[0].rating) {
              data[i]["rating"] = (
                rating[0].rating / rating[0].totalServices
              ).toFixed(2);
            }
            i = i + 1;
            getSubcategoriesConditionaly(i, data, conn, callback);
          }
        );
      }
    );
  } else {
    let finalData = {
      success: true,
      data: data,
    };
    callback(finalData);
  }
}
controller.getutilityProvidersDropDown = (req, res) => {
  req.getConnection((err, conn) => {
    if (err) {
      res.status(400).send({ err: err });
      return;
    }
    var quer;
    var para;
    console.log("--req.boddyyyy-", req.body);
    //const login_user_id = req.headers.decoded.user_id
    // quer = `SELECT utilities.id as utilitiesId,utilities.title as utilitiesTitle,subUtilities.id as subUtilitiesId,subUtilities.title as subUtilitiesTitle from utilities LEFT JOIN subUtilities on utilities.id = subUtilities.utility_id
    //     LEFT JOIN utilityModulesProviders on utilityModulesProviders.utility_id=utilities.id
    //     LEFT JOIN utilityProviders on utilityProviders.id=utilityModulesProviders.utility_provider_id 
    //     LEFT JOIN utilityServiceTypes on utilityServiceTypes.utility_provider_id= utilityProviders.id      
    //     where ( utilities.title like ? ) AND (utilities.is_deleted = 'false' AND utilities.is_active = 'true') and utilityServiceTypes.utility_id=utilities.id AND (subUtilities.is_deleted = 'False' AND subUtilities.is_active = 'True') and utilityProviders.is_active='true' and utilityProviders.is_deleted='false' and utilityServiceTypes.is_active='true' and utilityServiceTypes.is_deleted='false' and ( utilityProviders.city like ? or utilityProviders.zip =?)  group by utilityModulesProviders.utility_id  order by utilities.title,subUtilities.title`;

    quer = `SELECT 
    utilities.id AS utilitiesId, 
    utilities.title AS utilitiesTitle, 
    subUtilities.id AS subUtilitiesId, 
    subUtilities.title AS subUtilitiesTitle
FROM utilities 
LEFT JOIN subUtilities 
    ON utilities.id = subUtilities.utility_id 
LEFT JOIN utilityModulesProviders 
    ON utilityModulesProviders.utility_id = utilities.id
LEFT JOIN utilityProviders 
    ON utilityProviders.id = utilityModulesProviders.utility_provider_id 
LEFT JOIN utilityServiceTypes 
    ON utilityServiceTypes.utility_provider_id = utilityProviders.id 
WHERE 
    utilities.is_deleted = 'false' 
    AND utilities.is_active = 'true' 
ORDER BY utilities.title, subUtilities.title;
`;
    para = [
      "%" + req.body.keyword + "%",
      "%" + req.body.zipcode + "%",
      req.body.zipcode,
    ];
    conn.query(quer, para, (err, customer) => {
      console.log("==getutilityProvidersDropDownss--", err, customer);
      if (err) {
        res.status(400).send({ err: err });
        return;
      } else {
        res.status(200).send({ success: true, data: customer });
      }
    });
  });
};

controller.getUtilityServiceSubTypes = (req, res) => {
  var id = req.params.id;

  req.getConnection((err, conn) => {
    if (err) {
      res.status(400).send({ err: err });
      return;
    }
    conn.query(
      `SELECT * from utilityServiceSubTypes where service_type_id = ? and is_active = 'true'`,
      [id],
      (err, customer) => {
        if (err) {
          res.status(400).send({ err: err });
          return;
        } else {
          res.status(200).send({ success: true, data: customer });
        }
      }
    );
  });
};

controller.cancelServiceRequest = (req, res) => {
  var data = req.body;
  console.log("=-=--=data--=-=", data);
  var requestId = Buffer.from(data.requestId, "base64").toString();

  req.getConnection((err, conn) => {
    if (err) {
      res.status(400).send({ err: err });
      return;
    }
    conn.query(
      `update utilityServiceRequest set current_status=6 where id = ?`,
      [requestId],
      (err, serviceRequest) => {
        var currentdate = moment().format("YYYY-MM-DD HH:mm:ss");
        conn.query(
          "insert into  utilityProgressServices(service_request_id,service_provider_id,service_request_status,notes,created_at,modified_at) values(?,?,?,?,?,?)",
          [
            requestId,
            data.providerId,
            6,
            data.cancelComments,
            currentdate,
            currentdate,
          ],
          (err, insertData) => {
            if (err) {
              callback({ status: "error", error: err });
            }

            console.log(
              "=-=--=cancelServiceRequest--=-=",
              requestId,
              err,
              serviceRequest
            );
            if (err) {
              res.status(400).send({ err: err });
              return;
            } else {
              res.status(200).send({ success: true, data: serviceRequest });
            }
          }
        );
      }
    );
  });
};

controller.getServiceRequestDetails = (req, res) => {
  var id = Buffer.from(req.params.id, "base64").toString();

  console.log("=======getServiceRequestDetails=======", id);
  req.getConnection((err, conn) => {
    let quer = `SELECT utilityServiceRequest.*,utilityServiceRequest.id as requestId,utilityProgressServices.service_request_status, utilities.title as utilityServiceTypes_title,subUtilities.title as subUtilityServiceTypes_title,
         utilityServiceProviderRating.rating,utilityServiceProviderRating.comments,concat(utilityProviders.first_name,' ',utilityProviders.last_name) as provider_name,utilityProviders.email as provider_email,
         utilityProviders.logo,utilityProviders.company_url,utilityProviders.phone,utilityProviders.provider_type,utilityProviders.company_name,
         utilityProgressServices.service_request_status ,
         customers.address,
            utilityStatus.status as taskStatus,utilityStatus.slugCustomer as slugCustomer,
            utilityProgressServices.notes as statusNotes,utilityServiceSubTypes.sub_category_title,utilityServiceSubTypes.hourly_rate as jobType ,utilityServiceSubTypes.flat_rate as optionCost         
            FROM utilityServiceRequest 
          INNER JOIN utilities on utilities.id = utilityServiceRequest.utility_id 
          INNER JOIN subUtilities on subUtilities.id = utilityServiceRequest.subUtility_id
          INNER JOIN utilityProviders on utilityProviders.id = utilityServiceRequest.utility_provider_id 
          INNER JOIN utilityServiceTypes on utilityServiceTypes.id = utilityServiceRequest.service_type_id 
          INNER JOIN utilityServiceSubTypes on utilityServiceSubTypes.service_type_id = utilityServiceTypes.id 
          LEFT JOIN utilityProgressServices on utilityProgressServices.service_request_id = utilityServiceRequest.id
          LEFT JOIN customers on customers.id=utilityServiceRequest.customer_id
          LEFT JOIN utilityServiceProviderRating on utilityServiceProviderRating.service_request_id=utilityServiceRequest.id
          LEFT JOIN utilityStatus on (utilityStatus.id = utilityServiceRequest.current_status)
       where utilityServiceRequest.id = ? and utilityServiceSubTypes.id=utilityServiceRequest.utility_service_sub_type_id and  subUtilities.utility_id=utilities.id AND utilityServiceRequest.current_status = utilityProgressServices.service_request_status`;
    conn.query(quer, [id], (err, details) => {
      if (err) {
        res.status(400).send({ err: err });
      }
      console.log("=--=-=-=", err, details);

      conn.query(
        "select utilityServiceProviders.id,utilityServiceProviders.first_name,utilityServiceProviders.last_name from utilityServiceProviders LEFT JOIN utilityProgressServices on utilityServiceProviders.id=utilityProgressServices.service_provider_id LEFT JOIN utilityServiceRequest on utilityServiceRequest.id= utilityProgressServices.service_request_id where  utilityProgressServices.service_request_status=2 and utilityServiceRequest.id=?",
        [id],
        (err, assignedProvider) => {
          if (err) {
            res.status(400).send({ err: err });
          }
          let dataDetails = {};
          dataDetails.details = details;
          dataDetails.assignedProvider = assignedProvider;
          res.status(200).send({ success: true, data: dataDetails });
        }
      );
    });
  });
};

module.exports = controller;
