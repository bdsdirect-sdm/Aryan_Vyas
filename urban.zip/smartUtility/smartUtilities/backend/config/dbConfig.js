let db = {
  // host: '34.211.31.84',
  host: '35.80.198.152',
  user: 'bhuvinsingla',
  password: 'bhuvinsingla',
  database: 'smartUtilities'

  // user: 'smartUtilities',
  // password: 'SmarTut1l!ty346t',

  // host     : 'localhost',
  // user     : 'root',
  // password : 'ramank2014',
  // database : 'smartUtilities'

  // host: 'localhost',
  // user: 'root',
  // password: 'Smartutilities#$!23',
  // database: 'smartUtilities'

};

module.exports = db;


// 25d55ad283aa400af464c76d713c07ad