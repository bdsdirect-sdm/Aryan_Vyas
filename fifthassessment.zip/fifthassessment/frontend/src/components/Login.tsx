import React from 'react';
import './Login.css';
import { Link, useNavigate, useParams } from 'react-router-dom'; 
import { Formik } from 'formik';
import * as Yup from 'yup';
import axios from 'axios';
import "./Login.css";

const Login: React.FC = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  
  const schema = Yup.object().shape({
    email: Yup.string().required("Email Is Required"),
    password: Yup.string()
      .required("Password Is Required")
      .min(8, "Password must be at least 8 characters"),
  });

  const handleSubmit = async (values: { email: string; password: string }) => {
    try {
      const response = await axios.post('http://localhost:9000/api/login', values);
      const token = response.data.token;
      localStorage.setItem('token', token);
      console.log(response.data.user);
      alert("Login Successfully Done");
      navigate(`/dashboard`);
    } catch (error) {
      console.error("Error Fetching Error", error);
    }
  };

  return (
    <Formik
      validationSchema={schema}
      initialValues={{ email: "", password: "" }}
      onSubmit={handleSubmit}
    >
      {({ values, errors, touched, handleChange, handleBlur, handleSubmit }) => (
        <div className="login">
          <div className="form">
            <form noValidate onSubmit={handleSubmit}>
             <center><span className="form-title">Login</span></center>

              <input
                type="email"
                name="email"
                placeholder="Enter Your Email"
                className="form-control inp_text"
                onChange={handleChange}
                onBlur={handleBlur}
                value={values.email}
              />
              <p className="error-message">{errors.email && touched.email && errors.email}</p>

              <input
                type="password"
                name="password"
                placeholder="Enter Your Password"
                className="form-control"
                onChange={handleChange}
                onBlur={handleBlur}
                value={values.password}
              />
              <p className="error-message">{errors.password && touched.password && errors.password}</p>
              <button type="submit" className="form-button">
                Submit
              </button>
     
            <Link to="/">
              <button className="register-button">
                Click here to Register
              </button>
            </Link>
            </form>
          </div>
         
        </div>
      )}
    </Formik>
  );
};

export default Login;
