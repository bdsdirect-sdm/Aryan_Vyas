import React, { useEffect, useRef, useState } from "react";
import { io, Socket } from "socket.io-client";
import {
  Button,
  Container,
  TextField,
  Typography,
  Box,
  Stack,
} from "@mui/material";
import { useParams } from "react-router-dom";
import axios from "axios";

const Chat: React.FC = () => {
  const { id } = useParams();


  const socket = useRef<Socket | null>(null);

  const [message, setMessage] = useState<string>("");
  const [room, setRoom] = useState<string>("");
  const [socketID, setSocketID] = useState<string>("");
  const [messages, setMessages] = useState<string[]>([]);
  const [roomName, setRoomName] = useState<string>("");
  const [history, setHistory] = useState<any>([]);

  const senderId = localStorage.getItem("userId");
  const receiverId = id;

  useEffect(() => {
    socket.current = io("http://localhost:9000");

    socket.current.on("connect", () => {
      console.log(socket.current?.id);
      setSocketID(socket.current?.id || "");
      console.log("connected", socket.current?.id);
    });

    socket.current.emit("join-room", senderId, receiverId);

    socket.current.emit("get-histories", { senderId, receiverId });

    socket.current.on("histories", (data) => {
      console.log(data,"........................")
      setHistory(data);
    });

    socket.current.on("receive-message", (data: string) => {
      console.log("receive-message", data);
      setMessages((messages) => [...messages, data]);
    });

    return () => {
      socket.current?.disconnect();
    };
  }, [id , messages]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    socket.current?.emit("send-message", { message, senderId, receiverId });

    setMessage("");
  };

  return (
<Container maxWidth="sm" sx={{ backgroundColor: "#f9f9f9", borderRadius: "8px", padding: "20px", boxShadow: "0px 0px 10px rgba(0,0,0,0.1)" }}>

      <Stack spacing={2} sx={{ maxHeight: "400px", overflowY: "auto", marginBottom: "20px" }}>
        {history.map((msg: any, i: any) => (
          <Box key={i} sx={{
            alignSelf: msg.senderId === senderId ? 'flex-end' : 'flex-start',
            backgroundColor: msg.senderId === senderId ? "#d1e7dd" : "#ffffff",
            padding: "10px",
            borderRadius: "10px",
            maxWidth: "70%",
            wordWrap: "break-word",
            display: 'flex',
            justifyContent: msg.senderId === senderId ? 'flex-end' : 'flex-start',
          }}>
            <Typography variant="body1" sx={{ color: "#333" }}>
              {msg.content}
            </Typography>
          </Box>
        ))}
      </Stack>

      <form onSubmit={handleSubmit} style={{ display: 'flex', alignItems: 'center' }}>
        <TextField
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          label="Type a message"
          variant="outlined"
          fullWidth
          sx={{ marginRight: '10px' }}
        />
        <Button type="submit" variant="contained" color="primary" sx={{
          "&:hover": {
            backgroundColor: "#0056b3",
          },
        }}>
          Send
        </Button>
      </form>
    </Container>
  );
};

export default Chat;