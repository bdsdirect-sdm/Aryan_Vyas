import React, { useEffect, useState } from "react";
import axios from "axios";
import { useNavigate } from "react-router-dom";
import { GoBellFill } from "react-icons/go";
import './Dashboard.css';

interface User {
  usertype: string;
  resumeFile: string | null;
  profileImage: string | null;
  id: number;
  firstName: string;
  lastName: string;
  email: string;
  phone: string;
  gender: string;
  userType: string;
  agencyId: number | null;
  status: number | null;
}

const Dashboard: React.FC = () => {
  const [users, setUsers] = useState<User[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);
  const [loggedInUser, setLoggedInUser] = useState<User | null>(null);
  
  const navigate = useNavigate();

  const logout = () => {
    localStorage.removeItem("token");
    navigate("/login");
  };

  useEffect(() => {
    const fetchUsers = async () => {
      try {
        const token = localStorage.getItem("token");
        if (!token) throw new Error("No token found. Please log in.");

        const response = await axios.get(
          "http://localhost:9000/api/dashboard",
          {
            headers: { Authorization: `Bearer ${token}` },
          }
        );
        setUsers(response.data.updatedUserList);
        setLoggedInUser(response.data.loggedInUserDetail);
        localStorage.setItem("userId", response?.data?.loggedInUserDetail?.userId);

      } catch (error) {
        setError("Error fetching users");
      } finally {
        setLoading(false);
      }
    };
    
    fetchUsers();
  }, []);

  const handleStatusChange = async (userId: number, newStatus: string) => {
    try {
      await axios.post("http://localhost:9000/api/update-status", {
        userId,
        status: newStatus,
      });
      setUsers((prevUsers) =>
        prevUsers.map((user) =>
          user.id === userId ? { ...user, status: parseInt(newStatus) } : user
        )
      );
    } catch (error) {
      console.error("Error updating status:", error);
      setError("Error updating user status. Please try again.");
    }
  };

  const handleChatClick = async (userId: number) => {
    try {
      const token = localStorage.getItem("token");
      if (!token) throw new Error("No token found. Please log in.");
  
      const response = await axios.post(
        `http://localhost:9000/api/chat`,
        { userId },
        {
          headers: { Authorization: `Bearer ${token}` },
        }
      );

      if (response.data.success) {
        navigate(`/chat/${userId}`);
      } else {
        console.error("Failed to initiate chat:", response.data.message);
        setError("Error initiating chat. Please try again.");
      }
    } catch (error) {
      console.error("Error initiating chat:", error);
      setError("Error initiating chat. Please try again.");
    }
  };

  const handleNotification = () => {
    navigate("/notification");
  };

  if (loading) return <div>Loading...</div>;
  if (error) return <div className="error">{error}</div>;

  const pendingUsers = users.filter(user => user.status === 0);
  const acceptedUsers = users.filter(user => user.status === 1);
  const rejectedUsers = users.filter(user => user.status === 2);

  return (
    <div className="dashboard-container">
      <h1 className="greeting">
  Welcome:- {loggedInUser ? `${loggedInUser.firstName} ${loggedInUser.lastName}` : "User"}
</h1>
<h1 className="dashboard-title">Your Dashboard</h1>
<GoBellFill onClick={handleNotification} className="notification-icon" />

<h2>Pending</h2>
<div className="user-cards">
  {pendingUsers.map((user) => (
    <UserCard 
      key={user.id} 
      user={user} 
      loggedInUser={loggedInUser}
      handleStatusChange={handleStatusChange}
      handleChatClick={handleChatClick}
    />
  ))}
</div>

      <h2>Accepted</h2>
      <div className="user-cards">
        {acceptedUsers.map((user) => (
          <UserCard 
            key={user.id} 
            user={user} 
            loggedInUser={loggedInUser}
            handleStatusChange={handleStatusChange}
            handleChatClick={handleChatClick}
          />
        ))}
      </div>

      <h2>Rejected</h2>
      <div className="user-cards">
        {rejectedUsers.map((user) => (
          <UserCard 
            key={user.id} 
            user={user} 
            loggedInUser={loggedInUser}
            handleStatusChange={handleStatusChange}
            handleChatClick={handleChatClick}
          />
        ))}
      </div>

      <div className="logout-container">
        <button className="logout-button" onClick={logout}>Logout</button>
      </div>
    </div>
  );
};

interface UserCardProps {
  user: User;
  loggedInUser: User | null;
  handleStatusChange: (userId: number, newStatus: string) => void;
  handleChatClick: (userId: number) => void;
}

const UserCard: React.FC<UserCardProps> = ({ user, loggedInUser, handleStatusChange, handleChatClick }) => (
  <div className="user-card">
    <h2>{`${user.firstName} ${user.lastName}`}</h2>
    <p>Email: {user.email}</p>
    <p>Phone: {user.phone}</p>
    <p>Gender: {user.gender}</p>
    <p>User Type: {user.userType === "1" ? "Job Seeker" : "Agency"}</p>
    {loggedInUser?.userType === "2" && user.profileImage && (
      <img src={user.profileImage} alt="Profile" className="profile-image" />
    )}
    {loggedInUser?.userType === "2" && user.resumeFile && (
      <a href={user.resumeFile} target="_blank" rel="noopener noreferrer" className="resume-link">Download Resume</a>
    )}
    <div className="status-container">
      {loggedInUser?.userType === "2" ? (
        <select
          value={user.status?.toString() || "0"}
          onChange={(e) => handleStatusChange(user.id, e.target.value)}
        >
          <option value="0">Pending</option>
          <option value="1">Accepted</option>
          <option value="2">Rejected</option>
        </select>
      ) : (
        <span>{user.status === 0 ? "Pending" : user.status === 1 ? "Accepted" : "Rejected"}</span>
      )}
    </div>
    <div className="action-container">
      {user.status !== 1 ? (
        <span>No Chat Available</span>
      ) : (
        <button className="chat-button" onClick={() => handleChatClick(user.id)}>Chat</button>
      )}
    </div>
  </div>
);

export default Dashboard;
