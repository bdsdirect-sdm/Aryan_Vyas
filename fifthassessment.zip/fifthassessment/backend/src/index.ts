import express, { Request, Response } from 'express';
import sequelize from '../src/config/db'
import User from './models/User';
import UserRoutes from './routes/UserRoutes';
import { Server, Socket } from 'socket.io';
import cors from 'cors';
import path from 'path';
import ChatRoom from './models/ChatRoom';
import Message from './models/Message';
import http from 'http';

const app = express();
app.use(cors());
const server = http.createServer(app); 
const io = new Server(server, {
  cors: {
    origin: '*',
    methods: ['GET', 'POST']
  }
});

io.on('connection', (socket: Socket) => {
  console.log('A user connected:', socket.id);
   socket.on('join-room', (senderId:number , receiverId:number) => {
    console.log(`User ${senderId} joined room with ${receiverId}`);
    const room:any = [senderId, receiverId]?.sort().join("");
    socket.join(room); 
    console.log(`${socket.id} joined room: ${room} ${senderId} - ${receiverId}`);
  });
  socket.on('send-message', async ({ message , receiverId , senderId }) => {
    const room:any = [senderId, receiverId]?.sort().join("");
    console.log(`Message from ${senderId} to ${receiverId}: ${message}`);    

    try {
        const chatRoom:any = await ChatRoom.create({
          senderId,
          receiverId,
          room,
          content: message,
        });
        console.log('New chat room created:', chatRoom);
        console.log(message)
        socket.to(room).emit("receive-message", message);

      }
      catch (error) {
        console.error('Error saving message to DB:', error);
      }
    
  });

  socket.on('get-histories', async ({ receiverId , senderId }) => {
    const room:any = [senderId, receiverId]?.sort().join(""); 

    try {

        const chatRoom:any = await ChatRoom?.findAll({where:{room}});
        
        socket.emit("histories", chatRoom);
      } 
      catch (error) {
        console.error('Error saving message to DB:', error);
      }
    
  });

});

app.use(express.json());
const PORT = process.env.PORT || 9000;
app.use('/uploads', express.static(path.join(__dirname, '../', 'uploads')));
app.use('/api', UserRoutes);

app.get('/', (req: Request, res: Response) => {
  res.send('Hello, TypeScript with Express!');
});

const startServer = async () => {
  try {
    await sequelize.sync({ alter: true });

    server.listen(PORT, () => {
      console.log(`Server is running on http://localhost:${PORT}`);
    });
  } catch (error) {
    console.error('Unable to connect to the database:', error);
  }
};

startServer();