import sequelize from "../config/db";
import { DataTypes,Model } from "sequelize";

class UserModel extends Model{
    public id!:number;
    public firstName!:string;
    public lastName!:string;
    public email!:string;
    public password!:string;
    public gender!:string;
    public phoneNumber!:string;
    public userType!:number;
    public hobbies!:string;
    public resumeFile!:string | null;
    public profilePicture!:string | null;
    public agencyId!:number | null;
    public status!:boolean | null;
}

UserModel.init(
    {
        firstName:{
            type:DataTypes.STRING,
            allowNull:false,
        },
        lastName:{
            type:DataTypes.STRING,
            allowNull:false,
        },
        email:{
            type:DataTypes.STRING,
            allowNull:false,
            unique:true,
        },
        password:{
            type:DataTypes.STRING,
            allowNull:false,
        },
        gender:{
            type:DataTypes.STRING,
            allowNull:false,
        },
        hobbies:{
            type:DataTypes.STRING,
            allowNull:false,
        },
        phoneNumber:{
            type:DataTypes.STRING,
            allowNull:false,
        },
        userType:{
            type:DataTypes.INTEGER,
            allowNull:false,
        },
        resumeFile:{
            type:DataTypes.STRING,
            allowNull:true,
        },
        profilePicture:{
            type:DataTypes.STRING,
            allowNull:true,
        },
        agencyId:{
            type:DataTypes.STRING,
            allowNull:true,
        },
        status:{
            type:DataTypes.STRING,
            allowNull:true,
            defaultValue:false,
        }
    },
    {
        sequelize,
        modelName:"UserModel",
    }
    );

    UserModel.hasMany(UserModel,{foreignKey:"agencyId",as:"JobSeekers"});
    UserModel.belongsTo(UserModel,{foreignKey:"agencyId",as:"Agency"});
    
    export default UserModel; 