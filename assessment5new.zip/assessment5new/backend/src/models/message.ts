import sequelize from "../config/db";
import { DataTypes,Model } from "sequelize";

class Message extends Model{
    public id!:number;
    public chatRoomId!:number;
    public senderId!:number;
    public messages!:string;
}

Message.init({
    chatRoomId:{
        type:DataTypes.INTEGER,
        allowNull:false,
    },
    senderId:{
        type:DataTypes.INTEGER,
        allowNull:false,
    },
    messages:{
        type:DataTypes.STRING,
        allowNull:false,
    }
},
    {
        sequelize,
        modelName:"Messages"
})