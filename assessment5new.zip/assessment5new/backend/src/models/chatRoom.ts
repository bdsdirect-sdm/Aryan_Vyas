import sequelize from "../config/db";
import { DataTypes,Model } from "sequelize";

class ChatRoom extends Model{
    public id!:number;
    public agencyId!:number;
    public jobSeekerId!:number;
    public roomId!:string
}
ChatRoom.init({
    agencyId:{
        type:DataTypes.INTEGER,
        allowNull:false,
    },
    jobSeekerId:{
        type:DataTypes.INTEGER,
        allowNull:false,
    },
    roomId:{
        type:DataTypes.STRING,
        allowNull:false,
    }
},
{
    sequelize,
    modelName:"ChatRoom",
}
);
export default ChatRoom;