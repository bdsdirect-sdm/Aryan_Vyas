export default function PrivateRoute(){
    return(
        <h1>You Cannot View This In The Browser</h1>
    )
}