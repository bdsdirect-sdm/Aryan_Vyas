export default function ForgetPassword(){
    return(
        <h1>Forget password</h1>
    )
}