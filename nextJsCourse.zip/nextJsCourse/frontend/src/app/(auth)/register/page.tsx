export default function Register(){
    return(
        <h1>Register</h1>
    )
}