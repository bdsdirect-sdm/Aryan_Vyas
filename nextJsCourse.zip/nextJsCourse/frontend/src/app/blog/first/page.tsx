export default function FirstBlog(){
    return (
        <h1>First blog Post</h1>
    )
}