export default function SecondBlog(){
    return (
        <h1>Second blog Post</h1>
    )
}