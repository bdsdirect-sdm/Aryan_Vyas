export default function Blog() {
    return(
        <h1>My Blog</h1>
    )
}