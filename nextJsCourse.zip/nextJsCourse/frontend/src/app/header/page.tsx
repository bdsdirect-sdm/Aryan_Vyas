export default function Header(){
    return (
        <header
        style={{
          backgroundColor: 'lightblue',
          padding: '1rem',
        }}
      >
        <p>Header</p>
      </header>
    );
}