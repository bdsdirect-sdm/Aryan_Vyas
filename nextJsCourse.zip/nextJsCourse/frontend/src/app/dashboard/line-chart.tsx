export default function PieChart(){
    return (
        <h1>Pie Chert</h1>
    )
}