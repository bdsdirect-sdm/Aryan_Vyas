// export default async function ProductDetails({
//     params}:{
//     params: Promise<{ productId: string }>;
//   }) {
//     const  productId  = (await params).productId;
  
//     return <h1>Details About Product {productId}</h1>;
//   }
  
  // export default function ProductDetails({
  //   params}:{
  //   params: { productId: string };
  // }) {
  //   return <h1>Details About Product {params.productId}</h1>;
  // }

  // export default function ProductDetails({params,
  // }:
  //   {
  //     params:{productId:string}
  //   }){
  //     return(
  //       <h1>Details Of Product {params.productId}</h1>
  //     )
  //   }
  
  // export default async function ProductDetails({ params }: { params: Promise<{ productId: string }> }) {
  //   try {
  //     const { productId } = await params;
  //     return <h1>Details Of Product {productId}</h1>;
  //   } catch (error) {
  //     console.error('Error fetching product details:', error);
  //     return <h1>Error fetching product details</h1>;
  //   }
  // }
  
export default async function ProductDetails({params,}:{params:Promise<{productId:string}>}){
  const {productId}=(await params)
return(
<h1>Details Of Product {productId}</h1>
)}
