import { notFound } from "next/navigation";
export default async function ProductRewiew({ params, }: { params: Promise<{ productId: string; reviewId: string }> }) {
    const { productId, reviewId } = await params;
    if (parseInt(reviewId)>1000){
        notFound();
    }
    return (        
        <h1>Review {reviewId} for product {productId}</h1>
    )
}


// export default async function ProductReviews({params, }:{params:Promise<{productId:string}>}){
//     const {productId}=await params
//     return(
//         <>
//         <h1>List Of {productId} Product Rewiew</h1>
//         <ul>
//         <li>Review 1</li>
//         <li>Review 2</li>
//         <li>Review 3</li>
//         <li>Review 4</li>
//         <li>Review 5</li>
//         <li>Review 6</li>
//         </ul>
//         </>
//     )
// }