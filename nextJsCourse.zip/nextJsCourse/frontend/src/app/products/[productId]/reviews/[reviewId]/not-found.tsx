"use client";

export const metadata = {
  title: 'Review Not Found',
  description: 'This review could not be found.',
}

import { usePathname } from "next/navigation";

export default function NotFound() {
  const pathName = usePathname();
  const productId = pathName.split("/")[2];
  const reviewId = pathName.split("/")[4];

  return (
    <html lang="en">
      <body>
        <div>
          <h2>Review {reviewId} Not Found for product {productId}</h2>
        </div>
      </body>
    </html>
  );
}
