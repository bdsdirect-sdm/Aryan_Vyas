export default function Footer(){
    return (
        <footer
          style={{
            backgroundColor: 'ghostwhite',
            padding: '1rem',
          }}
        >
            <p>Footer</p>
        </footer>
      );
    }
    