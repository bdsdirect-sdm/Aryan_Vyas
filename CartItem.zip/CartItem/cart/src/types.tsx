export interface Product {
    id: number;
    name: string;
    image: string;
    price: number;
    category: string;
    stock: number;
    tags: string[];
    rating: number;
    seller: string;
    description: string;
    quantity?: number;  // Optional, for managing quantity in the cart
  }
  