import React, { useState } from 'react';

interface CheckoutProps {
  handleCheckout: (paymentInfo: any) => void;
}

export const Checkout: React.FC<CheckoutProps> = ({ handleCheckout }) => {
  const [cardNumber, setCardNumber] = useState('');
  const [expiryDate, setExpiryDate] = useState('');
  const [cvv, setCvv] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    const paymentInfo = { cardNumber, expiryDate, cvv };
    handleCheckout(paymentInfo);
  };

  return (
    <div>
      <h2>Checkout</h2>
      <form onSubmit={handleSubmit}>
        <label>Card Number</label>
        <input 
          type="text" 
          value={cardNumber} 
          onChange={(e) => setCardNumber(e.target.value)} 
          required
        />

        <label>Expiry Date</label>
        <input 
          type="text" 
          value={expiryDate} 
          onChange={(e) => setExpiryDate(e.target.value)} 
          required
        />

        <label>CVV</label>
        <input 
          type="text" 
          value={cvv} 
          onChange={(e) => setCvv(e.target.value)} 
          required
        />

        <button type="submit" disabled={isSubmitting}>
          {isSubmitting ? 'Processing...' : 'Place Order'}
        </button>
      </form>
    </div>
  );
};
