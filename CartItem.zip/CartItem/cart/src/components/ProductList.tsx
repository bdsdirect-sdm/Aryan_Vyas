import React from 'react';
import './ProductList.css';

interface Product {
  id: string;
  name: string;
  image: string;
  price: number;
  category: string;
  stock: number;
  tags: string[];
  rating: number;
  seller: string;
  description: string;
}

interface ProductListProps {
  products: Product[];
  addToCart: (product: Product) => void;
  goToCart: () => void;
}

export const ProductList: React.FC<ProductListProps> = ({ products, addToCart, goToCart }) => {
  const productsPerPage = 5;
  const [currentPage, setCurrentPage] = React.useState(1);
  const totalPages = Math.ceil(products.length / productsPerPage);

  const handlePageChange = (page: number) => {
    setCurrentPage(page);
  };

  const displayedProducts = products.slice((currentPage - 1) * productsPerPage, currentPage * productsPerPage);

  return (
    <div className="product-list-container">
      <div className="product-list">
        {displayedProducts.map((product) => (
          <div key={product.id} className="product-item">
            <img className="product-image" src={product.image} alt={product.name} />
            <div className="product-info">
              <h3 className="product-name">{product.name}</h3>
              <p className="product-description">{product.description}</p>
              <p className="product-price">${product.price}</p>
              <button className="add-to-cart-btn" onClick={() => addToCart(product)}>
                Add to Cart
              </button>
            </div>
          </div>
        ))}
      </div>

      <div className="pagination">
        {Array.from({ length: totalPages }).map((_, index) => (
          <button
            key={index}
            className={`page-btn ${currentPage === index + 1 ? 'active' : ''}`}
            onClick={() => handlePageChange(index + 1)}
          >
            {index + 1}
          </button>
        ))}
      </div>

      <button className="go-to-cart-btn" onClick={goToCart}>Go to Cart</button>
    </div>
  );
};
