import React from 'react';
import './Cart.css'
interface CartItem {
  id: string;
  name: string;
  price: number;
  quantity: number;
  image: string;
}

interface CartProps {
  cart: CartItem[];
  updateCartQuantity: (id: string, quantity: number) => void;
  removeFromCart: (id: string) => void;
  goToCheckout: () => void;
}

export const Cart: React.FC<CartProps> = ({ cart, updateCartQuantity, removeFromCart, goToCheckout }) => {
  const totalPrice = cart.reduce((acc, item) => acc + item.price * item.quantity, 0);

  return (
    <div>
      <h2>Your Cart</h2>
      {cart.length === 0 ? (
        <p>Your cart is empty</p>
      ) : (
        <div>
          {cart.map(item => (
            <div key={item.id} className="cart-item">
              <img src={item.image} alt={item.name} />
              <h4>{item.name}</h4>
              <p>${item.price}</p>
              <input
                type="number"
                value={item.quantity}
                onChange={(e) => updateCartQuantity(item.id, parseInt(e.target.value))}
                min="1"
              />
              <button onClick={() => removeFromCart(item.id)}>Remove</button>
            </div>
          ))}
          <h3>Total: ${totalPrice}</h3>
          <button onClick={goToCheckout}>Proceed to Checkout</button>
        </div>
      )}
    </div>
  );
};
