import React, { useState } from 'react';
import { ProductList } from './components/ProductList';
import { Cart } from './components/Cart';
import { Checkout } from './components/Checkout';
import { productData } from '../src/data/productData';

const App: React.FC = () => {
  const [cart, setCart] = useState<any[]>([]);
  const [step, setStep] = useState<'productList' | 'cart' | 'checkout' | 'success'>('productList');

  const addToCart = (product: any) => {
    setCart(prevCart => {
      const existingItem = prevCart.find(item => item.id === product.id);
      if (existingItem) {
        return prevCart.map(item =>
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      } else {
        return [...prevCart, { ...product, quantity: 1 }];
      }
    });
  };

  const updateCartQuantity = (id: string, quantity: number) => {
    setCart(prevCart => prevCart.map(item => 
      item.id === id ? { ...item, quantity } : item
    ));
  };

  const removeFromCart = (id: string) => {
    setCart(prevCart => prevCart.filter(item => item.id !== id));
  };

  const handleCheckout = (paymentInfo: any) => {
    // In a real app, you would send paymentInfo to the backend for processing
    setStep('success');
    // Simulate sending email
    setTimeout(() => alert("Success! A confirmation email has been sent."), 500);
  };

  const goToCart = () => setStep('cart');
  const goToCheckout = () => setStep('checkout');

  return (
    <div className="app">
      <h1>Product Catalog</h1>

      {step === 'productList' && (
        <ProductList 
          products={productData} 
          addToCart={addToCart} 
          goToCart={goToCart} 
        />
      )}

      {step === 'cart' && (
        <Cart 
          cart={cart} 
          updateCartQuantity={updateCartQuantity} 
          removeFromCart={removeFromCart} 
          goToCheckout={goToCheckout} 
        />
      )}

      {step === 'checkout' && (
        <Checkout handleCheckout={handleCheckout} />
      )}

      {step === 'success' && (
        <div>
          <h2>Order Placed Successfully!</h2>
          <p>Thank you for your purchase. A confirmation email has been sent to you.</p>
        </div>
      )}
    </div>
  );
}

export default App;
