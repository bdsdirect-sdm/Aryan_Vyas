export const productData = [
    {
      id: '1',
      name: 'Product 1',
      image: '/src/assets/images/product1.jpeg',
      price: 29.99,
      category: 'Category 1',
      stock: 10,
      tags: ['new', 'sale'],
      rating: 4.5,
      seller: 'Seller 1',
      description: 'Description of Product 1'
    },
    {
      id: '2',
      name: 'Product 2',
      image: '/src/assets/images/product2.jpeg',
      price: 39.99,
      category: 'Category 2',
      stock: 5,
      tags: ['featured'],
      rating: 4.8,
      seller: 'Seller 2',
      description: 'Description of Product 2'
    },
    // Add more products as needed

    {
        id: '3',
        name: 'Product 3',
        image: '/src/assets/images/product3.jpeg',
        price: 59.99,
        category: 'Category 3',
        stock: 15,
        tags: ['featured'],
        rating: 3.8,
        seller: 'Seller 1',
        description: 'Description of Product 3'
      },
  ];
  